package com.airtelbank.transaction.strategy;

import com.airtelbank.payments.hub.client.dto.response.DirectPaymentResponse;
import com.airtelbank.payments.hub.client.dto.response.ResponseDTO;
import com.airtelbank.payments.hub.client.service.impl.PHDirectPaymentRequestServiceImpl;
import com.airtelbank.transaction.BaseTest;
import com.airtelbank.transaction.service.impl.TransactionServiceImpl;
import com.airtelbank.transaction.util.LogMasker;
import com.airtelbank.transaction.util.PHClientConfig;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.data.aerospike.core.AerospikeTemplate;
import org.springframework.test.util.ReflectionTestUtils;
import org.testcontainers.shaded.com.google.common.reflect.Reflection;

import javax.xml.ws.Response;

import static org.junit.Assert.*;
import static org.mockito.Mockito.when;

public class SbaTransactionRuleStrategyTest extends BaseTest {
    @InjectMocks
    private SbaTransactionRuleStrategy sbaRule;

    @Mock
    private PHClientConfig pHClientConfig;

    @Mock
    private LogMasker logMasker;

    @Mock
    private TransactionServiceImpl transactionService;

    @Mock
    private PHDirectPaymentRequestServiceImpl pHDirectPaymentRequestServiceImpl;

    @Mock
    private AerospikeTemplate aerospikeTemplate;

    @Before
    public void init(){
        MockitoAnnotations.initMocks(this);
        ReflectionTestUtils.setField(sbaRule, "retailerOnboardingUseCase", "cd");
    }

    @Test
    public void onboardingUsecaseToPaymentHub() {
        when(pHDirectPaymentRequestServiceImpl.paymentRequest(Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(getDirectPaymentResponseDto());
        ResponseDTO<DirectPaymentResponse> response = sbaRule.onboardingUsecaseToPaymentHub(getTransactionRequestDTO(), getHeaderRequestDTO(), "1234");
        assertEquals(0, response.getMeta().getStatus());
    }
}