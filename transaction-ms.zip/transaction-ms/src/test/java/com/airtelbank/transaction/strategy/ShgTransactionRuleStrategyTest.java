package com.airtelbank.transaction.strategy;

import com.airtelbank.payments.hub.client.dto.response.DirectPaymentResponse;
import com.airtelbank.payments.hub.client.dto.response.ResponseDTO;
import com.airtelbank.payments.hub.client.service.impl.PHDirectPaymentRequestServiceImpl;
import com.airtelbank.payments.hub.client.service.impl.PHPaymentEnquiryServiceImpl;
import com.airtelbank.transaction.BaseTest;
import com.airtelbank.transaction.aerospike.entity.TransactionStore;
import com.airtelbank.transaction.constant.Constants;
import com.airtelbank.transaction.dto.balance.EnquiryResponse;
import com.airtelbank.transaction.exception.GenericException;
import com.airtelbank.transaction.model.HeaderRequestDTO;
import com.airtelbank.transaction.model.response.DocumentMgmtStoreResponseDTO;
import com.airtelbank.transaction.service.impl.TransactionServiceHelper;
import com.airtelbank.transaction.service.impl.TransactionServiceImpl;
import com.airtelbank.transaction.util.LogMasker;
import com.airtelbank.transaction.util.RestServiceHelper;
import com.airtelbank.transaction.util.SHGPHClientConfig;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.slf4j.Logger;
import org.springframework.data.aerospike.core.AerospikeTemplate;
import org.springframework.test.util.ReflectionTestUtils;

import java.util.HashMap;

import static org.mockito.Mockito.*;

public class ShgTransactionRuleStrategyTest extends BaseTest {
    @Mock
    Logger log;
    @Mock
    AerospikeTemplate aerospikeTemplate;
    @Mock
    TransactionServiceImpl transactionService;
    @Mock
    PHDirectPaymentRequestServiceImpl pHDirectPaymentRequestServiceImpl;
    @Mock
    PHPaymentEnquiryServiceImpl phPaymentEnquiryService;
    @Mock
    LogMasker logMasker;
    @Mock
    SHGPHClientConfig phClientConfig;
    @Mock
    TransactionServiceHelper serviceHelper;
    @Mock
    RestServiceHelper apiClient;
    @InjectMocks
    ShgTransactionRuleStrategy shgTransactionRuleStrategy;

    @Before
    public void setUp() {
        MockitoAnnotations.initMocks(this);
        ReflectionTestUtils.setField(shgTransactionRuleStrategy,"shgCashWithdrawUseCase","retailer.shg.withdraw");
        ReflectionTestUtils.setField(shgTransactionRuleStrategy,"shgCashDepositUseCase","retailer.shg.deposit");
        ReflectionTestUtils.setField(shgTransactionRuleStrategy,"shgFundTransferUseCase","retailer.shg.internalfundtransfer");
        ReflectionTestUtils.setField(shgTransactionRuleStrategy,"partnerId","4000000001");
    }

    @Test(expected = GenericException.class)
    public void testOnboardingUsecaseToPaymentHub() throws Exception {
        when(transactionService.orderId()).thenReturn("orderIdResponse");
        when(logMasker.patternReplace(anyString())).thenReturn("patternReplaceResponse");

        when(apiClient.hitGetStateByAppId(anyString(), any())).thenReturn(getManageStateAccountResponse());
        when(apiClient.hitBalanceEnquiry(any(), any())).thenReturn(new EnquiryResponse(Integer.valueOf(0), "netBalance", "holdBalance", "availableBalance"));
        HeaderRequestDTO headerRequestDTO = getHeaderRequestDTO();
        headerRequestDTO.setAction(Constants.Action.SHG_CW);
        headerRequestDTO.setFlowKey("SHG-CW20102323");
        ResponseDTO<DirectPaymentResponse> result = shgTransactionRuleStrategy.onboardingUsecaseToPaymentHub(getTransactionRequestDTO(), headerRequestDTO, "500");
                Assert.assertEquals(null, result);
    }

    @Test
    public void testOnboardingUsecaseToPaymentHubCWSuccess() throws Exception {
        when(transactionService.orderId()).thenReturn("orderIdResponse");
        when(logMasker.patternReplace(anyString())).thenReturn("patternReplaceResponse");

        when(apiClient.hitGetDocumentByDocId(Mockito.anyString(),Mockito.any())).thenReturn(getDocumentMgmtResponsDto());
        when(apiClient.hitGetStateByAppId(anyString(), any())).thenReturn(getManageStateAccountResponse());
        when(apiClient.hitBalanceEnquiry(any(), any())).thenReturn(new EnquiryResponse(Integer.valueOf(1), "netBalance", "holdBalance", "1000"));

        when(pHDirectPaymentRequestServiceImpl.paymentRequest(Mockito.anyString(),Mockito.any(),Mockito.anyString())).thenReturn(getDirectPaymentResponseDto());
        HeaderRequestDTO headerRequestDTO = getHeaderRequestDTO();
        headerRequestDTO.setAction(Constants.Action.SHG_CW);
        headerRequestDTO.setFlowKey("SHG-CW20102323");
        headerRequestDTO.setContentid("ABCD");
        ResponseDTO<DirectPaymentResponse> result = shgTransactionRuleStrategy.onboardingUsecaseToPaymentHub(getTransactionRequestDTO(), headerRequestDTO, "500");
        Assert.assertEquals("TXN124", result.getData().getPaymentReqId());
    }

    @Test
    public void testCWPaymentHubEnquiry() throws Exception {
        when(logMasker.patternReplace(anyString())).thenReturn("patternReplaceResponse");
        when(apiClient.hitGetStateByAppId(anyString(), any())).thenReturn(getManageStateAccountResponse());
        when(apiClient.hitGetDocumentByDocId(anyString(), any())).thenReturn(getDocumentMgmtResponsDto());
        TransactionStore transactionStore = new TransactionStore();
        transactionStore.setAppId("ABCD1234");
        when(aerospikeTemplate.findById(Mockito.anyString(), Mockito.any())).thenReturn(transactionStore);
        HeaderRequestDTO headerRequestDTO = getHeaderRequestDTO();
        headerRequestDTO.setAction(Constants.Action.SHG_CW);
        headerRequestDTO.setFlowKey("SHG-CW20102323");
        headerRequestDTO.setContentid("ABCD");

        ResponseDTO<String> result = shgTransactionRuleStrategy.paymentHubEnquiry(getTransactionEnquiryRequest(), headerRequestDTO);
        Assert.assertEquals("7012", result.getMeta().getCode());
    }

    @Test
    public void testCheckDocumentList() throws Exception {
        when(apiClient.hitGetDocumentByDocId(anyString(), any())).thenReturn(new DocumentMgmtStoreResponseDTO("Id", "customerHandleType", "customerHandleNumber", "appType", "appId", "createTime", "updateTime", new HashMap<String, Object>() {{
            put("String", "docAuxiliaryInfo");
        }}));

        HeaderRequestDTO headerRequestDTO = getHeaderRequestDTO();
        headerRequestDTO.setAction(Constants.Action.SHG_CW);
        headerRequestDTO.setFlowKey("SHG-CW20102323");
        headerRequestDTO.setContentid("ABCD");
        boolean result = shgTransactionRuleStrategy.checkDocumentList("docId",headerRequestDTO,"ABCD1234");
        Assert.assertEquals(false, result);
    }

    @Test
    public void testOnboardingUsecaseToPaymentHubCDSuccess() throws Exception {
        when(transactionService.orderId()).thenReturn("999999999");
        when(logMasker.patternReplace(anyString())).thenReturn("******");
        when(apiClient.hitGetStateByAppId(anyString(), any())).thenReturn(getManageStateAccountResponseForCD());
        when(apiClient.hitBalanceEnquiry(any(), any())).thenReturn(new EnquiryResponse(Integer.valueOf(1), "1000", "1000", "1000"));
        when(pHDirectPaymentRequestServiceImpl.paymentRequest(Mockito.anyString(),Mockito.any(),Mockito.anyString())).thenReturn(getDirectPaymentResponseDtoSuccess());
        HeaderRequestDTO headerRequestDTO = getHeaderRequestDTO();
        headerRequestDTO.setAction(Constants.Action.SHG_CD);
        headerRequestDTO.setFlowKey("SHG-CD20102323");
        headerRequestDTO.setContentid("ABCD");
        headerRequestDTO.setCustomerHandleNumber("9567678990");
        ResponseDTO<DirectPaymentResponse> result = shgTransactionRuleStrategy.onboardingUsecaseToPaymentHub(getCDTransactionRequestDTO(), headerRequestDTO, "500");
        Assert.assertEquals("TXN124", result.getData().getPaymentReqId());
    }

    @Test
    public void testOnboardingUsecaseToPaymentHubIFTSuccess() throws Exception {
        when(transactionService.orderId()).thenReturn("999999991");
        when(logMasker.patternReplace(anyString())).thenReturn("******");
        when(apiClient.hitGetStateByAppId(anyString(), any())).thenReturn(getManageStateAccountResponseForIFT());
        when(apiClient.hitGetDocumentByDocId(anyString(), any())).thenReturn(getIFTDocumentMgmtResponsDto());
        when(apiClient.hitBalanceEnquiry(any(), any())).thenReturn(new EnquiryResponse(Integer.valueOf(1), "1000", "1000", "1000"));
        when(pHDirectPaymentRequestServiceImpl.paymentRequest(Mockito.anyString(),Mockito.any(),Mockito.anyString())).thenReturn(getDirectPaymentResponseDtoSuccess());
        HeaderRequestDTO headerRequestDTO = getHeaderRequestDTO();
        headerRequestDTO.setAction(Constants.Action.SHG_IFT);
        headerRequestDTO.setFlowKey("SHG-IFT20102323");
        headerRequestDTO.setContentid("ABCD");
        headerRequestDTO.setCustomerHandleNumber("9567678990");
        ResponseDTO<DirectPaymentResponse> result = shgTransactionRuleStrategy.onboardingUsecaseToPaymentHub(getIFTTransactionRequestDTO(), headerRequestDTO, "500");
        Assert.assertEquals("TXN124", result.getData().getPaymentReqId());
    }

    @Test
    public void testOnboardingUsecaseToPaymentHubIFTSuccessWithV3Calling() throws Exception {
        when(transactionService.orderId()).thenReturn("999999991");
        when(logMasker.patternReplace(anyString())).thenReturn("******");
        when(apiClient.hitGetStateByAppId(anyString(), any())).thenReturn(getManageStateAccountResponseForIFT());
        when(apiClient.hitGetDocumentByDocId(anyString(), any())).thenReturn(getIFTDocumentMgmtResponsDto());
        when(apiClient.hitBalanceEnquiry(any(), any())).thenReturn(new EnquiryResponse(Integer.valueOf(1), "1000", "1000", "1000"));
        when(apiClient.getCustomerV3Profile(Mockito.anyString(),Mockito.anyString(),Mockito.anyString())).thenReturn(getCustomerProfileV3Response());
        when(pHDirectPaymentRequestServiceImpl.paymentRequest(Mockito.anyString(),Mockito.any(),Mockito.anyString())).thenReturn(getDirectPaymentResponseDtoSuccess());
        HeaderRequestDTO headerRequestDTO = getHeaderRequestDTO();
        headerRequestDTO.setAction(Constants.Action.SHG_IFT);
        headerRequestDTO.setFlowKey("SHG-IFT20102323");
        headerRequestDTO.setContentid("ABCD");
        headerRequestDTO.setCustomerHandleNumber("9567678990");
        ResponseDTO<DirectPaymentResponse> result = shgTransactionRuleStrategy.onboardingUsecaseToPaymentHub(getIFTTransactionRequestDTODiffAccount(), headerRequestDTO, "500");
        Assert.assertEquals("TXN124", result.getData().getPaymentReqId());
    }

    @Test
    public void testCDPaymentHubEnquiryNoDataFound() throws Exception {
        when(logMasker.patternReplace(anyString())).thenReturn("*******");
        when(apiClient.hitGetStateByAppId(anyString(), any())).thenReturn(getManageStateAccountResponseForCD());
        TransactionStore transactionStore = new TransactionStore();
        transactionStore.setAppId("ABCD1234");
        when(aerospikeTemplate.findById(Mockito.anyString(), Mockito.any())).thenReturn(transactionStore);
        when(phPaymentEnquiryService.paymentEnquiry(Mockito.anyString(),Mockito.any(),Mockito.anyString())).thenReturn(null);
        HeaderRequestDTO headerRequestDTO = getHeaderRequestDTO();
        headerRequestDTO.setAction(Constants.Action.SHG_CD);
        headerRequestDTO.setFlowKey("SHG-CD20102323");
        headerRequestDTO.setContentid("ABCD");
        headerRequestDTO.setCustomerHandleNumber("9567678990");
        ResponseDTO<String> result = shgTransactionRuleStrategy.paymentHubEnquiry(getTransactionEnquiryRequest(), headerRequestDTO);
        Assert.assertEquals("7012", result.getMeta().getCode());
    }

    @Test
    public void testCDPaymentHubEnquiryFailed() throws Exception {
        when(logMasker.patternReplace(anyString())).thenReturn("*******");
        when(apiClient.hitGetStateByAppId(anyString(), any())).thenReturn(getManageStateAccountResponseForCD());
        TransactionStore transactionStore = new TransactionStore();
        transactionStore.setAppId("ABCD1234");
        when(aerospikeTemplate.findById(Mockito.anyString(), Mockito.any())).thenReturn(transactionStore);
        when(phPaymentEnquiryService.paymentEnquiry(Mockito.anyString(),Mockito.any(),Mockito.anyString())).thenReturn(getPaymentEnquiryResponseFailed("FAILED"));
        HeaderRequestDTO headerRequestDTO = getHeaderRequestDTO();
        headerRequestDTO.setAction(Constants.Action.SHG_CD);
        headerRequestDTO.setFlowKey("SHG-CD20102323");
        headerRequestDTO.setContentid("ABCD");
        headerRequestDTO.setCustomerHandleNumber("9567678990");
        ResponseDTO<String> result = shgTransactionRuleStrategy.paymentHubEnquiry(getTransactionEnquiryRequest(), headerRequestDTO);
        Assert.assertEquals("7010", result.getMeta().getCode());
    }

    @Test
    public void testIFTPaymentHubEnquirySuccess() throws Exception {
        when(logMasker.patternReplace(anyString())).thenReturn("patternReplaceResponse");
        when(apiClient.hitGetStateByAppId(anyString(), any())).thenReturn(getManageStateAccountResponseForIFT());
        when(apiClient.hitGetDocumentByDocId(anyString(), any())).thenReturn(getIFTDocumentMgmtResponsDto());
        TransactionStore transactionStore = new TransactionStore();
        transactionStore.setAppId("ABCD1234");
        when(aerospikeTemplate.findById(Mockito.anyString(), Mockito.any())).thenReturn(transactionStore);
        when(phPaymentEnquiryService.paymentEnquiry(Mockito.anyString(),Mockito.any(),Mockito.anyString())).thenReturn(getPaymentEnquiryResponseSuccess());
        HeaderRequestDTO headerRequestDTO = getHeaderRequestDTO();
        headerRequestDTO.setAction(Constants.Action.SHG_IFT);
        headerRequestDTO.setFlowKey("SHG-IFT20102323");
        headerRequestDTO.setContentid("ABCD");
        headerRequestDTO.setCustomerHandleNumber("9567678990");
        ResponseDTO<String> result = shgTransactionRuleStrategy.paymentHubEnquiry(getTransactionEnquiryRequest(), headerRequestDTO);
        Assert.assertEquals("000", result.getMeta().getCode());
    }



    @Test
    public void testIFTPaymentHubEnquiryFailedOrTimeOut() throws Exception {
        when(logMasker.patternReplace(anyString())).thenReturn("patternReplaceResponse");
        when(apiClient.hitGetStateByAppId(anyString(), any())).thenReturn(getManageStateAccountResponseForIFT());
        when(apiClient.hitGetDocumentByDocId(anyString(), any())).thenReturn(getIFTDocumentMgmtResponsDto());
        TransactionStore transactionStore = new TransactionStore();
        transactionStore.setAppId("ABCD1234");
        when(aerospikeTemplate.findById(Mockito.anyString(), Mockito.any())).thenReturn(transactionStore);
        when(phPaymentEnquiryService.paymentEnquiry(Mockito.anyString(),Mockito.any(),Mockito.anyString())).thenReturn(getPaymentEnquiryResponseFailed("TIMEOUT"));
        HeaderRequestDTO headerRequestDTO = getHeaderRequestDTO();
        headerRequestDTO.setAction(Constants.Action.SHG_IFT);
        headerRequestDTO.setFlowKey("SHG-IFT20102323");
        headerRequestDTO.setContentid("ABCD");
        headerRequestDTO.setCustomerHandleNumber("9567678990");
        ResponseDTO<String> result = shgTransactionRuleStrategy.paymentHubEnquiry(getTransactionEnquiryRequest(), headerRequestDTO);
        Assert.assertEquals("7011", result.getMeta().getCode());
    }

    @Test(expected = GenericException.class)
    public void testCDPaymentHubEnquiryNoAppIdFound() throws Exception {
        when(logMasker.patternReplace(anyString())).thenReturn("*******");
        when(apiClient.hitGetStateByAppId(anyString(), any())).thenReturn(getManageStateAccountResponseForCD());
        when(aerospikeTemplate.findById(Mockito.anyString(), Mockito.any())).thenReturn(null);
        HeaderRequestDTO headerRequestDTO = getHeaderRequestDTO();
        headerRequestDTO.setAction(Constants.Action.SHG_CD);
        headerRequestDTO.setFlowKey("SHG-CD20102323");
        headerRequestDTO.setContentid("ABCD");
        headerRequestDTO.setCustomerHandleNumber("9567678990");
        shgTransactionRuleStrategy.paymentHubEnquiry(getTransactionEnquiryRequest(), headerRequestDTO);
    }

    @Test(expected = GenericException.class)
    public void testIFTPaymentHubEnquiryMismatchAppId() throws Exception {
        when(logMasker.patternReplace(anyString())).thenReturn("patternReplaceResponse");
        when(apiClient.hitGetStateByAppId(anyString(), any())).thenReturn(getManageStateAccountResponseForIFT());
        when(apiClient.hitGetDocumentByDocId(anyString(), any())).thenReturn(getIFTDocumentMgmtResponsDto());
        TransactionStore transactionStore = new TransactionStore();
        transactionStore.setAppId("ABCD12311");
        when(aerospikeTemplate.findById(Mockito.anyString(), Mockito.any())).thenReturn(transactionStore);
         HeaderRequestDTO headerRequestDTO = getHeaderRequestDTO();
        headerRequestDTO.setAction(Constants.Action.SHG_IFT);
        headerRequestDTO.setFlowKey("SHG-IFT20102323");
        headerRequestDTO.setContentid("ABCD");
        headerRequestDTO.setCustomerHandleNumber("9567678990");
        shgTransactionRuleStrategy.paymentHubEnquiry(getTransactionEnquiryRequest(), headerRequestDTO);
    }

}

