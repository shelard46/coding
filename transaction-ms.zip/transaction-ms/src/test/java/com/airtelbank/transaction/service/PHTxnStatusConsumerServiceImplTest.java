
package com.airtelbank.transaction.service;

import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.doNothing;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.data.aerospike.core.AerospikeTemplate;
import org.springframework.test.util.ReflectionTestUtils;

import com.airtelbank.payments.hub.client.dto.kafka.FulfilmentStatus;
import com.airtelbank.payments.hub.client.dto.kafka.PaymentStatus;
import com.airtelbank.payments.hub.client.model.FulfilmentDetails;
import com.airtelbank.payments.hub.client.model.TransactionDetails;
import com.airtelbank.payments.hub.client.service.impl.PHServiceFulfilmentProducerServiceImpl;
import com.airtelbank.transaction.BaseTest;
import com.airtelbank.transaction.aerospike.entity.TransactionStore;
import com.airtelbank.transaction.constant.Constants;
import com.airtelbank.transaction.producer.CustomerRewardProducer;
import com.airtelbank.transaction.producer.Producer;
import com.airtelbank.transaction.service.impl.PHTxnStatusConsumerServiceImpl;
import com.airtelbank.transaction.util.PHClientConfig;

public class PHTxnStatusConsumerServiceImplTest extends BaseTest {

	@InjectMocks
	private PHTxnStatusConsumerServiceImpl phTxnStatusConsumerServiceImpl;

	@Mock
	private AerospikeTemplate aerospikeTemplate;
	
	@Mock
	private PHClientConfig pHClientConfig;
	

	@Mock
	private PHServiceFulfilmentProducerServiceImpl pHDirectPaymentRequestServiceImpl;
	
	@Mock
	private Producer producer;
	
	@Mock
	private CustomerRewardProducer customerRewardProducer;

	@Before
	public void init() {
		ReflectionTestUtils.setField(phTxnStatusConsumerServiceImpl, "retailerOnboardingUseCase", "retailer.onboarding.sba");
		ReflectionTestUtils.setField(phTxnStatusConsumerServiceImpl, "aerospikeRetryCount", 3);		
	}
	
	@Test
	public void txnStatusTest() {
		PaymentStatus paymentStatus = new PaymentStatus();
		List<FulfilmentDetails> fulfilmentDetails = new ArrayList<>();
		FulfilmentStatus fulfilmentStatus = FulfilmentStatus.builder().useCase("SBA")
				.orderId("123").paymentReqId("3145")
				.fulfilmentDetails(fulfilmentDetails).build();
		paymentStatus.setPaymentReqId("2342424");
		List<TransactionDetails> debitDetails = new ArrayList();
		TransactionDetails trans = new TransactionDetails();
		trans.setAccountNumber("232424");
		trans.setStatus(Constants.SUCCESS);
		debitDetails.add(trans);
		paymentStatus.setDebitDetails(debitDetails);
		TransactionStore transaction = new TransactionStore();
		Mockito.when(aerospikeTemplate.findById(Mockito.anyString(), Mockito.any())).thenReturn(transaction);
		doNothing().when(pHDirectPaymentRequestServiceImpl).sendFulfilmentStatus(Mockito.any(), Mockito.any());
		doNothing().when(pHClientConfig).fullFillmentInit(Mockito.any());
		doNothing().when(customerRewardProducer).produceRewardsStatus(Mockito.any());
		phTxnStatusConsumerServiceImpl.txnStatus(paymentStatus);
	}
	
	@Test
	public void txnStatusWhenDebitstatusFailedTest() {
		PaymentStatus paymentStatus = new PaymentStatus();
		List<FulfilmentDetails> fulfilmentDetails = new ArrayList<>();
		FulfilmentStatus fulfilmentStatus = FulfilmentStatus.builder().useCase("SBA")
				.orderId("123").paymentReqId("3145")
				.fulfilmentDetails(fulfilmentDetails).build();
		paymentStatus.setPaymentReqId("2342424");
		List<TransactionDetails> debitDetails = new ArrayList();
		TransactionDetails trans = new TransactionDetails();
		trans.setAccountNumber("232424");
		trans.setStatus(Constants.FAILED);
		assertNotNull(trans);
		debitDetails.add(trans);
		paymentStatus.setDebitDetails(debitDetails);
		phTxnStatusConsumerServiceImpl.txnStatus(paymentStatus);
	}
	
	@Test
	public void txnStatusWhenPaymentstatusNullTest1() {
		TransactionDetails trans = new TransactionDetails();
		trans.setAccountNumber("232424");
		assertNotNull(trans);
		phTxnStatusConsumerServiceImpl.txnStatus(null);
	}

}
