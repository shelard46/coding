
package com.airtelbank.transaction;

import java.util.*;

import com.airtelbank.payments.hub.client.dto.response.DirectPaymentResponse;
import com.airtelbank.payments.hub.client.dto.response.PaymentEnquiryResponse;
import com.airtelbank.payments.hub.client.model.TransactionDetails;
import com.airtelbank.transaction.aerospike.entity.TransactionStore;
import com.airtelbank.transaction.constant.Constants;
import com.airtelbank.transaction.dto.application.ManageAccountStateResponse;
import com.airtelbank.transaction.dto.application.PaymentAuxInfo;
import com.airtelbank.transaction.model.*;
import com.airtelbank.transaction.model.response.AuaAuxResponseDTO;
import com.airtelbank.transaction.model.response.AuaAuxResponses;
import com.airtelbank.transaction.model.response.DocumentMgmtStoreResponseDTO;
import com.airtelbank.transaction.model.response.ShgPaymentTrx;
import org.junit.runner.RunWith;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

import com.airtelbank.payments.hub.models.customerprofile.Account;
import com.airtelbank.transaction.dto.cbs.CBSFCIDetailsRequest;
import com.airtelbank.transaction.dto.customerProfile.CustomerProfileDTO;

import static com.airtelbank.transaction.constant.Constants.AUA_VERIFICATION_SUCCESS;


@ActiveProfiles("test")

@RunWith(SpringRunner.class)
public abstract class BaseTest {


	public TransactionRequestDTO getTransactionRequestDepositDTO() {
		TransactionRequestDTO transaction = new TransactionRequestDTO();
		transaction.setAccountNumber("1232323");
		transaction.setUseCase("retailer.onboarding.sba");
		transaction.setRetailCustID("12442424");
		transaction.setRetailCustID("4222323");
		transaction.setRetailMobileNumber("9999999999");
		transaction.setAppId("12344334");
		return transaction;
	}

	public TransactionRequestDTO getTransactionRequestDepositDTO1() {
		TransactionRequestDTO transaction = new TransactionRequestDTO();
		transaction.setAccountNumber("1232323");
		transaction.setUseCase("retailer.onboarding.sba");
		transaction.setRetailCustID("12442424");
		transaction.setRetailCustID("4222323");
		transaction.setRetailMobileNumber("9999999999");
		transaction.setAppId(null);
		return transaction;
	}




	

	public TransactionRequestDTO getTransactionRequestDTO() {
		TransactionRequestDTO transactionRequestDTO = new TransactionRequestDTO();
		transactionRequestDTO.setUseCase("withdraw");
		transactionRequestDTO.setAppId("ABCD1234");
		AccountDetails accountDetails = new AccountDetails();
		accountDetails.setAccountNo("ABCD1234");
		transactionRequestDTO.setSourceDetails(accountDetails);
		transactionRequestDTO.setTargetDetails(accountDetails);
		transactionRequestDTO.setAmount("500");
		return transactionRequestDTO;
	}

	public RequestDTO<CBSFCIDetailsRequest> getFciDetails()
	{
		RequestDTO<CBSFCIDetailsRequest> request=new RequestDTO<CBSFCIDetailsRequest>();
		MetaV3 meta=new MetaV3();
		meta.setAppType("SBA");
		meta.setAppId("234552");
		CBSFCIDetailsRequest fciDetail=new CBSFCIDetailsRequest();
		fciDetail.setAccountType("bharosa");
		fciDetail.setAfc("123");
		fciDetail.setFci("324");
		fciDetail.setMobileNumber("3456567678");
		fciDetail.setSubscription("3455");
		fciDetail.setTotalamount("4545");
		request.setData(fciDetail);
		request.setMeta(meta);
		return request;
	}
	
	public RequestDTO<CBSFCIDetailsRequest> getFciDetails1()
	{
		RequestDTO<CBSFCIDetailsRequest> request=new RequestDTO<CBSFCIDetailsRequest>();
		MetaV3 meta=new MetaV3();
		meta.setAppType("SBA");
		meta.setAppId("234552");
		CBSFCIDetailsRequest fciDetail=new CBSFCIDetailsRequest();
		fciDetail.setAccountType("bharosa");
		fciDetail.setAfc("123");
		fciDetail.setFci("1000");
		fciDetail.setCircle("NE");
		fciDetail.setMobileNumber("3456567678");
		fciDetail.setRetailerMobileNumber("8928383222");
		fciDetail.setSubscription("3455");
		fciDetail.setTotalamount("4545");
		request.setData(fciDetail);
		request.setMeta(meta);
		return request;
	}

	public CustomerProfileDTO getCustomerProfileDto() {
		CustomerProfileDTO customerProfile = new CustomerProfileDTO();
		Map<String, Account> customerProfileAccount = new HashMap<String, Account>();
		customerProfileAccount.put("lky", new Account());
		customerProfile.setId("1");
		customerProfile.setOnboardChannel("channel");
		customerProfile.setFciAmount("10000");
		customerProfile.setCreationDate("2021-05-02");
		customerProfile.setAccounts(customerProfileAccount);
		return customerProfile;
	}
	
	public <T> ResponseEntity<ResponseDTO<T>> getResponseEntitySuccess(ResponseDTO<T> body) {
		ResponseEntity<ResponseDTO<T>> responseEntitySuccess = new ResponseEntity<ResponseDTO<T>>(body, HttpStatus.OK);
		return responseEntitySuccess;
	}
	
	public <T> ResponseDTO<T> getResponseDTO(T data) {
		ResponseDTO<T> response = new ResponseDTO<T>();
		Meta meta = new Meta();
		meta.setStatus(0);
		meta.setDescription("success");
		response.setMeta(meta);
		response.setData(data);
		return response;
	}
	
	public HeaderRequestDTO getHeaderRequestDTO() {
		HeaderRequestDTO headerRequestDTO = new HeaderRequestDTO();
		headerRequestDTO.setChannel("ANDROID");
		headerRequestDTO.setContentid("AN3565432");
		headerRequestDTO.setCustomerHandleNumber("9900121002");
		headerRequestDTO.setAppType(Constants.AppType.SHGTRX);
		return headerRequestDTO;
	}

	public ManageAccountStateResponse getManageStateAccountResponse(){
		ManageAccountStateResponse manageAccountStateResponse = new ManageAccountStateResponse();
		manageAccountStateResponse.setAccountNo("ABCD1234");
		manageAccountStateResponse.setCustomerHandleNo("9900121002");
		return manageAccountStateResponse;
	}
	public com.airtelbank.payments.hub.client.dto.response.ResponseDTO<DirectPaymentResponse> getDirectPaymentResponseDto(){
		com.airtelbank.payments.hub.client.dto.response.ResponseDTO<DirectPaymentResponse> responseDTO = new com.airtelbank.payments.hub.client.dto.response.ResponseDTO<>();
		DirectPaymentResponse directPaymentResponse = new DirectPaymentResponse();
		directPaymentResponse.setPaymentReqId("TXN124");
		responseDTO.setData(directPaymentResponse);
		com.airtelbank.payments.hub.client.dto.response.Meta meta = new com.airtelbank.payments.hub.client.dto.response.Meta();
		meta.setStatus(0);
		meta.setCode("0");
		meta.setDescription("success");
		responseDTO.setMeta(meta);
		return responseDTO;
	}

	public TransactionEnquiryRequest getTransactionEnquiryRequest(){
		TransactionEnquiryRequest transactionEnquiryRequest = new TransactionEnquiryRequest();
		transactionEnquiryRequest.setAppId("ABCD1234");
		transactionEnquiryRequest.setPrId("PR1234");
		return transactionEnquiryRequest;
	}

	public DocumentMgmtStoreResponseDTO getDocumentMgmtResponsDto(){
		DocumentMgmtStoreResponseDTO documentMgmtStoreResponseDTO = new DocumentMgmtStoreResponseDTO();
		documentMgmtStoreResponseDTO.setAppId("ABCD1234");
		documentMgmtStoreResponseDTO.setCustomerHandleNumber("9900121002");

		AuaAuxResponseDTO auaAuxResponseDTO = new AuaAuxResponseDTO();
		AuaAuxResponses auaAuxResponses = new AuaAuxResponses();
		auaAuxResponses.setDocNum("1234");
		auaAuxResponses.setDocStatus(AUA_VERIFICATION_SUCCESS);
		auaAuxResponses.setDocType("AADHAR");
		AuaAuxResponses auaAuxResponses1 = new AuaAuxResponses();
		auaAuxResponses1.setDocNum("1235");
		auaAuxResponses1.setDocStatus(AUA_VERIFICATION_SUCCESS);
		auaAuxResponses1.setDocType("AADHAR");
		List<AuaAuxResponses> auaAuxResponsesList = new ArrayList<>();
		auaAuxResponsesList.add(auaAuxResponses);
		auaAuxResponsesList.add(auaAuxResponses1);
		auaAuxResponseDTO.setAuaAuxResponses(auaAuxResponsesList);
		documentMgmtStoreResponseDTO.setDocAuxiliaryInfo(getAuxInfoMap("AUA_DETAILS",auaAuxResponseDTO));
		return documentMgmtStoreResponseDTO;
	}

	public HashMap<String, Object> getAuxInfoMap(String mgmtAuxiliaryInfo, Object object) {
		HashMap<String, Object> auxInfoMap = new HashMap<>();
		auxInfoMap.put(mgmtAuxiliaryInfo, object);
		return auxInfoMap;
	}

	public ManageAccountStateResponse getManageStateAccountResponseForIFT(){
		ManageAccountStateResponse manageAccountStateResponse = new ManageAccountStateResponse();
		manageAccountStateResponse.setAccountNo("011019098");
		manageAccountStateResponse.setCustomerHandleNo("9567678990");
		return manageAccountStateResponse;
	}

	public TransactionRequestDTO getCDTransactionRequestDTO() {
		TransactionRequestDTO transactionRequestDTO = new TransactionRequestDTO();
		transactionRequestDTO.setAppId("ABCD1234");
		AccountDetails targetAccount = new AccountDetails();
		targetAccount.setAccountNo("011019098");
		targetAccount.setMobileNo("9876589897");

		AccountDetails sourceAccountDetails = new AccountDetails();
		sourceAccountDetails.setAccountNo("1000100119");
		sourceAccountDetails.setMobileNo("9999999999");
		transactionRequestDTO.setSourceDetails(sourceAccountDetails);
		transactionRequestDTO.setTargetDetails(targetAccount);
		transactionRequestDTO.setAmount("50");
		return transactionRequestDTO;
	}


	public com.airtelbank.payments.hub.client.dto.response.ResponseDTO<DirectPaymentResponse> getDirectPaymentResponseDtoSuccess(){
		com.airtelbank.payments.hub.client.dto.response.ResponseDTO<DirectPaymentResponse> responseDTO = new com.airtelbank.payments.hub.client.dto.response.ResponseDTO<>();
		DirectPaymentResponse directPaymentResponse = new DirectPaymentResponse();
		directPaymentResponse.setPaymentReqId("TXN124");
		responseDTO.setData(directPaymentResponse);
		com.airtelbank.payments.hub.client.dto.response.Meta meta= new com.airtelbank.payments.hub.client.dto.response.Meta();
		meta.setDescription("SUCCESS");
		meta.setCode("0");
		meta.setStatus(0);
		responseDTO.setMeta(meta);
		return responseDTO;
	}

	public ManageAccountStateResponse getManageStateAccountResponseForCD(){
		ManageAccountStateResponse manageAccountStateResponse = new ManageAccountStateResponse();
		manageAccountStateResponse.setAccountNo("011019098");
		manageAccountStateResponse.setCustomerHandleNo("9567678990");
		PaymentAuxInfo paymentAuxInfo=new PaymentAuxInfo();
		ShgPaymentTrx shgPaymentTrx=new ShgPaymentTrx();
		shgPaymentTrx.setRetailerAccountNo("1000100119");
		shgPaymentTrx.setRetailerMobile("9999999999");
		shgPaymentTrx.setFlowKey("SHG-CD20102323");
		shgPaymentTrx.setMpinResponse("SUCCESS");
		List<ShgPaymentTrx> shgPaymentTrxList=new ArrayList<>();
		shgPaymentTrxList.add(shgPaymentTrx);
		paymentAuxInfo.setShgPaymentTrxList(shgPaymentTrxList);
		manageAccountStateResponse.setPaymentAuxInfo(paymentAuxInfo);
		return manageAccountStateResponse;
	}

	public TransactionRequestDTO getIFTTransactionRequestDTO() {
		TransactionRequestDTO transactionRequestDTO = new TransactionRequestDTO();
		transactionRequestDTO.setAppId("ABCD1234");
		AccountDetails sourceAccountDetails = new AccountDetails();
		sourceAccountDetails.setAccountNo("011019098");
		sourceAccountDetails.setMobileNo("9876589897");

		AccountDetails targetAccountDetails = new AccountDetails();
		targetAccountDetails.setAccountNo("9999999999");
		targetAccountDetails.setMobileNo("9999999999");
		transactionRequestDTO.setSourceDetails(sourceAccountDetails);
		transactionRequestDTO.setTargetDetails(targetAccountDetails);
		transactionRequestDTO.setAmount("50");
		return transactionRequestDTO;
	}

	public DocumentMgmtStoreResponseDTO getIFTDocumentMgmtResponsDto(){
		DocumentMgmtStoreResponseDTO documentMgmtStoreResponseDTO = new DocumentMgmtStoreResponseDTO();
		documentMgmtStoreResponseDTO.setAppId("ABCD1234");
		documentMgmtStoreResponseDTO.setCustomerHandleNumber("9567678990");

		AuaAuxResponseDTO auaAuxResponseDTO = new AuaAuxResponseDTO();
		AuaAuxResponses auaAuxResponses = new AuaAuxResponses();
		auaAuxResponses.setDocNum("1234");
		auaAuxResponses.setDocStatus(AUA_VERIFICATION_SUCCESS);
		auaAuxResponses.setDocType("AADHAR");
		AuaAuxResponses auaAuxResponses1 = new AuaAuxResponses();
		auaAuxResponses1.setDocNum("1235");
		auaAuxResponses1.setDocStatus(AUA_VERIFICATION_SUCCESS);
		auaAuxResponses1.setDocType("AADHAR");
		List<AuaAuxResponses> auaAuxResponsesList = new ArrayList<>();
		auaAuxResponsesList.add(auaAuxResponses);
		auaAuxResponsesList.add(auaAuxResponses1);
		auaAuxResponseDTO.setAuaAuxResponses(auaAuxResponsesList);
		documentMgmtStoreResponseDTO.setDocAuxiliaryInfo(getAuxInfoMap("AUA_DETAILS",auaAuxResponseDTO));
		return documentMgmtStoreResponseDTO;
	}

	public com.airtelbank.payments.hub.client.dto.response.ResponseDTO<PaymentEnquiryResponse> getPaymentEnquiryResponseSuccess() {
		com.airtelbank.payments.hub.client.dto.response.ResponseDTO<PaymentEnquiryResponse> responseDTO=new com.airtelbank.payments.hub.client.dto.response.ResponseDTO<>();
		PaymentEnquiryResponse paymentEnquiryResponse=new PaymentEnquiryResponse();
		TransactionDetails transactionDetails=new TransactionDetails();
		transactionDetails.setStatus("SUCCESS");
		transactionDetails.setTransactionId("PH11111");
		List<TransactionDetails> details=new ArrayList<>();
		details.add(transactionDetails);
		paymentEnquiryResponse.setDebitDetails(details);
		com.airtelbank.payments.hub.client.dto.response.Meta meta= new com.airtelbank.payments.hub.client.dto.response.Meta();
		meta.setDescription("SUCCESS");
		meta.setCode("0");
		meta.setStatus(0);
		responseDTO.setData(paymentEnquiryResponse);
		responseDTO.setMeta(meta);
		return responseDTO;
	}


	public com.airtelbank.payments.hub.client.dto.response.ResponseDTO<PaymentEnquiryResponse> getPaymentEnquiryResponseFailed(String status) {
		com.airtelbank.payments.hub.client.dto.response.ResponseDTO<PaymentEnquiryResponse> responseDTO=new com.airtelbank.payments.hub.client.dto.response.ResponseDTO<>();
		PaymentEnquiryResponse paymentEnquiryResponse=new PaymentEnquiryResponse();
		TransactionDetails transactionDetails=new TransactionDetails();
		transactionDetails.setStatus(status);
		List<TransactionDetails> details=new ArrayList<>();
		details.add(transactionDetails);
		paymentEnquiryResponse.setDebitDetails(details);
		com.airtelbank.payments.hub.client.dto.response.Meta meta= new com.airtelbank.payments.hub.client.dto.response.Meta();
		meta.setDescription("SUCCESS");
		meta.setCode("0");
		meta.setStatus(0);
		responseDTO.setData(paymentEnquiryResponse);
		responseDTO.setMeta(meta);
		return responseDTO;
	}

	public CustomerProfileDTO getCustomerProfileV3Response() {
		Account account=new Account();
		account.setNumber("9087190871");
		Map<String,Account> map=new HashMap<>();
		map.put("sba",account);
		CustomerProfileDTO customerProfileDTO=new CustomerProfileDTO();
		customerProfileDTO.setAccounts(map);
		return customerProfileDTO;
	}

	public TransactionRequestDTO getIFTTransactionRequestDTODiffAccount() {
		TransactionRequestDTO transactionRequestDTO = new TransactionRequestDTO();
		transactionRequestDTO.setAppId("ABCD1234");
		AccountDetails sourceAccountDetails = new AccountDetails();
		sourceAccountDetails.setAccountNo("011019098");
		sourceAccountDetails.setMobileNo("9876589897");

		AccountDetails targetAccountDetails = new AccountDetails();
		targetAccountDetails.setAccountNo("9087190871");
		targetAccountDetails.setMobileNo("9999999999");
		transactionRequestDTO.setSourceDetails(sourceAccountDetails);
		transactionRequestDTO.setTargetDetails(targetAccountDetails);
		transactionRequestDTO.setAmount("50");
		return transactionRequestDTO;
	}

	public TransactionStore populateTransactionStore(){
		TransactionStore transactionStore = new TransactionStore();
		transactionStore.setStatus("success");
		transactionStore.setAppId("123456");
		transactionStore.setAppType(Constants.SHG);
		transactionStore.setOrderId("111111");
		return transactionStore;
	}

	public PaymentEnquiryResponse populatePaymentEnquiryResponse(){
		return PaymentEnquiryResponse.builder()
				.paymentReqId("1234567")
				.channel("RAPP")
				.debitDetails(Arrays.asList(TransactionDetails.builder()
						.accountNumber("1234667").status("success").build()))
				.build();
	}
}
