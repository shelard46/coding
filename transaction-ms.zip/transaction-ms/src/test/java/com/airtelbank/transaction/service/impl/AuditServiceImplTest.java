package com.airtelbank.transaction.service.impl;

import com.airtelbank.transaction.BaseTest;
import com.airtelbank.transaction.model.AuditLog;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;

import static org.junit.Assert.assertNotNull;

public class AuditServiceImplTest extends BaseTest {
	
	@InjectMocks
	private AuditServiceImpl auditServiceImpl;
	
	@Before
	public void setUp() throws Exception {
		MockitoAnnotations.initMocks(this);
	}
	
	@Test
	public void createRecordForAuditLogsuceessTest() {
				AuditLog auditLog=new AuditLog();
		auditServiceImpl.createRecordForAuditLog(null, "76328", "76328", "76328", null, null, null, auditLog);
		assertNotNull(auditLog);
	}




}

