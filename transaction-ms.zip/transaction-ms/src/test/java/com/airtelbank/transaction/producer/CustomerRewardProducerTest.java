package com.airtelbank.transaction.producer;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.HashMap;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.aerospike.core.AerospikeTemplate;
import org.springframework.test.util.ReflectionTestUtils;

import com.airtelbank.transaction.BaseTest;
import com.airtelbank.transaction.dto.customerState.CustomerStateDetailsDataDTO;
import com.airtelbank.transaction.dto.customerState.CustomerStateResponse;
import com.airtelbank.transaction.dto.intermediateDTOs.RewardsDTO;
import com.airtelbank.transaction.dto.travellerPack.AccountType;
import com.airtelbank.transaction.dto.travellerPack.OfferApiResponse;
import com.airtelbank.transaction.util.TransactionHelperUtil;

public class CustomerRewardProducerTest extends BaseTest{

	@Mock
	Producer producer;
	
	@Mock
	TransactionHelperUtil transactionHelper;

	@Mock
	private AerospikeTemplate aerospikeTemplate;
	
	@InjectMocks
	CustomerRewardProducer customerRewardProducer;
	
	@Before
	public void setUp() throws Exception {
		MockitoAnnotations.initMocks(this);
		ReflectionTestUtils.setField(customerRewardProducer, "configRewardPaymentCustomer", "http://10.56.110.189:1808/api/v4/customers/{customerId}/offerst");
		ReflectionTestUtils.setField(customerRewardProducer, "customerRewards", "reward1,reward2,reward3");
	}
	
	@Test
	public void produceRewardsStatusTest() {
		RewardsDTO rewardsDTO = new RewardsDTO();
		rewardsDTO.setAppId("12344334");
		rewardsDTO.setChannel("ANDROID");
		
		CustomerStateDetailsDataDTO custStateDetailsData = new CustomerStateDetailsDataDTO();
		HashMap<String, Object> map1 = new HashMap<>();
		map1.put("it", new Object());
		custStateDetailsData.setOffersMap(map1);
		custStateDetailsData.setCustType("SBA");
		custStateDetailsData.setMobileNumber("9876876576");
		
		CustomerStateResponse custResponse = new CustomerStateResponse();
		custResponse.setCustomerId("217632");
		custResponse.setCustomerDetail(custStateDetailsData);
		
		Mockito.when(transactionHelper.hitGetCustomerStateApi(Mockito.anyString(), Mockito.any())).thenReturn(custResponse);
		assertNotNull(custResponse);
		customerRewardProducer.produceRewardsStatus(rewardsDTO);
	}
	
	@Test
	public void produceRewardsStatusTest1() {
		RewardsDTO rewardsDTO = new RewardsDTO();
		rewardsDTO.setAppId("12344334");
		rewardsDTO.setChannel("ANDROID");
		rewardsDTO.setRetailerNumber("9786766578");
		
		CustomerStateDetailsDataDTO custStateDetailsData = new CustomerStateDetailsDataDTO();
		HashMap<String, Object> map1 = new HashMap<>();
		map1.put("reward1", new Object());
		custStateDetailsData.setOffersMap(map1);
		custStateDetailsData.setCustType("SBA");
		custStateDetailsData.setMobileNumber("9876876576");
		
		CustomerStateResponse custResponse = new CustomerStateResponse();
		custResponse.setCustomerId("217632");
		custResponse.setCustomerDetail(custStateDetailsData);
		
		OfferApiResponse response = new OfferApiResponse();
		AccountType acc = new AccountType();
		acc.setBackendId("reward");
		acc.setPrice("500");
		
		AccountType[] arr = new AccountType[1];
		arr[0] = acc;
		response.setAccountType(arr);
		
		Mockito.when(transactionHelper.hitTravellerPackApi(Mockito.anyString())).thenReturn(response);
		assertNotNull(response);
		
		Mockito.when(transactionHelper.hitGetCustomerStateApi(Mockito.anyString(), Mockito.any())).thenReturn(custResponse);
		customerRewardProducer.produceRewardsStatus(rewardsDTO);
	}
}
