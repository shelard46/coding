package com.airtelbank.transaction.consumer;

import static org.junit.Assert.*;

import java.io.IOException;

import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.aerospike.core.AerospikeTemplate;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.kafka.support.Acknowledgment;

import com.airtelbank.payments.hub.client.dto.response.DirectPaymentResponse;
import com.airtelbank.transaction.BaseTest;
import com.airtelbank.transaction.aerospike.entity.FCIInfoDetails;
import com.airtelbank.transaction.dto.response.CustomerOfferDetails;
import com.airtelbank.transaction.model.Meta;
import com.airtelbank.transaction.model.ResponseDTO;
import com.airtelbank.transaction.model.TransactionRequestDTO;
import com.airtelbank.transaction.service.TransactionService;
import com.airtelbank.transaction.util.JsonUtils2;
import com.airtelbank.transaction.util.LoggingUtil;
import com.airtelbank.transaction.util.TransactionHelperUtil;

public class TransactionConsumerTest extends BaseTest {

	@Mock
	private LoggingUtil loggingUtil;

	@Mock
	private TransactionService transactionService;

	@Mock
	private TransactionHelperUtil transactionServiceHelper;

	@Mock
	private AerospikeTemplate aerospikeTemplate;

	@InjectMocks
	TransactionConsumer transactionConsumer;

	public Acknowledgment getAcknowledgment() {
		Acknowledgment acknowledgment = new Acknowledgment() {
			@Override
			public void acknowledge() {

			}
		};
		return acknowledgment;
	}

	@Test
	public void transactionPaymentConsumerTest() throws IOException {
		String payload = "{\"accountNumber\":\"1232323\",\"appId\":\"12344334\"}";
		FCIInfoDetails fciInfoDetails = new FCIInfoDetails();
		fciInfoDetails.setAccountType("Rewards123");
		fciInfoDetails.setRetailerMobileNumber("9876543210");

		Mockito.when(aerospikeTemplate.findById(Mockito.anyString(), Mockito.any())).thenReturn(fciInfoDetails);
		assertNotNull(fciInfoDetails);

		Mockito.when(transactionServiceHelper.getCustomerOfferDetails(Mockito.any(), Mockito.anyString(),
				Mockito.anyString())).thenReturn(getResponseEntitySuccess(getResponseDTO(null)));
		transactionConsumer.transactionPaymentConsumer(payload, getAcknowledgment());
	}

	@Test
	public void transactionPaymentConsumerTest1() throws Exception {
		String payload = "{\"accountNumber\":\"1232323\",\"appId\":\"12344334\",\"customerMobileNo\":\"9876556789\",\"retailMobileNumber\":\"923456789\"}";
		FCIInfoDetails fciInfoDetails = new FCIInfoDetails();
		fciInfoDetails.setAccountType("Rewards");
		Mockito.when(aerospikeTemplate.findById(Mockito.anyString(), Mockito.any())).thenReturn(fciInfoDetails);
		assertNotNull(fciInfoDetails);

		CustomerOfferDetails offers = new CustomerOfferDetails();
		offers.setRewards123Status(true);

		transactionConsumer.transactionPaymentConsumer(payload, getAcknowledgment());
	}

	@Test
	public void transactionPaymentConsumerTest2() throws Exception {
		String payload = "{\"accountNumber\":\"1232323\",\"appId\":\"12344334\"}";
		FCIInfoDetails fciInfoDetails = new FCIInfoDetails();
		fciInfoDetails.setAccountType("Rewards");
		Mockito.when(aerospikeTemplate.findById(Mockito.anyString(), Mockito.any())).thenReturn(fciInfoDetails);
		assertNotNull(fciInfoDetails);

		com.airtelbank.payments.hub.client.dto.response.ResponseDTO<DirectPaymentResponse> response = new com.airtelbank.payments.hub.client.dto.response.ResponseDTO<>();
		DirectPaymentResponse response1 = new DirectPaymentResponse();
		response1.setOrderId("1332572");
		response1.setPaymentReqId("87269");
		response.setData(response1);

		Mockito.when(
				transactionService.onboardingUsecaseToPaymentHub(getTransactionRequestDepositDTO(), getHeaderRequestDTO(), "1000"))
				.thenReturn(response);
		transactionConsumer.transactionPaymentConsumer(payload, getAcknowledgment());
	}
	
	@Test
	public void transactionPaymentConsumerTest3() throws Exception {
		String payload = "{\"accountNumber\":\"1232323\",\"appId\":\"12344334\",\"customerMobileNo\":\"9876556789\",\"retailMobileNumber\":\"923456789\"}";
		FCIInfoDetails fciInfoDetails = new FCIInfoDetails();
		fciInfoDetails.setAccountType("Rewards");
		Mockito.when(aerospikeTemplate.findById(Mockito.anyString(), Mockito.any())).thenThrow(new RuntimeException());
		assertNotNull(fciInfoDetails);
		transactionConsumer.transactionPaymentConsumer(payload, getAcknowledgment());
	}

	@Test
	public void transactionPaymentConsumerTest4() throws IOException {
		String payload = "{\"accountNumber\":\"1232323\",\"appId\":\"12344334\"}";
		FCIInfoDetails fciInfoDetails = new FCIInfoDetails();
		fciInfoDetails.setAccountType("Rewards123");
		fciInfoDetails.setRetailerMobileNumber("9876543210");
		ResponseDTO<CustomerOfferDetails> responseDTO = new ResponseDTO<>();
		CustomerOfferDetails customerOfferDetails = CustomerOfferDetails.builder()
				.rewards123Status(true)
				.build();
		responseDTO.setMeta(new Meta("0", "success", 0));
		responseDTO.setData(customerOfferDetails);
		ResponseEntity<ResponseDTO<CustomerOfferDetails>> responseEntity = new ResponseEntity(responseDTO, HttpStatus.OK);
		Mockito.when(aerospikeTemplate.findById(Mockito.any(), Mockito.any())).thenReturn(fciInfoDetails);
		assertNotNull(fciInfoDetails);

		Mockito.when(transactionServiceHelper.getCustomerOfferDetails(Mockito.any(), Mockito.any(),
				Mockito.any())).thenReturn(responseEntity);
		transactionConsumer.transactionPaymentConsumer(payload, getAcknowledgment());
	}

	@Test
	public void transactionPaymentConsumerTest5() throws Exception {
		String payload = "{\"accountNumber\":\"1232323\",\"appId\":\"12344334\"}";
		FCIInfoDetails fciInfoDetails = new FCIInfoDetails();
		fciInfoDetails.setAccountType("Rewards123");
		fciInfoDetails.setRetailerMobileNumber("9876543210");
		ResponseDTO<CustomerOfferDetails> responseDTO = new ResponseDTO<>();
		CustomerOfferDetails customerOfferDetails = CustomerOfferDetails.builder()
				.rewards123Status(true)
				.build();
		responseDTO.setMeta(new Meta("0", "success", 0));
		responseDTO.setData(customerOfferDetails);
		ResponseEntity<ResponseDTO<CustomerOfferDetails>> responseEntity = new ResponseEntity(responseDTO, HttpStatus.OK);
		Mockito.when(aerospikeTemplate.findById(Mockito.any(), Mockito.any())).thenReturn(fciInfoDetails);
		assertNotNull(fciInfoDetails);

		Mockito.when(transactionServiceHelper.getCustomerOfferDetails(Mockito.any(), Mockito.any(),
				Mockito.any())).thenReturn(responseEntity);
		Mockito.when(transactionService.onboardingUsecaseToPaymentHub(Mockito.any(), Mockito.any(), Mockito.any()))
						.thenReturn(getDirectPaymentResponseDto());
		transactionConsumer.transactionPaymentConsumer(payload, getAcknowledgment());
	}

}
