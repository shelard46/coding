package com.airtelbank.transaction.controller;

import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import com.airtelbank.transaction.constant.Constants;
import com.airtelbank.transaction.exception.ClientSideException;
import com.airtelbank.transaction.exception.GenericException;
import com.airtelbank.transaction.validator.RequestValidator;
import org.apache.commons.collections4.map.HashedMap;
import org.apache.logging.log4j.core.config.Configurator;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.airtelbank.payments.hub.client.dto.response.DirectPaymentResponse;
import com.airtelbank.payments.hub.client.dto.response.ResponseDTO;
import com.airtelbank.transaction.BaseTest;
import com.airtelbank.transaction.dto.fciCircleBased.FCIResponseDTO;
import com.airtelbank.transaction.dto.response.TransactionStateResponseDTO;
import com.airtelbank.transaction.service.TransactionService;
import com.airtelbank.transaction.util.PHClientConfig;
import com.airtelbank.transaction.validator.MetaValidator;
import com.airtelbank.transaction.validator.TransactionValidator;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.validation.BindingResult;
import org.springframework.validation.ObjectError;
import org.springframework.validation.Validator;
import org.testcontainers.shaded.org.apache.http.HttpException;

import javax.naming.Binding;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class TransactionControllerTest extends BaseTest {

	@InjectMocks
	private TransactionController transactionController;

	@Mock
	private TransactionService transactionService;

	@Mock
	private PHClientConfig pHClientConfig;

	@Mock
	RequestValidator validator;

	private MockMvc mockMvc;

	@Mock
	private TransactionValidator requestValidator;

	@Mock
	private MetaValidator metaValidator;

	@Mock
	private BindingResult bindingResult;

	@Before
	public void init() {
		MockitoAnnotations.initMocks(this);
		mockMvc = MockMvcBuilders.standaloneSetup(transactionController).build();
		Configurator.setAllLevels("", org.apache.logging.log4j.Level.ALL);

	}

	@Test
	public void postPaymentDetailsTest() throws JsonProcessingException, Exception {
		ResponseDTO<DirectPaymentResponse> response = new ResponseDTO<DirectPaymentResponse>();
		when(transactionService.onboardingUsecaseToPaymentHub(Mockito.any(), Mockito.any(),Mockito.any()))
				.thenReturn(response);
		this.mockMvc.perform(MockMvcRequestBuilders.post("/api/v1/payments/transactions/direct")
				.content(new ObjectMapper().writeValueAsString(getTransactionRequestDepositDTO()))
				.header("contentid", "Test").accept(MediaType.APPLICATION_JSON_VALUE)
				.contentType(MediaType.APPLICATION_JSON_VALUE)).andExpect(status().isOk());
	}

	@Test(expected = Exception.class)
	public void postPaymentDetailsTestClientSideException() throws JsonProcessingException, Exception {
		ResponseDTO<DirectPaymentResponse> response = new ResponseDTO<DirectPaymentResponse>();
		when(transactionService.onboardingUsecaseToPaymentHub(Mockito.any(), Mockito.any(),Mockito.any()))
				.thenReturn(response);
		this.mockMvc.perform(MockMvcRequestBuilders.post("/api/v1/payments/transactions/direct")
				.content(new ObjectMapper().writeValueAsString(getTransactionRequestDepositDTO()))
				.header("contentid", "").accept(MediaType.APPLICATION_JSON_VALUE)
				.contentType(MediaType.APPLICATION_JSON_VALUE)).andExpect(status().isOk());
	}

	@Test
	public void postPaymentDetailsTestGenericException() throws JsonProcessingException, Exception {
		ResponseDTO<DirectPaymentResponse> response = new ResponseDTO<DirectPaymentResponse>();
		doThrow(new GenericException()).when(transactionService).onboardingUsecaseToPaymentHub(Mockito.any(), Mockito.any(),Mockito.any());
		this.mockMvc.perform(MockMvcRequestBuilders.post("/api/v1/payments/transactions/direct")
				.content(new ObjectMapper().writeValueAsString(getTransactionRequestDepositDTO()))
				.header("contentid", "Test").header("apptype", Constants.AppType.SHGTRX).accept(MediaType.APPLICATION_JSON_VALUE)
				.contentType(MediaType.APPLICATION_JSON_VALUE)).andExpect(status().isOk());
	}

	@Test
	public void postPaymentDetailsTestException() throws JsonProcessingException, Exception {
		ResponseDTO<DirectPaymentResponse> response = new ResponseDTO<DirectPaymentResponse>();
		doThrow(new HttpException()).when(transactionService).onboardingUsecaseToPaymentHub(Mockito.any(), Mockito.any(),Mockito.any());
		this.mockMvc.perform(MockMvcRequestBuilders.post("/api/v1/payments/transactions/direct")
				.content(new ObjectMapper().writeValueAsString(getTransactionRequestDepositDTO()))
				.header("contentid", "Test").header("apptype", Constants.AppType.SHGTRX).accept(MediaType.APPLICATION_JSON_VALUE)
				.contentType(MediaType.APPLICATION_JSON_VALUE)).andExpect(status().isOk());
	}

	@Test
	public void postPaymentDetailsExceptionTest() throws JsonProcessingException, Exception {

		ResponseDTO<DirectPaymentResponse> response = new ResponseDTO<DirectPaymentResponse>();
		when(transactionService.onboardingUsecaseToPaymentHub(Mockito.any(), Mockito.any(),Mockito.any()))
				.thenReturn(response);
		this.mockMvc.perform(MockMvcRequestBuilders.get("/api/v1/payments/transactions")
				.content(new ObjectMapper().writeValueAsString(getTransactionRequestDepositDTO()))
				.accept(MediaType.APPLICATION_JSON_VALUE).contentType(MediaType.APPLICATION_JSON_VALUE));
	}



	@Test
	public void getFCIDetailsByIdTest() throws JsonProcessingException, Exception {

		when(transactionService.getFCIDetailsById(Mockito.any())).thenReturn(null);
		this.mockMvc
				.perform(MockMvcRequestBuilders.get("/api/v1/payments/transactions").header("contentid", "1234")
						.header("channel", "RAPP").param("appId", "664444747447")
						.accept(MediaType.APPLICATION_JSON_VALUE).contentType(MediaType.APPLICATION_JSON_VALUE))
				.andExpect(status().isOk());
	} 
	
	@Test
	public void getTransactionStateTest() throws JsonProcessingException, Exception {

		com.airtelbank.transaction.model.ResponseDTO<TransactionStateResponseDTO> response  = new com.airtelbank.transaction.model.ResponseDTO<TransactionStateResponseDTO>();
		when(transactionService.getTransactionState( Mockito.anyString())).thenReturn(response);
		this.mockMvc.perform(MockMvcRequestBuilders.get("/api/v1/payments/transaction/appId/12344334")
				.header("customerhandlenumber", "8889988789")
				.header("contentid", "a1wert")
				.header("channel", "WEB")
				.accept(MediaType.APPLICATION_JSON_VALUE).contentType(MediaType.APPLICATION_JSON_VALUE))
				.andExpect(status().isOk());
	}

	@Test
	public void getTransactionStateExceptionTest() throws JsonProcessingException, Exception {

		com.airtelbank.transaction.model.ResponseDTO<TransactionStateResponseDTO> response  = new com.airtelbank.transaction.model.ResponseDTO<TransactionStateResponseDTO>();
		doThrow(new GenericException()).when(transactionService).getTransactionState( Mockito.anyString());
		this.mockMvc.perform(MockMvcRequestBuilders.get("/api/v1/payments/transaction/appId/12344334")
						.header("customerhandlenumber", "8889988789")
						.header("contentid", "a1wert")
						.header("channel", "WEB")
						.accept(MediaType.APPLICATION_JSON_VALUE).contentType(MediaType.APPLICATION_JSON_VALUE))
				.andExpect(status().isOk());
	}

	@Test
	public void postEnquiryDetailsTest() throws JsonProcessingException, Exception {
		ResponseDTO<DirectPaymentResponse> response = new ResponseDTO<DirectPaymentResponse>();
		when(transactionService.onboardingUsecaseToPaymentHub(Mockito.any(), Mockito.any(),Mockito.any()))
				.thenReturn(response);
		this.mockMvc.perform(MockMvcRequestBuilders.post("/api/v1/payments/transactions/enquiry")
				.content(new ObjectMapper().writeValueAsString(getTransactionEnquiryRequest()))
				.header("contentid", "Test").accept(MediaType.APPLICATION_JSON_VALUE)
				.contentType(MediaType.APPLICATION_JSON_VALUE)).andExpect(status().isOk());
	}

	@Test
	public void postEnquiryDetailsTestSuccess() throws JsonProcessingException, Exception {
		ResponseDTO<DirectPaymentResponse> response = new ResponseDTO<DirectPaymentResponse>();
		when(transactionService.paymentEnquiry(Mockito.any(),Mockito.any()))
				.thenReturn(new ResponseDTO<String>());
		this.mockMvc.perform(MockMvcRequestBuilders.post("/api/v1/payments/transactions/enquiry")
				.content(new ObjectMapper().writeValueAsString(getTransactionEnquiryRequest()))
				.header("contentid", "Test").accept(MediaType.APPLICATION_JSON_VALUE)
				.contentType(MediaType.APPLICATION_JSON_VALUE)).andExpect(status().isOk());
	}

	@Test()
	public void postEnquiryDetailsGenericExceptionTest() throws JsonProcessingException, Exception {
		ResponseDTO<DirectPaymentResponse> response = new ResponseDTO<DirectPaymentResponse>();
		doThrow(new GenericException()).when(transactionService).paymentEnquiry(Mockito.any(),Mockito.any());
		this.mockMvc.perform(MockMvcRequestBuilders.post("/api/v1/payments/transactions/enquiry")
				.content(new ObjectMapper().writeValueAsString(getTransactionEnquiryRequest()))
				.header("contentid", "Test")
				.header("apptype", Constants.AppType.SHGTRX)
				.accept(MediaType.APPLICATION_JSON_VALUE)
				.contentType(MediaType.APPLICATION_JSON_VALUE)).andExpect(status().isOk());
	}

	@Test()
	public void postEnquiryDetailsExceptionTest() throws JsonProcessingException, Exception {
		ResponseDTO<DirectPaymentResponse> response = new ResponseDTO<DirectPaymentResponse>();
		doThrow(new ClientSideException()).when(transactionService).paymentEnquiry(Mockito.any(),Mockito.any());
		this.mockMvc.perform(MockMvcRequestBuilders.post("/api/v1/payments/transactions/enquiry")
				.content(new ObjectMapper().writeValueAsString(getTransactionEnquiryRequest()))
				.header("contentid", "Test").accept(MediaType.APPLICATION_JSON_VALUE)
				.contentType(MediaType.APPLICATION_JSON_VALUE)).andExpect(status().isOk());
	}

	@Test
	public void saveFCIDetailsTest() throws Exception {
		this.mockMvc.perform(MockMvcRequestBuilders.post("/api/v1/payments/transactions/fciDetail")
				.content(new ObjectMapper().writeValueAsString(getTransactionEnquiryRequest()))
				.header("contentid", "test").accept(MediaType.APPLICATION_JSON_VALUE)
				.contentType(MediaType.APPLICATION_JSON_VALUE)).andExpect(status().isOk());
	}

	@Test
	public void saveFCIDetailsExceptionTest(){
		HashMap<String, String> headers = new HashMap<>();
		ObjectError error = new ObjectError("8001","error");
		List<ObjectError> errorList = new ArrayList<>();
		errorList.add(error);
		bindingResult.addError(error);
		when(bindingResult.hasErrors()).thenReturn(true);
		transactionController.saveFCIDetails(headers, getFciDetails(), bindingResult);
	}
}
