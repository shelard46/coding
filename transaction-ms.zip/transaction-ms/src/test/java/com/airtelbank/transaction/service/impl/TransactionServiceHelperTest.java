package com.airtelbank.transaction.service.impl;

import com.airtelbank.payments.hub.client.dto.response.PaymentEnquiryResponse;
import com.airtelbank.transaction.BaseTest;
import com.airtelbank.transaction.constant.Constants;
import com.airtelbank.transaction.exception.GenericException;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.context.MessageSource;
import org.springframework.data.aerospike.core.AerospikeTemplate;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.test.util.ReflectionTestUtils;

import java.util.Map;

import static org.junit.Assert.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.when;

public class TransactionServiceHelperTest extends BaseTest {
    @InjectMocks
    private TransactionServiceHelper transactionServiceHelper;

    @Mock
    private KafkaTemplate kafkaTemplate;

    @Mock
    private TransactionServiceImpl transactionService;

    @Mock
    private AerospikeTemplate aerospikeTemplate;

    @Mock
    private MessageSource messageSource;

    @Before
    public void setUp() throws Exception {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void updatePaymentResponseDepositTest() {
        ReflectionTestUtils.setField(transactionServiceHelper, "shgCashDepositUseCase", "deposit");
        ReflectionTestUtils.setField(transactionServiceHelper, "paymentTopic", "topic");
        transactionServiceHelper.updatePaymentResponse(populatePaymentEnquiryResponse(), populateTransactionStore(),
                getHeaderRequestDTO(), "deposit");
    }

    @Test
    public void updatePaymentResponseWithdrawalTest() {
        ReflectionTestUtils.setField(transactionServiceHelper, "shgCashDepositUseCase", "deposit");
        ReflectionTestUtils.setField(transactionServiceHelper, "shgCashWithdrawUseCase", "withdraw");
        ReflectionTestUtils.setField(transactionServiceHelper, "paymentTopic", "topic");
        transactionServiceHelper.updatePaymentResponse(populatePaymentEnquiryResponse(), populateTransactionStore(),
                getHeaderRequestDTO(), "withdraw");
    }

    @Test
    public void updatePaymentResponseFundTransferTest() {
        ReflectionTestUtils.setField(transactionServiceHelper, "shgCashDepositUseCase", "deposit");
        ReflectionTestUtils.setField(transactionServiceHelper, "shgCashWithdrawUseCase", "withdraw");
        ReflectionTestUtils.setField(transactionServiceHelper, "shgFundTransferUseCase", "transfer");
        ReflectionTestUtils.setField(transactionServiceHelper, "paymentTopic", "topic");
        transactionServiceHelper.updatePaymentResponse(populatePaymentEnquiryResponse(), populateTransactionStore(),
                getHeaderRequestDTO(), "transfer");
    }

    @Test
    public void updatePaymentResponseFundWithdrawFailTest() {
        PaymentEnquiryResponse paymentEnquiryResponse = populatePaymentEnquiryResponse();
        paymentEnquiryResponse.getDebitDetails().get(0).setStatus("failure");
        ReflectionTestUtils.setField(transactionServiceHelper, "shgCashDepositUseCase", "deposit");
        ReflectionTestUtils.setField(transactionServiceHelper, "shgCashWithdrawUseCase", "withdraw");
        ReflectionTestUtils.setField(transactionServiceHelper, "shgFundTransferUseCase", "transfer");
        ReflectionTestUtils.setField(transactionServiceHelper, "paymentTopic", "topic");
        transactionServiceHelper.updatePaymentResponse(paymentEnquiryResponse, populateTransactionStore(),
                getHeaderRequestDTO(), "withdraw");
    }

    @Test
    public void updatePaymentResponseFundDepositFailTest() {
        PaymentEnquiryResponse paymentEnquiryResponse = populatePaymentEnquiryResponse();
        paymentEnquiryResponse.getDebitDetails().get(0).setStatus("failure");
        ReflectionTestUtils.setField(transactionServiceHelper, "shgCashDepositUseCase", "deposit");
        ReflectionTestUtils.setField(transactionServiceHelper, "shgCashWithdrawUseCase", "withdraw");
        ReflectionTestUtils.setField(transactionServiceHelper, "shgFundTransferUseCase", "transfer");
        ReflectionTestUtils.setField(transactionServiceHelper, "paymentTopic", "topic");
        transactionServiceHelper.updatePaymentResponse(paymentEnquiryResponse, populateTransactionStore(),
                getHeaderRequestDTO(), "deposit");
    }

    @Test
    public void updatePaymentResponseFundTransferFailTest() {
        PaymentEnquiryResponse paymentEnquiryResponse = populatePaymentEnquiryResponse();
        paymentEnquiryResponse.getDebitDetails().get(0).setStatus("failure");
        ReflectionTestUtils.setField(transactionServiceHelper, "shgCashDepositUseCase", "deposit");
        ReflectionTestUtils.setField(transactionServiceHelper, "shgCashWithdrawUseCase", "withdraw");
        ReflectionTestUtils.setField(transactionServiceHelper, "shgFundTransferUseCase", "transfer");
        ReflectionTestUtils.setField(transactionServiceHelper, "paymentTopic", "topic");
        doThrow(new GenericException()).when(aerospikeTemplate).update(any());
        transactionServiceHelper.updatePaymentResponse(paymentEnquiryResponse, populateTransactionStore(),
                getHeaderRequestDTO(), "transfer");
    }

    @Test
    public void savePaymentResponseSuccess() {
        transactionServiceHelper.savePaymentResponse("deposit", getTransactionRequestDTO(), getDirectPaymentResponseDto(), getHeaderRequestDTO());
    }

    @Test
    public void savePaymentResponseFail() {
        doThrow(new GenericException()).when(aerospikeTemplate).save(any());
        transactionServiceHelper.savePaymentResponse("deposit", getTransactionRequestDTO(), getDirectPaymentResponseDto(), getHeaderRequestDTO());
    }

    @Test
    public void useCaseNarrationCDTest(){
        when(messageSource.getMessage(any(), any(), any())).thenReturn("success");
        Map<String,String> response = transactionServiceHelper.useCaseNarration(Constants.Action.SHG_CD, "YES");
        assertEquals("success", response.get(Constants.DR_KEY));
    }

    @Test
    public void useCaseNarrationCWTest(){
        when(messageSource.getMessage(any(), any(), any())).thenReturn("success");
        Map<String,String> response = transactionServiceHelper.useCaseNarration(Constants.Action.SHG_CW, "success");
        assertEquals("success", response.get(Constants.DR_KEY));
    }

    @Test
    public void useCaseNarrationIFTTest(){
        when(messageSource.getMessage(any(), any(), any())).thenReturn("success");
        Map<String,String> response = transactionServiceHelper.useCaseNarration(Constants.Action.SHG_IFT, "success");
        assertEquals("success", response.get(Constants.DR_KEY));
    }
}