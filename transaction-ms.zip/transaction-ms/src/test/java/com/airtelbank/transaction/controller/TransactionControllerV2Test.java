package com.airtelbank.transaction.controller;

import com.airtelbank.payments.hub.client.dto.response.Meta;
import com.airtelbank.payments.hub.client.dto.response.ResponseDTO;
import com.airtelbank.transaction.dto.TransactionReqDTO;
import com.airtelbank.transaction.dto.fciCircleBased.FCIResponseDTO;
import com.airtelbank.transaction.exception.ClientSideException;
import com.airtelbank.transaction.service.TransactionService;
import com.fasterxml.jackson.core.JsonProcessingException;
import org.apache.logging.log4j.core.config.Configurator;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import java.util.HashMap;
import java.util.Map;

import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

public class TransactionControllerV2Test {

    @InjectMocks
    private TransactionControllerV2 transactionControllerV2;

    private MockMvc mockMvc;
    @Mock
    private TransactionService transactionService;

    @Before
    public void setUp() throws Exception {
        MockitoAnnotations.initMocks(this);
        mockMvc = MockMvcBuilders.standaloneSetup(transactionControllerV2).build();
        Configurator.setAllLevels("", org.apache.logging.log4j.Level.ALL);
    }

    @After
    public void tearDown() throws Exception {
    }

    @Test
    public void getCircleCodeInfo() {
        ReflectionTestUtils.setField(transactionControllerV2,"privateKey","MIIBVAIBADANBgkqhkiG9w0BAQEFAASCAT4wggE6AgEAAkEAmUIa1G/XYHsFG9LjYIyDnzUQnz+P7R7NrJqEEbDxx6zSTbfh79Ri9vlH4+OPC+0RR7V4PCXyCZ16U6XpnHTP+QIDAQABAkA94QfuMD4Y0XLtmgd+ax2VwZo1gjd9eQt4HmcmsXfds5Q8DBRHX199+IypL4kO7Xj5wv7N7vrDdRv4P663ahGVAiEA1ogj2b2bFBPryaXadqXkqsCpqeAqAybGoO1Axyz1ptMCIQC24emDhhiyQuEehjTNiCtdkQpPi45o5erBZM/RHBqGgwIhAMvKp8PACgEYq3PyyYTMMlzCiGmHOGGmBCn7Nv3+B51hAiBEeJauKJGshD+25vZ0EUxzLq+WkqCSA6r+F1l7aDNCMwIgIw7Hu7V3NO6lFI4o8oXNYkJZisFhAlYe4kkG3HdW9Qs=");
        Map<String,String> stringStringMap=new HashMap<>();
        ResponseDTO<FCIResponseDTO> fciResponseDTOResponseDTO=new ResponseDTO<>();
        FCIResponseDTO fciResponseDTO= FCIResponseDTO.builder().minFCIAmount("100").build();
        fciResponseDTOResponseDTO.setData(fciResponseDTO);
        Meta meta=new Meta();
        meta.setCode("test");
        meta.setDescription("test");
        meta.setStatus(1);
        fciResponseDTOResponseDTO.setMeta(meta);
        Mockito.doReturn(fciResponseDTOResponseDTO).when(transactionService).getCircleCodeInfo(Mockito.anyString(),Mockito.anyString(),Mockito.anyString(),Mockito.anyString(),Mockito.anyString());
        stringStringMap.put("customerhandlenumber","joZ6CrBfvOGRdbUjlsT3FLmFgC/rFlSLPxova6HAMMR3LMf7mt4oofsbOBSQ4lBvH4zGwCbi8Cv0WTfCGRsTdg==");
        stringStringMap.put("channel","joZ6CrBfvOGRdbUjlsT3FLmFgC/rFlSLPxova6HAMMR3LMf7mt4oofsbOBSQ4lBvH4zGwCbi8Cv0WTfCGRsTdg==");
        stringStringMap.put("contentid","joZ6CrBfvOGRdbUjlsT3FLmFgC/rFlSLPxova6HAMMR3LMf7mt4oofsbOBSQ4lBvH4zGwCbi8Cv0WTfCGRsTdg==");
        ResponseEntity<?> responseEntity=transactionControllerV2.getCircleCodeInfo("test","test",stringStringMap);
        assertNotNull(responseEntity);
    }

    @Test(expected = ClientSideException.class)
    public void getCircleCodeInfo_exception_Test() {
        ReflectionTestUtils.setField(transactionControllerV2,"privateKey","MIIBVAIBADANBgkqhkiG9w0BAQEFAASCAT4wggE6AgEAAkEAmUIa1G/XYHsFG9LjYIyDnzUQnz+P7R7NrJqEEbDxx6zSTbfh79Ri9vlH4+OPC+0RR7V4PCXyCZ16U6XpnHTP+QIDAQABAkA94QfuMD4Y0XLtmgd+ax2VwZo1gjd9eQt4HmcmsXfds5Q8DBRHX199+IypL4kO7Xj5wv7N7vrDdRv4P663ahGVAiEA1ogj2b2bFBPryaXadqXkqsCpqeAqAybGoO1Axyz1ptMCIQC24emDhhiyQuEehjTNiCtdkQpPi45o5erBZM/RHBqGgwIhAMvKp8PACgEYq3PyyYTMMlzCiGmHOGGmBCn7Nv3+B51hAiBEeJauKJGshD+25vZ0EUxzLq+WkqCSA6r+F1l7aDNCMwIgIw7Hu7V3NO6lFI4o8oXNYkJZisFhAlYe4kkG3HdW9Qs=");
        Map<String,String> stringStringMap=new HashMap<>();
        ResponseDTO<FCIResponseDTO> fciResponseDTOResponseDTO=new ResponseDTO<>();
        FCIResponseDTO fciResponseDTO= FCIResponseDTO.builder().minFCIAmount("100").build();
        fciResponseDTOResponseDTO.setData(fciResponseDTO);
        Meta meta=new Meta();
        meta.setCode("test");
        meta.setDescription("test");
        meta.setStatus(1);
        fciResponseDTOResponseDTO.setMeta(meta);
        Mockito.doReturn(fciResponseDTOResponseDTO).when(transactionService).getCircleCodeInfo(Mockito.anyString(),Mockito.anyString(),Mockito.anyString(),Mockito.anyString(),Mockito.anyString());
        stringStringMap.put("customerhandlenumber","9168258903");
        stringStringMap.put("channel","joZ6CrBfvOGRdbUjlsT3FLmFgC/rFlSLPxova6HAMMR3LMf7mt4oofsbOBSQ4lBvH4zGwCbi8Cv0WTfCGRsTdg==");
        stringStringMap.put("contentid","joZ6CrBfvOGRdbUjlsT3FLmFgC/rFlSLPxova6HAMMR3LMf7mt4oofsbOBSQ4lBvH4zGwCbi8Cv0WTfCGRsTdg==");
        ResponseEntity<?> responseEntity=transactionControllerV2.getCircleCodeInfo("test","test",stringStringMap);
        assertNotNull(responseEntity);
    }

    @Test(expected = ClientSideException.class)
    public void getCircleCodeInfoscirclecodenull_exception_Test() {
        ReflectionTestUtils.setField(transactionControllerV2,"privateKey","MIIBVAIBADANBgkqhkiG9w0BAQEFAASCAT4wggE6AgEAAkEAmUIa1G/XYHsFG9LjYIyDnzUQnz+P7R7NrJqEEbDxx6zSTbfh79Ri9vlH4+OPC+0RR7V4PCXyCZ16U6XpnHTP+QIDAQABAkA94QfuMD4Y0XLtmgd+ax2VwZo1gjd9eQt4HmcmsXfds5Q8DBRHX199+IypL4kO7Xj5wv7N7vrDdRv4P663ahGVAiEA1ogj2b2bFBPryaXadqXkqsCpqeAqAybGoO1Axyz1ptMCIQC24emDhhiyQuEehjTNiCtdkQpPi45o5erBZM/RHBqGgwIhAMvKp8PACgEYq3PyyYTMMlzCiGmHOGGmBCn7Nv3+B51hAiBEeJauKJGshD+25vZ0EUxzLq+WkqCSA6r+F1l7aDNCMwIgIw7Hu7V3NO6lFI4o8oXNYkJZisFhAlYe4kkG3HdW9Qs=");
        Map<String,String> stringStringMap=new HashMap<>();
        ResponseDTO<FCIResponseDTO> fciResponseDTOResponseDTO=new ResponseDTO<>();
        FCIResponseDTO fciResponseDTO= FCIResponseDTO.builder().minFCIAmount("100").build();
        fciResponseDTOResponseDTO.setData(fciResponseDTO);
        Meta meta=new Meta();
        meta.setCode("test");
        meta.setDescription("test");
        meta.setStatus(1);
        fciResponseDTOResponseDTO.setMeta(meta);
        Mockito.doReturn(fciResponseDTOResponseDTO).when(transactionService).getCircleCodeInfo(Mockito.anyString(),Mockito.anyString(),Mockito.anyString(),Mockito.anyString(),Mockito.anyString());
        stringStringMap.put("customerhandlenumber","joZ6CrBfvOGRdbUjlsT3FLmFgC/rFlSLPxova6HAMMR3LMf7mt4oofsbOBSQ4lBvH4zGwCbi8Cv0WTfCGRsTdg==");
        stringStringMap.put("channel","joZ6CrBfvOGRdbUjlsT3FLmFgC/rFlSLPxova6HAMMR3LMf7mt4oofsbOBSQ4lBvH4zGwCbi8Cv0WTfCGRsTdg==");
        stringStringMap.put("contentid","joZ6CrBfvOGRdbUjlsT3FLmFgC/rFlSLPxova6HAMMR3LMf7mt4oofsbOBSQ4lBvH4zGwCbi8Cv0WTfCGRsTdg==");
        ResponseEntity<?> responseEntity=transactionControllerV2.getCircleCodeInfo("","",stringStringMap);

    }

    @Test
    public void getCircleCodeInfo1() {
        Map<String,String> stringStringMap=new HashMap<>();
        ResponseDTO<FCIResponseDTO> fciResponseDTOResponseDTO=new ResponseDTO<>();
        FCIResponseDTO fciResponseDTO= FCIResponseDTO.builder().minFCIAmount("100").build();
        fciResponseDTOResponseDTO.setData(fciResponseDTO);
        Meta meta=new Meta();
        meta.setCode("test");
        meta.setDescription("test");
        meta.setStatus(1);
        fciResponseDTOResponseDTO.setMeta(meta);
        Mockito.doReturn(fciResponseDTOResponseDTO).when(transactionService).getCircleCodeInfo(Mockito.anyString(),Mockito.anyString(),Mockito.anyString(),Mockito.anyString(),Mockito.anyString());
        stringStringMap.put("customerhandlenumber","joZ6CrBfvOGRdbUjlsT3FLmFgC/rFlSLPxova6HAMMR3LMf7mt4oofsbOBSQ4lBvH4zGwCbi8Cv0WTfCGRsTdg==");
        stringStringMap.put("channel","joZ6CrBfvOGRdbUjlsT3FLmFgC/rFlSLPxova6HAMMR3LMf7mt4oofsbOBSQ4lBvH4zGwCbi8Cv0WTfCGRsTdg==");
        stringStringMap.put("contentid","joZ6CrBfvOGRdbUjlsT3FLmFgC/rFlSLPxova6HAMMR3LMf7mt4oofsbOBSQ4lBvH4zGwCbi8Cv0WTfCGRsTdg==");
        TransactionReqDTO transactionReqDTO=new TransactionReqDTO();
        transactionReqDTO.setCustomerHandlerNumber("9168258903");
        ResponseEntity<?> responseEntity=transactionControllerV2.getCircleCodeInfo1("test",transactionReqDTO,"test",stringStringMap);
        assertNotNull(responseEntity);
    }

    @Test(expected = ClientSideException.class)
    public void getCircleCodeInfo1_exception_test() {
        Map<String,String> stringStringMap=new HashMap<>();
        ResponseDTO<FCIResponseDTO> fciResponseDTOResponseDTO=new ResponseDTO<>();
        FCIResponseDTO fciResponseDTO= FCIResponseDTO.builder().minFCIAmount("100").build();
        fciResponseDTOResponseDTO.setData(fciResponseDTO);
        Meta meta=new Meta();
        meta.setCode("test");
        meta.setDescription("test");
        meta.setStatus(1);
        fciResponseDTOResponseDTO.setMeta(meta);
        Mockito.doReturn(fciResponseDTOResponseDTO).when(transactionService).getCircleCodeInfo(Mockito.anyString(),Mockito.anyString(),Mockito.anyString(),Mockito.anyString(),Mockito.anyString());
        stringStringMap.put("customerhandlenumber","joZ6CrBfvOGRdbUjlsT3FLmFgC/rFlSLPxova6HAMMR3LMf7mt4oofsbOBSQ4lBvH4zGwCbi8Cv0WTfCGRsTdg==");
        stringStringMap.put("channel","joZ6CrBfvOGRdbUjlsT3FLmFgC/rFlSLPxova6HAMMR3LMf7mt4oofsbOBSQ4lBvH4zGwCbi8Cv0WTfCGRsTdg==");
        stringStringMap.put("contentid","joZ6CrBfvOGRdbUjlsT3FLmFgC/rFlSLPxova6HAMMR3LMf7mt4oofsbOBSQ4lBvH4zGwCbi8Cv0WTfCGRsTdg==");
        TransactionReqDTO transactionReqDTO=new TransactionReqDTO();
        transactionReqDTO.setCustomerHandlerNumber(null);
        ResponseEntity<?> responseEntity=transactionControllerV2.getCircleCodeInfo1("test",transactionReqDTO,"test",stringStringMap);
        assertNotNull(responseEntity);
    }

    @Test(expected = ClientSideException.class)
    public void getCircleCodeInfo1circlecodnull_exception_test() {
        Map<String,String> stringStringMap=new HashMap<>();
        ResponseDTO<FCIResponseDTO> fciResponseDTOResponseDTO=new ResponseDTO<>();
        FCIResponseDTO fciResponseDTO= FCIResponseDTO.builder().minFCIAmount("100").build();
        fciResponseDTOResponseDTO.setData(fciResponseDTO);
        Meta meta=new Meta();
        meta.setCode("test");
        meta.setDescription("test");
        meta.setStatus(1);
        fciResponseDTOResponseDTO.setMeta(meta);
        Mockito.doReturn(fciResponseDTOResponseDTO).when(transactionService).getCircleCodeInfo(Mockito.anyString(),Mockito.anyString(),Mockito.anyString(),Mockito.anyString(),Mockito.anyString());
        stringStringMap.put("customerhandlenumber","joZ6CrBfvOGRdbUjlsT3FLmFgC/rFlSLPxova6HAMMR3LMf7mt4oofsbOBSQ4lBvH4zGwCbi8Cv0WTfCGRsTdg==");
        stringStringMap.put("channel","joZ6CrBfvOGRdbUjlsT3FLmFgC/rFlSLPxova6HAMMR3LMf7mt4oofsbOBSQ4lBvH4zGwCbi8Cv0WTfCGRsTdg==");
        stringStringMap.put("contentid","joZ6CrBfvOGRdbUjlsT3FLmFgC/rFlSLPxova6HAMMR3LMf7mt4oofsbOBSQ4lBvH4zGwCbi8Cv0WTfCGRsTdg==");
        TransactionReqDTO transactionReqDTO=new TransactionReqDTO();
        transactionReqDTO.setCustomerHandlerNumber("9168258903");
        ResponseEntity<?> responseEntity=transactionControllerV2.getCircleCodeInfo1("",transactionReqDTO,"",stringStringMap);
        assertNotNull(responseEntity);
    }

    @Test(expected = Exception.class)
    public void getCircleCodeInfoNoHandlerNumberTest() throws JsonProcessingException, Exception {

        this.mockMvc.perform(MockMvcRequestBuilders.get("/api/v1/payments/circle/NE/retailer")
                .param("retailerId", "12345").header("customerHandleNumber", "8889988789")
                .accept(MediaType.APPLICATION_JSON_VALUE).contentType(MediaType.APPLICATION_JSON_VALUE));
    }

    @Test
    public void getCircleCodeInfoSuccessTest() throws JsonProcessingException, Exception {

        ResponseDTO<FCIResponseDTO> response = new ResponseDTO<FCIResponseDTO>();
        when(transactionService.getCircleCodeInfo(Mockito.any(), Mockito.any(), Mockito.anyString(),
                Mockito.anyString(), Mockito.anyString())).thenReturn(response);
        this.mockMvc.perform(MockMvcRequestBuilders.get("/api/v1/payments/circle/NE/retailer")
                        .param("retailerId", "12345").header("customerhandlenumber", "8889988789")
                        .header("contentid", "a1wert")
                        .header("channel", "WEB")
                        .accept(MediaType.APPLICATION_JSON_VALUE).contentType(MediaType.APPLICATION_JSON_VALUE))
                .andExpect(status().isOk());
    }

    @Test(expected = Exception.class)
    public void getCircleCodeInfoNoRetailerIdTest() throws JsonProcessingException, Exception {

        this.mockMvc.perform(MockMvcRequestBuilders.get("/api/v1/payments/circle/NE/retailer").param("retailerId", "")
                .header("customerhandlenumber", "8889988789").accept(MediaType.APPLICATION_JSON_VALUE)
                .contentType(MediaType.APPLICATION_JSON_VALUE));
    }

}