package com.airtelbank.transaction.strategy;

import com.airtelbank.transaction.constant.Constants;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import javax.sound.midi.Track;

import static org.junit.Assert.*;

public class TransactionRuleStrategyFactoryTest {
    @InjectMocks
    private TransactionRuleStrategyFactory transactionRuleStrategyFactory;

    @Mock
    ShgTransactionRuleStrategy shgTrxRule;

    @Mock SbaTransactionRuleStrategy sbaTrxRule;

    @Before
    public void setUp(){
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void getRuleStrategyFactoryShgTest() {
        TransactionRuleStrategy txnRule = transactionRuleStrategyFactory.
                getRuleStrategyFactory(Constants.AppType.SHGTRX);
        assertEquals(shgTrxRule, txnRule);
    }

    @Test
    public void getRuleStrategyFactorySbaTest() {
        TransactionRuleStrategy txnRule = transactionRuleStrategyFactory.
                getRuleStrategyFactory(Constants.AppType.SBA);
        assertEquals(sbaTrxRule, txnRule);
    }

    @Test
    public void getRuleStrategyFactoryEmptyTest() {
        TransactionRuleStrategy txnRule = transactionRuleStrategyFactory.
                getRuleStrategyFactory(null);
        assertEquals(sbaTrxRule, txnRule);
    }
}