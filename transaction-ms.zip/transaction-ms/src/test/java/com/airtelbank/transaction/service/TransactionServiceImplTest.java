
package com.airtelbank.transaction.service;

import com.airtelbank.payments.hub.client.dto.response.DirectPaymentResponse;
import com.airtelbank.payments.hub.client.dto.response.ResponseDTO;
import com.airtelbank.payments.hub.client.service.PHHashService;
import com.airtelbank.payments.hub.client.service.PHPaymentEnquiryService;
import com.airtelbank.payments.hub.client.service.impl.PHDirectPaymentRequestServiceImpl;
import com.airtelbank.payments.hub.client.service.impl.PHServiceFulfilmentProducerServiceImpl;
import com.airtelbank.transaction.BaseTest;
import com.airtelbank.transaction.aerospike.entity.AllowedCustomer;
import com.airtelbank.transaction.aerospike.entity.AllowedRetailer;
import com.airtelbank.transaction.aerospike.entity.AppIdToPaymentReqId;
import com.airtelbank.transaction.aerospike.entity.CreationIdGeneration;
import com.airtelbank.transaction.aerospike.entity.FCIConfiguration;
import com.airtelbank.transaction.aerospike.entity.FCIInfoDetails;
import com.airtelbank.transaction.aerospike.entity.TransactionStore;
import com.airtelbank.transaction.dto.cbs.CBSFCIDetailsRequest;
import com.airtelbank.transaction.dto.customerProfile.Balance;
import com.airtelbank.transaction.dto.fciCircleBased.FCIResponseDTO;
import com.airtelbank.transaction.dto.response.TransactionStateResponseDTO;
import com.airtelbank.transaction.dto.retailerprofile.AccountResponse;
import com.airtelbank.transaction.dto.retailerprofile.Retailer;
import com.airtelbank.transaction.exception.GenericException;
import com.airtelbank.transaction.model.HeaderRequestDTO;
import com.airtelbank.transaction.model.Meta;
import com.airtelbank.transaction.model.RequestDTO;
import com.airtelbank.transaction.model.RestRequest;
import com.airtelbank.transaction.model.response.AuditLogResponse;
import com.airtelbank.transaction.service.impl.TransactionServiceImpl;
import com.airtelbank.transaction.strategy.ShgTransactionRuleStrategy;
import com.airtelbank.transaction.strategy.TransactionRuleStrategyFactory;
import com.airtelbank.transaction.util.LogMasker;
import com.airtelbank.transaction.util.PHClientConfig;
import com.airtelbank.transaction.util.RequestCreationUtil;
import com.airtelbank.transaction.util.RestUtil;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.data.aerospike.core.AerospikeTemplate;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.web.client.ResourceAccessException;
import org.springframework.web.client.RestClientException;

import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.assertNotNull;



import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;

public class TransactionServiceImplTest extends BaseTest {

	@InjectMocks
	private TransactionServiceImpl transactionServiceImpl;

	@Mock
	private RestUtil restUtil;

	@Mock
	private AerospikeTemplate aerospikeTemplate;

	@Mock
	private AerospikeTemplate aerospikeTemplate1;
	@Mock
	private AerospikeTemplate aerospikeTemplate2;

	@Mock
	private PHDirectPaymentRequestServiceImpl pHDirectPaymentRequestServiceImpl;

	@Mock
	private PHPaymentEnquiryService pHPaymentEnquiryService;

	@Mock
	private PHHashService phHashService;

	@Mock
	TransactionRuleStrategyFactory ruleStrategyFactory;

	@Mock
	ShgTransactionRuleStrategy shgTransactionRuleStrategy;

	@Mock
	private LogMasker logMasker;
	@Mock
	private AuditService auditService;
	@Mock
	private PHClientConfig pHClientConfig;

	@Mock
	private RequestCreationUtil requestCreationUtil;

	@Mock
	private PHServiceFulfilmentProducerServiceImpl pHServiceFulfilmentProducerServiceImpl;

	@Before
	public void setUp() throws Exception {
		MockitoAnnotations.initMocks(this);
		ReflectionTestUtils.setField(transactionServiceImpl, "auditUrl", "http://10.56.110.189:2301/api/v1/audit");
		ReflectionTestUtils.setField(transactionServiceImpl, "retailerProfileUrl",
				"http://10.56.110.189:1808/api/v1/retailers/{id}?embedAccounts=true");

	}

	@Test
	public void postCashDepoistUsecaseToPaymentHubSuccessTest() throws Exception {
		when(ruleStrategyFactory.getRuleStrategyFactory(Mockito.anyString())).thenReturn(shgTransactionRuleStrategy);
		when(shgTransactionRuleStrategy.onboardingUsecaseToPaymentHub(Mockito.any(),Mockito.any(),Mockito.anyString())).
				thenReturn(getDirectPaymentResponseDto());
		ResponseDTO<DirectPaymentResponse> response = transactionServiceImpl
				.onboardingUsecaseToPaymentHub(getTransactionRequestDepositDTO(), getHeaderRequestDTO(),"100");
		assertEquals("TXN124",response.getData().getPaymentReqId());
	}

    @Ignore
	@Test(expected = GenericException.class)
	public void postCashDepoistUsecaseToPaymentHubExceptionTest() throws Exception {
		ReflectionTestUtils.setField(transactionServiceImpl, "retailerOnboardingUseCase", "retailer.onboarding.sba");
		ResponseDTO<DirectPaymentResponse> transactionResponse = new ResponseDTO<DirectPaymentResponse>();
		HeaderRequestDTO headerRequestDTO = new HeaderRequestDTO();
		CreationIdGeneration creationIdGenerationExist = new CreationIdGeneration();
		creationIdGenerationExist.setOrderId(123);
		headerRequestDTO.setContentid("324242");
		headerRequestDTO.setCustomerHandleNumber("1234323234");
		headerRequestDTO.setAppType("SBA");
		DirectPaymentResponse directPaymentResponse = new DirectPaymentResponse();
		directPaymentResponse.setPaymentReqId("2344242");
		transactionResponse.setData(directPaymentResponse);
		Mockito.when(pHDirectPaymentRequestServiceImpl.paymentRequest(Mockito.any(), Mockito.any(), Mockito.any()))
				.thenReturn(transactionResponse);
		FCIInfoDetails fciInfoValue = new FCIInfoDetails();
		fciInfoValue.setTotalamount("1000");
		Mockito.when(aerospikeTemplate.findById(Mockito.anyString(), Mockito.any()))
				.thenReturn(creationIdGenerationExist).thenReturn(fciInfoValue);
		Mockito.when(restUtil.sendHttpRequest(Mockito.any()))
				.thenReturn(getResponseEntitySuccess(getResponseDTO(getSweepOutConsentDTO())));
		ResponseDTO<DirectPaymentResponse> response = transactionServiceImpl
				.onboardingUsecaseToPaymentHub(getTransactionRequestDepositDTO1(), headerRequestDTO,"100");
	assertNotNull(response);
	}


	@Test(expected = Exception.class)
	public void postCashDepoistUsecaseToPaymentHubSuccessExceptionTest() throws Exception {

		ResponseDTO<DirectPaymentResponse> transactionResponse = new ResponseDTO<DirectPaymentResponse>();
		HeaderRequestDTO headerRequestDTO = new HeaderRequestDTO();
		headerRequestDTO.setContentid("324242");
		headerRequestDTO.setCustomerHandleNumber("1234323234");
		headerRequestDTO.setAppType("SBA");
		DirectPaymentResponse directPaymentResponse = new DirectPaymentResponse();
		directPaymentResponse.setPaymentReqId("2344242");
		transactionResponse.setData(directPaymentResponse);
		Mockito.when(pHDirectPaymentRequestServiceImpl.paymentRequest(Mockito.any(), Mockito.any(), Mockito.any()))
				.thenReturn(null);
		CreationIdGeneration creationIdGenerationExist = new CreationIdGeneration();
		Mockito.when(aerospikeTemplate.findById(Mockito.anyString(), Mockito.any()))
				.thenReturn(creationIdGenerationExist);
		FCIInfoDetails fciInfoValue = new FCIInfoDetails();
		fciInfoValue.setTotalamount("1000");
		Mockito.when(aerospikeTemplate.findById(Mockito.anyString(), Mockito.any())).thenReturn(fciInfoValue);
		transactionServiceImpl.onboardingUsecaseToPaymentHub(getTransactionRequestDepositDTO(), headerRequestDTO,"100");
	}

	public <T> ResponseEntity<com.airtelbank.transaction.model.ResponseDTO<T>> getResponseEntitySuccess(
			com.airtelbank.transaction.model.ResponseDTO<T> body) {
		ResponseEntity<com.airtelbank.transaction.model.ResponseDTO<T>> responseEntitySuccess = new ResponseEntity<com.airtelbank.transaction.model.ResponseDTO<T>>(
				body, HttpStatus.OK);
		return responseEntitySuccess;
	}

	public <T> com.airtelbank.transaction.model.ResponseDTO<T> getResponseDTO(T data) {
		com.airtelbank.transaction.model.ResponseDTO<T> response = new com.airtelbank.transaction.model.ResponseDTO<T>();
		Meta meta = new Meta();
		meta.setStatus(0);
		response.setMeta(meta);
		response.setData(data);
		return response;
	}

	public AuditLogResponse getSweepOutConsentDTO() {
		AuditLogResponse auditLogResponse = new AuditLogResponse();
		auditLogResponse.setAuditId("a1asd");
		return auditLogResponse;
	}

	@Test(expected = Exception.class)
	public void getCircleCodeInfoTest() {
		FCIConfiguration fciConfig = new FCIConfiguration();
		fciConfig.setHighFciArr("12");
		fciConfig.setHighAchArr("123");
		fciConfig.setLowFciArr("123");
		fciConfig.setLowAchArr("23");
		AllowedCustomer allowedCustomer = new AllowedCustomer();
		AllowedRetailer allowedRetailer = new AllowedRetailer();
		Mockito.when(aerospikeTemplate.findById(Mockito.any(), Mockito.any())).thenReturn(fciConfig);
		transactionServiceImpl.getCircleCodeInfo("NE", "123445", "123441", "", "");
	}

	@Test
	public void getCircleCodeInfofciConfigisnullTest() {
		FCIConfiguration fciConfig = new FCIConfiguration();
		fciConfig.setHighFciArr("12");
		fciConfig.setHighAchArr("123");
		fciConfig.setLowFciArr("123");
		fciConfig.setLowAchArr("23");
		AllowedCustomer allowedCustomer = new AllowedCustomer();
		AllowedRetailer allowedRetailer = new AllowedRetailer();
		Mockito.when(aerospikeTemplate.findById(Mockito.any(), Mockito.any())).thenReturn(null);
		transactionServiceImpl.getCircleCodeInfo("NE", "123445", "123441", "", "");
	}

	@Test
	public void getCircleCodeInfallowedCustomerisnullTest() {
		FCIConfiguration fciConfig = new FCIConfiguration();
		fciConfig.setHighFciArr("12");
		fciConfig.setHighAchArr("123");
		fciConfig.setLowFciArr("123");
		fciConfig.setLowAchArr("23");
		AllowedCustomer allowedCustomer = new AllowedCustomer();

		AllowedRetailer allowedRetailer = new AllowedRetailer();
		Mockito.when(aerospikeTemplate.findById(Mockito.any(), Mockito.any())).thenReturn(fciConfig);
		Mockito.when(aerospikeTemplate.findById(Long.valueOf("123441"), AllowedCustomer.class)).thenReturn(new AllowedCustomer());
		Mockito.when(aerospikeTemplate.findById(Long.valueOf("123445"), AllowedRetailer.class)).thenReturn(new AllowedRetailer());
		transactionServiceImpl.getCircleCodeInfo("NE", "123445", "123441", "", "");
	}

	@Test
	@Ignore
	public void getCircleCodeInfoNullTest() {
		FCIConfiguration fciConfig = new FCIConfiguration();
		fciConfig.setHighFciArr("12");
		fciConfig.setHighAchArr("123");
		fciConfig.setLowFciArr("123");
		fciConfig.setLowAchArr("23");
		Mockito.when(aerospikeTemplate.findById(Mockito.any(), Mockito.any())).thenReturn(fciConfig);
		transactionServiceImpl.getCircleCodeInfo("NE", "123445", "123434", "QWER", "WEB");
	}

	@Test
	@Ignore
	public void saveFCIDetailsTest() {
		Mockito.doNothing().when(aerospikeTemplate).save(Mockito.any());
		transactionServiceImpl.saveFCIDetails(getFciDetails(), "ASDF", "WEB");
	}

	@Test
	public void getFCIDetailsByIdTest() {
		FCIInfoDetails fciInfoValue = new FCIInfoDetails();
		Mockito.when(aerospikeTemplate.findById(Mockito.anyString(), Mockito.any())).thenReturn(fciInfoValue);

		com.airtelbank.transaction.model.ResponseDTO<com.airtelbank.transaction.dto.cbs.FCIDetailResponse> response = transactionServiceImpl
				.getFCIDetailsById("1234456");
		assertNotNull(response);
	}

	@Test
	public void getFCIDetailsByIdNullTest() {
		Mockito.when(aerospikeTemplate.findById(Mockito.anyString(), Mockito.any())).thenReturn(null);

		com.airtelbank.transaction.model.ResponseDTO<com.airtelbank.transaction.dto.cbs.FCIDetailResponse> response = transactionServiceImpl
				.getFCIDetailsById("1234456");
		assertNotNull(response);
	}
	
	@Test
	public void getFCIDetailsByIdExceptionTest() {
		Mockito.when(aerospikeTemplate.findById(Mockito.anyString(), Mockito.any())).thenThrow(new RuntimeException(""));

		com.airtelbank.transaction.model.ResponseDTO<com.airtelbank.transaction.dto.cbs.FCIDetailResponse> response = transactionServiceImpl
				.getFCIDetailsById("1234456");
		assertNotNull(response);
	}
	
	@Test
	public void getCircleCodeInfoTest1() {

		FCIConfiguration fciConfig = new FCIConfiguration();
		fciConfig.setHighFciArr("12");
		fciConfig.setHighAchArr("123");
		fciConfig.setLowFciArr("123");
		fciConfig.setLowAchArr("23");

		Mockito.when(aerospikeTemplate.findById(Mockito.anyString(), Mockito.any())).thenReturn(fciConfig);

		AllowedCustomer allowedCustomer = new AllowedCustomer(8552958666L);

		ResponseEntity<com.airtelbank.transaction.model.ResponseDTO<Object>> response = getResponseEntitySuccess(
				new com.airtelbank.transaction.model.ResponseDTO<Object>());
		Meta meta = new Meta();
		meta.setStatus(0);
		response.getBody().setMeta(meta);
		response.getBody().setData(getCustomerProfileDto());
		Mockito.when(restUtil.sendHttpRequest(Mockito.any(RestRequest.class))).thenReturn(response);
		ResponseDTO<FCIResponseDTO> response1 = transactionServiceImpl.getCircleCodeInfo("NE", "123445", "123441", "",
				"");
		assertNotNull(response1);
	}
	
	@Test
	public void getRetailerProfileDetailsTest() {
		RequestDTO<CBSFCIDetailsRequest> fciDetailsRequest = getFciDetails();
		Retailer retailer = new Retailer();
		retailer.setNationality("IN");
		retailer.setNatlId("9811111112");

		Mockito.when(restUtil.sendHttpRequest(Mockito.any(RestRequest.class))).thenReturn(getResponseEntitySuccess(getResponseDTO(retailer)));

		com.airtelbank.transaction.model.ResponseDTO<?> response2 = transactionServiceImpl
				.saveFCIDetails(fciDetailsRequest, "content", "chennel");
		assertNotNull(response2);
	}

	@Test(expected = GenericException.class)
	public void getRetailerProfileDetailsFailTest() {
		RequestDTO<CBSFCIDetailsRequest> fciDetailsRequest = getFciDetails();
		Mockito.when(restUtil.sendHttpRequest(Mockito.any(RestRequest.class)))
				.thenThrow(new ResourceAccessException(""));
		transactionServiceImpl.saveFCIDetails(fciDetailsRequest, "content", "chennel");
	}

	@Test(expected = GenericException.class)
	public void getRetailerProfileDetailsFailTest1() {
		RequestDTO<CBSFCIDetailsRequest> fciDetailsRequest = getFciDetails();
		Mockito.when(restUtil.sendHttpRequest(Mockito.any(RestRequest.class))).thenThrow(new RestClientException(""));
		transactionServiceImpl.saveFCIDetails(fciDetailsRequest, "content", "chennel");
	}

	@Test(expected = GenericException.class)
	public void getRetailerProfileDetailsFailTest2() {
		RequestDTO<CBSFCIDetailsRequest> fciDetailsRequest = getFciDetails();
		Mockito.when(restUtil.sendHttpRequest(Mockito.any(RestRequest.class))).thenReturn(null);
		transactionServiceImpl.saveFCIDetails(fciDetailsRequest, "content", "chennel");
	}
	
	@Test(expected = Exception.class)
	public void getRetailerProfileDetailsFailTest3() {
		RequestDTO<CBSFCIDetailsRequest> fciDetailsRequest = getFciDetails();
		Mockito.when(restUtil.sendHttpRequest(Mockito.any(RestRequest.class))).thenReturn(getResponseEntitySuccess(getResponseDTO(null)));
		transactionServiceImpl.saveFCIDetails(fciDetailsRequest, "content", "chennel");
	}
	
	@Test
	public void saveFCIDetailsTest1() {
		RequestDTO<CBSFCIDetailsRequest> fciDetailsRequest = getFciDetails();
		FCIConfiguration fciConfig = new FCIConfiguration();
		fciConfig.setLowFci("0");

		Retailer retailer = new Retailer();
		retailer.setNationality("IN");
		retailer.setNatlId("9811111112");
		Mockito.when(restUtil.sendHttpRequest(Mockito.any(RestRequest.class)))
				.thenReturn(getResponseEntitySuccess(getResponseDTO(retailer)));

		Mockito.when(aerospikeTemplate.findById(Mockito.any(), Mockito.any())).thenReturn(fciConfig);

		com.airtelbank.transaction.model.ResponseDTO<?> response2 = transactionServiceImpl
				.saveFCIDetails(fciDetailsRequest, "content", "chennel");
		assertNotNull(response2);
	}
	
	@Test
	public void saveFCIDetailsTest2() {
		RequestDTO<CBSFCIDetailsRequest> fciDetailsRequest = getFciDetails();
		FCIConfiguration fciConfig = new FCIConfiguration();
		fciConfig.setLowFci("0");

		Retailer retailer = new Retailer();
		retailer.setCategoryCode("2030");
		List<AccountResponse> list=new ArrayList<AccountResponse>();
		AccountResponse accountResponse = new AccountResponse();
		accountResponse.setAccountNumber("1000069444");
		accountResponse.setBalance(new Balance());
		list.add(accountResponse);
		retailer.setAccountList(list);	
		Mockito.when(restUtil.sendHttpRequest(Mockito.any(RestRequest.class))).thenReturn(getResponseEntitySuccess(getResponseDTO(retailer)));

		Mockito.when(aerospikeTemplate.findById(Mockito.any(), Mockito.any())).thenReturn(fciConfig);

		com.airtelbank.transaction.model.ResponseDTO<?> response2 = transactionServiceImpl
				.saveFCIDetails(fciDetailsRequest, "content", "chennel");
		assertNotNull(response2);
	}
	
	@Test
	public void saveFCIDetailsTest3() {
		RequestDTO<CBSFCIDetailsRequest> fciDetailsRequest = getFciDetails1();
		FCIConfiguration fciConfig = new FCIConfiguration();
		fciConfig.setLowFci("0");
		fciConfig.setCircleCode("NE");
		fciConfig.setHighFciArr("123,500,700");
		fciConfig.setHighAchArr("223,400,600,800");
	
		Mockito.when(restUtil.sendHttpRequest(Mockito.any(RestRequest.class))).thenReturn(getResponseEntitySuccess(getResponseDTO(null)));
		Mockito.when(aerospikeTemplate.findById("NE", FCIConfiguration.class)).thenReturn(fciConfig);

		com.airtelbank.transaction.model.ResponseDTO<?> response2 = transactionServiceImpl
				.saveFCIDetails(fciDetailsRequest, "content", "chennel");
		assertNotNull(response2);
	}
	

	
	@Test
	public void saveFCIDetailsTest5() {
		RequestDTO<CBSFCIDetailsRequest> fciDetailsRequest = getFciDetails1();
		FCIConfiguration fciConfig = new FCIConfiguration();
		fciConfig.setLowFci("0");
		fciConfig.setCircleCode("NE");
		fciConfig.setHighFciArr("123,400,1100");
		fciConfig.setHighAchArr("223,400,450,500");
	
		Mockito.when(restUtil.sendHttpRequest(Mockito.any(RestRequest.class))).thenReturn(getResponseEntitySuccess(getResponseDTO(null)));
		Mockito.when(aerospikeTemplate.findById("NE", FCIConfiguration.class)).thenReturn(fciConfig);

		com.airtelbank.transaction.model.ResponseDTO<?> response2 = transactionServiceImpl
				.saveFCIDetails(fciDetailsRequest, "content", "chennel");
		assertNotNull(response2);
	}

	@Test(expected = ArrayIndexOutOfBoundsException.class)
	public void saveFCIDetailsTest6() {
		RequestDTO<CBSFCIDetailsRequest> fciDetailsRequest = getFciDetails1();
		FCIConfiguration fciConfig = new FCIConfiguration();
		fciConfig.setLowFci("0");
		fciConfig.setCircleCode("NE");
		fciConfig.setHighFciArr("123,400,1100");
		fciConfig.setHighAchArr("223,400,450,500");
		fciConfig.setLowFciArr("123,345");
		fciConfig.setLowAchArr("234,456");

		Mockito.when(restUtil.sendHttpRequest(Mockito.any(RestRequest.class))).thenReturn(getResponseEntitySuccess(getResponseDTO(null)));
		Mockito.when(aerospikeTemplate.findById("NE", FCIConfiguration.class)).thenReturn(fciConfig);
		Mockito.when(aerospikeTemplate.findById(Long.valueOf(fciDetailsRequest.getData().getMobileNumber()), AllowedCustomer.class)).thenReturn(new AllowedCustomer());
		Mockito.when(aerospikeTemplate.findById(Long.valueOf(fciDetailsRequest.getData().getRetailerMobileNumber()), AllowedRetailer.class)).thenReturn(new AllowedRetailer());

		com.airtelbank.transaction.model.ResponseDTO<?> response2 = transactionServiceImpl
				.saveFCIDetails(fciDetailsRequest, "content", "chennel");
		assertNotNull(response2);
	}

	@Test
	public void getTransactionStateTest() {
		AppIdToPaymentReqId request = new AppIdToPaymentReqId();
		request.setAppId("12344334");
		List<String> paymentList=new ArrayList<>();
		paymentList.add("879919");
		request.setPaymentReqId(paymentList);


		Mockito.when(aerospikeTemplate.findById("12344334", AppIdToPaymentReqId.class)).thenReturn(request);
		
		TransactionStore transStore = new TransactionStore();
		transStore.setAmount("500");
		
		Mockito.when(aerospikeTemplate.findById("879919", TransactionStore.class)).thenReturn(transStore);
		com.airtelbank.transaction.model.ResponseDTO<TransactionStateResponseDTO> transactionState = transactionServiceImpl
				.getTransactionState("12344334");
		assertNotNull(transactionState);
	}
	
	@Test
	public void getTransactionStateTest1() {
		AppIdToPaymentReqId request = new AppIdToPaymentReqId();
		request.setAppId("12344334");
		List<String> paymentList=new ArrayList<>();
		paymentList.add("879919");
		request.setPaymentReqId(paymentList);
		Mockito.when(aerospikeTemplate.findById(Mockito.anyString(), Mockito.any())).thenReturn(request);

		com.airtelbank.transaction.model.ResponseDTO<TransactionStateResponseDTO> transactionState = transactionServiceImpl
				.getTransactionState("12344334");
		assertNotNull(transactionState);
	}
	
	@Test
	public void getTransactionStateTest2() {
		AppIdToPaymentReqId request = new AppIdToPaymentReqId();
		request.setAppId("12344334");
		Mockito.when(aerospikeTemplate.findById(Mockito.anyString(), Mockito.any())).thenReturn(null);

		com.airtelbank.transaction.model.ResponseDTO<TransactionStateResponseDTO> transactionState = transactionServiceImpl
				.getTransactionState("12344334");
		assertNotNull(transactionState);
	}


	@Test
	public void paymentEnquiryTest() {
		AppIdToPaymentReqId request = new AppIdToPaymentReqId();
		request.setAppId("12344334");
		Mockito.when(ruleStrategyFactory.getRuleStrategyFactory(Mockito.anyString())).thenReturn(shgTransactionRuleStrategy);
		ResponseDTO<String > responseDTO = new ResponseDTO<>();
		responseDTO.setData("Success");
		when(shgTransactionRuleStrategy.paymentHubEnquiry(Mockito.any(),Mockito.any())).thenReturn(responseDTO);

		ResponseDTO<String> transactionState = transactionServiceImpl
				.paymentEnquiry(getTransactionEnquiryRequest(),getHeaderRequestDTO());
		assertEquals("Success",transactionState.getData());
	}

}
