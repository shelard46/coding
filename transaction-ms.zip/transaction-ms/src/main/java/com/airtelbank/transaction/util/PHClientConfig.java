package com.airtelbank.transaction.util;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.airtelbank.payments.hub.client.model.PHEnvironment;
import com.airtelbank.payments.hub.client.utility.PHInitialiseEnvironment;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class PHClientConfig {
	

	@Value("${config.sba.payment.hub.salt}")
	private String salt;

	@Value("${config.sba.payment.hub.partnerId}")
	private String partnerId;

	@Value("${config.sba.payment.hub.baseUrl}")
	private String baseUrl;
	
	@Value("${config.sba.payment.hub.serviceFulfilmentTopic}")
	private String serviceFulfilmentTopic;
	
	public void init(String useCase) {
		PHEnvironment PhEnvironment = PHEnvironment.builder().baseUrl(baseUrl).salt(salt).partnerId(partnerId).build();
		PHInitialiseEnvironment.init(PhEnvironment, useCase);
	}

	public void fullFillmentInit(String useCase) {
		PHEnvironment PhEnvironment = PHEnvironment.builder().baseUrl(baseUrl).salt(salt).partnerId(partnerId).
				serviceFulfilmentTopic(serviceFulfilmentTopic).build();
		PHInitialiseEnvironment.init(PhEnvironment, useCase);
	}
}
