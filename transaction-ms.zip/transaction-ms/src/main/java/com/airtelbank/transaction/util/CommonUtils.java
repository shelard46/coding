package com.airtelbank.transaction.util;

import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.stereotype.Service;
import org.springframework.web.util.UriComponents;
import org.springframework.web.util.UriComponentsBuilder;

import com.airtelbank.transaction.constant.Constants;
import com.airtelbank.transaction.dto.LoggerModel;
import com.airtelbank.transaction.model.HeaderRequestDTO;
import com.airtelbank.transaction.model.Meta;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import lombok.extern.slf4j.Slf4j;

@Service
@RefreshScope
@Slf4j
public class CommonUtils {
	private static final Logger logger = LoggerFactory.getLogger(CommonUtils.class);

	public static String getURLfromUri(String uriTemplate, Object... params) {
		if (params == null || params.length == 0) {
			return uriTemplate;
		} else {
			UriComponents uriComponents = UriComponentsBuilder.fromUriString(uriTemplate).build();
			uriComponents = uriComponents.expand(params);
			return uriComponents.toUriString();
		}
	}

	public static LoggerError setLoggerError(Meta meta) {
		if (null == meta) {
			return null;
		}
		LoggerError logError = new LoggerError();
		logError.setStatus(String.valueOf(meta.getStatus()));
		logError.setErrorCode(meta.getCode());
		logError.setErrorDescription(meta.getDescription());
		return logError;
	}
	
	public static Meta getResponseMeta(Meta meta, String code, int status, String description) {
		meta.setCode(code);
		meta.setStatus(status);
		meta.setDescription(description);
		return meta;
	}
	public static String jsonObjectToString(Object jsonObject) {
		String jsonOutput = null;
		try {
			Gson gson = new GsonBuilder().setPrettyPrinting().create();
			jsonOutput = gson.toJson(jsonObject);
		} catch (Exception ex) {
			log.info("Exception while converting json object to string");
		}
		return jsonOutput;
	}
	
	public static String errorPrefixSuffix(String message) {
		String finalMessage = null;
		if (message != null) {
			finalMessage = Constants.ERROR_MSG_PREFIX + message + Constants.ERROR_MSG_SUFFIX;
		}
		return finalMessage;
	}
	
	public static void printRecordMetaData(ConsumerRecord<String, ?> payload) {
		try {
			if (payload != null)
				logger.info("Records Metadata ======> {Topic = " + payload.topic() + ", Partition = "
						+ payload.partition() + ", Offset = " + payload.offset() + ", " + payload.timestampType()
						+ " = " + payload.timestamp() + "} <======");
		} catch (Exception ex) {
			logger.error("Exception while printing metadata of record {}", ex);
		}
	}

	public static LoggerModel.LoggerError setLoggerErrorMessage(com.airtelbank.payments.hub.client.dto.response.Meta meta) {
		if (null == meta) {
			return null;
		}
		LoggerModel.LoggerError loggerError = new LoggerModel.LoggerError();
		loggerError.setErrorCode(meta.getCode());
		loggerError.setErrorDescription(meta.getDescription());
		loggerError.setStatus(meta.getStatus());
		return loggerError;
	}
	
	public static HeaderRequestDTO createHeader(String customerHandleNumber, String channel) {
		HeaderRequestDTO header = new HeaderRequestDTO();
		header.setChannel(channel);
		header.setCustomerHandleNumber(customerHandleNumber);
		return header;
	}
	public static boolean isValidAction(String flowkey, String action) {
		return flowkey.startsWith(action);
	}
}
