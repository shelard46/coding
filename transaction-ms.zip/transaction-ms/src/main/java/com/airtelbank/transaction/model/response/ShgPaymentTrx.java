package com.airtelbank.transaction.model.response;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@Builder
@ToString
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_EMPTY)
@JsonIgnoreProperties(ignoreUnknown = true)
public class ShgPaymentTrx {

    private String appId;
    private String flowKey;
    private String status;
    private String mobileNum;
    private String authSig1;
    private String authSig2;
    private String description;
    private String createdTime;
    private String updateTime;
    private String appType;
    private String key;
    private String mpinResponse;
    private String retailerMobile;
    private String retailerAccountNo;
    private String state;
}
