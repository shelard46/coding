package com.airtelbank.transaction.dto.retailerprofile;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.datatype.jsr310.deser.LocalDateDeserializer;
import com.fasterxml.jackson.datatype.jsr310.deser.LocalDateTimeDeserializer;
import com.fasterxml.jackson.datatype.jsr310.ser.LocalDateSerializer;
import com.fasterxml.jackson.datatype.jsr310.ser.LocalDateTimeSerializer;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;

@Data
@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_EMPTY)
@ToString
public class Retailer {

    @NotNull
    @Size(min = 10,max = 12)
    private String natlId;
    @NotNull
    @Size(min = 1,message="Can not be empty")
    private String sex;
    private String maritalStatus;
    private String educationLevel;
    private String motherMaidenName;
    private String fatherOrHusbandName;
    private String countryOfResidence;
    private String nationality;
    @NotNull
    private Map<String,String> mobileNumberMap;
    private Map<String,String> emailAddressMAp;
    private String circle;
    @NotNull
    @Size(min = 1,message="Can not be empty")
    private String customerType;
    @NotNull
    @JsonDeserialize(using = LocalDateDeserializer.class)
    @JsonSerialize(using = LocalDateSerializer.class)
    private LocalDate dateOfBirthOrRegistration;

    @JsonDeserialize(using = LocalDateTimeDeserializer.class)
    @JsonSerialize(using = LocalDateTimeSerializer.class)
    private LocalDateTime customerCreationDate;

    @JsonDeserialize(using = LocalDateTimeDeserializer.class)
    @JsonSerialize(using = LocalDateTimeSerializer.class)
    private LocalDateTime modificationDate;

    @JsonDeserialize(using = LocalDateTimeDeserializer.class)
    @JsonSerialize(using = LocalDateTimeSerializer.class)
    private LocalDateTime activationDateTime;
    private String regStatus;
    @Valid
    private Map<String,Address> addressMap;
    @Valid
    private Name name;
    private Employment employment;
    private String language;
    @Valid
    private CustomerMiscellanoeus miscellaneous;
    private String categoryCode;
    @Valid
    private Benefits benefits;

    private String image;
    private String custId;
    private String subAccountType;

    private String newCustomerType;
    private String customerSegment;

    private String incomeAgriculture;
    private String incomeNonAgriculture;
    private String annualIncome;
    private String pan;
    private String aadhaarId;
    private String amountFirstCashIn;
    private NomineeDetails nominee;
    private GuardianDetails guardian;
    private String panAckNo;
    private LocalDateTime panApplicationDate;

    private List<AccountResponse> accountList;
    private String aadhaarReferenceNumber;


    }
