package com.airtelbank.transaction.service.impl;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.aerospike.core.AerospikeTemplate;
import org.springframework.stereotype.Service;

import com.airtelbank.payments.hub.client.dto.kafka.FulfilmentStatus;
import com.airtelbank.payments.hub.client.dto.kafka.PaymentStatus;
import com.airtelbank.payments.hub.client.model.FulfilmentDetails;
import com.airtelbank.payments.hub.client.service.PHTxnStatusConsumerService;
import com.airtelbank.payments.hub.client.service.impl.PHServiceFulfilmentProducerServiceImpl;
import com.airtelbank.transaction.aerospike.entity.TransactionStore;
import com.airtelbank.transaction.constant.Constants;
import com.airtelbank.transaction.dto.intermediateDTOs.RewardsDTO;
import com.airtelbank.transaction.producer.CustomerRewardProducer;
import com.airtelbank.transaction.service.AuditService;
import com.airtelbank.transaction.util.PHClientConfig;

import lombok.extern.slf4j.Slf4j;

@Service(value = "retailer.onboarding.sba")
@Slf4j
public class PHTxnStatusConsumerServiceImpl implements PHTxnStatusConsumerService {

	SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSSSSS");

	@Autowired
	private AerospikeTemplate aerospikeTemplate;
	
	@Value("${config.transaction.create.aerospike.retry.count}")
	private int aerospikeRetryCount;
	
	@Autowired
	PHServiceFulfilmentProducerServiceImpl pHServiceFulfilmentProducerServiceImpl;
	
	@Autowired
	AuditService auditService;
	
	@Value("${config.sba.payment.hub.case.onboarding.usecase}")
	private String retailerOnboardingUseCase;
	
	@Autowired
	private PHClientConfig pHClientConfig;
	
	@Autowired
	private CustomerRewardProducer customerRewardProducer;

	/*
		We receive the response(Kafka topic :- PHOnboardingSbaTxnStatus) from PaymentsHub team
		and  If the response is succesfull, we shall perform following tasks :-

			1.) We are hitting to API (http://10.56.110.191:9072/api/v4/customers/appId/{appId})
				in order to get the details of the customer. It returns the offerMap, with the
				help of which, we check, whether user has taken any offer or not.

			2.) We are hitting to Traveller-Pack
			API(http://10.56.110.189:8096/api/v1/content/addons/retailerTravellerPack.offers),
			in order to get the details of the Rewards-Amount.

			3.) We are pushing this data onto this topic: “onb-activateAddOnViaAssistedChannel”
			for enabling offer which will be consumed by the rewards team.
			(customerId=918767867990, custType=SBA, contentId=3C7AR, amount=299,
			retailerNumber=9837001239, channel=RAPP, addOnName=REWARD123, action=CREATE,
			creChannel=WEB)
	 */
	@Override
	public void txnStatus(PaymentStatus paymentStatus) {
		String debitStatus = null;
		boolean updateOperationToDataStore = false;
		pHClientConfig.fullFillmentInit(retailerOnboardingUseCase);
		if (paymentStatus != null) {
			log.info("Payment status received for useCase: {}, prId: {} - {}", paymentStatus.getUseCase(),
					paymentStatus.getPaymentReqId(), paymentStatus.toString());
			String paymentRequestid = paymentStatus.getPaymentReqId();
			if (paymentStatus.getDebitDetails() != null) {
				debitStatus = paymentStatus.getDebitDetails().get(0).getStatus();
			}
			updateOperationToDataStore = saveInAerospike(paymentRequestid, debitStatus);
			
			if (updateOperationToDataStore && debitStatus.equals(Constants.SUCCESS)) {
				TransactionStore transactionStore = aerospikeTemplate.findById(paymentRequestid, TransactionStore.class);
				RewardsDTO rewardsDTOObject = new RewardsDTO();
				if (transactionStore != null) {
					rewardsDTOObject.setAppId(transactionStore.getAppId());
					rewardsDTOObject.setChannel(paymentStatus.getChannel());
					rewardsDTOObject.setRetailerNumber(transactionStore.getDepositerMobileNumber());
				}
				customerRewardProducer.produceRewardsStatus(rewardsDTOObject);

				log.info("Fullfillment status details for prId :{} ,Status :{}", paymentRequestid, Constants.SUCCESS);
				List<FulfilmentDetails> fulfilmentDetails = new ArrayList<>();
				FulfilmentDetails details = new FulfilmentDetails();
				details.setOrderItemId(paymentStatus.getOrderId());
				details.setStatus(debitStatus);
				fulfilmentDetails.add(details);
				FulfilmentStatus fulfilmentStatus = FulfilmentStatus.builder().useCase(paymentStatus.getUseCase())
						.orderId(paymentStatus.getOrderId()).paymentReqId(paymentStatus.getPaymentReqId())
						.fulfilmentDetails(fulfilmentDetails).build();
				pHServiceFulfilmentProducerServiceImpl.sendFulfilmentStatus(paymentStatus.getUseCase(),
						fulfilmentStatus);
				log.info(
						"Inside PHTxnStatusConsumerServiceImpl::getTransactionEnquiry Produced Fullfillment status details for prId :{} , Status :{}",
						paymentStatus.getPaymentReqId(), Constants.SUCCESS);
			}else {
				log.info("Inside PHTxnStatusConsumerServiceImpl::getTransactionEnquiry Produced Fullfillment status details for prId :{} , Status :{}",
						paymentStatus.getPaymentReqId(), Constants.FAILED);
			}
		} else {
			log.info("Inside PHTxnStatusConsumerServiceImpl::txnStatus , PaymnetStatus object is empty for usecase: {} ",
					retailerOnboardingUseCase);
		}
	}

	// prId stands for paymentRequestId.
	private boolean saveInAerospike(String prId, String status) {
		boolean isSuccess = false;
		int retryCounter = 0;
		while (retryCounter <= aerospikeRetryCount) {
			try {
				log.info("Trying to insert entry into TransactionStore for prId :{}:", prId);
				TransactionStore transactionStore = aerospikeTemplate.findById(prId, TransactionStore.class);
				transactionStore.setStatus(status);
				transactionStore.setUpdateDate(simpleDateFormat.format(new Date()));
				aerospikeTemplate.save(transactionStore);
				isSuccess = true;
				break;
			} catch (Exception ex) {
				try {
					Thread.sleep(100);
				} catch (InterruptedException e) {
					isSuccess = false;
					log.error("InterruptedException while putting entry into transaction in Aerospike: for prId :{}:",
							prId, e);
				}
				isSuccess = false;
				log.error("Failed while putting entry into transaction in Aerospike: for prId :{}:", prId, ex);
				retryCounter++;
				if (retryCounter > aerospikeRetryCount) {
					log.error("Max retries exceeded for creating entry into transaction!");
				}
			}
		}
		return isSuccess;

	}
}
