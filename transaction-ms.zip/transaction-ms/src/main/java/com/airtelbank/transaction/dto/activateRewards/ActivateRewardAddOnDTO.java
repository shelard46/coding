package com.airtelbank.transaction.dto.activateRewards;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

/* THis is the object pushed to Kafka topic "onb-activateAddOnViaAssistedChannel" in case of succes
response from the PaymentsHub.
*/

@Setter
@Getter
@NoArgsConstructor
@AllArgsConstructor
@ToString
@Builder
public class ActivateRewardAddOnDTO {

	private String customerId;
	private String custType;
	private String contentId;
	private String amount;
	private String retailerNumber;
	private String channel;
	private String addOnName;
	private String action;
	private String creChannel;

}
