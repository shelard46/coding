package com.airtelbank.transaction.dto;

import lombok.*;

/**
 * @author A1W87715
 */
@Setter
@Getter
@NoArgsConstructor
@AllArgsConstructor
@ToString
@Builder
public class TransactionReqDTO {

    private String customerHandlerNumber;
}
