package com.airtelbank.transaction.service;

import com.airtelbank.payments.hub.client.dto.response.DirectPaymentResponse;
import com.airtelbank.payments.hub.client.dto.response.PaymentEnquiryResponse;
import com.airtelbank.payments.hub.client.dto.response.ResponseDTO;
import com.airtelbank.transaction.dto.cbs.CBSFCIDetailsRequest;
import com.airtelbank.transaction.dto.cbs.FCIDetailResponse;
import com.airtelbank.transaction.dto.fciCircleBased.FCIResponseDTO;
import com.airtelbank.transaction.dto.response.TransactionStateResponseDTO;
import com.airtelbank.transaction.model.HeaderRequestDTO;
import com.airtelbank.transaction.model.RequestDTO;
import com.airtelbank.transaction.model.TransactionEnquiryRequest;
import com.airtelbank.transaction.model.TransactionRequestDTO;

public interface TransactionService {

	ResponseDTO<DirectPaymentResponse> onboardingUsecaseToPaymentHub(TransactionRequestDTO transactionRequestDTO,
			HeaderRequestDTO headerRequestDTO,String amount) throws Exception;

	public ResponseDTO<FCIResponseDTO> getCircleCodeInfo(String circleCode, String retailerId, String customerId ,String contentId ,String channel);

	public com.airtelbank.transaction.model.ResponseDTO<?> saveFCIDetails(
			RequestDTO<CBSFCIDetailsRequest> fciDetailsRequest, String contentId, String channel);

	public com.airtelbank.transaction.model.ResponseDTO<FCIDetailResponse> getFCIDetailsById(String appId);

	public com.airtelbank.transaction.model.ResponseDTO<TransactionStateResponseDTO> getTransactionState(String appId);

	ResponseDTO<String> paymentEnquiry(TransactionEnquiryRequest transactionEnquiryRequest,HeaderRequestDTO headerRequestDTO);


}