package com.airtelbank.transaction.model;


import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Setter
@Getter
@NoArgsConstructor
@AllArgsConstructor
@ToString
@Builder
@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class TransactionRequestDTO {

	private String accountNumber;

	private String appId;
	
	private String customerId;
	
	private String customerName;

	private String customerMobileNo;

	private String mpin;

	private String useCase;

	private String retailAccountNumber;

	private String retailCash;

	private String retailCustID;

	private String retailMobileNumber;

	private String retailerName;

	private String afcCharge;

	private String contentId;

	private String channel;

	private AccountDetails sourceDetails;

	private AccountDetails targetDetails;

	private String amount;

	private String description;


}
