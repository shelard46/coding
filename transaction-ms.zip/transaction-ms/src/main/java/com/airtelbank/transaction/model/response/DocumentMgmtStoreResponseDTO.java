package com.airtelbank.transaction.model.response;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.HashMap;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder(toBuilder = true)
@JsonInclude(JsonInclude.Include.NON_EMPTY)
@JsonIgnoreProperties(ignoreUnknown = true)
public class DocumentMgmtStoreResponseDTO {

	    private String                        Id;			// Flow key will be Id

	    private String                        customerHandleType; // generic customerHandle like mobile

	    private String                        customerHandleNumber; // generic customerHandleNumber like mobileNumber

	 
	    private String                        appType; // (e.g. SHGTRX)

	   
	    private String                        appId; // (e.g. AppId i.e. ApplicationId)

	  
	    private String                        createTime;

	
	    private String                        updateTime;

	    /**
	     * Below Map will store AUA Response
	     */

	    private HashMap<String, Object> docAuxiliaryInfo;




}
