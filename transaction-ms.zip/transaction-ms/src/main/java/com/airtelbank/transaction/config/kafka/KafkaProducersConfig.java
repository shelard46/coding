package com.airtelbank.transaction.config.kafka;

import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.common.serialization.StringSerializer;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.kafka.core.DefaultKafkaProducerFactory;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.core.ProducerFactory;
import org.springframework.kafka.support.serializer.JsonSerializer;

import java.util.HashMap;
import java.util.Map;

@Configuration
@RefreshScope
public class KafkaProducersConfig<T> {

	@Value(value = "${kafka.bootstrap.server}")
	private String bootstrapAddress;

	@Value(value = "${kafka.producer.retry.count}")
	private int retrycount;

	@Value(value = "${kafka.producer.acks.config}")
	private String acksConfig;

	@Value(value = "${kafka.producer.bufferMemory.config}")
	private String buffConfig;

	@Value(value = "${kafka.producer.batch.config}")
	private String batchConfig;

	@Value(value = "${kafka.producer.reqTimeout.config}")
	private String reqTimeOutConfig;

	@Value(value = "${kafka.producer.typeInfo.config}")
	private String typeInfoConfig;

	@Value(value = "${kafka.producer.linger.config}")
	private String lingerConfig;

	@Bean
	public ProducerFactory<String, T> producerFactory(String bootstrapAddress) {
		Map<String, Object> configProps = new HashMap<>();
		configProps.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, bootstrapAddress);
		configProps.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, StringSerializer.class);
		configProps.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, JsonSerializer.class);
		configProps.put(ProducerConfig.LINGER_MS_CONFIG, lingerConfig);
		configProps.put(JsonSerializer.ADD_TYPE_INFO_HEADERS, typeInfoConfig);
		configProps.put(ProducerConfig.RETRIES_CONFIG, retrycount);
		configProps.put(ProducerConfig.ACKS_CONFIG, acksConfig);
		configProps.put(ProducerConfig.BUFFER_MEMORY_CONFIG, buffConfig);
		configProps.put(ProducerConfig.BATCH_SIZE_CONFIG, batchConfig);
		configProps.put(ProducerConfig.REQUEST_TIMEOUT_MS_CONFIG, reqTimeOutConfig);

		return new DefaultKafkaProducerFactory<>(configProps);
	}

	@Primary
	@Bean(name = "kafkaTemplate")
	public KafkaTemplate<String, T> kafkaTemplateOldCluster() {
		return new KafkaTemplate<>(producerFactory(bootstrapAddress));
	}

}
