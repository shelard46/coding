package com.airtelbank.transaction.strategy;

import com.airtelbank.payments.hub.client.dto.response.DirectPaymentResponse;
import com.airtelbank.transaction.model.HeaderRequestDTO;
import com.airtelbank.payments.hub.client.dto.response.ResponseDTO;
import com.airtelbank.transaction.model.TransactionEnquiryRequest;
import com.airtelbank.transaction.model.TransactionRequestDTO;

public interface TransactionRuleStrategy {
    ResponseDTO<DirectPaymentResponse> onboardingUsecaseToPaymentHub(TransactionRequestDTO transactionRequestDTO,
                                                                     HeaderRequestDTO headerRequestDTO, String amount);


    ResponseDTO<String> paymentHubEnquiry(TransactionEnquiryRequest transactionEnquiryRequest, HeaderRequestDTO headerRequestDTO);

}
