package com.airtelbank.transaction.dto.customerState;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@ToString
@AllArgsConstructor
@Builder
public class CustomerStateResponse {
	private String customerId;
	private String customerState;
	private CustomerStateDetailsDataDTO customerDetail;
}
