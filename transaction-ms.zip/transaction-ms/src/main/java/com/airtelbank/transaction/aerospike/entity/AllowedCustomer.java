package com.airtelbank.transaction.aerospike.entity;

import org.springframework.data.aerospike.mapping.Document;
import org.springframework.data.aerospike.mapping.Field;
import org.springframework.data.annotation.Id;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.NoArgsConstructor;

@Builder
@Document
@NoArgsConstructor
@AllArgsConstructor
public class AllowedCustomer {
	@Id
	@Field(value = "PK")
	private Long customerId;
}
