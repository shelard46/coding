package com.airtelbank.transaction.exception;

import com.airtelbank.transaction.model.Meta;
import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Setter
@Getter
@ToString
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class GenericException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = -3201228269077444961L;
	private Meta meta;
	private String errorCode;
	private String errorMessage;

	public GenericException(String errorCode, String errorMessage) {
		super(errorMessage);
		this.errorCode = errorCode;
		this.errorMessage = errorMessage;
	}

	public GenericException(String errorMessage) {
		super(errorMessage);
		this.errorMessage = errorMessage;
	}

	public GenericException(Meta meta) {
		this.meta = meta;
	}
}
