package com.airtelbank.transaction.dto.customerProfile;

import java.io.Serializable;

import org.springframework.data.aerospike.mapping.Field;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.*;



@Setter
@Getter
@ToString
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_EMPTY)
@JsonIgnoreProperties(ignoreUnknown = true)
public class Identity implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@Field("idntType")
	private String type;
	private String isPoa;
	private String isPoi;
	private String status;
	private String ackNumber;
	private String uid;
	private String applyDate;
	private String issueAuthority;
	private String issueDate;
	private String expiryDate;
	private String issuePlace;
	private String id;
}
