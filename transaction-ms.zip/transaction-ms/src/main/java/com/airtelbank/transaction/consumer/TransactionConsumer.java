package com.airtelbank.transaction.consumer;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.data.aerospike.core.AerospikeTemplate;
import org.springframework.http.ResponseEntity;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.support.Acknowledgment;
import org.springframework.stereotype.Service;

import com.airtelbank.payments.hub.client.dto.response.DirectPaymentResponse;
import com.airtelbank.payments.hub.client.dto.response.ResponseDTO;
import com.airtelbank.transaction.aerospike.entity.FCIInfoDetails;
import com.airtelbank.transaction.constant.Constants;
import com.airtelbank.transaction.dto.response.CustomerOfferDetails;
import com.airtelbank.transaction.model.HeaderRequestDTO;
import com.airtelbank.transaction.model.TransactionRequestDTO;
import com.airtelbank.transaction.service.TransactionService;
import com.airtelbank.transaction.util.JsonUtils2;
import com.airtelbank.transaction.util.LoggingUtil;
import com.airtelbank.transaction.util.TransactionHelperUtil;
import com.fasterxml.jackson.databind.ObjectMapper;

import lombok.extern.slf4j.Slf4j;

@Service
@RefreshScope
@Slf4j
public class TransactionConsumer<T> {
	private static final Logger LOGGER = LoggerFactory.getLogger(TransactionConsumer.class);

	@Autowired
	private LoggingUtil loggingUtil;

	@Autowired
	private TransactionService transactionService;

	@Autowired
	private TransactionHelperUtil transactionServiceHelper;

	@Autowired
	private AerospikeTemplate aerospikeTemplate;

	/*
	 * PROD : kafka.createCustomer.success.topic= customer-pipeline-success
	 * This consumer performs following action: We check from FCIDetails.ACCOUNT_TYPE Aerospike set :
	 	* whether AccountType is "Rewards123" OR "BHAROSA".
	 		* If its BHAROSA type of account, directly we would send to Payments-Hub API, in order to debit the retailer
	 			* & credit the customer’s SBA account.
	 		* If its REWARDS123 type of account, then we are doing following stuff :- Checking for that customer whether
	 			* REWARDS is enabled by calling the API (V4 GET /customers/{customerId}/offers). If it's TRUE, then we call to PaymentsHub.
	 */

	@KafkaListener(topics = "${kafka.createCustomer.success.topic}", containerFactory = "customerPipelineSuccessContainerFactory")
	public void transactionPaymentConsumer(String payload, Acknowledgment acknowledgment) {
		LOGGER.info("Starting TransactionConsumer::transactionPaymentConsumer");
		acknowledgment.acknowledge();
		ObjectMapper objectMapper = new ObjectMapper();
		TransactionRequestDTO consumerRequest = null;
		HeaderRequestDTO headerRequestDTO = null;
		FCIInfoDetails fciInfoValue = null;
		ResponseDTO<DirectPaymentResponse> response = null;
		try {
			headerRequestDTO = new HeaderRequestDTO();
			consumerRequest = JsonUtils2.jsonToEntity(payload, TransactionRequestDTO.class, objectMapper);
			log.info("Received Transaction request for accountNumber: {} from usecase: {}",
					consumerRequest.getAccountNumber(), consumerRequest.getUseCase());
			headerRequestDTO.setContentid(consumerRequest.getContentId());
			headerRequestDTO.setChannel(consumerRequest.getChannel());
			fciInfoValue = aerospikeTemplate.findById(consumerRequest.getAppId(), FCIInfoDetails.class);
			if (fciInfoValue != null && fciInfoValue.getAccountType() != null
					&& fciInfoValue.getAccountType().contains("Rewards123")
					&& fciInfoValue.getRetailerMobileNumber() != null) {
				// Rewards123 flow
				String retailerNumber = fciInfoValue.getRetailerMobileNumber();
				if (StringUtils.isNotBlank(retailerNumber) && retailerNumber.length() < 12) {
					retailerNumber = "91" + retailerNumber;
				}
				ResponseEntity<com.airtelbank.transaction.model.ResponseDTO<CustomerOfferDetails>> CustomerOfferDetailsResponse = transactionServiceHelper
						.getCustomerOfferDetails(consumerRequest, retailerNumber, consumerRequest.getCustomerId());

				if (null == CustomerOfferDetailsResponse || null == CustomerOfferDetailsResponse.getBody()
						|| null == CustomerOfferDetailsResponse.getBody().getMeta()) {
					log.info("CustomerOfferDetails V4 service not responding for appid:{}", consumerRequest.getAppId());
				} else if (CustomerOfferDetailsResponse.getBody().getData().rewards123Status) {
					response = transactionService.onboardingUsecaseToPaymentHub(consumerRequest, headerRequestDTO,
							fciInfoValue.getTotalamount());
					if (response != null && response.getData() != null
							&& response.getData().getPaymentReqId() != null) {
						LOGGER.info("Payment RequestId created for Rewards123: mobilenumber: {} {}",
								consumerRequest.getCustomerMobileNo(), response.getData().getPaymentReqId());
					} else {
						LOGGER.info("Payment RequestId not generated Rewards123: for mobilenumber: {} ",
								consumerRequest.getCustomerMobileNo());
					}
				} else {
					log.info("Rewards123Status is false for appId {}!!" + consumerRequest.getAppId());
				}
			} else {
				// NORMAL/BHAROSA saving account flow
				response = transactionService.onboardingUsecaseToPaymentHub(consumerRequest, headerRequestDTO,
						fciInfoValue.getTotalamount());
				if (response != null && response.getData() != null && response.getData().getPaymentReqId() != null) {
					LOGGER.info("Payment RequestId created for mobilenumber: {} {}",
							consumerRequest.getCustomerMobileNo(), response.getData().getPaymentReqId());
				} else {
					LOGGER.info("Payment RequestId not generated for mobilenumber: {} ",
							consumerRequest.getCustomerMobileNo());
				}
			}
		} catch (Exception ex) {
			LOGGER.error("Exception in TransactionConsumer::transactionPaymentConsumer: {}", ex);
		} finally {
			// set meta and log
			loggingUtil.doKibanaLogging(Constants.KibanaLoggingIdentifier.TRANSACTION_PAYMENT_CONSUMER_ASYNC,
					headerRequestDTO.getContentid(), headerRequestDTO.getChannel(), consumerRequest.getAppId(),
					consumerRequest.getCustomerMobileNo(), consumerRequest, response);
		}
	}

}
