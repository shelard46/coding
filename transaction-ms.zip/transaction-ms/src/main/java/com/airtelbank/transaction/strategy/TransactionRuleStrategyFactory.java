
package com.airtelbank.transaction.strategy;

import com.airtelbank.transaction.constant.Constants;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Objects;

@Service
public class TransactionRuleStrategyFactory {
    @Autowired
    ShgTransactionRuleStrategy shgTxnRule;

    @Autowired
    SbaTransactionRuleStrategy sbaTxnRule;

    public TransactionRuleStrategy getRuleStrategyFactory(String appType) {
        appType = Objects.isNull(appType) ? StringUtils.EMPTY : appType;
        switch (appType) {

            case Constants.AppType.SHGTRX:
                return shgTxnRule;

            default:
                return sbaTxnRule;

        }
    }
}