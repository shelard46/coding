package com.airtelbank.transaction.util;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.airtelbank.transaction.config.LogMaskingConfiguration;
import com.airtelbank.transaction.constant.Constants;

@Component
public class LogMasker {

	@Autowired
	private LogMaskingConfiguration logMaskingConfiguration;
	
	private Pattern pattern = null;
	private String maskPattern = null;

	@PostConstruct
	public void setPatterns() {
		String regex = logMaskingConfiguration.getRegex();
		maskPattern = logMaskingConfiguration.getPattern();
		pattern = Pattern.compile(regex);
	}

	public String patternReplace(String message) {
		try {
			setPatterns();
			message = message.replaceAll("\\s?:\\s?", ":");
			Matcher matcher = pattern.matcher(message);
			StringBuffer result = new StringBuffer();
			while (matcher.find()) {
				StringBuilder replacement = replacePattern(matcher);
				matcher.appendReplacement(result, replacement.toString());
			}
			matcher.appendTail(result);
			return result.toString();
		} catch (Exception e) {
			return message;
		}
	}

	private StringBuilder replacePattern(Matcher matcher) {
		StringBuilder replacement = new StringBuilder();
		String group = matcher.group(0);
		if (group != null) {
			if (group.contains(Constants.GREATER_THAN_SYMBOL) && group.contains(Constants.GREATER_THAN_SYMBOL_PLUS) && group.contains(Constants.LESSER_THAN_SYMBOL)) {
				replacement = new StringBuilder(
						group.substring(0, group.indexOf(Constants.LESSER_THAN_SYMBOL) + 1) + Constants.MASK + group.substring(group.lastIndexOf(Constants.GREATER_THAN_SYMBOL_PLUS)));
			} else {
				String[] patternsToBeMasked = maskPattern.split(Constants.FORWARD_SLASH_WITH_PIPE);
				for (String patternReplace : patternsToBeMasked) {
					if (group.contains(patternReplace)) {
						String lastCharSeq = group.substring(group.length() - 2);
						group = group.subSequence(patternReplace.length(), group.length() - 2).toString();
						replacement = new StringBuilder(Constants.MASK);
						replacement = new StringBuilder(patternReplace).append(replacement).append(lastCharSeq);
					}
				}
			}
		} else {
			replacement = new StringBuilder(Constants.MASK);
		}
		return replacement;
	}

}
