package com.airtelbank.transaction.dto.customerProfile;


import java.util.Map;

import com.airtelbank.payments.hub.models.customerprofile.Account;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_EMPTY)
@ToString
@Builder@AllArgsConstructor
public class CustomerProfileDTO {

private static final long serialVersionUID = 1L;
	
	@JsonProperty("homeBranch")
	public String homeBranch;
	@JsonProperty("category")
	public String category;
	@JsonProperty("status")
	public String status;
	@JsonProperty("creationDate")
	public String creationDate;
	@JsonProperty("cspMobile")
	public String cspMobile;
	@JsonProperty("cspNatl")
	public String cspNatl;
	@JsonProperty("cspSegment")
	public String cspSegment;
	@JsonProperty("activationDate")
	public String activationDate;
	@JsonProperty("custType")
	public String custType;
	@JsonProperty("dob")
	public String dob;
	@JsonProperty("icType")
	public String icType;
	@JsonProperty("flgBlocked")
	public String flgBlocked;
	@JsonProperty("fciAmount")
	public String fciAmount;
	@JsonProperty("fatherName")
	public String fatherName;
	@JsonProperty("eSign")
	public String eSign;
	@JsonProperty("gender")
	public String gender;
	@JsonProperty("id")
	public String id;
	@JsonProperty("lang")
	public String lang;
	@JsonProperty("maritalStatus")
	public String maritalStatus;
	@JsonProperty("nationality")
	public String nationality;
	@JsonProperty("natlId")
	public String natlId;
	@JsonProperty("msme")
	public String msme;
	@JsonProperty("motherName")
	public String motherName;
	@JsonProperty("onboardChannel")
	public String onboardChannel;
	@JsonProperty("upgradeChannel")
	public String upgradeChannel;
	@JsonProperty("kycStatus")
	public String kycStatus;
	@JsonProperty("officerId")
	public String officerId;
	@JsonProperty("pep")
	public String pep;
	@JsonProperty("txnId")
	public String txnId;
	@JsonProperty("accounts")
	public Map<String, Account> accounts;
	@JsonProperty("addresses")
	public Addresses addresses;
	@JsonProperty("benefits")
	public Benefits benefits;
	@JsonProperty("identities")
	private Map<String, Identity> identities;
	@JsonProperty("employment")
	public Employment employment;
	@JsonProperty("incomeDetails")
	public IncomeDetails incomeDetails;
	@JsonProperty("mobileNumberDetails")
	public MobileNumberDetails mobileNumberDetails;
	@JsonProperty("emailDetails")
	public EmailDetails emailDetails;
	@JsonProperty("name")
	public Name name;
	@JsonProperty("balances")
	private Map<String, Balance> balances;
	@JsonProperty("riskProfile")
	public RiskProfile riskProfile;
}
