package com.airtelbank.transaction.aerospike.entity;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
import org.springframework.data.aerospike.mapping.Document;
import org.springframework.data.aerospike.mapping.Field;
import org.springframework.data.annotation.Id;

import java.util.List;

@Getter
@Setter
@Builder
@ToString
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_EMPTY)
@JsonIgnoreProperties(ignoreUnknown = true)
@Document(collection = "APPID_TO_PAYMENT_REQ_ID")
public class AppIdToPaymentReqId {
    @Id
    @Field(value = "PK")
    private String appId;
    @Field(value = "paymentReqId")
    private List<String> paymentReqId;
    @Field(value = "creationTime")
    private String creationTime;
    @Field(value = "updationTime")
    private String updationTime;
}