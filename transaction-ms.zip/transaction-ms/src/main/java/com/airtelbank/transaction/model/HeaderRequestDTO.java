package com.airtelbank.transaction.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@Builder
@ToString
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_EMPTY)
@JsonIgnoreProperties(ignoreUnknown = true)
public class HeaderRequestDTO {
	@JsonProperty("contentid")
	private String contentid;
	@JsonProperty("feSessionId")
	private String feSessionId;
	@JsonProperty("content-type")
	private String content_type;
	@JsonProperty("Authorization")
	private String authorization;
	@JsonIgnoreProperties("X-Request-ID")
	private String xRequestId;
	@JsonProperty("customerhandlenumber")
	private String customerHandleNumber;
	
	@JsonProperty("apptype")
	private String appType;
	@JsonProperty("channel")
	private String channel;
	
	@JsonProperty("useragent")
	private String useragent;
	@JsonProperty("mobilenumber")
	private String mobilenumber;

	@JsonProperty("action")
	private String action;

	@JsonProperty("flow_key")
	private String flowKey;

}
