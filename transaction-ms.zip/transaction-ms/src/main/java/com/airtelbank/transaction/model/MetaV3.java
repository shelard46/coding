package com.airtelbank.transaction.model;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class MetaV3 {
	private String appType;
	private String appId;
	
}
