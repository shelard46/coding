package com.airtelbank.transaction.dto.retailerprofile;

import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.AccessLevel;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@JsonInclude(JsonInclude.Include.NON_EMPTY)
@Getter
@Setter
@NoArgsConstructor
public class Employment {
	
	@Getter(AccessLevel.NONE)
    @Setter(AccessLevel.NONE)
	private boolean isStaff;
	private String employeeId;
	private String professionCode;
	private String bussinessCode;
	
	public boolean isStaff() {
		return isStaff;
	}
	public void setStaff(boolean isStaff) {
		this.isStaff = isStaff;
	}
}
