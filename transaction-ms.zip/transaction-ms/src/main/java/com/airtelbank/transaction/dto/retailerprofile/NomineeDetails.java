package com.airtelbank.transaction.dto.retailerprofile;

import java.time.LocalDate;

import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@JsonInclude(JsonInclude.Include.NON_EMPTY)
@Setter
@Getter
@ToString
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class NomineeDetails {
	private boolean nomineeAddressSame;
	private String nomineeId;
	private String nomineeName;
	private String nomineeFname;
	private String nomineeMname;
	private String nomineeLname;
    private String nomPhone;
    private String nomEmailId;
    private String nomMobile;
	private LocalDate nomineedateOfBirth;
	private String nomineeDob;
	private String nomineeRelationship;

	private String nomineeAddress1;
	private String nomineeAddress2;
	private String nomineeAddress3;
	private String nomineeAddress4;
	private String nomineeDistrict;
	private String nomineeCity;
	private String nomineeState;
	@Builder.Default
	private String nomineeCountry = "India";
	private String nomineeZip;

	private Double sharePercentage;
    private Double shareAmount;

}
