package com.airtelbank.transaction.model;

import java.util.Map;

import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.util.MultiValueMap;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class RestRequest<T> {
	private String uri;
	private Map<String, Object> params;
	private HttpMethod httpMethod;
	private Class<T> responseClass;
	private MultiValueMap<String, String> headers;
	private Object entity;		
}
