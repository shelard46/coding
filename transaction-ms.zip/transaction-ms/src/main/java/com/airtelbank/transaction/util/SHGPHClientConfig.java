package com.airtelbank.transaction.util;

import com.airtelbank.payments.hub.client.model.PHEnvironment;
import com.airtelbank.payments.hub.client.utility.PHInitialiseEnvironment;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

@Service
@Slf4j
public class SHGPHClientConfig {
    @Value("${config.shg.payment.hub.salt}")
    private String salt;

    @Value("${config.shg.payment.hub.partnerId}")
    private String partnerId;

    @Value("${config.shg.payment.hub.baseUrl}")
    private String baseUrl;


    public void init(String useCase) {
        PHEnvironment PhEnvironment = PHEnvironment.builder().baseUrl(baseUrl).salt(salt).partnerId(partnerId).build();
        PHInitialiseEnvironment.init(PhEnvironment, useCase);
    }

}
