package com.airtelbank.transaction.producer;

import java.util.Arrays;
import java.util.List;

import org.apache.commons.lang3.RandomStringUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.data.aerospike.core.AerospikeTemplate;
import org.springframework.stereotype.Service;

import com.airtelbank.transaction.aerospike.entity.FCIInfoDetails;
import com.airtelbank.transaction.constant.Constants;
import com.airtelbank.transaction.dto.activateRewards.ActivateRewardAddOnDTO;
import com.airtelbank.transaction.dto.customerState.CustomerStateResponse;
import com.airtelbank.transaction.dto.intermediateDTOs.RewardsDTO;
import com.airtelbank.transaction.dto.travellerPack.AccountType;
import com.airtelbank.transaction.dto.travellerPack.OfferApiResponse;
import com.airtelbank.transaction.model.HeaderRequestDTO;
import com.airtelbank.transaction.util.CommonUtils;
import com.airtelbank.transaction.util.TransactionHelperUtil;
import com.google.gson.Gson;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
@RefreshScope
public class CustomerRewardProducer {

	@Autowired
	Producer producer;

	@Value("${config.sba.payment.hub.configRewardPaymentCustomer}")
	private String configRewardPaymentCustomer;

	@Value("${config.sba.customer.Rewards}")
	private String customerRewards;

	@Autowired
	TransactionHelperUtil transactionHelper;

	@Autowired
	private AerospikeTemplate aerospikeTemplate;

	public void produceRewardsStatus(RewardsDTO rewardsobj) {
		log.info("Reward status recieved from Transaction MS");
		try {
			String customerHandleNumber = null;
			Gson gson = new Gson();
			String reward = null;

			FCIInfoDetails fciInfoValue = aerospikeTemplate.findById(rewardsobj.getAppId(), FCIInfoDetails.class);
			if (fciInfoValue != null) {
				customerHandleNumber = fciInfoValue.getMobileNumber();
			}
			HeaderRequestDTO header = CommonUtils.createHeader(customerHandleNumber, rewardsobj.getChannel());
			CustomerStateResponse customerStateResponse = transactionHelper
					.hitGetCustomerStateApi(rewardsobj.getAppId(), header);

			List<String> customerRewardsList = Arrays.asList(customerRewards.split(","));

			if (customerStateResponse.getCustomerDetail().getOffersMap() != null)
				reward = customerRewardsList.stream()
						.filter(it -> customerStateResponse.getCustomerDetail().getOffersMap().containsKey(it))
						.findFirst().orElse(null);

			if (customerStateResponse.getCustomerDetail().getOffersMap() != null
					&& !customerStateResponse.getCustomerDetail().getOffersMap().isEmpty()
					&& StringUtils.isNoneBlank(reward)
					&& Constants.SBA.equals(customerStateResponse.getCustomerDetail().getCustType())) {
				ActivateRewardAddOnDTO objMap = createObjMap(rewardsobj, customerStateResponse, reward);
				producer.produce(configRewardPaymentCustomer, customerStateResponse.getCustomerId(), objMap);
				log.info(
						"Pushing an event to issue the REWARDS to the concerned team for this appId :{}: and custId :{}:"
								+ rewardsobj.getAppId(),
						customerStateResponse.getCustomerDetail().getCustomerId());
				log.info("producedRecord {} ", gson.toJson(objMap));

			} else {
				log.info("Reward Offer Not Avaialable for Customer {} and appId {} ",
						customerStateResponse.getCustomerId(), rewardsobj.getAppId());
			}

		} catch (Exception e) {
			log.error("Inside CustomerConsumer::getReward123Status, Exception : {}, appId : {}", e,
					rewardsobj.getAppId());

		}

	}

	private ActivateRewardAddOnDTO createObjMap(RewardsDTO map, CustomerStateResponse customerStateResponse,
			String reward) {
		ActivateRewardAddOnDTO objMap = new ActivateRewardAddOnDTO();
		if (customerStateResponse != null && customerStateResponse.getCustomerDetail() != null) {
			objMap.setCustomerId("91" + customerStateResponse.getCustomerDetail().getMobileNumber());
			objMap.setCustType(customerStateResponse.getCustomerDetail().getCustType());
			objMap.setContentId(RandomStringUtils.randomAlphanumeric(5));
		}
		OfferApiResponse offerApiResponse = transactionHelper.hitTravellerPackApi(map.getAppId());
		if (null != offerApiResponse) {
			for (AccountType accountType : offerApiResponse.getAccountType()) {
				if (accountType.getBackendId().equalsIgnoreCase(reward)) {
					objMap.setAmount(accountType.getPrice());
					objMap.setAddOnName(reward);
				}
			}
			if (map.getRetailerNumber() != null)
				objMap.setRetailerNumber(map.getRetailerNumber());

			objMap.setCreChannel(map.getChannel());
			objMap.setAction(Constants.ACTION);
			objMap.setChannel(Constants.RAPP);

		}
		return objMap;

	}
}