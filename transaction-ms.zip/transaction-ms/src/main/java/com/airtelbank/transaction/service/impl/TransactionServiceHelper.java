package com.airtelbank.transaction.service.impl;

import com.airtelbank.payments.hub.client.dto.response.DirectPaymentResponse;
import com.airtelbank.payments.hub.client.dto.response.PaymentEnquiryResponse;
import com.airtelbank.transaction.aerospike.entity.TransactionStore;
import com.airtelbank.transaction.constant.Constants;
import com.airtelbank.transaction.model.HeaderRequestDTO;
import com.airtelbank.transaction.model.TransactionRequestDTO;
import com.airtelbank.transaction.model.response.ShgPaymentTrx;
import freemarker.template.Configuration;
import freemarker.template.Template;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.MessageSource;
import org.springframework.data.aerospike.core.AerospikeTemplate;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import java.io.StringReader;
import java.io.StringWriter;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
@Slf4j
@Service
public class TransactionServiceHelper {

    @Autowired
    private AerospikeTemplate aerospikeTemplate;

    @Autowired
    private TransactionServiceImpl transactionService;

    @Value("${config.transaction.create.aerospike.retry.count}")
    private int aerospikeRetryCount;

    @Value("${kafka.manage.payment.topic}")
    private String paymentTopic;

    @Value("${config.shg.payment.hub.case.withdraw.usecase}")
    private String shgCashWithdrawUseCase;

    @Value("${config.shg.payment.hub.case.deposit.usecase}")
    private String shgCashDepositUseCase;
    
    @Value("${config.shg.payment.hub.case.fund.usecase}")
    private String shgFundTransferUseCase;

    @Autowired
    private KafkaTemplate<String, Object> kafkaTemplate;

    @Autowired
    private MessageSource messageSource;

    private SimpleDateFormat simpleDateFormat = new SimpleDateFormat ("yyyy-MM-dd HH:mm:ss.SSSSSS");

    public void updatePaymentResponse(PaymentEnquiryResponse paymentEnquiryResponse, TransactionStore transactionStore,HeaderRequestDTO headerRequestDTO,String useCase) {
        int retryCounter = 0;
        if(Objects.nonNull(paymentEnquiryResponse.getDebitDetails()) &&!(CollectionUtils.isEmpty(paymentEnquiryResponse.getDebitDetails()))) {
            transactionStore.setUpdateDate(simpleDateFormat.format(new Date()));
            transactionStore.setStatus(paymentEnquiryResponse.getDebitDetails().get(0).getStatus());
            ShgPaymentTrx shgPaymentTrx=ShgPaymentTrx.builder().updateTime(simpleDateFormat.format(new Date())).appType(headerRequestDTO.getAppType()).appId(transactionStore.getAppId()).flowKey(headerRequestDTO.getFlowKey()).status(paymentEnquiryResponse.getDebitDetails().get(0).getStatus()).build();
            if (!(Constants.SUCCESS.equalsIgnoreCase(paymentEnquiryResponse.getDebitDetails().get(0).getStatus()))) {
                transactionStore.setErrorCode(paymentEnquiryResponse.getDebitDetails().get(0).getErrorCode());
                transactionStore.setErrorDesc(paymentEnquiryResponse.getDebitDetails().get(0).getMessage());
                if(shgCashDepositUseCase.equalsIgnoreCase(useCase))
                    shgPaymentTrx.setState(Constants.CASH_DEPOSIT_FAILURE_CODE);
                else if(shgCashWithdrawUseCase.equalsIgnoreCase(useCase))
                    shgPaymentTrx.setState(Constants.CASH_WITHDRAWAL_FAILURE_CODE);
                else if(shgFundTransferUseCase.equalsIgnoreCase(useCase))
                    shgPaymentTrx.setState(Constants.IFT_FAILURE_CODE);
            }
            if(shgCashDepositUseCase.equalsIgnoreCase(useCase)) {
                shgPaymentTrx.setKey(Constants.MgmtAuxiliaryInfo.SHG_PAYMENT_TRX_CD);
                if (Constants.SUCCESS.equalsIgnoreCase(paymentEnquiryResponse.getDebitDetails().get(0).getStatus()))
                    shgPaymentTrx.setState(Constants.CASH_DEPOSIT_SUCCESS_CODE);
                produceEventPaymentStatusToPipeline(shgPaymentTrx);
            }
            else if(shgCashWithdrawUseCase.equalsIgnoreCase(useCase)) {
                shgPaymentTrx.setKey(Constants.MgmtAuxiliaryInfo.SHG_PAYMENT_TRX_CW);
                if (Constants.SUCCESS.equalsIgnoreCase(paymentEnquiryResponse.getDebitDetails().get(0).getStatus()))
                    shgPaymentTrx.setState(Constants.CASH_WITHDRAWAL_SUCCESS_CODE);
                produceEventPaymentStatusToPipeline(shgPaymentTrx);
            }
            else if(shgFundTransferUseCase.equalsIgnoreCase(useCase)) {
                shgPaymentTrx.setKey(Constants.MgmtAuxiliaryInfo.SHG_PAYMENT_TRX_IFT);
                if (Constants.SUCCESS.equalsIgnoreCase(paymentEnquiryResponse.getDebitDetails().get(0).getStatus()))
                    shgPaymentTrx.setState(Constants.IFT_SUCCESS_CODE);
                produceEventPaymentStatusToPipeline(shgPaymentTrx);
            }
            while (retryCounter <= aerospikeRetryCount) {
                try {
                    aerospikeTemplate.update(transactionStore);
                    break;
                } catch (Exception ex) {
                    log.error("Failed while update entry into TransactionStore in Aerospike: for prId :{}:", transactionStore.getPaymentReqId(), ex);
                    retryCounter++;
                    if (retryCounter > aerospikeRetryCount) {
                        log.error("Max retries exceeded for updating entry into TransactionStore!");
                    }
                }
            }
        }
    }

    public void savePaymentResponse(String shgPaymentUseCase, TransactionRequestDTO transactionRequestDTO, com.airtelbank.payments.hub.client.dto.response.ResponseDTO<DirectPaymentResponse> transactionResponse, HeaderRequestDTO headerRequestDTO) {
        int retryCounter = 0;
        TransactionStore transactionDetails = null;
        HashMap<String, Object> txnInfo = new HashMap<>();
        txnInfo.put(Constants.SOURCE_DETAILS, transactionRequestDTO.getSourceDetails());
        txnInfo.put(Constants.TARGET_DETAILS, transactionRequestDTO.getTargetDetails());
        transactionDetails = TransactionStore.builder().amount(transactionRequestDTO.getAmount())
                .orderId(transactionResponse.getData().getOrderId()).status(Constants.status.INITIATED)
                .paymentReqId(transactionResponse.getData().getPaymentReqId())
                .depositerMobileNumber(headerRequestDTO.getCustomerHandleNumber())
                .useCase(shgPaymentUseCase)
                .createdDate(Constants.SIMPLEDATEFORMAT.format(new Date()))
                .appId(transactionRequestDTO.getAppId())
                .amount(transactionRequestDTO.getAmount())
                .appType(headerRequestDTO.getAppType())
                .txnAuxInfo(txnInfo)
                .updateDate(Constants.SIMPLEDATEFORMAT.format(new Date())).build();
        transactionService.saveAppIdToPaymentReqIdInAerospike(transactionRequestDTO.getAppId(), transactionResponse.getData().getPaymentReqId());
        log.info(
                "Inside ShgTransactionRuleStrategy::savePaymentResponse Saved transaction details for orderId :{} and paymentRequestId: {}",
                transactionResponse.getData().getOrderId(), transactionResponse.getData().getPaymentReqId());
        while (retryCounter <= aerospikeRetryCount) {
            try {
                aerospikeTemplate.save(transactionDetails);
                break;
            } catch (Exception ex) {
                log.error("Failed while putting entry into TransactionStore in Aerospike: for prId :{}:", transactionResponse.getData().getPaymentReqId(), ex);
                retryCounter++;
                if (retryCounter > aerospikeRetryCount) {
                    log.error("Max retries exceeded for creating entry into TransactionStore!");
                }
            }
        }
    }

    public void produceEventPaymentStatusToPipeline(ShgPaymentTrx paymentTrx) {
        log.info("producing message in topic :: {} , {}", paymentTopic,paymentTrx);
        kafkaTemplate.send(paymentTopic, paymentTrx);
        log.debug("produced message in topic :: {}",paymentTopic);
    }

    private String generateRemarks(String data, Map<String, String> map) throws Exception {
        Configuration cfg = new Configuration(Configuration.VERSION_2_3_31);
        cfg.setLogTemplateExceptions(false);
        Template template = new Template(null, new StringReader(data), cfg);
        StringWriter out = new StringWriter();
        template.process(map, out);
        return out.toString();
    }

    private String getNarration(String panStatus,String key,String defaultKey) {
        Map<String, String> map = null;
        try {
            map = new HashMap<>();
            map.put("accType", panStatus.equalsIgnoreCase(Constants.YES)?Constants.PAN:Constants.NON_PAN);
            return generateRemarks(messageSource.getMessage(key, null, Locale.ENGLISH), map);
        } catch (Exception e) {
            log.info("exception in narration :: {}",e.getMessage());
            return messageSource.getMessage(defaultKey, null, Locale.ENGLISH);
        }
    }

    public Map<String,String> useCaseNarration(String action,String panStatus) {
        Map<String,String> map=new HashMap<>();
        if(Constants.Action.SHG_CD.equalsIgnoreCase(action)) {
           map.put(Constants.DR_KEY,getNarration(panStatus,Constants.CSB_CD_DR_NR,Constants.CSB_CD_DR_DEFAULT_NR));
           map.put(Constants.CR_KEY,getNarration(panStatus,Constants.CSB_CD_CR_NR,Constants.CSB_CD_CR_DEFAULT_NR));
           map.put(Constants.PARAM_1_KEY,getNarration(panStatus,Constants.CSB_CD_PARAM_1_NR,Constants.CSB_CD_DEFAULT_PARAM_1_NR));
           map.put(Constants.PARAM_2_KEY,getNarration(panStatus,Constants.CSB_CD_PARAM_2_NR,Constants.CSB_CD_DEFAULT_PARAM_2_NR));
        } else if (Constants.Action.SHG_CW.equalsIgnoreCase(action)){
            map.put(Constants.DR_KEY,getNarration(panStatus,Constants.CSB_CW_DR_NR,Constants.CSB_CW_DR_DEFAULT_NR));
            map.put(Constants.CR_KEY,getNarration(panStatus,Constants.CSB_CW_CR_NR,Constants.CSB_CW_CR_DEFAULT_NR));
            map.put(Constants.PARAM_1_KEY,getNarration(panStatus,Constants.CSB_CW_PARAM_1_NR,Constants.CSB_CW_DEFAULT_PARAM_1_NR));
            map.put(Constants.PARAM_2_KEY,getNarration(panStatus,Constants.CSB_CW_PARAM_2_NR,Constants.CSB_CW_DEFAULT_PARAM_2_NR));
        } else if(Constants.Action.SHG_IFT.equalsIgnoreCase(action)) {
            map.put(Constants.DR_KEY,getNarration(panStatus,Constants.CSB_IFT_DR_NR,Constants.CSB_IFT_DR_DEFAULT_NR));
            map.put(Constants.CR_KEY,getNarration(panStatus,Constants.CSB_IFT_CR_NR,Constants.CSB_IFT_CR_DEFAULT_NR));
            map.put(Constants.PARAM_1_KEY,getNarration(panStatus,Constants.CSB_IFT_PARAM_1_NR,Constants.CSB_IFT_DEFAULT_PARAM_1_NR));
            map.put(Constants.PARAM_2_KEY,getNarration(panStatus,Constants.CSB_IFT_PARAM_2_NR,Constants.CSB_IFT_DEFAULT_PARAM_2_NR));
        }
        return map;
    }

}
