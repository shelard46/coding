package com.airtelbank.transaction.dto.retailerprofile;


import com.airtelbank.transaction.dto.customerProfile.Balance;
import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;



@Getter
@Setter
@ToString
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class AccountResponse {
    private String accountNumber;
    private String status;
    private String accountType;
    private Balance balance;
    private Product product;
}

