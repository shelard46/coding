package com.airtelbank.transaction.strategy;

import com.airtelbank.payments.hub.client.dto.request.DirectPaymentRequest;
import com.airtelbank.payments.hub.client.dto.response.DirectPaymentResponse;
import com.airtelbank.payments.hub.client.dto.response.ResponseDTO;
import com.airtelbank.payments.hub.client.model.Options;
import com.airtelbank.payments.hub.client.model.OrderDetails;
import com.airtelbank.payments.hub.client.model.OrderItems;
import com.airtelbank.payments.hub.client.service.impl.PHDirectPaymentRequestServiceImpl;
import com.airtelbank.payments.hub.dto.paymentrequest.AccountDetail;
import com.airtelbank.payments.hub.dto.paymentrequest.CustomerDetail;
import com.airtelbank.transaction.aerospike.entity.TransactionStore;
import com.airtelbank.transaction.constant.Constants;
import com.airtelbank.transaction.exception.GenericException;
import com.airtelbank.transaction.model.AuditLog;
import com.airtelbank.transaction.model.HeaderRequestDTO;
import com.airtelbank.transaction.model.TransactionEnquiryRequest;
import com.airtelbank.transaction.model.TransactionRequestDTO;
import com.airtelbank.transaction.service.impl.TransactionServiceImpl;
import com.airtelbank.transaction.util.CommonUtils;
import com.airtelbank.transaction.util.LogMasker;
import com.airtelbank.transaction.util.PHClientConfig;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.aerospike.core.AerospikeTemplate;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Slf4j
@Component
public class SbaTransactionRuleStrategy implements TransactionRuleStrategy{

    @Autowired
    private AerospikeTemplate aerospikeTemplate;

    @Autowired
    private TransactionServiceImpl transactionService;

    @Autowired
    private PHDirectPaymentRequestServiceImpl pHDirectPaymentRequestServiceImpl;

    @Autowired
    private LogMasker logMasker;

    @Value("${config.sba.payment.hub.partnerId}")
    private String partnerId;

    @Value("${config.sba.payment.hub.case.onboarding.usecase}")
    private String retailerOnboardingUseCase;

    @Autowired
    private PHClientConfig pHClientConfig;

    @Override
    public ResponseDTO<DirectPaymentResponse> onboardingUsecaseToPaymentHub(TransactionRequestDTO transactionRequestDTO, HeaderRequestDTO headerRequestDTO, String amount) {

        pHClientConfig.init(retailerOnboardingUseCase);

        AuditLog auditLog = null;
        log.info(CommonUtils.errorPrefixSuffix(
                "Inside SbaTransactionRuleStrategy::onboardingUsecaseToPaymentHub DirectPayment request : {}")
                + logMasker.patternReplace(CommonUtils.jsonObjectToString(transactionRequestDTO)));
        String hash = null;
        String orderId = null;
        List<OrderItems> orderItemsList = new ArrayList<>();
        List<Options> selectedOptionsList = new ArrayList<>();
        TransactionStore transactionDetails = null;
        ResponseDTO<DirectPaymentResponse> transactionResponse = null;
        orderId = transactionService.orderId();
        try {
            if (transactionRequestDTO.getAppId() != null) {
                log.info("Inside SbaTransactionRuleStrategy::onboardingUsecaseToPaymentHub Fetching fciDEtails for appId:{}",
                        transactionRequestDTO.getAppId());
                log.info("Inside SbaTransactionRuleStrategy::onboardingUsecaseToPaymentHub Fetched total amount - {}",
                        amount);
                CustomerDetail customerDetail = CustomerDetail.builder()
                        .custMsisdn(transactionRequestDTO.getCustomerMobileNo())
                        .custName(transactionRequestDTO.getCustomerName()).build();

                CustomerDetail assistedBy = CustomerDetail.builder()
                        .custMsisdn(transactionRequestDTO.getRetailMobileNumber())
                        .custId(transactionRequestDTO.getRetailCustID())
                        .custName(transactionRequestDTO.getRetailerName()).build();
                Options selectedOptionsRequest = Options.builder().amount(amount).optionType(Constants.MCASH).build();
                selectedOptionsList.add(selectedOptionsRequest);
                AccountDetail accountDetail = AccountDetail.builder()
                        .accountNumber(transactionRequestDTO.getAccountNumber()).custType(Constants.SBA)
                        .name(transactionRequestDTO.getCustomerName()).billerCode(transactionRequestDTO.getAfcCharge())
                        .build();

                OrderItems orderItems = new OrderItems();
                orderItems.setAmt(amount);
                orderItems.setOrderItemId(orderId);
                orderItems.setBillerDetails(accountDetail);
                orderItemsList.add(orderItems);
                OrderDetails orderDetailsRequest = OrderDetails.builder().orderItems(orderItemsList).build();

                Map<String, Object> additionalDetails = new HashMap<>();
                additionalDetails.put("sbaAccountNumber", transactionRequestDTO.getAccountNumber());
                DirectPaymentRequest directPaymentRequest = new DirectPaymentRequest();
                directPaymentRequest.setSelectedOptions((List<? super Options>) selectedOptionsList);
                directPaymentRequest.setMpin(transactionRequestDTO.getMpin());
                directPaymentRequest.setUseCase(transactionRequestDTO.getUseCase());
                directPaymentRequest.setAccessChannel(Constants.ACCESS_CHANNEL);
                directPaymentRequest.setTotalAmt(amount);
                directPaymentRequest.setOrderId(orderId);
                directPaymentRequest.setHash(hash);
                directPaymentRequest.setPartnerId(partnerId);
                directPaymentRequest.setOrderDetails(orderDetailsRequest);
                directPaymentRequest.setCustomerDetail(customerDetail);
                directPaymentRequest.setAssistedBy(assistedBy);
                directPaymentRequest.setAdditionalDetails(additionalDetails);
                directPaymentRequest.setTotalAmount(new BigDecimal(amount));
                transactionResponse = pHDirectPaymentRequestServiceImpl.paymentRequest(
                        transactionRequestDTO.getUseCase(), directPaymentRequest, headerRequestDTO.getContentid());

                if (transactionResponse == null) {
                    throw new GenericException(Constants.THIRD_PARTY_ERROR_CODE, Constants.THIRD_PARTY_ERROR_MSG);
                }
                if (transactionResponse.getData() != null && transactionResponse.getData().getPaymentReqId() != null) {
                    transactionDetails = TransactionStore.builder().amount(amount)
                            .orderId(transactionResponse.getData().getOrderId()).status(Constants.PENDING)
                            .paymentReqId(transactionResponse.getData().getPaymentReqId())
                            .depositerMobileNumber(transactionRequestDTO.getCustomerMobileNo())
                            .useCase(transactionRequestDTO.getUseCase()).appId(transactionRequestDTO.getAppId())
                            .createdDate(Constants.SIMPLEDATEFORMAT.format(new Date()))
                            .updateDate(Constants.SIMPLEDATEFORMAT.format(new Date())).build();
                    transactionService.saveAppIdToPaymentReqIdInAerospike(transactionRequestDTO.getAppId(),transactionResponse.getData().getPaymentReqId());

                    log.info(
                            "Inside SbaTransactionRuleStrategy::onboardingUsecaseToPaymentHub Saved transaction details for orderId :{} and paymnetRequrestId: {}",
                            orderId, transactionResponse.getData().getPaymentReqId());
                    aerospikeTemplate.save(transactionDetails);
                }

            } else {
                throw new GenericException(Constants.INVALID_APPID_CODE, Constants.INVALID_APPID_MSG);
            }
        } catch (Exception ex) {
            log.error("Error for orderId {} : {}", orderId, ExceptionUtils.getStackTrace(ex));
            throw new GenericException(Constants.THIRD_PARTY_ERROR_CODE, Constants.THIRD_PARTY_ERROR_MSG);
        }
        return transactionResponse;
    }


    @Override
    public ResponseDTO<String>  paymentHubEnquiry(TransactionEnquiryRequest transactionEnquiryRequest, HeaderRequestDTO headerRequestDTO) {
        //No implementation for SBA use case
        return null;
    }
}
