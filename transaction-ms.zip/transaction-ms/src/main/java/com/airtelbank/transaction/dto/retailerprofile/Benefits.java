package com.airtelbank.transaction.dto.retailerprofile;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data@NoArgsConstructor
@Builder@AllArgsConstructor
public class Benefits {

	private Boolean isInsuranceGiven;
	private Boolean isUpiEnabled;
	private Boolean isDbtOpted;
	private Boolean isDtrOpted;
}
