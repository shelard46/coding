package com.airtelbank.transaction.aerospike.entity;

import org.springframework.data.aerospike.mapping.Document;
import org.springframework.data.aerospike.mapping.Field;
import org.springframework.data.annotation.Id;

import com.airtelbank.transaction.aerospike.entity.FCIConfiguration.FCIConfigurationBuilder;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Setter
@Getter
@NoArgsConstructor
@AllArgsConstructor
@ToString
@Builder
@Document(collection = "FCIDetails")
public class FCIInfoDetails {

	@Id
	@Field(value = "APP_ID")
	private String appId;
	
	@Field(value = "APP_TYPE")
	private String appType;
	
	@Field(value = "FCI")
	private String fci;
	
	@Field(value = "AFC")
	private String afc;
	
	@Field(value = "MOBILENUMBER")
	private String mobileNumber;
	
	@Field(value = "ACCOUNT_TYPE")
	private String accountType;
	
	@Field(value="SUBSCRIPTION")
	private String subscription;
	
	@Field(value="TOTAL_AMOUNT")
	private String totalamount;
	
	@Field(value="CIRCLE")
	private String circle;
	
	@Field(value="RET_NUMBER")
	private String retailerMobileNumber;
	
	@Field(value = "creationTime")
	private String creationTime;

	@Field(value = "updationTime")
	private String updationTime;
	
}
