package com.airtelbank.transaction.model.response;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.airtelbank.transaction.constant.Constants;

public final class ResponseEntityBuilder {
	private ResponseEntityBuilder(HttpStatus httpStatus) {
		this.httpStatus = httpStatus;
	}

	private HttpStatus httpStatus;

	public static ResponseEntityBuilder getBuilder(HttpStatus status) {
		return new ResponseEntityBuilder(status);
	}

	public ResponseEntity<RestApiResponse> errorResponse(String code, String message) {
		RestApiResponse response = RestApiResponse.buildResponse(code, message,Constants.STATUS_FAILURE);
		return new ResponseEntity<>(response, httpStatus);
	}
	
}
