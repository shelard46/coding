package com.airtelbank.transaction.dto.retailerprofile;

import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@JsonInclude(JsonInclude.Include.NON_EMPTY)
@Getter
@Setter
@Builder
@ToString
@NoArgsConstructor
@AllArgsConstructor
public class CustomerMiscellanoeus {
	private String onboardChannel;
	private String upgradeChannel;
	private Boolean isNdsFound;
	private String onBoardedByNatlId;
	private String onBoardedBySegment;
	private Boolean isPoliticallyExposed;
	private String classification;
	private String esignStatus;
	private String uidToken;
	private String dbtConsent;
	private String signedPdfPath;
	private String MSME;
	private String freeField1;
	private String contentId;
	private String crrAddrSameAsPerAddr;
	private String PoaTypePhoto1;
	private String PoaTypePhoto2;
	private String PoaTypePhoto3;
	private String PoaTypePhoto4;
	private String PoaTypePhoto5;
}
