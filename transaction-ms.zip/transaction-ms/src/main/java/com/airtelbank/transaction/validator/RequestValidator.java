package com.airtelbank.transaction.validator;

import com.airtelbank.transaction.constant.Constants;
import com.airtelbank.transaction.exception.ClientSideException;
import com.airtelbank.transaction.model.HeaderRequestDTO;
import com.airtelbank.transaction.model.TransactionEnquiryRequest;
import com.airtelbank.transaction.model.TransactionRequestDTO;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;


import java.util.Objects;
import java.util.regex.Pattern;

import static com.airtelbank.transaction.constant.Constants.MOBILE_NUMBER_REGEX;
@Component
public class RequestValidator {

    public void requestValidator(TransactionRequestDTO transactionRequestDTO,HeaderRequestDTO headerRequestDTO)
    {
        if (StringUtils.isBlank(transactionRequestDTO.getAppId()))
            throw new ClientSideException(Constants.REQUEST_VALIDATION_FAILED, Constants.APPID_NOT_NULL_MSG);

        if (StringUtils.isBlank(transactionRequestDTO.getAmount()))
            throw new ClientSideException(Constants.REQUEST_VALIDATION_FAILED, Constants.AMOUNT_NOT_NULL_MSG);

        if (StringUtils.isBlank(transactionRequestDTO.getDescription()))
            throw new ClientSideException(Constants.REQUEST_VALIDATION_FAILED, Constants.DESC_NOT_NULL_MSG);

        if (Objects.isNull(transactionRequestDTO.getSourceDetails()))
            throw new ClientSideException(Constants.REQUEST_VALIDATION_FAILED, Constants.SOURCE_NOT_NULL_MSG);

        if (Objects.isNull(transactionRequestDTO.getTargetDetails()))
            throw new ClientSideException(Constants.REQUEST_VALIDATION_FAILED, Constants.TARGET_NOT_NULL_MSG);

        if (StringUtils.isBlank(transactionRequestDTO.getSourceDetails().getAccountNo()))
            throw new ClientSideException(Constants.REQUEST_VALIDATION_FAILED, Constants.SOURCE_ACCOUNT_NO_NULL_MSG);

        if(StringUtils.isBlank(transactionRequestDTO.getTargetDetails().getAccountNo()))
            throw new ClientSideException(Constants.REQUEST_VALIDATION_FAILED, Constants.TARGET_ACCOUNT_NO_NULL_MSG);

        if (StringUtils.isBlank(transactionRequestDTO.getSourceDetails().getMobileNo()))
            throw new ClientSideException(Constants.REQUEST_VALIDATION_FAILED, Constants.SOURCE_MOBILE_NO_NULL_MSG);

        if((!Constants.Action.SHG_IFT.equalsIgnoreCase(headerRequestDTO.getAction())) && StringUtils.isBlank(transactionRequestDTO.getTargetDetails().getMobileNo()))
            throw new ClientSideException(Constants.REQUEST_VALIDATION_FAILED, Constants.TARGET_MOBILE_NO_NULL_MSG);

        if (!Pattern.matches(MOBILE_NUMBER_REGEX,transactionRequestDTO.getSourceDetails().getMobileNo()))
            throw new ClientSideException(Constants.REQUEST_VALIDATION_FAILED, Constants.SOURCE_MOB_INVALID_MSG);

        if(StringUtils.isNotBlank(transactionRequestDTO.getTargetDetails().getMobileNo()) && !Pattern.matches(MOBILE_NUMBER_REGEX,transactionRequestDTO.getTargetDetails().getMobileNo()))
            throw new ClientSideException(Constants.REQUEST_VALIDATION_FAILED, Constants.TARGET_MOB_INVALID_MSG);

        if (!Pattern.matches(Constants.Regex.ACC_NUMBER,transactionRequestDTO.getTargetDetails().getAccountNo()))
            throw new ClientSideException(Constants.REQUEST_VALIDATION_FAILED, Constants.TARGET_ACCOUNT_NO_INVALID_MSG);

        if( !Pattern.matches(Constants.Regex.ACC_NUMBER,transactionRequestDTO.getSourceDetails().getAccountNo()))
            throw new ClientSideException(Constants.REQUEST_VALIDATION_FAILED, Constants.SOURCE_ACCOUNT_NO_INVALID_MSG);

        if (!(Pattern.matches(Constants.Regex.NUMBER,transactionRequestDTO.getAmount())) || Double.parseDouble(transactionRequestDTO.getAmount())<=0)
            throw new ClientSideException(Constants.REQUEST_VALIDATION_FAILED, Constants.AMOUNT_INVALID_MSG);

    }

    public void headerValidator(HeaderRequestDTO headerRequestDTO) {
        if (StringUtils.isBlank(headerRequestDTO.getAppType()))
            throw new ClientSideException(Constants.REQUEST_VALIDATION_FAILED, Constants.APPTYPE_NOT_NULL);


        if (StringUtils.isBlank(headerRequestDTO.getAction()))
            throw new ClientSideException(Constants.REQUEST_VALIDATION_FAILED, Constants.ACTION_NOT_NULL);


        if (StringUtils.isBlank(headerRequestDTO.getFlowKey()))
            throw new ClientSideException(Constants.REQUEST_VALIDATION_FAILED, Constants.FLOWKEY_NOT_NULL);


        if (StringUtils.isBlank(headerRequestDTO.getChannel()))
            throw new ClientSideException(Constants.REQUEST_VALIDATION_FAILED, Constants.CHANNEL_NOT_NULL);

        if (StringUtils.isBlank(headerRequestDTO.getCustomerHandleNumber()))
            throw new ClientSideException(Constants.REQUEST_VALIDATION_FAILED, Constants.CUSTOMER_HANDLE_NOT_NULL);


    }

    public void requestValidator(TransactionEnquiryRequest transactionEnquiryRequest)
    {
        if (StringUtils.isBlank(transactionEnquiryRequest.getPrId()))
            throw new ClientSideException(Constants.REQUEST_VALIDATION_FAILED, Constants.PRID_NOT_NULL_MSG);

        if (StringUtils.isBlank(transactionEnquiryRequest.getAppId()))
            throw new ClientSideException(Constants.REQUEST_VALIDATION_FAILED, Constants.APPID_NOT_NULL_MSG);
    }

    public void enquiryHeaderValidator(HeaderRequestDTO headerRequestDTO) {
        if (StringUtils.isBlank(headerRequestDTO.getAppType()))
            throw new ClientSideException(Constants.REQUEST_VALIDATION_FAILED, Constants.APPTYPE_NOT_NULL);


        if (StringUtils.isBlank(headerRequestDTO.getAction()))
            throw new ClientSideException(Constants.REQUEST_VALIDATION_FAILED, Constants.ACTION_NOT_NULL);


        if (StringUtils.isBlank(headerRequestDTO.getFlowKey()))
            throw new ClientSideException(Constants.REQUEST_VALIDATION_FAILED, Constants.FLOWKEY_NOT_NULL);

        if (StringUtils.isBlank(headerRequestDTO.getContentid()))
            throw new ClientSideException(Constants.REQUEST_VALIDATION_FAILED, Constants.INVALID_CONTENT_ID_MSG);


    }
}
