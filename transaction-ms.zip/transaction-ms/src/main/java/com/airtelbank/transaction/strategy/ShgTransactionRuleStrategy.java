package com.airtelbank.transaction.strategy;

import com.airtelbank.payments.hub.client.dto.request.DirectPaymentRequest;
import com.airtelbank.payments.hub.client.dto.request.PaymentEnquiryRequest;
import com.airtelbank.payments.hub.client.dto.response.DirectPaymentResponse;
import com.airtelbank.payments.hub.client.dto.response.Meta;
import com.airtelbank.payments.hub.client.dto.response.PaymentEnquiryResponse;
import com.airtelbank.payments.hub.client.dto.response.ResponseDTO;
import com.airtelbank.payments.hub.client.model.Options;
import com.airtelbank.payments.hub.client.model.OrderDetails;
import com.airtelbank.payments.hub.client.model.OrderItems;
import com.airtelbank.payments.hub.client.service.impl.PHDirectPaymentRequestServiceImpl;
import com.airtelbank.payments.hub.client.service.impl.PHPaymentEnquiryServiceImpl;
import com.airtelbank.payments.hub.dto.paymentrequest.AccountDetail;
import com.airtelbank.payments.hub.dto.paymentrequest.CustomerDetail;
import com.airtelbank.transaction.aerospike.entity.TransactionStore;
import com.airtelbank.transaction.constant.Constants;
import com.airtelbank.transaction.dto.application.ManageAccountStateResponse;
import com.airtelbank.transaction.dto.balance.EnquiryRequest;
import com.airtelbank.transaction.dto.balance.EnquiryResponse;
import com.airtelbank.transaction.dto.customerProfile.CustomerProfileDTO;
import com.airtelbank.transaction.exception.GenericException;
import com.airtelbank.transaction.model.HeaderRequestDTO;
import com.airtelbank.transaction.model.MetaV3;
import com.airtelbank.transaction.model.RequestDTO;
import com.airtelbank.transaction.model.TransactionEnquiryRequest;
import com.airtelbank.transaction.model.TransactionRequestDTO;
import com.airtelbank.transaction.model.response.AuaAuxResponseDTO;
import com.airtelbank.transaction.model.response.DocumentMgmtStoreResponseDTO;
import com.airtelbank.transaction.model.response.ShgPaymentTrx;
import com.airtelbank.transaction.service.impl.TransactionServiceHelper;
import com.airtelbank.transaction.service.impl.TransactionServiceImpl;
import com.airtelbank.transaction.util.CommonUtils;
import com.airtelbank.transaction.util.LogMasker;
import com.airtelbank.transaction.util.RestServiceHelper;
import com.airtelbank.transaction.util.SHGPHClientConfig;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.aerospike.core.AerospikeTemplate;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import static com.airtelbank.transaction.constant.Constants.AUA_VERIFICATION_SUCCESS;


@Component
public class ShgTransactionRuleStrategy implements TransactionRuleStrategy {
    private static final Logger log = LoggerFactory.getLogger(ShgTransactionRuleStrategy.class);

    @Autowired
    private AerospikeTemplate aerospikeTemplate;

    @Autowired
    private TransactionServiceImpl transactionService;

    @Autowired
    private PHDirectPaymentRequestServiceImpl pHDirectPaymentRequestServiceImpl;

    @Autowired
    private PHPaymentEnquiryServiceImpl phPaymentEnquiryService;

    @Autowired
    private LogMasker logMasker;

    @Value("${config.shg.payment.hub.partnerId}")
    private String partnerId;

    @Value("${config.shg.payment.hub.case.withdraw.usecase}")
    private String shgCashWithdrawUseCase;

    @Value("${config.shg.payment.hub.case.deposit.usecase}")
    private String shgCashDepositUseCase;

    @Value("${config.shg.payment.hub.case.fund.usecase}")
    private String shgFundTransferUseCase;

    @Autowired
    private SHGPHClientConfig phClientConfig;

    @Autowired
    private TransactionServiceHelper serviceHelper;

    @Autowired
    private RestServiceHelper restServiceHelper;


    @Override
    public ResponseDTO<DirectPaymentResponse> onboardingUsecaseToPaymentHub(TransactionRequestDTO transactionRequestDTO, HeaderRequestDTO headerRequestDTO, String amount) {
        ResponseDTO<DirectPaymentResponse> transactionResponse = null;
        DirectPaymentRequest directPaymentRequest = null;
        log.info("ShgTransactionRuleStrategy::onboardingUsecaseToPaymentHub with action ::{}", headerRequestDTO.getAction());
        log.info(CommonUtils.errorPrefixSuffix(
                "Inside ShgTransactionRuleStrategy::onboardingUsecaseToPaymentHub DirectPayment request : {}")
                + logMasker.patternReplace(CommonUtils.jsonObjectToString(transactionRequestDTO)));
        boolean cashWithdrawAction = Constants.Action.SHG_CW.equalsIgnoreCase(headerRequestDTO.getAction());
        boolean cashDepositAction =  Constants.Action.SHG_CD.equalsIgnoreCase(headerRequestDTO.getAction());
        boolean fundTransferAction = Constants.Action.SHG_IFT.equalsIgnoreCase(headerRequestDTO.getAction());
        if(!cashDepositAction && !cashWithdrawAction && !fundTransferAction) {
            log.error("ShgTransactionRuleStrategy::onboardingUsecaseToPaymentHub Invalid Action :: {} for initiate Payment ",headerRequestDTO.getAction());
            throw new GenericException(Constants.INVALID_REST_REQUEST_CODE, Constants.INVALID_ACTION);
        }
        if(!CommonUtils.isValidAction(headerRequestDTO.getFlowKey(),headerRequestDTO.getAction())) {
            log.error("Flow key and action is mismatching :: {} ,{}",headerRequestDTO.getFlowKey(),headerRequestDTO.getAction());
            throw new GenericException(Constants.INVALID_REST_REQUEST_CODE, Constants.INVALID_FLOW_KEY);
        }

        ManageAccountStateResponse manageAccountStateResponse= restServiceHelper.hitGetStateByAppId(transactionRequestDTO.getAppId(),headerRequestDTO);
        requestValidation(manageAccountStateResponse,headerRequestDTO);

        if (cashWithdrawAction) {
            //check source(SHG) account is correct or not
            checkAccountNo(transactionRequestDTO.getSourceDetails().getAccountNo(),manageAccountStateResponse);
           //check signatories are AUA verified or not
            if (!checkDocumentList(headerRequestDTO.getFlowKey(), headerRequestDTO,transactionRequestDTO.getAppId())) {
                log.error("ShgTransactionRuleStrategy::onboardingUsecaseToPaymentHub Signatory AUA verification is not completed for cash withdraw");
                throw new GenericException(Constants.INVALID_REST_REQUEST_CODE, Constants.AUA_NOT_COMPLETED);
            }
            //CBS A003 API call
            balanceAndLimitCheck(transactionRequestDTO,headerRequestDTO);
            // create payment hub request
            directPaymentRequest = cashWithDrawRequest(transactionRequestDTO, headerRequestDTO, shgCashWithdrawUseCase,manageAccountStateResponse.getPanAvailable());
            transactionResponse = initiatePaymentRequest(shgCashWithdrawUseCase, transactionRequestDTO, headerRequestDTO, directPaymentRequest);
        } else if (cashDepositAction) {
            //check target(SHG) account is correct or not
            checkAccountNo(transactionRequestDTO.getTargetDetails().getAccountNo(),manageAccountStateResponse);
            //check MPIN is verified or not
            checkMpinResponse(manageAccountStateResponse,headerRequestDTO);
            //check retailer account is correct or not
            checkRetailerAccountNo(manageAccountStateResponse,headerRequestDTO,transactionRequestDTO);
            //CBS A003 API call
            balanceAndLimitCheck(transactionRequestDTO,headerRequestDTO);
            directPaymentRequest = cashDepositRequest(transactionRequestDTO, headerRequestDTO, shgCashDepositUseCase,manageAccountStateResponse.getPanAvailable());
            transactionResponse = initiatePaymentRequest(shgCashDepositUseCase, transactionRequestDTO, headerRequestDTO, directPaymentRequest);
        } else if (fundTransferAction) {
            //check source(SHG) account is correct or not
            checkAccountNo(transactionRequestDTO.getSourceDetails().getAccountNo(),manageAccountStateResponse);
            if (!checkDocumentList(headerRequestDTO.getFlowKey(), headerRequestDTO,transactionRequestDTO.getAppId())) {
                log.error("ShgTransactionRuleStrategy::onboardingUsecaseToPaymentHub Signatory AUA verification is not completed for fund transfer");
                throw new GenericException(Constants.INVALID_REST_REQUEST_CODE, Constants.AUA_NOT_COMPLETED);
            }
            //CBS A003 API call
            balanceAndLimitCheck(transactionRequestDTO,headerRequestDTO);
            //v3Profile calling
            if(StringUtils.isNotBlank(transactionRequestDTO.getTargetDetails().getMobileNo()) && !transactionRequestDTO.getTargetDetails().getAccountNo().equals(transactionRequestDTO.getTargetDetails().getMobileNo()))
            	getCustomerV3Profile(transactionRequestDTO.getTargetDetails().getMobileNo(),headerRequestDTO,transactionRequestDTO.getTargetDetails().getAccountNo());

            directPaymentRequest = fundTransferRequest(transactionRequestDTO, headerRequestDTO, shgFundTransferUseCase,manageAccountStateResponse.getPanAvailable());
            transactionResponse = initiatePaymentRequest(shgFundTransferUseCase, transactionRequestDTO, headerRequestDTO, directPaymentRequest);
        }
        return transactionResponse;
    }

    @Override
    public ResponseDTO<String> paymentHubEnquiry(TransactionEnquiryRequest transactionEnquiryRequest, HeaderRequestDTO headerRequestDTO) {
        PaymentEnquiryResponse paymentEnquiryResponse=null;
        log.info("ShgTransactionRuleStrategy::paymentHubEnquiry with action ::{}", headerRequestDTO.getAction());
        boolean cashWithdrawAction = Constants.Action.SHG_CW.equalsIgnoreCase(headerRequestDTO.getAction());
        boolean cashDepositAction = Constants.Action.SHG_CD.equalsIgnoreCase(headerRequestDTO.getAction());
        boolean fundTransferAction = Constants.Action.SHG_IFT.equalsIgnoreCase(headerRequestDTO.getAction());
        if(!cashDepositAction && !cashWithdrawAction && !fundTransferAction) {
            log.error("ShgTransactionRuleStrategy::paymentHubEnquiry Invalid Action :: {} for  Payment enquiry ",headerRequestDTO.getAction());
            throw new GenericException(Constants.INVALID_REST_REQUEST_CODE, Constants.INVALID_ACTION);
        }
        if(!CommonUtils.isValidAction(headerRequestDTO.getFlowKey(),headerRequestDTO.getAction())) {
            log.error("Flow key and action is mismatching :: {} ,{}",headerRequestDTO.getFlowKey(),headerRequestDTO.getAction());
            throw new GenericException(Constants.INVALID_REST_REQUEST_CODE, Constants.INVALID_FLOW_KEY);
        }
        ManageAccountStateResponse manageAccountStateResponse= restServiceHelper.hitGetStateByAppId(transactionEnquiryRequest.getAppId(),headerRequestDTO);
        requestValidation(manageAccountStateResponse,headerRequestDTO);
        TransactionStore transactionStore = aerospikeTemplate.findById(transactionEnquiryRequest.getPrId(), TransactionStore.class);

        if (Objects.isNull(transactionStore)) {
            log.error("No Data found for given prId :: {} in TransactionStore", transactionEnquiryRequest.getPrId());
            throw new GenericException(Constants.INVALID_REST_REQUEST_CODE, Constants.INVALID_PAYMENT_ID);
        }

        if(!transactionStore.getAppId().equalsIgnoreCase(transactionEnquiryRequest.getAppId())) {
            log.error("AppId in request is not matched with appId present in txn_store");
            throw new GenericException(Constants.INVALID_REST_REQUEST_CODE, Constants.INVALID_APPLICATION_ID);
        }

        if(cashWithdrawAction) {
            //check signatories are AUA verified or not
            if (!checkDocumentList(headerRequestDTO.getFlowKey(), headerRequestDTO,transactionEnquiryRequest.getAppId())) {
                log.error("ShgTransactionRuleStrategy::paymentHubEnquiry Signatory AUA verification is not completed for cash withdraw");
                throw new GenericException(Constants.INVALID_REST_REQUEST_CODE,Constants.AUA_NOT_COMPLETED);
            }
            paymentEnquiryResponse = paymentEnquiry(shgCashWithdrawUseCase, transactionEnquiryRequest, transactionStore, headerRequestDTO);
        } else if(cashDepositAction) {
            //checking MPIN is verified or not
            checkMpinResponse(manageAccountStateResponse,headerRequestDTO);
            paymentEnquiryResponse = paymentEnquiry(shgCashDepositUseCase, transactionEnquiryRequest, transactionStore, headerRequestDTO);
        } else if (fundTransferAction) {
            if (!checkDocumentList(headerRequestDTO.getFlowKey(), headerRequestDTO,transactionEnquiryRequest.getAppId())) {
                log.error("ShgTransactionRuleStrategy::paymentHubEnquiry Signatory AUA verification is not completed for fund transfer");
                throw new GenericException(Constants.INVALID_REST_REQUEST_CODE,Constants.AUA_NOT_COMPLETED);
            }
            paymentEnquiryResponse = paymentEnquiry(shgFundTransferUseCase, transactionEnquiryRequest, transactionStore, headerRequestDTO);
        }
        return responseBuilder(paymentEnquiryResponse);
    }


    public boolean checkDocumentList(String docId, HeaderRequestDTO headerRequestDTO,String appId) {
        boolean status = false;
        long auaSuccessCount;
        AuaAuxResponseDTO signatoryAUAResponse = null;
        ObjectMapper mapper = new ObjectMapper();
        DocumentMgmtStoreResponseDTO documentMgmtStoreResponseDTO = restServiceHelper.hitGetDocumentByDocId(docId, headerRequestDTO);
        if (Objects.isNull(documentMgmtStoreResponseDTO)) {
            log.error("documentMgmtStoreResponseDTO is null");

        }
        if (Objects.nonNull(documentMgmtStoreResponseDTO) && documentMgmtStoreResponseDTO.getAppId().equalsIgnoreCase(appId) && documentMgmtStoreResponseDTO.getCustomerHandleNumber().equalsIgnoreCase(headerRequestDTO.getCustomerHandleNumber()) && Objects.nonNull(documentMgmtStoreResponseDTO.getDocAuxiliaryInfo()) && Objects.nonNull(documentMgmtStoreResponseDTO.getDocAuxiliaryInfo().get("AUA_DETAILS"))) {
            signatoryAUAResponse = mapper.convertValue(documentMgmtStoreResponseDTO.getDocAuxiliaryInfo().get(Constants.AUA_DETAILS), AuaAuxResponseDTO.class);
            if (Objects.nonNull(signatoryAUAResponse) && Objects.nonNull(signatoryAUAResponse.getAuaAuxResponses()) && (!CollectionUtils.isEmpty(signatoryAUAResponse.getAuaAuxResponses()))) {
                auaSuccessCount = signatoryAUAResponse.getAuaAuxResponses().stream().filter(a -> a.getDocStatus().equalsIgnoreCase(AUA_VERIFICATION_SUCCESS)).count();
                if (auaSuccessCount >= Constants.AUA_SUCCESS_COUNT) {
                    status = true;
                }
            }
        }
        return status;
    }


    private DirectPaymentRequest cashWithDrawRequest(TransactionRequestDTO transactionRequestDTO, HeaderRequestDTO headerRequestDTO, String usecase,String panStatus) {
        CustomerDetail customerDetail = CustomerDetail.builder()
                .custMsisdn(transactionRequestDTO.getSourceDetails().getMobileNo()).build();
        DirectPaymentRequest directPaymentRequest=directPaymentRequestForPH(usecase,headerRequestDTO,transactionRequestDTO,Constants.SBA,Constants.SHG,Constants.RET,panStatus);
        directPaymentRequest.setCustomerDetail(customerDetail);
        log.info(CommonUtils.errorPrefixSuffix(
                "Inside ShgTransactionRuleStrategy::onboardingUsecaseToPaymentHub cash withdraw Payment hub request : {}")
                + logMasker.patternReplace(CommonUtils.jsonObjectToString(directPaymentRequest)));
        return directPaymentRequest;
    }


    private DirectPaymentRequest cashDepositRequest(TransactionRequestDTO transactionRequestDTO, HeaderRequestDTO headerRequestDTO, String usecase,String panStatus) {
        CustomerDetail assistedBy = CustomerDetail.builder()
                .custMsisdn(transactionRequestDTO.getSourceDetails().getMobileNo()).build();
        DirectPaymentRequest directPaymentRequest=directPaymentRequestForPH(usecase,headerRequestDTO,transactionRequestDTO,Constants.MCASH,Constants.RET,Constants.SHG,panStatus);
        directPaymentRequest.setAssistedBy(assistedBy);
        log.info(CommonUtils.errorPrefixSuffix(
                "Inside ShgTransactionRuleStrategy::onboardingUsecaseToPaymentHub cash deposit transfer  Payment hub request : {}")
                + logMasker.patternReplace(CommonUtils.jsonObjectToString(directPaymentRequest)));
        return directPaymentRequest;
    }



    private DirectPaymentRequest fundTransferRequest(TransactionRequestDTO transactionRequestDTO, HeaderRequestDTO headerRequestDTO, String usecase,String panStatus) {
        CustomerDetail customerDetail = CustomerDetail.builder()
                .custMsisdn(transactionRequestDTO.getSourceDetails().getMobileNo()).build();
        DirectPaymentRequest directPaymentRequest=directPaymentRequestForPH(usecase,headerRequestDTO,transactionRequestDTO,Constants.SBA,Constants.SHG,Constants.SBA,panStatus);
        directPaymentRequest.setCustomerDetail(customerDetail);
        log.info(CommonUtils.errorPrefixSuffix(
                "Inside ShgTransactionRuleStrategy::onboardingUsecaseToPaymentHub Fund transfer Payment hub request : {}")
                + logMasker.patternReplace(CommonUtils.jsonObjectToString(directPaymentRequest)));
        return directPaymentRequest;
    }

    private ResponseDTO responseBuilder(PaymentEnquiryResponse paymentEnquiryResponse) {
        Meta meta = null;
        ResponseDTO responseDTO = null;
        if (Objects.nonNull(paymentEnquiryResponse) && Objects.nonNull(paymentEnquiryResponse.getDebitDetails())
                && !(CollectionUtils.isEmpty(paymentEnquiryResponse.getDebitDetails()))) {
            if (Constants.SUCCESS.equalsIgnoreCase(paymentEnquiryResponse.getDebitDetails().get(0).getStatus())) {
                meta = new Meta();
                responseDTO = new ResponseDTO();
                meta.setStatus(Constants.STATUS_SUCCESS);
                meta.setCode(Constants.SUCCESS_RES_CODE);
                meta.setDescription(Constants.SUCCESS_ENQUIRY);
                responseDTO.setMeta(meta);
                return responseDTO;
            } else if (Constants.FAILED.equalsIgnoreCase(paymentEnquiryResponse.getDebitDetails().get(0).getStatus())){
                meta = new Meta();
                responseDTO = new ResponseDTO();
                meta.setStatus(Constants.STATUS_FAILURE);
                meta.setCode(Constants.FAILED_RES_CODE);
                meta.setDescription(Constants.FAILED_ENQUIRY);
                responseDTO.setMeta(meta);
                return responseDTO;
            } else {
                meta = new Meta();
                responseDTO = new ResponseDTO();
                meta.setStatus(Constants.STATUS_PENDING_OR_INITIATED);
                meta.setCode(Constants.INITIATED_OR_PENDING_RES_CODE);
                meta.setDescription(Constants.INITIATED_OR_PENDING_ENQUIRY);
                responseDTO.setMeta(meta);
                return responseDTO;
            }
        } else {
            meta = new Meta();
            responseDTO = new ResponseDTO();
            meta.setStatus(Constants.NO_DATA);
            meta.setCode(Constants.NO_DATA_RES_CODE);
            meta.setDescription(Constants.NO_DATA_ENQUIRY);
            responseDTO.setMeta(meta);
            return responseDTO;
        }
    }

    private ResponseDTO<DirectPaymentResponse> initiatePaymentRequest(String useCase, TransactionRequestDTO transactionRequestDTO, HeaderRequestDTO headerRequestDTO, DirectPaymentRequest directPaymentRequest) {
        ResponseDTO<DirectPaymentResponse> transactionResponse = null;
        phClientConfig.init(useCase);
        log.info("payment hub request :: {}", directPaymentRequest);
        transactionResponse = pHDirectPaymentRequestServiceImpl.paymentRequest(useCase,
                directPaymentRequest, headerRequestDTO.getContentid());
        log.info("Payment hub response :: {}", transactionResponse);
        if (Objects.isNull(transactionResponse)) {
            log.error("transactionResponse is null");
            throw new GenericException(Constants.TECHNICAL_ISSUE_CODE, Constants.TECHNICAL_ISSUE);
        }
        if (Objects.nonNull(transactionResponse.getData()) && Objects.nonNull(transactionResponse.getData().getPaymentReqId())) {
            serviceHelper.savePaymentResponse(useCase, transactionRequestDTO, transactionResponse, headerRequestDTO);
        }
        return transactionResponse;
    }

    private PaymentEnquiryResponse paymentEnquiry(String useCase,TransactionEnquiryRequest transactionEnquiryRequest,TransactionStore transactionStore,HeaderRequestDTO headerRequestDTO)
    {
        phClientConfig.init(useCase);
        PaymentEnquiryRequest paymentEnquiryRequest = PaymentEnquiryRequest.builder()
                .partnerId(partnerId)
                .paymentReqId(transactionEnquiryRequest.getPrId())
                .orderId(transactionStore.getOrderId())
                .useCase(useCase)
                .build();
        log.info(CommonUtils.errorPrefixSuffix(
                "Inside ShgTransactionRuleStrategy::paymentHubEnquiry PaymentEnquiryRequest request : {}")
                + logMasker.patternReplace(CommonUtils.jsonObjectToString(paymentEnquiryRequest)));
        ResponseDTO<PaymentEnquiryResponse> paymentEnquiry = phPaymentEnquiryService.paymentEnquiry(useCase, paymentEnquiryRequest, headerRequestDTO.getContentid());
        log.info("Payment hub enquiry response :: {}", paymentEnquiry);
        if (Objects.isNull(paymentEnquiry)) {
            log.error("paymentEnquiryResponse is null");
            return null;
        }
        if (Objects.nonNull(paymentEnquiry.getData())) {
            //updating store and pushing data to kafka
            serviceHelper.updatePaymentResponse(paymentEnquiry.getData(), transactionStore, headerRequestDTO,useCase);
        }
        return paymentEnquiry.getData();
    }

    private void requestValidation(ManageAccountStateResponse manageAccountStateResponse,HeaderRequestDTO headerRequestDTO) {
        if(Objects.isNull(manageAccountStateResponse)) {
            log.error("manageAccountStateResponse is null");
            throw new GenericException(Constants.INVALID_REST_REQUEST_CODE, Constants.INVALID_APPLICATION_ID);
        }
        if(StringUtils.isBlank(manageAccountStateResponse.getCustomerHandleNo())) {
            log.error("manageAccountStateResponse :: CustomerHandleNo is null");
            throw new GenericException(Constants.INVALID_REST_REQUEST_CODE, Constants.INVALID_REQUEST_MSG);
        }
        if(!manageAccountStateResponse.getCustomerHandleNo().equalsIgnoreCase(headerRequestDTO.getCustomerHandleNumber())) {
            log.error("Customer handle number is not matched with customer handle present in management store");
            throw new GenericException(Constants.INVALID_REST_REQUEST_CODE, Constants.INVALID_CUST_HANDLE_NO);
        }
    }
    private void checkMpinResponse(ManageAccountStateResponse manageAccountStateResponse,HeaderRequestDTO headerRequestDTO) {
        ShgPaymentTrx shgPaymentTrx=null;
        List<ShgPaymentTrx> shgPaymentTrxList=null;
        if(Constants.Action.SHG_CD.equalsIgnoreCase(headerRequestDTO.getAction())) {
            if(Objects.nonNull(manageAccountStateResponse.getPaymentAuxInfo()) && !(CollectionUtils.isEmpty(manageAccountStateResponse.getPaymentAuxInfo().getShgPaymentTrxList()))) {
                shgPaymentTrxList=manageAccountStateResponse.getPaymentAuxInfo().getShgPaymentTrxList();
                shgPaymentTrx=shgPaymentTrxList.get(shgPaymentTrxList.size()-1);
                if(shgPaymentTrx.getFlowKey().equalsIgnoreCase(headerRequestDTO.getFlowKey())) {
                    log.info("Flow key is  matching with present flow key in account manage store ");
                    if(Constants.SUCCESS.equalsIgnoreCase(shgPaymentTrx.getMpinResponse()))
                        log.info("Mpin response is success for flow key :: {}",headerRequestDTO.getFlowKey());
                    else {
                        log.error("Mpin is not validated for flow key :: {}", headerRequestDTO.getFlowKey());
                        throw new GenericException(Constants.INVALID_REST_REQUEST_CODE, Constants.MPIN_VERIFICATION_FAILED);
                    }
                } else {
                    log.error("Flow key is not matching with present flow key in account manage store");
                    throw new GenericException(Constants.INVALID_REST_REQUEST_CODE, Constants.INVALID_REQUEST_MSG);
                }
            }
            else {
                log.error("Aux List of empty or data is null in aux for Cash deposit");
                throw new GenericException(Constants.INVALID_REST_REQUEST_CODE, Constants.INVALID_REQUEST_MSG);
            }
        }
    }
    private void checkAccountNo(String accountNo,ManageAccountStateResponse manageAccountStateResponse) {
        if(StringUtils.isBlank(manageAccountStateResponse.getAccountNo())) {
            log.error("ManageAccountStateResponse :: Account No is null");
            throw new GenericException(Constants.INVALID_REST_REQUEST_CODE, Constants.INVALID_REQUEST_MSG);
        }if(!(accountNo.equalsIgnoreCase(manageAccountStateResponse.getAccountNo()))) {
            log.error("user account is not matching with account number present in account management store");
            throw new GenericException(Constants.INVALID_REST_REQUEST_CODE, Constants.INVALID_ACCOUNT_NO);
        }
    }

    private void checkRetailerAccountNo(ManageAccountStateResponse manageAccountStateResponse,HeaderRequestDTO headerRequestDTO,TransactionRequestDTO transactionRequestDTO) {
        ShgPaymentTrx shgPaymentTrx=null;
        List<ShgPaymentTrx> shgPaymentTrxList=null;
        if(Objects.nonNull(manageAccountStateResponse.getPaymentAuxInfo()) && !(CollectionUtils.isEmpty(manageAccountStateResponse.getPaymentAuxInfo().getShgPaymentTrxList()))) {
            shgPaymentTrxList = manageAccountStateResponse.getPaymentAuxInfo().getShgPaymentTrxList();
            shgPaymentTrx = shgPaymentTrxList.get(shgPaymentTrxList.size() - 1);
            if (shgPaymentTrx.getFlowKey().equalsIgnoreCase(headerRequestDTO.getFlowKey())) {
                log.info("Flow key is  matching with present flow key in account manage store ");
                if (!(shgPaymentTrx.getRetailerAccountNo().equalsIgnoreCase(transactionRequestDTO.getSourceDetails().getAccountNo())) ||
                        !(shgPaymentTrx.getRetailerMobile().equalsIgnoreCase(transactionRequestDTO.getSourceDetails().getMobileNo()))) {
                    log.error("Retailer Account, Retailer Mobile  is not matching with account management store for flow key :: {}", headerRequestDTO.getFlowKey());
                    throw new GenericException(Constants.INVALID_REST_REQUEST_CODE, Constants.INVALID_REQUEST_MSG);
                }
                else{
                    log.error("Retailer Account, Retailer Mobile  is  matching with account management store for flow key :: {}",headerRequestDTO.getFlowKey());
                }
            }
            else {
                log.error("Flow key is not matching with present flow key in account manage store");
                throw new GenericException(Constants.INVALID_REST_REQUEST_CODE, Constants.INVALID_REQUEST_MSG);
            }
        }else {
            log.error("Aux List of empty or data is null in aux for Cash deposit");
            throw new GenericException(Constants.INVALID_REST_REQUEST_CODE, Constants.INVALID_REQUEST_MSG);
        }

    }

    private RequestDTO<EnquiryRequest> balanceEnquiry(TransactionRequestDTO transactionRequestDTO,HeaderRequestDTO headerRequestDTO) {
        RequestDTO<EnquiryRequest> requestDTO=new RequestDTO<>();
        EnquiryRequest enquiryRequest= EnquiryRequest.builder()
                .sourceAccountNo(transactionRequestDTO.getSourceDetails().getAccountNo())
                .targetAccountNo(transactionRequestDTO.getTargetDetails().getAccountNo())
                .amount(new BigDecimal(transactionRequestDTO.getAmount()))
                .build();
        MetaV3 meta=new MetaV3();
        meta.setAppType(headerRequestDTO.getAppType());
        requestDTO.setData(enquiryRequest);
        requestDTO.setMeta(meta);
        return requestDTO;
    }
    private void balanceAndLimitCheck(TransactionRequestDTO transactionRequestDTO,HeaderRequestDTO headerRequestDTO) {
        EnquiryResponse enquiryResponse= restServiceHelper.hitBalanceEnquiry(balanceEnquiry(transactionRequestDTO,headerRequestDTO),headerRequestDTO);
        if(Objects.isNull(enquiryResponse)) {
            throw new GenericException(Constants.TECHNICAL_ISSUE_CODE, Constants.TECHNICAL_ISSUE);
        }
        if(Constants.LIMIT_ALLOWED!=enquiryResponse.getLimit()) {
            log.error("Transaction not allowed for this account , limit :: {}",enquiryResponse.getLimit());
            throw new GenericException(Constants.LIMIT_EXAUSTED_CODE, Constants.LIMIT_EXAUSTED_MSG);
        }
        if(Double.parseDouble(transactionRequestDTO.getAmount())>Double.parseDouble(enquiryResponse.getAvailableBalance())) {
            log.error("Transaction not allowed for this account , enter amount is greater than available balance :: {}",enquiryResponse.getAvailableBalance());
            throw new GenericException(Constants.BALANCE_EXCEED_CODE, Constants.BALANCE_EXCEED_MSG);
        }
    }
    
    private CustomerProfileDTO getCustomerV3Profile(String mobileNumber, HeaderRequestDTO headerRequestDTO, String targetAccountNo) {
        log.info("checking Customer Profile V3");
        CustomerProfileDTO customerPofileResponse = restServiceHelper.getCustomerV3Profile(
                mobileNumber, headerRequestDTO.getChannel(), headerRequestDTO.getContentid());
        log.info("customerPofileResponse ::{} ", customerPofileResponse);
        if(Objects.isNull(customerPofileResponse)) {
        	log.error("Null response for mobile :: {} in getCustomerV3Profile ",mobileNumber);
            throw new GenericException(Constants.INVALID_REST_REQUEST_CODE, Constants.TARGET_MOB_INVALID_MSG);
        }  
        checkSbaAccountNumber(customerPofileResponse,targetAccountNo);
        return customerPofileResponse;
    }
    
    private void checkSbaAccountNumber(CustomerProfileDTO customerPofileResponse,String sbaAccountNo) {
    	if (Objects.nonNull(customerPofileResponse.getAccounts()) && Objects.isNull(customerPofileResponse.getAccounts().get(Constants.ACCOUNT_TYPE_SBA))) {
        	log.error("Invalid Target account number :: {} in getCustomerV3Profile ",sbaAccountNo);
            throw new GenericException(Constants.INVALID_REST_REQUEST_CODE, Constants.INVALID_ACCOUNT_NO);
        }
        
        if (!customerPofileResponse.getAccounts().get(Constants.ACCOUNT_TYPE_SBA).getNumber().equals(sbaAccountNo)) {
        	log.error("Invalid Target account number :: {} in getCustomerV3Profile ",sbaAccountNo);
            throw new GenericException(Constants.INVALID_REST_REQUEST_CODE, Constants.ACCOUNT_NO_MISMATCHED);
        }
    }

    private OrderDetails orderDetailsRequest(TransactionRequestDTO transactionRequestDTO,String orderId,AccountDetail accountDetail,Map<String,String> map) {
        List<OrderItems> orderItemsList = new ArrayList<>();
        OrderItems orderItems=OrderItems.builder()
                .amount(Double.parseDouble(transactionRequestDTO.getAmount()))
                .amt(transactionRequestDTO.getAmount())
                .orderItemId(orderId)
                .billerDetails(accountDetail)
                .additionalParam1(map.get(Constants.PARAM_1_KEY))
                .additionalParam2(map.get(Constants.PARAM_2_KEY))
                .build();
        orderItemsList.add(orderItems);
        OrderDetails orderDetailsRequest = OrderDetails.builder().orderItems(orderItemsList).build();
        return orderDetailsRequest;
    }
    private Map<String, Object> additionalDetails(String crNarration,String drNarration) {
        Map<String, Object> additionalDetails = new HashMap<>();
        additionalDetails.put(Constants.CR_NARRATION, crNarration);
        additionalDetails.put(Constants.DR_NARRATION, drNarration);
        return additionalDetails;
    }
    private DirectPaymentRequest directPaymentRequestForPH(String usecase,HeaderRequestDTO headerRequestDTO,TransactionRequestDTO transactionRequestDTO,String optionType,String fromCustType,String toCustType,String panStatus) {
        Map<String,String> narrationMap=serviceHelper.useCaseNarration(headerRequestDTO.getAction(),panStatus);
        String orderId = transactionService.orderId();
        List<Options> selectedOptionsList = new ArrayList<>();
        Options selectedOptionsRequest = Options.builder().amount(transactionRequestDTO.getAmount()).optionType(optionType)
                .accountNumber(transactionRequestDTO.getSourceDetails().getAccountNo())
                .custType(fromCustType)
                .build();
        selectedOptionsList.add(selectedOptionsRequest);

        AccountDetail accountDetail = AccountDetail.builder()
                .accountNumber(transactionRequestDTO.getTargetDetails().getAccountNo())
                .msisdn(transactionRequestDTO.getTargetDetails().getMobileNo())
                .custType(toCustType)
                .build();
        DirectPaymentRequest directPaymentRequest = new DirectPaymentRequest();
        directPaymentRequest.setSelectedOptions(selectedOptionsList);
        directPaymentRequest.setAccessChannel(headerRequestDTO.getChannel());
        directPaymentRequest.setOrderId(orderId);
        directPaymentRequest.setHash(null);
        directPaymentRequest.setPartnerId(partnerId);
        directPaymentRequest.setOrderDetails(orderDetailsRequest(transactionRequestDTO,orderId,accountDetail,narrationMap));
        directPaymentRequest.setAdditionalDetails(additionalDetails(narrationMap.get(Constants.CR_KEY),narrationMap.get(Constants.DR_KEY)));
        directPaymentRequest.setTotalAmt(transactionRequestDTO.getAmount());
        directPaymentRequest.setTotalAmount(new BigDecimal(transactionRequestDTO.getAmount()));
        directPaymentRequest.setUseCase(usecase);
        return directPaymentRequest;
    }

}
