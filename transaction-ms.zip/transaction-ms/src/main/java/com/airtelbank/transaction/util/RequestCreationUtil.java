
package com.airtelbank.transaction.util;

import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Component;
import org.springframework.util.MultiValueMap;

import com.airtelbank.transaction.constant.Constants;
import com.airtelbank.transaction.model.RestRequest;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
public class RequestCreationUtil {
	public static <T> RestRequest<T> createRestRequest(String url, HttpMethod method, Object body,
													   Class<T> responseClass, Map params, MultiValueMap headers) {
		RestRequest<T> restRequest = new RestRequest<>();
		restRequest.setUri(url);
		restRequest.setHttpMethod(method);
		restRequest.setEntity(body);
		restRequest.setResponseClass(responseClass);
		restRequest.setParams(params);
		restRequest.setHeaders(headers);
		return restRequest;
	}
	public static MultiValueMap<String, String> getMultiValueMapHeader(String contentId, String channel, String userAgent) {
		MultiValueMap<String, String> headers = getMultiValueMapHeader(contentId, channel);
		if( null != userAgent ) {
			headers.add(Constants.USER_AGENT, userAgent);
		}
		return headers;
	}

	public static MultiValueMap<String, String> getMultiValueMapHeader(String contentId, String channel) {
		MultiValueMap<String, String> headers = new HttpHeaders();
		if( null != contentId ) {
			headers.add(Constants.CONTENT_ID, contentId);
		}
		if( null != channel ) {
			headers.add(Constants.CHANNEL, channel);
		}
		return headers;
	}

	public static MultiValueMap<String, String> getMultiValueMapHeader(String contentId, String channel, String customerHandleNumber, String callerEntity) {
		MultiValueMap<String, String> headers = getMultiValueMapHeader(contentId, channel);
		if( null != customerHandleNumber ) {
			headers.add(Constants.CUSTOMER_HANDLE_NUMBER, customerHandleNumber);
		}
		if( null != callerEntity) {
			headers.add(Constants.CALLER_ENTITY, callerEntity);
		}
		return headers;
	}

	public static MultiValueMap<String, String> getMultiValueMapHeader(HashMap<String,String> map) {
		MultiValueMap<String, String> headers = new HttpHeaders();
		if(Objects.nonNull(map.get(Constants.CONTENT_ID)))
			headers.add(Constants.CONTENT_ID, map.get(Constants.CONTENT_ID));
		if(Objects.nonNull(map.get(Constants.CHANNEL)))
			headers.add(Constants.CHANNEL, map.get(Constants.CHANNEL));
		if(Objects.nonNull(map.get(Constants.action)))
			headers.add(Constants.action, map.get(Constants.action));
		if(Objects.nonNull(map.get(Constants.APP_TYPE)))
			headers.add(Constants.APP_TYPE, map.get(Constants.APP_TYPE));
		if(Objects.nonNull(map.get(Constants.FLOW_KEY)))
			headers.add(Constants.FLOW_KEY, map.get(Constants.FLOW_KEY));
		return headers;
	}

	public static MultiValueMap<String, String> getMultiValueMapHeaderMobileNumber(String contentId, String channel, String customerHandleNumber) {
		MultiValueMap<String, String> headers = getMultiValueMapHeader(contentId, channel);
		if( null != customerHandleNumber ) {
			headers.add(Constants.MOBILE_NUMBER, customerHandleNumber);
		}
		return headers;
	}

	public static MultiValueMap<String, String> getMultiValueMapHeaderMobileNumberAndAppType(String contentId, String channel, String customerHandleNumber, String appType) {
		MultiValueMap<String, String> headers = getMultiValueMapHeader(contentId, channel);
		if( null != customerHandleNumber ) {
			headers.add(Constants.MOBILE_NUMBER, customerHandleNumber);
		}
		if( null != appType ) {
			headers.add(Constants.APP_TYPE, appType);
		}
		return headers;
	}
	
	public static MultiValueMap<String, String> getMultiValueMapHeader(String appType) {
		MultiValueMap<String, String> headers = new HttpHeaders();
		if( null != appType ) {
			headers.add(Constants.APP_TYPE, appType);
		}
		return headers;
	}

	public static Map<String, Object> getParamMap(String id, String requestType) {
		Map<String, Object> params = new HashMap<>();
		params.put(Constants.ID, id);
		params.put(Constants.REQUEST_TYPE, requestType);
		return params;
	}
	
	public static MultiValueMap<String, String> getSingleValueMapHeader(String contentType) {
		MultiValueMap<String, String> headers = new HttpHeaders();
		if( null != contentType ) {
			headers.add(Constants.CONTENT_TYPE, contentType);
		}
		return headers;
	}
	
	public static MultiValueMap<String, String> getMultiValueMapHeaderWithRetNo(String contentId, String channel, String retailerNo ) {
		MultiValueMap<String, String> headers = new HttpHeaders();
		if( null != contentId ) {
			headers.add(Constants.CONTENT_ID, contentId);
		}
		if( null != channel ) {
			headers.add(Constants.CHANNEL, channel);
		}
		if( null != retailerNo ) {
			headers.add(Constants.RET_NO, retailerNo);
		}
		return headers;
	}
	
	public static MultiValueMap<String, String> getMultiValueMapForCustomerProfileResponseV3(String channel, String contentId) {			
		MultiValueMap<String, String> headers = getMultiValueMapHeader(contentId, channel);
		headers.add(Constants.CONTENT_TYPE, Constants.APPLICATION_JSON);
		headers.add(Constants.SEGMENT, Constants.CUSTOMER_SEGMENT);
		return headers;
	}

	public static MultiValueMap<String, String> getMultiValueMapHeaderWithAppType(String contentId, String channel, String customerHandleNumber, String appType ) {
		MultiValueMap<String, String> headers = getMultiValueMapHeader(contentId, channel);
		if( null != customerHandleNumber ) {
			headers.add(Constants.CUSTOMER_HANDLE_NUMBER, customerHandleNumber);
		}
		if( null != appType ) {
			headers.add(Constants.APP_TYPE, appType);
		}
		return headers;
	}
}
