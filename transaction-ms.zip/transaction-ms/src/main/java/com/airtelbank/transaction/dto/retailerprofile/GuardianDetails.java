package com.airtelbank.transaction.dto.retailerprofile;

import java.time.LocalDate;

import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@JsonInclude(JsonInclude.Include.NON_EMPTY)
@Setter
@Getter
@ToString
@NoArgsConstructor
@Builder
@AllArgsConstructor
public class GuardianDetails {

	private boolean guardianAddressSame;
	private String guardianName;
	private String guardianFname;
	private String guardianMname;
	private String guardianLname;
	private String guardianMobile;
	private String guardianEmailId;
	private String guardianPhone;
	private String guardianAge;
	private LocalDate guardianDateOfBirth;
	private String guardianDob;
	private String guardianRelationship;

	private String guardianAddress1;
	private String guardianAddress2;
	private String guardianAddress3;
	private String guardianAddress4;
	private String guardianDistrict;
	private String guardianCity;
	private String guardianState;
	@Builder.Default
	private String guardianCountry = "India";
	private String guardianZip;

}
