package com.airtelbank.transaction.constant;

import java.text.SimpleDateFormat;

public class Constants {

	public static final int STATUS_SUCCESS = 0;
	public static final int STATUS_FAILURE = 1;
	public static final String ERRORS = "errors";
	public static final String ONE = "1";
	public static final String ACCESS_CHANNEL = "RAPP";
	public static final String SBA = "SBA";
	public static final String MCASH = "MCASH";
	public static final String APPTYPE = "appType";
	public static final String FE_SESSIONID = "feSessionId";
	public static final String Authorization = "Authorization";
	public static final String ID = "id";
	public static final String REQUEST_TYPE = "requestType";
	public static final String SUCCESS = "SUCCESS";
	public static final String PENDING = "PENDING";
	public static final String FAILED = "FAILED";
	public static final String PAYMENT_SUCCESS = "SUCCESS";
	public static final String AEROSPIKE_EXCEPTION_CODE = "8095";
	public static final String AEROSPIKE_EXCEPTION_MSG = "Error occurred while getting data";
	public static final String PAYMENT_ERROR_EXCEPTION_AUDIT = "Exception occured while making call to PaymentHub ";
	public static final String PAYMENT_REQUEST_SUCCESS_AUDIT = "Direct Payment Requst Successfull";
	public static final String PAYMENT_ENQUIRY_SUCCESS_AUDIT = "Direct ENQUIRY Requst Successfull";
	public static final int STATUS_EXCEPTION = 2;
	public static final String REQUEST_SUCCESS_DESCRIPTION = "SUCCESS";
	public static final String REQUEST_FAILURE_DESCRIPTION = "FAILED";
	public static final String THIRD_PARTY_ERROR_CODE = "7005";
	public static final String STATUS_CODE = "STATUS_CODE";
	public static final String STATUS_DESC = "STATUS_DESC";
	public static final String SUCCESS_CODE = "0";
	public static final String FAILURE_ERROR_CODE = "1";
	public static final String SERVICE_UNREACHABLE = "Service unreachable, Please try again later.";
	public static final String SOMETHING_WENT_WRONG = "Something went wrong, Please try again later.";
	public static final String BAD_REQ_ERROR_CODE = "APBM400";
	public static final String INVALID_REQUEST_MSG = "Invalid request.";
	public static final String FCI_DETAILS_NOT_RETRIEVED = "FCIDetails could not be retrieved for this request.";
	public static final String THIRD_PARTY_ERROR_MSG = "Third party error.";
	public static final String SUCCESSFULLY_PROCESSED = "Successfully Processed";
	public static final String DATA_DECRYPT_FAILED = "Data Decyrpting error";
	public static final String GENERATE_HASH_FAILED = "Not able to generate hash.";
	public static final String FULLLFILLLMENT_FAILED = "Fullfillment failed";
	public static final String INVALID_CUSTOMER_HANDLE_NUMBER_CODE = "7012";
	public static final String INVALID_CUSTOMER_HANDLE_NUMBER_MSG = "Invalid Customer Handle Number!!";
	public static final String INVALID_REST_REQUEST_CODE = "7002";
	public static final String INVALID_REST_REQUEST_MSG = "Invalid Rest Request.";
	public static final String FCI_NOT_EXIT = "FCI does not exist for given ID.";
	public static final String ERROR_MSG_PREFIX = "<!!! ";
	public static final String ERROR_MSG_SUFFIX = " !!!>";

	public static final String CONTENT_ID = "contentId";
	public static final String CHANNEL = "channel";
	public static final String CUSTOMER_HANDLE_NUMBER = "customerhandlenumber";
	public static final String CALLER_ENTITY = "callerEntity";
	public static final String APPLICATION_CONTEXT = "applicationContext";
	public static final String MOBILE_NUMBER = "mobilenumber";
	public static final String CONTENT_TYPE = "Content-Type";
	public static final String USER_AGENT = "User-Agent";
	public static final String CUSTOMER_ID = "customerId";
	public static final String APP_TYPE = "apptype";
	public static final String AGENT = "AGENT";
	public static final String AUDITOR = "AUDITOR";
	public static final SimpleDateFormat SIMPLEDATEFORMAT = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSSSSS");
	public static final String GREATER_THAN_SYMBOL = "<";
	public static final String GREATER_THAN_SYMBOL_PLUS = "</";
	public static final String LESSER_THAN_SYMBOL = ">";
	public static final String FORWARD_SLASH_WITH_PIPE = "\\|";
	public static final String MASK = "****";
	
	public static final String INVALID_APPID_MSG = "INVALID_APPID_MSG";
	public static final String INVALID_APPID_CODE = "7005";
	
	public static final String INVALID_CONTENT_ID_MSG = "INVALID_CONTENT_ID_MSG";
	public static final String INVALID_CONTENT_ID_CODE = "7006";
	public static final Integer RESPONSE_STATUS_SUCCESS = 0;
    public static final Integer RESPONSE_STATUS_FAIL = 1;
    public static final Integer RESPONSE_STATUS_TIMEOUT = 2;

    public static final String CASH_DEPOSIT_SUCCESS_CODE = "6010";
	public static final String CASH_DEPOSIT_FAILURE_CODE = "6011";
	public static final String CASH_WITHDRAWAL_SUCCESS_CODE = "6006";
	public static final String CASH_WITHDRAWAL_FAILURE_CODE = "6007";
	public static final String IFT_FAILURE_CODE = "6017";
	public static final String IFT_SUCCESS_CODE = "6016";
	public static final String INITIATED_OR_PENDING_RES_CODE="7011";
	public static final String NO_DATA_RES_CODE="7012";
	public static final String LIMIT_EXAUSTED_CODE = "7003";
	public static final String BALANCE_EXCEED_CODE = "7004";
	public static final String SUCCESS_RES_CODE="000";
	public static final String FAILED_RES_CODE="7010";
	public static final String THIRD_PARTY_TIMEOUT_CODE = "7013";

    public static final String DELIMITERS  = ",";
	public static final String WALLET_PRODUCT_TYPE = "W";
	public static final String LKY = "lky";
	public static final String YYYYMMDD = "yyyy-MM-dd";
	public static final int PERIOD = 1;
	public static final String ACTIVATION_CHARGES_SHOULD_BE_SAME_AS_AFC_DATA_FROM_REQUEST_CODE = "8017";
	public static final String ACTIVATION_CHARGES_SHOULD_BE_SAME_AS_AFC_DATA_FROM_REQUEST_MSG = "Invalid FCI value";
	

	public static final String OR_STORE_CATEGORY = "20030";
	public static final String OR_STORE_CATEGORY_CODE = "8018";
	public static final String OR_STORE_CATEGORY_MSG = "Dear Banking Point agent, you do not have enough balance. Please recharge M-Cash and try again.";
	public static final String RETAILER_DETAILS_NOT_RETRIEVED = "Retailer details could not be retrieved for this request.";
	public static final String RETAILER_CATEGORY_NOT_RETRIEVED = "Retailer category could not retrieved for this request.";
	public interface KibanaLoggingIdentifier {
		String TRANSACTION_PAYMENT_CONSUMER_ASYNC = "TRANSACTION_PAYMENT_CONSUMER_ASYNC";
	}
	
	public static final String ACTION = "CREATE";
	public static final String RAPP = "RAPP";
	
	public static final String RET_NO ="retailerNo";
	
	public static final String GET_TRANSACTION_STATE_FAILURE = "There does not exists any transaction corresponding to this AppId!!";
	public static final String GET_TRANSACTION_STATE_SUCCESS = "Fetched transaction state Successfully!!";

	public interface AppType {
		String SHGTRX = "SHGTRX";
		String SBA = "SBA";
	}

	public interface Action {
		String SHG_CW = "SHG-CW";
		String SHG_CD = "SHG-CD";
		String SHG_IFT = "SHG-IFT";
	}

	public interface status{
		String INITIATED="INITIATED";
	}
	public static final String SHG = "SHG";
	public static final String RET = "RET";
	public static final String SOURCE_DETAILS="SOURCE_DETAILS";
	public static final String TARGET_DETAILS="TARGET_DETAILS";
	public static final String YES="yes";
	public static final String TEST="test";
	public static final String AUA_DETAILS= "AUA_DETAILS";
	public static final String AUA_VERIFICATION_SUCCESS= "4037";
	public static final long AUA_SUCCESS_COUNT=2;
	public static final String TECHNICAL_ISSUE_CODE = "7007";
	public static final String TECHNICAL_ISSUE = "We are facing some technical issue , Please try again later.";

	public static final String REQUEST_VALIDATION_FAILED = "7008";
	public static final String APPID_NOT_NULL_MSG = "App Id must not be null";
	public static final String AMOUNT_NOT_NULL_MSG = "Amount must not be null";
	public static final String DESC_NOT_NULL_MSG = "Description must not be null";
	public static final String SOURCE_NOT_NULL_MSG = "Source details must not be null";
	public static final String TARGET_NOT_NULL_MSG = "Target details must not be null";
	public static final String SOURCE_ACCOUNT_NO_NULL_MSG = "Source account number must not be null";
	public static final String TARGET_ACCOUNT_NO_NULL_MSG = "Target account number must not be null";
	public static final String SOURCE_ACCOUNT_NO_INVALID_MSG = "Invalid source account number";
	public static final String TARGET_ACCOUNT_NO_INVALID_MSG = "Invalid target account number";
	public static final String AMOUNT_INVALID_MSG = "Invalid Amount";
	public static final String SOURCE_MOBILE_NO_NULL_MSG = "Source mobile number must not be null";
	public static final String TARGET_MOBILE_NO_NULL_MSG = "Target mobile number must not be null";
	public static final String SOURCE_MOB_INVALID_MSG = "Invalid source mobile number";
	public static final String TARGET_MOB_INVALID_MSG = "Invalid target mobile number";
	public static final String MOBILE_NUMBER_REGEX = "[6789][0-9]{9}";
	public static final String INITIATED_OR_PENDING_ENQUIRY="Payment is either in initiated,timeout or pending state";
	public static final String NO_DATA_ENQUIRY="We are facing some technical issue. Please try after some time";
	public static final String LIMIT_EXAUSTED_MSG = "Transaction limit reached for this SHG Account.";
	public static final String BALANCE_EXCEED_MSG = "Insufficient balance. Please enter an amount less than your account balance";
	public static final String APPTYPE_NOT_NULL = "App Type must not be null";
	public static final String ACTION_NOT_NULL = "Action must not be null";
	public static final String FLOWKEY_NOT_NULL = "Flow Key must not be null";
	public static final String CHANNEL_NOT_NULL = "Channel must not be null";
	public static final String CUSTOMER_HANDLE_NOT_NULL = "Customer handle no. must not be null";
	public static final String PRID_NOT_NULL_MSG = "Pr Id must not be null ";
	public static final String SUCCESS_ENQUIRY="Payment is successfully completed";
	public static final String FAILED_ENQUIRY="Payment is failed";
	public static final String INVALID_ACTION="Invalid Action";
	public static final String INVALID_CUST_HANDLE_NO="Invalid Customer handle number";
	public static final String INVALID_ACCOUNT_NO="Invalid Account No.";
	public static final String INVALID_APPLICATION_ID = "Invalid application id";
	public static final String AUA_NOT_COMPLETED = "Aua verification not completed";
	public static final String MPIN_VERIFICATION_FAILED = "Mpin verification not completed";
	public static final String INVALID_FLOW_KEY = "Invalid flow key";
	public static final String action="action";
	public static final String FLOW_KEY="FLOW_KEY";
	public static final String INVALID_PAYMENT_ID = "Invalid pr id";
	public static final String ACCOUNT_NO_MISMATCHED="Account number does not match with the mobile number.";

	public interface MgmtAuxiliaryInfo{
		String SHG_PAYMENT_TRX_CD="SHG_PAYMENT_TRX_CD";
		String SHG_PAYMENT_TRX_CW="SHG_PAYMENT_TRX_CW";
		String SHG_PAYMENT_TRX_IFT="SHG_PAYMENT_TRX_IFT";
	}

	public interface Regex{
		String NUMBER="[0-9]*\\.?[0-9]*";
		String ACC_NUMBER="[0-9]+";
	}

	public static final int STATUS_PENDING_OR_INITIATED = 2;
	public static final int NO_DATA = 2;
	public static Integer  LIMIT_ALLOWED = 1;
	public static final String APPLICATION_JSON = "application/json";
	public static final String SEGMENT = "segment";
    public static final String CUSTOMER_SEGMENT = "CUS";
    public static final String ACCOUNT_TYPE_SBA = "sba";
	public static final String PAN="PAN";
	public static final String NON_PAN="Non-PAN";

	public static final String CSB_CD_DR_NR="config.csb.cd.dr.narration";
	public static final String CSB_CD_CR_NR="config.csb.cd.cr.narration";
	public static final String CSB_CD_PARAM_1_NR="config.csb.cd.param.1";
	public static final String CSB_CD_PARAM_2_NR="config.csb.cd.param.2";
	public static final String CSB_CD_DR_DEFAULT_NR="config.csb.cd.dr.default.narration";
	public static final String CSB_CD_CR_DEFAULT_NR="config.csb.cd.cr.default.narration";
	public static final String CSB_CD_DEFAULT_PARAM_1_NR="config.csb.cd.default.param.1";
	public static final String CSB_CD_DEFAULT_PARAM_2_NR="config.csb.cd.default.param.2";



	public static final String CSB_CW_DR_NR="config.csb.cw.dr.narration";
	public static final String CSB_CW_CR_NR="config.csb.cw.cr.narration";
	public static final String CSB_CW_PARAM_1_NR="config.csb.cw.param.1";
	public static final String CSB_CW_PARAM_2_NR="config.csb.cw.param.2";
	public static final String CSB_CW_DR_DEFAULT_NR="config.csb.cw.dr.default.narration";
	public static final String CSB_CW_CR_DEFAULT_NR="config.csb.cw.cr.default.narration";
	public static final String CSB_CW_DEFAULT_PARAM_1_NR="config.csb.cw.default.param.1";
	public static final String CSB_CW_DEFAULT_PARAM_2_NR="config.csb.cw.default.param.2";

	public static final String CSB_IFT_DR_NR="config.csb.ift.dr.narration";
	public static final String CSB_IFT_CR_NR="config.csb.ift.cr.narration";
	public static final String CSB_IFT_PARAM_1_NR="config.csb.ift.param.1";
	public static final String CSB_IFT_PARAM_2_NR="config.csb.ift.param.2";
	public static final String CSB_IFT_DR_DEFAULT_NR="config.csb.ift.dr.default.narration";
	public static final String CSB_IFT_CR_DEFAULT_NR="config.csb.ift.cr.default.narration";
	public static final String CSB_IFT_DEFAULT_PARAM_1_NR="config.csb.ift.default.param.1";
	public static final String CSB_IFT_DEFAULT_PARAM_2_NR="config.csb.ift.default.param.2";


	public static final String PARAM_1="additionalParam1";
	public static final String PARAM_2="additionalParam2";
	public static final String CR_NARRATION="crNarration";
	public static final String DR_NARRATION="drNarration";

	public static final String PARAM_1_KEY="PARAM_1_KEY";
	public static final String PARAM_2_KEY="PARAM_2_KEY";
	public static final String CR_KEY="CR_KEY";
	public static final String DR_KEY="DR_KEY";

	}
