package com.airtelbank.transaction.exception;

import com.airtelbank.payments.hub.client.dto.response.Meta;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class ClientSideException extends RuntimeException {
	private static final long serialVersionUID = -227878766090924097L;
	private Meta meta;
	private String errorCode;
	private String errorMessage;

	public ClientSideException(String errorMessage) {
		super(errorMessage);
		this.errorMessage = errorMessage;
	}

	public ClientSideException(String errorCode, String errorMessage) {
		super(errorMessage);
		this.errorCode = errorCode;
		this.errorMessage = errorMessage;
	}
}
