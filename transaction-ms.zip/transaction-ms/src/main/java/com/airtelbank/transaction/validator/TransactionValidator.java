package com.airtelbank.transaction.validator;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

import com.airtelbank.transaction.dto.cbs.CBSFCIDetailsRequest;

@Component("beforeTransactionValidator")
public class TransactionValidator implements Validator {

	@Override
	public boolean supports(Class<?> classObj) {
		return CBSFCIDetailsRequest.class.equals(classObj);
	}

	@Override
	public void validate(Object obj, Errors errors) {
		CBSFCIDetailsRequest request = (CBSFCIDetailsRequest) obj;
		if (request != null) {

			if (StringUtils.isBlank(request.getMobileNumber())) {
				errors.rejectValue(null, "mobileNumber.null", "mobileNumber cannot be null");
			} else if (!request.getMobileNumber().matches("^[0-9]{10}$|^[0-9]{12}$|^[0]{1}[1-9]{10}$")) {
				errors.rejectValue(null, "mobileNumber.invalid", "mobileNumber invalid format");
			}
			if (null == request.getAccountType())
				errors.rejectValue(null, "accountType.null", "accountType cannot be null");

			if (null == request.getFci())
				errors.rejectValue(null, "fci.null", "fci amount cannot be null");

			if (null == request.getCircle())
				errors.rejectValue(null, "fci.null", "circle cannot be null");

			if (StringUtils.isBlank(request.getRetailerMobileNumber())) {
				errors.rejectValue(null, "mobileNumber.null", "Retiler mobileNumber cannot be null");
			} else if (!request.getRetailerMobileNumber().matches("^[0-9]{10}$|^[0-9]{12}$|^[0]{1}[1-9]{10}$")) {
				errors.rejectValue(null, "mobileNumber.invalid", "mobileNumber invalid format");
			}
		}
	}
}
