package com.airtelbank.transaction.config;

import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.common.serialization.StringDeserializer;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.annotation.EnableKafka;
import org.springframework.kafka.config.ConcurrentKafkaListenerContainerFactory;
import org.springframework.kafka.core.DefaultKafkaConsumerFactory;
import org.springframework.kafka.listener.ContainerProperties.AckMode;
import java.util.HashMap;
import java.util.Map;

@Configuration
@EnableKafka
public class ConsumersConfig {

	@Value("${kafka.customer.pipeline.success.bootstrap.server}")
	private String customerPipelineBootstrapAddress;

	@Value(value = "${kafka.customer.pipeline.success.groupid}")
	private String kafkaCustomerPipelineSuccessGroup;

	@Value(value = "${kafka.customer.pipeline.success.heartbeatInterval}")
	private Integer heartbeatInterval;

	@Value(value = "${kafka.customer.pipeline.success.reqTimeout}")
	private Integer reqTimeout;

	@Value(value = "${kafka.customer.pipeline.success.reset.config}")
	private String resetConfig;

	@Value(value = "${kafka.customer.pipeline.success.sessionTimeout}")
	private Integer sessionTimeout;

	@Value(value = "${kafka.customer.pipeline.success.maxPollInterval}")
	private Integer maxPollInterval;

	@Value(value = "${kafka.customer.pipeline.success.concurrency}")
	private Integer kafkaCustomerPipelineSuccessConcurrency;

	@Bean
	public ConcurrentKafkaListenerContainerFactory<String, String> customerPipelineSuccessContainerFactory() {
		ConcurrentKafkaListenerContainerFactory<String, String> factory = new ConcurrentKafkaListenerContainerFactory<>();
		factory.setConsumerFactory(new DefaultKafkaConsumerFactory<>(consumerFactory(customerPipelineBootstrapAddress,
				kafkaCustomerPipelineSuccessGroup, heartbeatInterval, reqTimeout, sessionTimeout, maxPollInterval),
				new StringDeserializer(), new StringDeserializer()));
		factory.setConcurrency(kafkaCustomerPipelineSuccessConcurrency);
		factory.getContainerProperties().setAckMode(AckMode.MANUAL_IMMEDIATE);
		return factory;
	}

	public Map<String, Object> consumerFactory(String bootstrapAddress, String groupId, Integer heartbeatInterval,
			Integer reqTimeout, Integer sessionTimeout, Integer maxPoll) {
		Map<String, Object> props = new HashMap<>();
		props.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, bootstrapAddress);
		props.put(ConsumerConfig.GROUP_ID_CONFIG, groupId);
		props.put(ConsumerConfig.HEARTBEAT_INTERVAL_MS_CONFIG, heartbeatInterval);
		props.put(ConsumerConfig.SESSION_TIMEOUT_MS_CONFIG, sessionTimeout);
		props.put(ConsumerConfig.MAX_POLL_INTERVAL_MS_CONFIG, maxPoll);
		props.put(ConsumerConfig.ENABLE_AUTO_COMMIT_CONFIG, false);
		props.put(ConsumerConfig.AUTO_OFFSET_RESET_CONFIG, resetConfig);
		return props;
	}

}
