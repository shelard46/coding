package com.airtelbank.transaction.exception;

import com.airtelbank.transaction.model.Meta;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.*;

@Setter
@Getter
@ToString
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class AeroSpikeException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 8416740059979828032L;
	private String id;
    private Meta meta;

    public AeroSpikeException(Meta meta) {
        super();
        this.meta = meta;
    }
}