package com.airtelbank.transaction.validator;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

import com.airtelbank.transaction.model.MetaV3;

@Component
public class MetaValidator implements Validator {
	@Override
	public boolean supports(Class<?> classObj) {
		return MetaV3.class.equals(classObj);
	}

	@Override
	public void validate(Object obj, Errors errors) {
		MetaV3 meta = (MetaV3) obj;
		if (meta != null) {
			
			if (StringUtils.isBlank(meta.getAppId()))
				errors.rejectValue(null, "appId.null", "AppId cannot be null");

			if (StringUtils.isBlank(meta.getAppType()))
				errors.rejectValue(null, "appType.null", "AppType cannot be null");
		}
	}
}