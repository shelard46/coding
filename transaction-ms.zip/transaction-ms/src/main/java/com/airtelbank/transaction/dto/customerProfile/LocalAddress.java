package com.airtelbank.transaction.dto.customerProfile;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class LocalAddress implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@JsonProperty("city")
	public String city;
	@JsonProperty("country")
	public String country;
	@JsonProperty("line1")
	public String line1;
	@JsonProperty("line2")
	public String line2;
	@JsonProperty("line3")
	public String line3;
	@JsonProperty("line4")
	public String line4;
	@JsonProperty("pincode")
	public String pincode;
	@JsonProperty("state")
	public String state;
	@JsonProperty("district")
	public String district;

}

