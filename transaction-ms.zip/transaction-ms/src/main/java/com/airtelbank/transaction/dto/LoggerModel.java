package com.airtelbank.transaction.dto;

import java.util.List;

import org.springframework.stereotype.Component;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@NoArgsConstructor
@AllArgsConstructor
@Component
public class LoggerModel {
	private long startTime;
	private String apiId;
	private String contentId;
	private String channel;
	private String sessionId;
	private String customerId;
	private String tranId;
	private String oldStateId;
	private String newStateId;
	private String actor;
	private String actionStatus;
	private String actionTime;
	private String rejectionReason;
	private String videoGeoLocation;
	private String videoDuration;
	private int retryCount;

	private List<LoggerError> errors;
	private List<MethodStats> methods;

	@Getter
	@Setter
	@ToString
	@NoArgsConstructor
	@AllArgsConstructor
	public static class LoggerError {
		private String errorCode;
		private String errorDescription;
		private int status;
	}

	@Getter
	@Setter
	@ToString
	@NoArgsConstructor
	@AllArgsConstructor
	public static class MethodStats{
		private String methodName;
		private long methodTime;
	}

	public void clear() {
		apiId = null;
		contentId = null;
		channel = null;
		sessionId = null;
		customerId = null;
		oldStateId = null;
		newStateId = null;
		actor = null;
		actionStatus = null;
		actionTime = null;
		rejectionReason = null;
		videoGeoLocation = null;
		videoDuration = null;

		if(null !=  errors)
			errors.clear();

		if(null !=  methods)
			methods.clear();
	}
}
