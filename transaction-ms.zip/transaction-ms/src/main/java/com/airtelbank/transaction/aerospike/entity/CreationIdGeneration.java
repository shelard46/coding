package com.airtelbank.transaction.aerospike.entity;

import org.springframework.data.aerospike.mapping.Document;
import org.springframework.data.aerospike.mapping.Field;
import org.springframework.data.annotation.Id;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@Builder
@ToString
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_EMPTY)
@JsonIgnoreProperties(ignoreUnknown = true)
@Document(collection = "CREATION_ID_GENERATION")
public class CreationIdGeneration {

	@Id
	@Field(value = "PK")
	private String id;

	@Field(value = "CREATION_ID")
	private int creationId;
	
	@Field(value = "ORDER_ID")
	private int orderId;
}
