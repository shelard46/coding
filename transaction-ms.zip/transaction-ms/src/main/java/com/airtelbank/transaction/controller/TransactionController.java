package com.airtelbank.transaction.controller;

import com.airtelbank.payments.hub.client.dto.response.DirectPaymentResponse;
import com.airtelbank.payments.hub.client.dto.response.Meta;
import com.airtelbank.payments.hub.client.dto.response.PaymentEnquiryResponse;
import com.airtelbank.payments.hub.client.dto.response.ResponseDTO;
import com.airtelbank.transaction.constant.Constants;
import com.airtelbank.transaction.dto.cbs.CBSFCIDetailsRequest;
import com.airtelbank.transaction.dto.cbs.FCIDetailResponse;
import com.airtelbank.transaction.dto.fciCircleBased.FCIResponseDTO;
import com.airtelbank.transaction.dto.response.TransactionStateResponseDTO;
import com.airtelbank.transaction.exception.ClientSideException;
import com.airtelbank.transaction.exception.GenericException;
import com.airtelbank.transaction.model.HeaderRequestDTO;
import com.airtelbank.transaction.model.RequestDTO;
import com.airtelbank.transaction.model.TransactionEnquiryRequest;
import com.airtelbank.transaction.model.TransactionRequestDTO;
import com.airtelbank.transaction.model.response.ResponseEntityBuilder;
import com.airtelbank.transaction.service.TransactionService;
import com.airtelbank.transaction.util.CommonUtils;
import com.airtelbank.transaction.validator.MetaValidator;
import com.airtelbank.transaction.validator.RequestValidator;
import com.airtelbank.transaction.validator.TransactionValidator;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.ServletRequestBindingException;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import javax.validation.constraints.NotBlank;
import java.util.Map;
import java.util.Objects;

@RestController
@Slf4j
@RequestMapping(value = {"api/v1/payments","api/v2/payments"})
public class TransactionController {

	@Autowired
	private TransactionService transactionService;

	@Autowired
	private TransactionValidator requestValidator;

	@Autowired
	private MetaValidator metaValidator;

	@Autowired
	private RequestValidator validator;

	/**
	 *  API is used to initiate payment
	 * @param transactionRequestDTO
	 * @param headers
	 * @param bindingResult
	 * @return
	 * @throws ServletRequestBindingException
	 * @throws MethodArgumentNotValidException
	 * @throws ClientSideException
	 */
	@PostMapping(path = "/transactions/direct")
	public ResponseEntity<?> postPaymentDetails(@RequestBody TransactionRequestDTO transactionRequestDTO,
			@RequestHeader Map<String, String> headers, BindingResult bindingResult)
			throws ServletRequestBindingException, MethodArgumentNotValidException ,ClientSideException{
		ObjectMapper mapper = new ObjectMapper();
		HeaderRequestDTO headerRequestDTO = mapper.convertValue(headers, HeaderRequestDTO.class);
		ResponseDTO<DirectPaymentResponse> response = null;
		log.info("Received Direct Transfer request :: {} from usecase: {} with appType :: {}",
				transactionRequestDTO, transactionRequestDTO.getUseCase(),headerRequestDTO.getAppType());
		if (StringUtils.isBlank(headerRequestDTO.getContentid())) {
			throw new ClientSideException(Constants.INVALID_CONTENT_ID_CODE, Constants.INVALID_CONTENT_ID_MSG);
		}
		if(requestValidator(headerRequestDTO)) {
			validator.headerValidator(headerRequestDTO);
			validator.requestValidator(transactionRequestDTO,headerRequestDTO);
		}
		try {
			response = transactionService.onboardingUsecaseToPaymentHub(transactionRequestDTO, headerRequestDTO ,null);
		} catch (GenericException e) {
			log.error("Exception occurred {}",e.getMessage());
			return ResponseEntityBuilder.getBuilder(HttpStatus.OK).errorResponse(e.getErrorCode(),
					e.getErrorMessage());
		}
		catch (Exception e) {
			log.error("Exception occurred {}",e.getMessage());
			return ResponseEntityBuilder.getBuilder(HttpStatus.OK).errorResponse(Constants.REQUEST_FAILURE_DESCRIPTION,
					Constants.TECHNICAL_ISSUE);
		}

		return ResponseEntity.ok().body(response);
	}


	//This will store data related to accountType,subscription, fci value, afc value ,circle details in aerospike
	@PostMapping(path = "/transactions/fciDetail")
	public ResponseEntity<?> saveFCIDetails(@RequestHeader Map<String, String> headers,
			@RequestBody RequestDTO<CBSFCIDetailsRequest> fciDetailsRequest, BindingResult bindingResult) {

		metaValidator.validate(fciDetailsRequest.getMeta(), bindingResult);
		requestValidator.validate(fciDetailsRequest.getData(), bindingResult);
		com.airtelbank.transaction.model.ResponseDTO<?> response = new com.airtelbank.transaction.model.ResponseDTO<>();
		com.airtelbank.transaction.model.Meta meta = new com.airtelbank.transaction.model.Meta();
		ObjectMapper mapper = new ObjectMapper();
		HeaderRequestDTO headerRequestDTO = mapper.convertValue(headers, HeaderRequestDTO.class);
		log.info("saveFCIDetails| Header received :{}:", headerRequestDTO);
		if (bindingResult.hasErrors()) {

			CommonUtils.getResponseMeta(meta, Constants.BAD_REQ_ERROR_CODE, Constants.STATUS_FAILURE,
					Constants.INVALID_REQUEST_MSG);
			response.setMeta(meta);
			return ResponseEntity.badRequest().body(response);
		}
		response = transactionService.saveFCIDetails(fciDetailsRequest,headerRequestDTO.getContentid(),headerRequestDTO.getChannel());
		return ResponseEntity.ok().body(response);

	}

	@GetMapping(value = "/transactions")
	public ResponseEntity<com.airtelbank.transaction.model.ResponseDTO<FCIDetailResponse>> getFCIDetailsById(
			@RequestHeader String channel, @RequestHeader String contentId, @RequestParam String appId) {
		log.info("get FCIDEtails for appId : {}", appId);

		com.airtelbank.transaction.model.ResponseDTO<FCIDetailResponse> response = transactionService
				.getFCIDetailsById(appId);
		return ResponseEntity.ok().body(response);
	}
	
	@GetMapping(path = "/transaction/appId/{appId}")
	public ResponseEntity<com.airtelbank.transaction.model.ResponseDTO<TransactionStateResponseDTO>> getTransactionState(
			@PathVariable @NotBlank(message = "AppId cannot be empty!") String appId,
			@RequestHeader Map<String, String> headers)
			throws ServletRequestBindingException, MethodArgumentNotValidException {
		log.info("Inside getTransactionState for appId : {}", appId);
		ObjectMapper mapper = new ObjectMapper();
		HeaderRequestDTO headerRequestDTO = mapper.convertValue(headers, HeaderRequestDTO.class);

		if (headerRequestDTO != null && log.isDebugEnabled()) {
			log.debug("Get Transaction State | ContentId is {}", headerRequestDTO.getContentid());
		}
		com.airtelbank.transaction.model.ResponseDTO<TransactionStateResponseDTO> response =null;
		com.airtelbank.transaction.model.Meta meta = new com.airtelbank.transaction.model.Meta();
		try {
			response = transactionService
					.getTransactionState(appId);
		} catch (Exception e) {
			log.error("Exception occurred" + e.getMessage());
			CommonUtils.getResponseMeta(meta, Constants.FAILED, Constants.STATUS_FAILURE,
					Constants.GET_TRANSACTION_STATE_FAILURE);
			response =new com.airtelbank.transaction.model.ResponseDTO<TransactionStateResponseDTO>();
			response.setMeta(meta);
		}
		return ResponseEntity.ok().body(response);
	}

	/**
	 * This is used to check status of payment based on PRID
	 * @param transactionEnquiryRequest
	 * @param headers
	 * @return
	 * @throws ServletRequestBindingException
	 * @throws MethodArgumentNotValidException
	 */
	@PostMapping(path = "/transactions/enquiry")
	public ResponseEntity<?> postEnquiryDetails(@RequestBody TransactionEnquiryRequest transactionEnquiryRequest,
												@RequestHeader Map<String, String> headers)
			throws ServletRequestBindingException, MethodArgumentNotValidException {
		ObjectMapper mapper = new ObjectMapper();
		HeaderRequestDTO headerRequestDTO = mapper.convertValue(headers, HeaderRequestDTO.class);
		log.info("Inside postEnquiryDetails method with request :: {} , headers :: {}",transactionEnquiryRequest,headerRequestDTO);
		ResponseDTO<String> response = null;

		if(requestValidator(headerRequestDTO)) {
			validator.enquiryHeaderValidator(headerRequestDTO);
			validator.requestValidator(transactionEnquiryRequest);
		}
		try {
			response = transactionService.paymentEnquiry(transactionEnquiryRequest, headerRequestDTO);
			if(Objects.isNull(response))
				return ResponseEntityBuilder.getBuilder(HttpStatus.OK).errorResponse(Constants.REQUEST_FAILURE_DESCRIPTION,
						Constants.TECHNICAL_ISSUE);
		} catch (GenericException e) {
			log.error("Exception occurred {}",e.getMessage());
			return ResponseEntityBuilder.getBuilder(HttpStatus.OK).errorResponse(e.getErrorCode(),
					e.getErrorMessage());
		}
		catch (Exception e) {
			log.error("Exception occurred {}",e.getMessage());
			return ResponseEntityBuilder.getBuilder(HttpStatus.OK).errorResponse(Constants.REQUEST_FAILURE_DESCRIPTION,
					Constants.TECHNICAL_ISSUE);
		}

		return ResponseEntity.ok().body(response);
	}



	private boolean requestValidator(HeaderRequestDTO headerRequestDTO){
		if(StringUtils.isNotBlank(headerRequestDTO.getAppType()) && Constants.AppType.SHGTRX.equalsIgnoreCase(headerRequestDTO.getAppType()))
			return true;
		return false;
	}


}