package com.airtelbank.transaction.exception;

import org.apache.log4j.MDC;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import com.airtelbank.transaction.constant.Constants;
import com.airtelbank.transaction.model.Meta;
import com.airtelbank.transaction.model.ResponseDTO;
import com.airtelbank.transaction.util.CommonUtils;


@ControllerAdvice
public class GlobalExceptionHandler extends ResponseEntityExceptionHandler {

	private static final Logger log = LoggerFactory.getLogger(GlobalExceptionHandler.class);

	@Autowired
	private MessageSource messageSource;

	@ExceptionHandler(value = { ClientSideException.class })
	protected ResponseEntity<?> badRequestException(ClientSideException ex) {
		log.error("ClientSide error : {}", ex);
		ResponseDTO<?> responseDTO = new ResponseDTO<>();
		String errorMessage = messageSource.getMessage("config.bad.request.error.description", null, null);
		String errorCode = messageSource.getMessage("config.bad.request.error.code", null, null);
		if (ex.getErrorCode() != null && ex.getErrorMessage() != null) {
			errorMessage = ex.getErrorMessage();
			errorCode = ex.getErrorCode();
		}
		Meta meta = new Meta(errorCode, errorMessage, Constants.STATUS_FAILURE);
		responseDTO.setMeta(meta);
		log.error("Exception Response DTO :" + responseDTO);
		MDC.put(Constants.ERRORS, CommonUtils.setLoggerError(meta));
		return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(responseDTO);
	}


	@ExceptionHandler(value = { GenericException.class})
    protected ResponseEntity<Object> handleGenericException(GenericException ex) {
		log.error("generic error : {}", ex);
		ResponseDTO<?> responseDTO = new ResponseDTO<>();
		Meta meta = new Meta();
		if (ex.getMeta() != null) {
			meta = ex.getMeta();
		} else if(ex.getErrorCode() != null && ex.getErrorMessage() != null){
			meta.setCode(ex.getErrorCode());
			meta.setDescription(ex.getErrorMessage());
		} else {
			meta.setCode(messageSource.getMessage("config.generic.errorCode",null,null));
			meta.setDescription(messageSource.getMessage("config.generic.errorMessage",null,null));
		}
		meta.setStatus(Constants.STATUS_FAILURE);
		responseDTO.setMeta(meta);
		log.error("Exception Response DTO :{} ",responseDTO);
        MDC.put(Constants.ERRORS, CommonUtils.setLoggerError(meta));
		return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(responseDTO);

	}
	
	@ExceptionHandler(value = { InvalidRestRequestException.class})
    protected ResponseEntity<Object> HandleInvalidRestRequestException(GenericException ex) {
		log.error("InvalidRestRequestException error : {}", ex);
		ResponseDTO<?> responseDTO = new ResponseDTO<>();
		Meta meta = new Meta();
		if (ex.getMeta() != null) {
			meta = ex.getMeta();
		} else if(ex.getErrorCode() != null && ex.getErrorMessage() != null){
			meta.setCode(ex.getErrorCode());
			meta.setDescription(ex.getErrorMessage());
		} else {
			meta.setCode(messageSource.getMessage("config.request.errorCode",null,null));
			meta.setDescription(messageSource.getMessage("config.request.errorMessage",null,null));
		}
		meta.setStatus(Constants.STATUS_FAILURE);
		responseDTO.setMeta(meta);
		log.error("Exception Response DTO :{} ",responseDTO);
        MDC.put(Constants.ERRORS, CommonUtils.setLoggerError(meta));
		return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(responseDTO);

	}
	
}