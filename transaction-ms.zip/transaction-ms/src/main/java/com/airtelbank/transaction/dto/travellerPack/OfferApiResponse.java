package com.airtelbank.transaction.dto.travellerPack;

import lombok.Data;

@Data
public class OfferApiResponse {

	private String heading1;
	private AccountType[] accountType;
	private String heading2;
	private AddOn addons;
	private String buttonText;

}
