package com.airtelbank.transaction.dto.cbs;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@Builder
@ToString
public class FCIDetailResponse {

	private String appId;

	private String appType;

	private String fci;

	private String afc;

	private String mobileNumber;

	private String accountType;

	private String subscription;

	private String totalamount;

	private String circle;

	private String retailerMobileNumber;
	
	private String creationTime;
	
	private String updationTime;
}

