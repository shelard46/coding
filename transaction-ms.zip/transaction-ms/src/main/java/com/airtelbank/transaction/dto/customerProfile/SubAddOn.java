package com.airtelbank.transaction.dto.customerProfile;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.*;

@Getter
@Setter
@Builder
@ToString
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_EMPTY)
@JsonIgnoreProperties(ignoreUnknown = true)
public class SubAddOn implements Serializable{
	
	private static final long serialVersionUID = 1L;
	private String type;
	private String startDate;
	private String endDate;
	private int status;

}

