package com.airtelbank.transaction.controller;

import com.airtelbank.payments.hub.client.dto.response.Meta;
import com.airtelbank.payments.hub.client.dto.response.ResponseDTO;
import com.airtelbank.transaction.constant.Constants;
import com.airtelbank.transaction.dto.TransactionReqDTO;
import com.airtelbank.transaction.dto.fciCircleBased.FCIResponseDTO;
import com.airtelbank.transaction.exception.ClientSideException;
import com.airtelbank.transaction.model.HeaderRequestDTO;
import com.airtelbank.transaction.service.TransactionService;
import com.airtelbank.transaction.util.CommonUtils;
import com.airtelbank.transaction.util.PHClientConfig;
import com.airtelbank.transaction.util.RSAUtil;
import com.airtelbank.transaction.validator.MetaValidator;
import com.airtelbank.transaction.validator.TransactionValidator;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

/**
 * @author A1W87715
 */
@RestController
@Slf4j
@RequestMapping(value = "api")
public class TransactionControllerV2 {

	@Autowired
	private TransactionService transactionService;

	@Autowired
	private PHClientConfig pHClientConfig;

	@Value("${config.sba.payment.hub.case.onboarding.usecase}")
	private String retailerOnboardingUseCase;

	@Autowired
	private TransactionValidator requestValidator;

	@Autowired
	private MetaValidator metaValidator;

	@Value("${rsa.private.key}")
	private String privateKey;


	@GetMapping(path = "/v2/payments/circle/{circleCode}/retailer")
	public ResponseEntity<?> getCircleCodeInfo(@PathVariable String circleCode,@RequestParam String retailerId,
			@RequestHeader Map<String, String> headers) {

		log.info("Load circleCode Info");
		Meta meta = new Meta();
		ObjectMapper mapper = new ObjectMapper();
		HeaderRequestDTO headerRequestDTO = mapper.convertValue(headers, HeaderRequestDTO.class);
		log.info("getCircleCodeInfo| Header received :{}:", headerRequestDTO);


		String customerhandlernumber=null;
		if (StringUtils.isNotEmpty(headerRequestDTO.getCustomerHandleNumber())) {
			try {
				customerhandlernumber = RSAUtil.decrypt(headerRequestDTO.getCustomerHandleNumber(), RSAUtil.getPrivateKey(privateKey));
			} catch (Exception ex) {
				log.info(CommonUtils.errorPrefixSuffix("Exception while decrypting natlId"));
				ExceptionUtils.printRootCauseStackTrace(ex);
			}
		}


		if (customerhandlernumber == null
				|| (!(customerhandlernumber.matches("[6789][0-9]{9}")))
				|| !(customerhandlernumber.length() == 10)) {
			throw new ClientSideException(Constants.INVALID_CUSTOMER_HANDLE_NUMBER_CODE,
					Constants.INVALID_CUSTOMER_HANDLE_NUMBER_MSG);
		}

		ResponseDTO<FCIResponseDTO> response = new ResponseDTO<>();
		if (StringUtils.isBlank(circleCode) || StringUtils.isBlank(retailerId)) {
			throw new ClientSideException(Constants.INVALID_REST_REQUEST_CODE, Constants.INVALID_REST_REQUEST_MSG);

		} else {
			response = transactionService.getCircleCodeInfo(circleCode, retailerId,
					customerhandlernumber, headerRequestDTO.getContentid(),
					headerRequestDTO.getChannel());
			meta.setStatus(Constants.STATUS_SUCCESS);
			response.setMeta(meta);
		}
		return ResponseEntity.ok().body(response);

	}

	@PostMapping(path = "/v2/payments/circle/{circleCode}/retailer")
	public ResponseEntity<?> getCircleCodeInfo1(@PathVariable String circleCode, @RequestBody TransactionReqDTO transactionReqDTO, @RequestParam String retailerId,
												@RequestHeader Map<String, String> headers) {

		log.info("Load circleCode Info");
		Meta meta = new Meta();
		ObjectMapper mapper = new ObjectMapper();
		HeaderRequestDTO headerRequestDTO = mapper.convertValue(headers, HeaderRequestDTO.class);
		log.info("getCircleCodeInfo| Header received :{}:", headerRequestDTO);

		if (transactionReqDTO.getCustomerHandlerNumber() == null
				|| (!(transactionReqDTO.getCustomerHandlerNumber().matches("[6789][0-9]{9}")))
				|| !(transactionReqDTO.getCustomerHandlerNumber().length() == 10)) {
			throw new ClientSideException(Constants.INVALID_CUSTOMER_HANDLE_NUMBER_CODE,
					Constants.INVALID_CUSTOMER_HANDLE_NUMBER_MSG);
		}

		ResponseDTO<FCIResponseDTO> response = new ResponseDTO<>();
		if (StringUtils.isBlank(circleCode) || StringUtils.isBlank(retailerId)) {
			throw new ClientSideException(Constants.INVALID_REST_REQUEST_CODE, Constants.INVALID_REST_REQUEST_MSG);

		} else {
			response = transactionService.getCircleCodeInfo(circleCode, retailerId,
					transactionReqDTO.getCustomerHandlerNumber(), headerRequestDTO.getContentid(),
					headerRequestDTO.getChannel());
			meta.setStatus(Constants.STATUS_SUCCESS);
			response.setMeta(meta);
		}
		return ResponseEntity.ok().body(response);

	}
	@GetMapping(path = "/v1/payments/circle/{circleCode}/retailer")
	public ResponseEntity<?> getCircleCodeInfo2(@PathVariable String circleCode, @RequestParam String retailerId, @RequestHeader Map<String, String> headers) {

		log.info("Load circleCode Info");
		Meta meta = new Meta();
		ObjectMapper mapper = new ObjectMapper();
		HeaderRequestDTO headerRequestDTO = mapper.convertValue(headers, HeaderRequestDTO.class);
		log.info("getCircleCodeInfo| Header received :{}:", headerRequestDTO);

		if (headerRequestDTO.getCustomerHandleNumber() == null
				|| (!(headerRequestDTO.getCustomerHandleNumber().matches("[6789][0-9]{9}")))
				|| !(headerRequestDTO.getCustomerHandleNumber().length() == 10)) {
			throw new ClientSideException(Constants.INVALID_CUSTOMER_HANDLE_NUMBER_CODE,
					Constants.INVALID_CUSTOMER_HANDLE_NUMBER_MSG);
		}

		ResponseDTO<FCIResponseDTO> response = new ResponseDTO<>();
		if (StringUtils.isBlank(circleCode) || StringUtils.isBlank(retailerId)) {
			throw new ClientSideException(Constants.INVALID_REST_REQUEST_CODE, Constants.INVALID_REST_REQUEST_MSG);

		} else {
			response = transactionService.getCircleCodeInfo(circleCode, retailerId,
					headerRequestDTO.getCustomerHandleNumber(), headerRequestDTO.getContentid(),
					headerRequestDTO.getChannel());
			meta.setStatus(Constants.STATUS_SUCCESS);
			response.setMeta(meta);
		}
		return ResponseEntity.ok().body(response);

	}



	

}