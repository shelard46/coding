package com.airtelbank.transaction.util;

import com.airtelbank.transaction.constant.Constants;
import com.airtelbank.transaction.dto.application.ManageAccountStateResponse;
import com.airtelbank.transaction.dto.balance.EnquiryRequest;
import com.airtelbank.transaction.dto.balance.EnquiryResponse;
import com.airtelbank.transaction.dto.customerProfile.CustomerProfileDTO;
import com.airtelbank.transaction.exception.GenericException;
import com.airtelbank.transaction.model.HeaderRequestDTO;
import com.airtelbank.transaction.model.RequestDTO;
import com.airtelbank.transaction.model.ResponseDTO;
import com.airtelbank.transaction.model.RestRequest;
import com.airtelbank.transaction.model.response.DocumentMgmtStoreResponseDTO;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.client.ResourceAccessException;
import org.springframework.web.client.RestClientException;

import java.util.HashMap;
import java.util.Objects;

@Slf4j
@Service
@RefreshScope
public class RestServiceHelper {

    @Value("${rest.get.state.appId}")
    private String getAppStateAppId;

    @Value("${rest.get.balance.enquiry}")
    private String getBalanceEnquiry;

    @Value("${rest.get.doc.docId}")
    private String getDocumentUrl;
    
    @Value("${rest.customer.profile.v3.url}")
    private String customerProfileV3Url;

    @Autowired
    RestUtil restUtil;



    public ManageAccountStateResponse hitGetStateByAppId(String appId, HeaderRequestDTO header){
        HashMap<String,String> headerMap = new HashMap<>();
        headerMap.put(Constants.action,header.getAction());
        headerMap.put(Constants.APP_TYPE,header.getAppType());
        MultiValueMap<String, String> headers = RequestCreationUtil.getMultiValueMapHeader(headerMap);
        String finalUrl = CommonUtils.getURLfromUri(getAppStateAppId, appId);
        try {
            RestRequest<ManageAccountStateResponse> restRequest = RequestCreationUtil.createRestRequest(finalUrl,
                    HttpMethod.GET, null, ManageAccountStateResponse.class, null, headers);
            ResponseEntity<ResponseDTO<ManageAccountStateResponse>> accountStateResponse = restUtil
                    .sendHttpRequest(restRequest);
            log.info("Get state response :: {}",accountStateResponse);
            if (null == accountStateResponse || null == accountStateResponse.getBody()
                    || null == accountStateResponse.getBody().getMeta()) {
                log.error("get state service not responding!!");
                throw new GenericException(Constants.THIRD_PARTY_ERROR_CODE, Constants.TECHNICAL_ISSUE);
            }
            log.info("get state service response :: {}",accountStateResponse.getBody().getData());
            return accountStateResponse.getBody().getData();
        } catch (ResourceAccessException ex) {
            log.error("Potential timeout occurred in get state service request", ex);
            throw new GenericException(Constants.THIRD_PARTY_TIMEOUT_CODE, Constants.TECHNICAL_ISSUE);
        } catch (HttpStatusCodeException ex) {
            log.error("HttpStatusCodeException occurred in get state service.", ex);
            throw new GenericException(Constants.THIRD_PARTY_ERROR_CODE, Constants.TECHNICAL_ISSUE);
        } catch (Exception ex) {
            log.error("Exception occurred in get state service.", ex);
            throw new GenericException(Constants.THIRD_PARTY_ERROR_CODE, Constants.TECHNICAL_ISSUE);
        }
    }


    public EnquiryResponse hitBalanceEnquiry(RequestDTO<EnquiryRequest> enquiryRequest, HeaderRequestDTO header){
        HashMap<String,String> headerMap = new HashMap<>();
        headerMap.put(Constants.CONTENT_ID,header.getContentid());
        headerMap.put(Constants.CHANNEL,header.getChannel());
        headerMap.put(Constants.action,header.getAction());
        headerMap.put(Constants.FLOW_KEY,header.getFlowKey());
        MultiValueMap<String, String> headers = RequestCreationUtil.getMultiValueMapHeader(headerMap);
        String finalUrl = CommonUtils.getURLfromUri(getBalanceEnquiry);
        try {
            RestRequest<EnquiryResponse> restRequest = RequestCreationUtil.createRestRequest(finalUrl,
                    HttpMethod.POST, enquiryRequest, EnquiryResponse.class, null, headers);
            ResponseEntity<ResponseDTO<EnquiryResponse>> balanceResponseEntity = restUtil
                    .sendHttpRequest(restRequest);
            log.info("Balance enquiry response :: {}",balanceResponseEntity);
            if (null == balanceResponseEntity || null == balanceResponseEntity.getBody()
                    || null == balanceResponseEntity.getBody().getMeta()) {
                log.error("balance enquiry wrapper api not responding!!");
                throw new GenericException(Constants.THIRD_PARTY_ERROR_CODE, Constants.TECHNICAL_ISSUE);
            }
            if(Constants.STATUS_FAILURE==balanceResponseEntity.getBody().getMeta().getStatus()) {
                log.error("balance enquiry wrapper api response status is 1");
                throw new GenericException(Constants.THIRD_PARTY_ERROR_CODE, balanceResponseEntity.getBody().getMeta().getDescription());
            }
            log.info("balance enquiry wrapper api response :: {}",balanceResponseEntity.getBody().getData());
            return balanceResponseEntity.getBody().getData();
        } catch (ResourceAccessException ex) {
            log.error("Potential timeout occurred in balance enquiry wrapper api request", ex);
            throw new GenericException(Constants.THIRD_PARTY_TIMEOUT_CODE, Constants.TECHNICAL_ISSUE);
        } catch (HttpStatusCodeException ex) {
            log.error("HttpStatusCodeException exception balance enquiry wrapper api.", ex);
            throw new GenericException(Constants.THIRD_PARTY_ERROR_CODE, Constants.TECHNICAL_ISSUE);
        } catch (GenericException ex) {
            log.error("GenericException in  exception balance enquiry wrapper api", ex);
            throw new GenericException(Constants.THIRD_PARTY_ERROR_CODE, ex.getErrorMessage());
        }
        catch (Exception ex) {
            log.error("Exception in  exception balance enquiry wrapper api", ex);
            throw new GenericException(Constants.THIRD_PARTY_ERROR_CODE, Constants.TECHNICAL_ISSUE);
        }
    }

    // hitting get document from DOC_MGMT_STORE based on flow key
    public DocumentMgmtStoreResponseDTO hitGetDocumentByDocId(String docId, HeaderRequestDTO header) {
        log.info("Inside TransactionServiceHelper :: hitGetDocumentByDocId with docId :: {} , headers :: {}",docId,header);
        MultiValueMap<String, String> headers = RequestCreationUtil.getMultiValueMapHeaderWithAppType(header.getContentid(),
                header.getChannel(), header.getCustomerHandleNumber(),header.getAppType());
        String finalUrl = CommonUtils.getURLfromUri(getDocumentUrl, docId);
        log.info("final url of API :: {} ",finalUrl);
        try {
            RestRequest<DocumentMgmtStoreResponseDTO> restRequest = RequestCreationUtil.createRestRequest(finalUrl,
                    HttpMethod.GET, null, DocumentMgmtStoreResponseDTO.class, null, headers);
            ResponseEntity<ResponseDTO<DocumentMgmtStoreResponseDTO>> responseDTOResponseEntity = restUtil
                    .sendHttpRequest(restRequest);
            if(Objects.nonNull(responseDTOResponseEntity) && responseDTOResponseEntity.getStatusCode().equals(HttpStatus.NO_CONTENT)) {
                log.error("204 No content response from hitGetDocumentByDocId API");
                return null;
            }
            if (Objects.isNull(responseDTOResponseEntity) || Objects.isNull(responseDTOResponseEntity.getBody())
                    || Objects.isNull(responseDTOResponseEntity.getBody().getMeta())) {
                log.error("Alert :: hitGetDocumentByDocId service not responding!!");
                throw new GenericException(Constants.THIRD_PARTY_ERROR_CODE, Constants.TECHNICAL_ISSUE);
            }
            if (Constants.STATUS_FAILURE == responseDTOResponseEntity.getBody().getMeta().getStatus()) {
                log.error("Alert :: hitGetDocumentByDocId status is 1");
                throw new GenericException(Constants.THIRD_PARTY_ERROR_CODE, Constants.TECHNICAL_ISSUE);
            }
            log.info("Response from hitGetDocumentByDocId API :: {}", responseDTOResponseEntity.getBody().getData());
            return responseDTOResponseEntity.getBody().getData();
        } catch (ResourceAccessException ex) {
            log.error("Get hit docs/{docId} request is unsuccessful.", ex);
            throw new GenericException(Constants.THIRD_PARTY_TIMEOUT_CODE, Constants.TECHNICAL_ISSUE);
        } catch (HttpStatusCodeException ex) {
            log.error("Get hit docs/{docId} request is unsuccessful.", ex);
            throw new GenericException(Constants.THIRD_PARTY_ERROR_CODE, Constants.TECHNICAL_ISSUE);
        } catch (Exception ex) {
            log.error("Get hit docs/{docId} is unsuccessful.", ex);
            throw new GenericException(Constants.THIRD_PARTY_ERROR_CODE, Constants.TECHNICAL_ISSUE);
        }
    }
    
    public CustomerProfileDTO getCustomerV3Profile(String custMobileNumber, String channel, String contentId) {
    	CustomerProfileDTO customerProfileV3 = null;
        try {
            log.info("RestServiceHelper getCustomerV3Profile method custMobileNumber is  ::{} ", custMobileNumber);
            String formattedCustomerProfileUrl = CommonUtils.getURLfromUri(customerProfileV3Url, custMobileNumber);
            log.info("RestServiceHelper getCustomerV3Profile method formattedCustomerProfileUrl is  ::{} ", formattedCustomerProfileUrl);
            MultiValueMap<String, String> headers = RequestCreationUtil
                    .getMultiValueMapForCustomerProfileResponseV3(channel, contentId);

            RestRequest<CustomerProfileDTO> restRequest = RequestCreationUtil.createRestRequest(
                    formattedCustomerProfileUrl, HttpMethod.GET, null, CustomerProfileDTO.class, null, headers);

            ResponseEntity<ResponseDTO<CustomerProfileDTO>> customerProfileResponse = restUtil
                    .sendHttpRequest(restRequest);

            if (null == customerProfileResponse || null == customerProfileResponse.getBody()
                    || null == customerProfileResponse.getBody().getMeta()) {
                log.info("CustomerProfileV3 service not responding!!");
                throw new GenericException(Constants.THIRD_PARTY_ERROR_CODE, Constants.TECHNICAL_ISSUE);

            } else {
                customerProfileV3 = customerProfileResponse.getBody().getData();

                log.debug(" successfully V3 Service for customer Id :: " + custMobileNumber);
                log.info("RestServiceHelper getCustomerV3Profile method customerProfileResponse is  ::{} ", customerProfileV3);
            }

        } catch (ResourceAccessException ex) {
            log.error("Potential timeout occurred while requesting for customer profile", ex);
            throw new GenericException(Constants.THIRD_PARTY_TIMEOUT_CODE, Constants.TECHNICAL_ISSUE);
        } catch (HttpStatusCodeException ex) {
            log.error("Customer profile service request is unsuccessful.", ex);
            throw new GenericException(Constants.THIRD_PARTY_ERROR_CODE, Constants.TECHNICAL_ISSUE);
        } catch (RestClientException ex) {
            log.error("Unable to process getCustomer profile service request.", ex);
            throw new GenericException(Constants.THIRD_PARTY_ERROR_CODE, Constants.TECHNICAL_ISSUE);
        } catch (Exception ex) {
            log.error("Generic exception occured while fetching customer profile.", ex);
            throw new GenericException(Constants.THIRD_PARTY_ERROR_CODE, Constants.TECHNICAL_ISSUE);
        }

        return customerProfileV3;
    }


}
