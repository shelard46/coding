package com.airtelbank.transaction.dto.travellerPack;

import lombok.Data;

@Data
public class AccountType {

	private String id;
	private String[] information;
	private String price;
	private String name;
	private String tnc;
	private String backendId;

	
}
