package com.airtelbank.transaction.util;

import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.util.Arrays;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import com.airtelbank.transaction.exception.InvalidRestRequestException;
import com.airtelbank.transaction.model.ResponseDTO;
import com.airtelbank.transaction.model.RestRequest;


@Component
public class RestUtil {

	@Autowired
	private RestTemplate restTemplate;
    
	private static final Logger log = LoggerFactory.getLogger(RestUtil.class);
    
	public RestUtil() {
		// TODO Auto-generated constructor stub
	}
	
	public <T> ResponseEntity<ResponseDTO<T>> sendHttpRequest(RestRequest<T> req) throws RestClientException {
		String uri = null;
		final Class<T> clazz = req.getResponseClass();
		HttpMethod httpMethod = null;
		Map<String, Object> params = null;
		Object body = null;

		HttpHeaders headers = (HttpHeaders) req.getHeaders();
		if (headers != null && !headers.isEmpty()) {
		headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
		}
		if(req.getEntity() != null) {
			body = req.getEntity();
		}
		 
		HttpEntity<Object> entity = new HttpEntity<>(body, headers);
		//mandatory parameters validation.
		if(StringUtils.isNotBlank(req.getUri()) && req.getResponseClass() != null && req.getHttpMethod() != null) {
			uri = req.getUri();		 
			httpMethod = req.getHttpMethod();
		} else {
			throw new InvalidRestRequestException();
		}			
		if (req.getParams() != null) {
            params = req.getParams();
            return restTemplate.exchange(uri, httpMethod, entity, new ParameterizedTypeReference<ResponseDTO<T>>() {
                public Type getType() {
                    return new MyParameterizedTypeImpl((ParameterizedType) super.getType(), new Type[]{clazz});
                }
            }, params);
        }
		return  restTemplate.exchange(uri, httpMethod, entity, new ParameterizedTypeReference<ResponseDTO<T>>() {
	            public Type getType() {
	                return new MyParameterizedTypeImpl((ParameterizedType) super.getType(), new Type[] {clazz});
	        }
	    });					
				
	}
	
	 public <T> ResponseEntity<Object> sendHttpRequestToElastic(RestRequest<T> req) throws RestClientException {
	        String uri = null;
	        final Class<T> clazz = (Class<T>) req.getClass();
	        HttpMethod httpMethod = null;
	        Map<String, Object> params = null;
	        Object body = null;
	        HttpHeaders headers = (HttpHeaders) req.getHeaders();
	        headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
	        if (req.getEntity() != null) {
	            body = req.getEntity();
	        }
	        HttpEntity<Object> entity = new HttpEntity<>(body, headers);
	        if (StringUtils.isNotBlank(req.getUri()) && req.getClass() != null && req.getHttpMethod() != null) {
	            uri = req.getUri();
	            httpMethod = req.getHttpMethod();
	        } else {
	            throw new InvalidRestRequestException();
	        }
	        if (req.getParams() != null) {
	            params = req.getParams();
	        }
	        return restTemplate.exchange(uri, httpMethod, entity, Object.class);
	    }
	
	public class MyParameterizedTypeImpl implements ParameterizedType {
	    private ParameterizedType delegate;
	    private Type[] actualTypeArguments;

	    MyParameterizedTypeImpl(ParameterizedType delegate, Type[] actualTypeArguments) {
	        this.delegate = delegate;
	        this.actualTypeArguments = actualTypeArguments;
	    }

	    @Override
	    public Type[] getActualTypeArguments() {
	        return actualTypeArguments;
	    }

	    @Override
	    public Type getRawType() {
	        return delegate.getRawType();
	    }

	    @Override
	    public Type getOwnerType() {
	        return delegate.getOwnerType();
	    }
	}

	public static String postXmlRequest(String requestXml, String url){
        RestTemplate restTemplate = new RestTemplate();
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_XML);
        HttpEntity<String> entity = new HttpEntity<String>(requestXml, headers);
        return restTemplate.postForObject(url, entity, String.class);
    }

}
