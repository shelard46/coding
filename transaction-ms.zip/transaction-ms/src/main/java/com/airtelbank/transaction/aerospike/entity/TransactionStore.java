package com.airtelbank.transaction.aerospike.entity;

import org.springframework.data.aerospike.mapping.Document;
import org.springframework.data.aerospike.mapping.Field;
import org.springframework.data.annotation.Id;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

import java.util.HashMap;

@Setter
@Getter
@NoArgsConstructor
@AllArgsConstructor
@ToString
@Builder
@Document(collection = "txn_store")
public class TransactionStore {

	@Id
	@Field(value = "PK")
	private String paymentReqId;
	@Field(value = "ORDER_ID")
	private String orderId;
	@Field(value = "AMOUNT")
	private String amount;
	@Field(value="APP_ID")
	private String appId;
	@Field(value="DEPOIST_NO")
	private String depositerMobileNumber;
	@Field(value="USECASE")
	private String useCase;
	@Field(value = "STATUS")
	private String status;
	@Field(value = "CREATED_DATE")
	private String createdDate;
	@Field(value = "UPDATED_DATE")
	private String updateDate;
	@Field(value="APP_TYPE")
	private String appType;
	@Field(value="TXN_AUX_INFO")
	private HashMap<String,Object> txnAuxInfo;
	@Field(value="ERROR_CODE")
	private String errorCode;
	@Field(value="ERROR_DESC")
	private String errorDesc;
	
}
