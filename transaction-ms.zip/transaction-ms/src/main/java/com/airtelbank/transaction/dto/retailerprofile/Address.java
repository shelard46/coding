package com.airtelbank.transaction.dto.retailerprofile;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@JsonInclude(JsonInclude.Include.NON_EMPTY)
@AllArgsConstructor@Builder
@NoArgsConstructor
@Getter@Setter
@ToString
public class Address {

	private String city;
	@Builder.Default
	private String country = "India";
	private String line1;
	private String line2;
	private String line3;
	private String line4;
	private String state;
	@NotNull
	@Size(min=1,message="Can not be empty")
	private String zip;
	private String district;

}
