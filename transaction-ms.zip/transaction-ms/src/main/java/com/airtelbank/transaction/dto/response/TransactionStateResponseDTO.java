package com.airtelbank.transaction.dto.response;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@Builder
@ToString
public class TransactionStateResponseDTO {

	private String paymentReqId;
	private String orderId;
	private String amount;
	private String appId;
	private String depositerMobileNumber;
	private String useCase;
	private String status;
	private String createdDate;
	private String updateDate;

}
