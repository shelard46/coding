package com.airtelbank.transaction.service;

import com.airtelbank.transaction.model.AuditLog;

public interface AuditService {

	AuditLog createRecordForAuditLog(String appId, String customerId, String appType, String desc, String txnStatus,
			String resCode, String channel, Object request);
}
