package com.airtelbank.transaction.util;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import org.springframework.stereotype.Component;

@Component
public class DateCalendarUtility {
	
	public static Date parse(String input, String formatFrom) throws ParseException {
		SimpleDateFormat from = new SimpleDateFormat(formatFrom);
		Date parsed = from.parse(input);
		return parsed;
	}

	public static Date getMonthBefore(int monthBefore) {
		Calendar calNow = Calendar.getInstance();
		// adding -1 month
		calNow.add(Calendar.DATE, -monthBefore);
		// fetching updated time
		return calNow.getTime();
	}

	public static int compareDate(Date date1, Date date2) throws Exception{
			return date1.compareTo(date2);
	}
	
}
