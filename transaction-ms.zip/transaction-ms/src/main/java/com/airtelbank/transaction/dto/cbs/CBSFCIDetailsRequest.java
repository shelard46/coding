package com.airtelbank.transaction.dto.cbs;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class CBSFCIDetailsRequest {

	
	private String fci;
	
	private String afc;
	
	private String mobileNumber;
	
	private String accountType;
	
	private String subscription;
	
	private String totalamount;
	
	private String circle;
	
	private String retailerMobileNumber;
	
}
