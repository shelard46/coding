package com.airtelbank.transaction.util;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.client.ResourceAccessException;
import org.springframework.web.client.RestClientException;

import com.airtelbank.transaction.constant.Constants;
import com.airtelbank.transaction.dto.customerState.CustomerStateResponse;
import com.airtelbank.transaction.dto.response.CustomerOfferDetails;
import com.airtelbank.transaction.dto.travellerPack.OfferApiResponse;
import com.airtelbank.transaction.exception.GenericException;
import com.airtelbank.transaction.model.HeaderRequestDTO;
import com.airtelbank.transaction.model.ResponseDTO;
import com.airtelbank.transaction.model.RestRequest;
import com.airtelbank.transaction.model.TransactionRequestDTO;

import lombok.extern.slf4j.Slf4j;

@RefreshScope
@Service
@Slf4j
public class TransactionHelperUtil {

	@Value("${rest.rewards.offer.url}")
	private String rewardsOfferUrl;

	@Value("${rest.get.customer.state.url}")
	private String getCustomerStateUrl;
	
	@Value("${rest.getCustOfferDetail.url}")
	private String getCustOfferDetailurl;

	@Autowired
	RestUtil restUtil;

	public OfferApiResponse hitTravellerPackApi(String appId) {
		log.info("Inside hitTravellerPackApi for appId {} !!", appId);
		OfferApiResponse offerApiResponse;
		try {
			RestRequest<OfferApiResponse> restRequest = RequestCreationUtil.createRestRequest(rewardsOfferUrl,
					HttpMethod.GET, null, OfferApiResponse.class, null, null);
			ResponseEntity<ResponseDTO<OfferApiResponse>> responseEntity = restUtil.sendHttpRequest(restRequest);
			if (null == responseEntity || null == responseEntity.getBody()
					|| null == responseEntity.getBody().getMeta()) {
				log.info("Retailer Traveller Pack  not responding for appId :{}:!!", appId);
				throw new GenericException(Constants.THIRD_PARTY_ERROR_CODE, Constants.THIRD_PARTY_ERROR_MSG);
			} else {
				if (null == responseEntity.getBody().getData()) {
					log.info("Traveller Pack offers not available for appId :{}:!!", appId);
					return null;
				} else {
					offerApiResponse = responseEntity.getBody().getData();
					log.info("Data recieved from traveller pack api {} for appId {}!!", offerApiResponse.toString(),
							appId);
				}
			}
		} catch (ResourceAccessException ex) {
			log.error("Potential timeout occurred while requesting for Traveller Pack for appId {} Exception {}", appId,
					ex);
			throw new GenericException(Constants.THIRD_PARTY_ERROR_CODE, Constants.THIRD_PARTY_ERROR_MSG);
		} catch (HttpStatusCodeException ex) {
			log.error("Traveller Pack service request is unsuccessful for appId {} Exception {}", appId, ex);
			throw new GenericException(Constants.THIRD_PARTY_ERROR_CODE, Constants.THIRD_PARTY_ERROR_MSG);
		} catch (RestClientException ex) {
			log.error("Unable to process Traveller Pack service request for appId {} Exception {}", appId, ex);
			throw new GenericException(Constants.THIRD_PARTY_ERROR_CODE, Constants.THIRD_PARTY_ERROR_MSG);
		} catch (Exception ex) {
			log.error("Generic exception occured while fetching Traveller Packfor appId {} Exception {}", appId, ex);
			throw new GenericException(Constants.THIRD_PARTY_ERROR_CODE, Constants.THIRD_PARTY_ERROR_MSG);
		}
		return offerApiResponse;
	}

	public CustomerStateResponse hitGetCustomerStateApi(String appId, HeaderRequestDTO header) {
		log.info("Inside hitGetCustomerStateApi for appId {} !!", appId);
		MultiValueMap<String, String> headers = RequestCreationUtil.getMultiValueMapHeaderMobileNumberAndAppType(
				header.getContentid(), header.getChannel(), header.getCustomerHandleNumber(), header.getAppType());

		String finalUrl = CommonUtils.getURLfromUri(getCustomerStateUrl, appId);
		RestRequest<CustomerStateResponse> restRequest = RequestCreationUtil.createRestRequest(finalUrl, HttpMethod.GET,
				null, CustomerStateResponse.class, null, headers);
		ResponseEntity<ResponseDTO<CustomerStateResponse>> customerResponseEntity = restUtil
				.sendHttpRequest(restRequest);
		if (null == customerResponseEntity || null == customerResponseEntity.getBody()
				|| null == customerResponseEntity.getBody().getMeta()) {
			log.info("Customer service not responding for appId {} !!", appId);
			throw new GenericException(Constants.THIRD_PARTY_ERROR_CODE, Constants.THIRD_PARTY_ERROR_MSG);
		}
		return customerResponseEntity.getBody().getData();
	}
	
	public ResponseEntity<ResponseDTO<CustomerOfferDetails>> getCustomerOfferDetails(
			TransactionRequestDTO consumerRequest, String retailerNumber, String customerId) {
		ResponseEntity<ResponseDTO<CustomerOfferDetails>> customerOfferDetailsResponse = null;
		try {
			MultiValueMap<String, String> headers = RequestCreationUtil.getMultiValueMapHeaderWithRetNo(
					consumerRequest.getContentId(), consumerRequest.getChannel(), retailerNumber);
			String finalUrl = CommonUtils.getURLfromUri(getCustOfferDetailurl, customerId);
			RestRequest<CustomerOfferDetails> restRequest = RequestCreationUtil.createRestRequest(finalUrl,
					HttpMethod.GET, null, CustomerOfferDetails.class, null, headers);
			customerOfferDetailsResponse = restUtil.sendHttpRequest(restRequest);
			log.info("The data recieved for customerId: {} followed by {}", customerId,
					customerOfferDetailsResponse.toString());
		} catch (ResourceAccessException ex) {
			log.error("Potential timeout occurred while calling get Customer Offer", ex);
		} catch (HttpStatusCodeException ex) {
			log.error("get Customer Offer request is unsuccessful.", ex);
		} catch (RestClientException ex) {
			log.error("Unable to process GET Customer Offer.", ex);
		} catch (Exception ex) {
			log.error("Generic exception occured while fetching GET Customer Offer.", ex);
		}
		return customerOfferDetailsResponse;
	}


}
