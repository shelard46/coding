package com.airtelbank.transaction.model;

import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@Builder
@ToString
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class AuditLog {
	private String auditId;
	private String app; 
	private String custId;
	private String appId;
	private String appType;
	private String accId;
	private String channel;
	private String sessId;
	private String msisdn;
	private String partId;
	private String creatTime;
	private String ipAddress;
	private String action; // [ ADD_USER, AUA_AUTH, CASH_WITHDRAW, DEL_USER, OTP_AUTH ]
	private String logBy;
	private String desc;
	private String txnStatus;
	private String resCode;
	private String request;
}