package com.airtelbank.transaction.dto.retailerprofile;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.*;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

@Getter
@Setter
@Builder
@ToString
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class Product {
    @NotNull
    @Size(min = 1, message = "Can not be empty")
    private String code;
    @NotNull
    @Size(min = 1, message = "Can not be empty")
    private String description;
    @NotNull
    @Size(min = 1, message = "Can not be empty")
    private String type;
}
