package com.airtelbank.transaction.aerospike.entity;

import org.springframework.data.aerospike.mapping.Document;
import org.springframework.data.aerospike.mapping.Field;
import org.springframework.data.annotation.Id;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Setter
@Getter
@NoArgsConstructor
@AllArgsConstructor
@ToString
@Builder
@Document(collection = "FCIConfiguration")
public class FCIConfiguration {

	@Id
	@Field(value = "PK")
	private String circleCode;

	@Field(value = "LOW_FCI")
	private String lowFci;

	@Field(value = "HIGH_FCI")
	private String highFci;

	@Field(value = "LOW_FCI_ARR")
	private String lowFciArr;

	@Field(value = "HIGH_FCI_ARR")
	private String highFciArr;

	@Field(value = "LOW_ACH_ARR")
	private String lowAchArr;

	@Field(value = "HIGH_ACH_ARR")
	private String highAchArr;

}
