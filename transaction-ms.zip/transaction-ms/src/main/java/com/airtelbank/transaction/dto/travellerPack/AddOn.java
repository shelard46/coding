package com.airtelbank.transaction.dto.travellerPack;

import lombok.Data;

@Data
public class AddOn {

	private String id;
	private String price;
	private String content;
	private String name;
	private String consent;
	
}
