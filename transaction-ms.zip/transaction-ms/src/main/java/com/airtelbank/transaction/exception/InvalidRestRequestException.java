package com.airtelbank.transaction.exception;



import com.airtelbank.payments.hub.client.dto.response.Meta;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class InvalidRestRequestException extends RuntimeException {
	/**
	 * 
	 */
	private static final long serialVersionUID = -2352848335470040996L;
	private Meta meta;
	private String errorCode;
	private String errorMessage;

	public InvalidRestRequestException(String errorCode, String errorMessage) {
		super(errorMessage);
		this.errorCode = errorCode;
		this.errorMessage = errorMessage;
	}
}
