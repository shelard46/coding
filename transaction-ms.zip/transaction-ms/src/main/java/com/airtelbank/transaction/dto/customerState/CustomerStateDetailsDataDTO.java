package com.airtelbank.transaction.dto.customerState;

import java.util.Map;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Setter
@Getter
@NoArgsConstructor
@AllArgsConstructor
@ToString
@Builder
public class CustomerStateDetailsDataDTO {

	private String customerId;
	private String appId;

	private String appType;

	private String customerState;

	private String mobileNumber;

	private String creChannel;

	private String modiChannel;

	private String aadhaarId;

	private String kycUidToken;

	private String accountType;

	private String emailId;

	private String primaryEmail;

	private String pan;

	private String panFname;

	private String panMname;

	private String panLname;

	private String agrIncome;

	private String nonAgrIncome;

	private String panAckNo;

	private String panAckDate;

	private String fatHusbName;

	private String mothMaidenName;

	private String occupation;

	private String annaulIncome;

	private String nomineeFname;

	private boolean isNomCurrAddressSame;

	private String nomineeMname;

	private String nomineeLname;

	private String nomineeName;

	private String nomineeAge;

	private String nomineeDob;

	private String nomineeRel;

	private String nomineeAddr1;

	private String nomineeAddr2;

	private String nomineeAddr3;

	private String nomineeAddr4;

	private String nomineeCity;

	private String nomineeDistrict;

	private String nomineeState;

	private String nomineePCode;

	private String guardianFname;

	private boolean isGurCurrAddressSame;

	private String guardianMname;

	private String guardianLname;

	private String guardianName;

	private String guardianDob;

	private String guardianRel;

	private String guardianAddr1;

	private String guardianAddr2;

	private String guardianAddr3;

	private String guardianAddr4;

	private String guardianCity;

	private String guardianDist;

	private String guardianState;

	private String guardianPCode;

	private String custFname;

	private String custMname;

	private String custLname;

	private String custFullName;

	private String custDob;

	private String permAddr1;

	private String permAddr2;

	private String permAddr3;

	private String permAddr4;

	private String permCity;

	private String permDistrict;

	private String permSubDistrict;

	private String permPostOff;

	private String permState;

	private String permPosCode;

	private String localAddr1;

	private String localAddr2;

	private String localAddr3;

	private String localAddr4;

	private String localCity;

	private String localDistrict;

	private String localState;

	private String localSubDistrict;

	private String localPosCode;

	private Boolean caddrSmPaddr;

	private String gender;

	private String photo;

	private String maritalStatus;

	private String educationLevel;

	private String contentId;

	private String custType;

	private String ver;

	private String blacklistCheckStatus;

	private String panCheckStatus;

	private String nameMatchCheckStatus;

	private String blacklistCheckDoneBy;

	private String panCheckDoneBy;

	private String nameMatchCheckDoneBy;

	private String walletExist;

	private String walletAccountNumber;

	private String whiteListedAddress;

	private String isDormant;

	private String dedupeAction;

	private String walletType;

	private String codCustId;

	private String isNomineeExist;

	private String mpin;

	private String creationTime;

	private String updationTime;

	private String natureOfBusiness;

	private String netWorth;

	private String sourceOfFunds;

	private String transactionType;

	private String annualTurnover;

	private String expectedCreditAndDebit;

	private String officeOwnership;

	private String businessOperatedFrom;

	private String typeOfPremises;

	private String assetsOnPremises;

	private String neighbourEntityName;

	private String neighbourEntityAddress;
	
	/** Added PEP flag for SBA flow **/
	private String politicallyExposedPerson;
    
	private String physicallyChallenged;
    //Added for sba flow
    private String accountNumber;
    
    private String retailMobileNumber;

    private String afcCharge;
   
    private String retailerMPIN;
    
    private Map<String, Object> offersMap;
}
