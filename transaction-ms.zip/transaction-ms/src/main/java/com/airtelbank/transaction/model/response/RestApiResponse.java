package com.airtelbank.transaction.model.response;

import com.airtelbank.transaction.model.Meta;
import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.Getter;
import lombok.Setter;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Getter
@Setter
public class RestApiResponse {

	private RestApiResponse() {
	}

	private Meta meta;
	private Object data;

	public static RestApiResponse buildResponse(String code, String message, int status) {
		RestApiResponse response = new RestApiResponse();
		Meta meta = new Meta();
		meta.setCode(code);
		meta.setStatus(status);
		meta.setDescription(message);
		response.setMeta(meta);
		return response;
	}

}
