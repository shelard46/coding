package com.airtelbank.transaction.dto.customerProfile;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Setter
@Getter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Name implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@JsonProperty("prefix")
	public String prefix;
	@JsonProperty("first")
	public String first;
	@JsonProperty("last")
	public String last;
	@JsonProperty("mid")
	public String mid;
	@JsonProperty("shortName")
	public String shortName;
	@JsonProperty("full")
	public String full;

}

