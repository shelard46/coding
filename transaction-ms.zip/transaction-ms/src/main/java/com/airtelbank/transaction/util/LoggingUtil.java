package com.airtelbank.transaction.util;

import java.util.ArrayList;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.stereotype.Component;
import org.springframework.util.ObjectUtils;

import com.airtelbank.payments.hub.client.dto.response.DirectPaymentResponse;
import com.airtelbank.payments.hub.client.dto.response.Meta;
import com.airtelbank.transaction.dto.LoggerModel;

import com.airtelbank.payments.hub.client.dto.response.ResponseDTO;

import lombok.extern.slf4j.Slf4j;

@Component
@RefreshScope
@Slf4j
public class LoggingUtil {

	@Autowired
	private LoggerModel loggerModel;
	@Autowired
	private LogMasker logMasker;

	@Value("${config.service.id}")
	private String serviceId;
	@Value("${config.kibana.separator}")
	private String separator;

	public void doKibanaLogging(String legId, String contentId, String channel, String sessionId, String customerId,
			Object request, ResponseDTO<DirectPaymentResponse> response) {
		loggerModel.setErrors(new ArrayList<>());
		loggerModel.setMethods(new ArrayList<>());
		Meta meta = response == null ? null : response.getMeta();
		setLoggerModel(contentId, channel, sessionId, customerId, legId);
		setLoggerModel(meta);
		asyncKibanaLogging(meta, legId, request, response);
	}

	public void setStartTime(long time) {
		loggerModel.setStartTime(time);
	}

	public void setLoggerModel(String contentId, String channel, String sessionId, String customerId, String apiId) {
		loggerModel.setContentId(contentId);
		loggerModel.setChannel(channel);
		loggerModel.setCustomerId(customerId);
		loggerModel.setApiId(apiId);
		loggerModel.setSessionId(sessionId);
	}

	public void setLoggerModel(Meta meta) {
		if (!ObjectUtils.isEmpty(meta))
			loggerModel.getErrors().add(CommonUtils.setLoggerErrorMessage(meta));
	}

	public void setAppId(String appId) {
		loggerModel.setSessionId(appId);
	}

	public void setTranId(String tranId) {
		loggerModel.setTranId(tranId);
	}

	public void setMobileNumber(String mobileNumber) {
		loggerModel.setCustomerId(mobileNumber);
	}

	public void setActionInfo(String actor, String actionStatus, String actionTime, String rejectionReason) {
		loggerModel.setActor(actor);
		loggerModel.setActionStatus(actionStatus);
		loggerModel.setActionTime(actionTime);
		loggerModel.setRejectionReason(rejectionReason);
	}

	public void setVideoInfo(String videoDuration, String videoGeoLocation) {
		loggerModel.setVideoGeoLocation(videoGeoLocation);
		loggerModel.setVideoDuration(videoDuration);
	}

	public void setStateAndRetryCountInLoggerModel(String oldStateId, String newStateId, int retryCount) {
		loggerModel.setOldStateId(oldStateId);
		loggerModel.setNewStateId(newStateId);
		loggerModel.setRetryCount(retryCount);
	}

	private void asyncKibanaLogging(Meta meta, String apiAction, Object request, Object response) {
		if (!ObjectUtils.isEmpty(meta))
			loggerModel.getErrors().add(CommonUtils.setLoggerErrorMessage(meta));

		long startTime = System.currentTimeMillis();
		StringBuilder stringBuilder = new StringBuilder();
		stringBuilder.append(serviceId).append(separator);
		stringBuilder.append(apiAction).append(separator);
		stringBuilder.append(loggerModel.getCustomerId()).append(separator);
		stringBuilder.append(loggerModel.getContentId()).append(separator);
		stringBuilder.append("").append(separator);
		stringBuilder.append("0").append(separator);

		/* id1 to id3 */
		stringBuilder.append(loggerModel.getSessionId()).append(separator);
		stringBuilder.append(loggerModel.getOldStateId()).append(separator);
		stringBuilder.append(loggerModel.getNewStateId()).append(separator);

		/* id4 to id10 */
		for (int i = 4; i <= 10; i++) {
			stringBuilder.append("").append(separator);
		}

		stringBuilder.append(loggerModel.getRetryCount()).append(separator);

		for (int i = 2; i <= 3; i++) {
			stringBuilder.append("").append(separator);
		}

		for (int i = 1; i <= 2; i++) {
			stringBuilder.append("").append(separator);
		}

		stringBuilder.append(CommonUtils.jsonObjectToString(request)).append(separator);
		stringBuilder.append(CommonUtils.jsonObjectToString(response)).append(separator);

		if (loggerModel.getErrors().size() > 0) {
			stringBuilder.append(loggerModel.getErrors().get(loggerModel.getErrors().size() - 1).getStatus())
					.append(separator)
					.append(loggerModel.getErrors().get(loggerModel.getErrors().size() - 1).getErrorCode())
					.append(separator)
					.append(loggerModel.getErrors().get(loggerModel.getErrors().size() - 1).getErrorDescription())
					.append(separator);
		} else {
			stringBuilder.append(separator).append(separator).append(separator);
		}

		long endTime = System.currentTimeMillis();
		long time = endTime - startTime;
		stringBuilder.append(time);
		String result = logMasker.patternReplace(StringUtils.normalizeSpace(stringBuilder.toString()));
		printInKibanaLogging(result);
	}

	public void printInKibanaLogging(String result) {
		try {
			log.info(result);
		} finally {
			loggerModel.clear();
		}
	}
}
