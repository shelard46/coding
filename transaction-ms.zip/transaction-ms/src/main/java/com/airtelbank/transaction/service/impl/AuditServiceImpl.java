package com.airtelbank.transaction.service.impl;

import org.springframework.stereotype.Service;

import com.airtelbank.transaction.model.AuditLog;
import com.airtelbank.transaction.service.AuditService;
import com.airtelbank.transaction.util.CommonUtils;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class AuditServiceImpl implements AuditService {

	@Override
	public AuditLog createRecordForAuditLog(String appId, String customerId, String appType, String desc,
			String txnStatus, String resCode, String channel, Object request) {
		log.info("Creating record for auditLog: {} ", customerId);
		AuditLog auditLog = null;
		try {
			auditLog = AuditLog.builder().auditId(appId).appType(appType).custId(customerId).desc(desc).channel(channel)
					.txnStatus(txnStatus).resCode(resCode).request(CommonUtils.jsonObjectToString(request)).build();
		} catch (Exception ex) {
			log.error("Error while creating record for auditLog:{} for customerId : {}", ex, customerId);
		}
		return auditLog;
	}

}
