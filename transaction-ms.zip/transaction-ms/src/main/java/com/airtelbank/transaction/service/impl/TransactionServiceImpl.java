package com.airtelbank.transaction.service.impl;

import com.airtelbank.payments.hub.client.dto.response.DirectPaymentResponse;
import com.airtelbank.payments.hub.client.dto.response.ResponseDTO;
import com.airtelbank.payments.hub.client.service.impl.PHDirectPaymentRequestServiceImpl;
import com.airtelbank.transaction.aerospike.entity.AllowedCustomer;
import com.airtelbank.transaction.aerospike.entity.AllowedRetailer;
import com.airtelbank.transaction.aerospike.entity.AppIdToPaymentReqId;
import com.airtelbank.transaction.aerospike.entity.CreationIdGeneration;
import com.airtelbank.transaction.aerospike.entity.FCIConfiguration;
import com.airtelbank.transaction.aerospike.entity.FCIInfoDetails;
import com.airtelbank.transaction.aerospike.entity.TransactionStore;
import com.airtelbank.transaction.constant.Constants;
import com.airtelbank.transaction.dto.cbs.CBSFCIDetailsRequest;
import com.airtelbank.transaction.dto.cbs.FCIDetailResponse;
import com.airtelbank.transaction.dto.fciCircleBased.FCIResponseDTO;
import com.airtelbank.transaction.dto.response.TransactionStateResponseDTO;
import com.airtelbank.transaction.dto.retailerprofile.AccountResponse;
import com.airtelbank.transaction.dto.retailerprofile.Retailer;
import com.airtelbank.transaction.exception.GenericException;
import com.airtelbank.transaction.model.HeaderRequestDTO;
import com.airtelbank.transaction.model.Meta;
import com.airtelbank.transaction.model.RequestDTO;
import com.airtelbank.transaction.model.RestRequest;
import com.airtelbank.transaction.model.TransactionEnquiryRequest;
import com.airtelbank.transaction.model.TransactionRequestDTO;
import com.airtelbank.transaction.service.AuditService;
import com.airtelbank.transaction.service.TransactionService;
import com.airtelbank.transaction.strategy.TransactionRuleStrategy;
import com.airtelbank.transaction.strategy.TransactionRuleStrategyFactory;
import com.airtelbank.transaction.util.CommonUtils;
import com.airtelbank.transaction.util.LogMasker;
import com.airtelbank.transaction.util.RequestCreationUtil;
import com.airtelbank.transaction.util.RestUtil;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.aerospike.core.AerospikeTemplate;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.client.ResourceAccessException;
import org.springframework.web.client.RestClientException;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Objects;

@Slf4j
@Service
public class TransactionServiceImpl implements TransactionService {

	@Autowired
	private AerospikeTemplate aerospikeTemplate;

	@Value("${config.sba.payment.hub.partnerId}")
	private String partnerId;

	@Value("${rest.post.audit.url}")
	private String auditUrl;

	@Autowired
	private LogMasker logMasker;

	@Autowired
	private RestUtil restUtil;

	@Autowired
	private PHDirectPaymentRequestServiceImpl pHDirectPaymentRequestServiceImpl;

	@Autowired
	private AuditService auditService;


	@Value("${rest.getRetailerData.url}")
	private String retailerProfileUrl;

	@Autowired
	private TransactionRuleStrategyFactory ruleStrategyFactory;

	@Value("${config.transaction.create.aerospike.retry.count}")
	private int aerospikeRetryCount;

	@Override
	public ResponseDTO<DirectPaymentResponse> onboardingUsecaseToPaymentHub(TransactionRequestDTO transactionRequestDTO,
			HeaderRequestDTO headerRequestDTO,String amount) throws Exception {

		TransactionRuleStrategy strategy = ruleStrategyFactory.getRuleStrategyFactory(headerRequestDTO.getAppType());
		return strategy.onboardingUsecaseToPaymentHub(transactionRequestDTO,headerRequestDTO,amount);
	}

	public String orderId() {
		int orderId = 0;
		try {
			CreationIdGeneration creationIdGenerationExist = aerospikeTemplate.findById(Constants.ONE,
					CreationIdGeneration.class);
			orderId = creationIdGenerationExist.getOrderId();
			log.info("OrderId created {}", orderId);
			creationIdGenerationExist.setOrderId(creationIdGenerationExist.getOrderId() + 1);
			aerospikeTemplate.update(creationIdGenerationExist);
		} catch (Exception ex) {
			log.error("Exception while generating creationId {}", ex);
		}
		return String.valueOf(orderId);
	}

	@Override
	public ResponseDTO<FCIResponseDTO> getCircleCodeInfo(String circleCode, String retailerId, String customerId,
			String contentId, String channel) {
		log.info("fetch Circle Code Info for circleCode:{} ,retailerId:{} , customerId:{}", circleCode, retailerId,
				customerId);
		ResponseDTO<FCIResponseDTO> response = new ResponseDTO<>();
		FCIConfiguration fciConfig = null;
		List<String> fciValues = null;
		List<String> activationCharges = null;
		String fciAmount = null;
		AllowedCustomer allowedCustomer = null;
		AllowedRetailer allowedRetailer = null;

		fciConfig = aerospikeTemplate.findById(circleCode, FCIConfiguration.class);

		if (fciConfig != null) {
			if (StringUtils.isNotBlank(customerId)) {
				allowedCustomer = aerospikeTemplate.findById(Long.valueOf(customerId), AllowedCustomer.class);
			}
			if (StringUtils.isNotBlank(retailerId)) {
				allowedRetailer = aerospikeTemplate.findById(Long.valueOf(retailerId), AllowedRetailer.class);
			}
			if (null != allowedCustomer || null != allowedRetailer) {
				log.info("Low FCI charges applied for circleCode:{} ,retailerId:{} , customerId:{}", circleCode,
						retailerId, customerId);
				fciAmount = fciConfig.getLowFci();
				if (fciConfig.getLowFciArr() != null)
					fciValues = Arrays.asList(fciConfig.getLowFciArr().split(","));
				if (fciConfig.getLowAchArr() != null)
					activationCharges = Arrays.asList(fciConfig.getLowAchArr().split(","));
			} else {
				log.info("High FCI charges applied for circleCode:{} ,retailerId:{} , customerId:{}", circleCode,
						retailerId, customerId);
				fciAmount = fciConfig.getHighFci();
				if (fciConfig.getHighFciArr() != null)
					fciValues = Arrays.asList(fciConfig.getHighFciArr().split(","));
				if (fciConfig.getHighAchArr() != null)
					activationCharges = Arrays.asList(fciConfig.getHighAchArr().split(","));
			}
		} else {
			log.info(
					"ApplicationServiceImpl::getCircleCodeInfo:: No details for circleCode:{} found in Aerospike set ApplicationDetails",
					circleCode);
		}
		FCIResponseDTO fciResponse = FCIResponseDTO.builder().minFCIAmount(fciAmount).fciValues(fciValues)
				.activationCharges(activationCharges).build();
		response.setData(fciResponse);
		return response;
	}

	@Override
	public com.airtelbank.transaction.model.ResponseDTO<?> saveFCIDetails(
			RequestDTO<CBSFCIDetailsRequest> fciDetailsRequest, String contentId, String channel) {

		Meta meta = new Meta();
		com.airtelbank.transaction.model.ResponseDTO<?> response = new com.airtelbank.transaction.model.ResponseDTO<>();
		AllowedCustomer allowedCustomer = null;
		AllowedRetailer allowedRetailer = null;
		List<String> activationChargesFromAS = null;
		List<String> fciValuesFromAS = null;
		FCIConfiguration fciConfig = null;
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.SSSSSS");
		LocalDateTime now = LocalDateTime.now();
		int totalAmount = 0;

		CBSFCIDetailsRequest fciRequest = fciDetailsRequest.getData();
		
		
		/*----------Start--Category check--------*/
		
		BigDecimal availableBalance=null;
		Retailer retailerProfileDetails=null;
		try {
			retailerProfileDetails = getRetailerProfileDetails(fciRequest.getRetailerMobileNumber(), channel, contentId);
		if (retailerProfileDetails != null) {
		String categoryCode = retailerProfileDetails.getCategoryCode();
		if(categoryCode==null) {
			CommonUtils.getResponseMeta(meta, Constants.FAILED, Constants.STATUS_FAILURE, Constants.RETAILER_CATEGORY_NOT_RETRIEVED);
			response.setMeta(meta);
			return response;
		}else {
		log.info("Retailer category is {}",categoryCode);
		if(!categoryCode.equals(Constants.OR_STORE_CATEGORY)) {
		List<AccountResponse> accountListResponse = retailerProfileDetails.getAccountList();
		
		for(AccountResponse accountResponse : accountListResponse) { 
    		 availableBalance = accountResponse.getBalance().getAvailableBalance();
		}
		
		BigDecimal fciTotalamount = new BigDecimal(fciRequest.getTotalamount());
		log.info("Retailer availableBalance is {} and fciTotalamount is{} ",availableBalance,fciTotalamount);

			if( null == availableBalance || availableBalance.compareTo(fciTotalamount) < 0) {
				CommonUtils.getResponseMeta(meta, Constants.FAILED, Constants.STATUS_FAILURE, Constants.OR_STORE_CATEGORY_MSG);
				response.setMeta(meta);
				return response;
			}
		}
		}}
		} catch (Exception ex) {
			log.error("Exception occured inside getRetailerProfileDetails for retailer:{}",fciRequest.getRetailerMobileNumber() , ex);
			throw new GenericException(Constants.THIRD_PARTY_ERROR_CODE, Constants.THIRD_PARTY_ERROR_MSG);
		}
		/*--------END--Category check--------*/
		
		int chargesFromAS = 0;
		if (null != fciRequest) {
			fciConfig = aerospikeTemplate.findById(fciRequest.getCircle(), FCIConfiguration.class);
			if (StringUtils.isNotBlank(fciRequest.getMobileNumber())) {
				allowedCustomer = aerospikeTemplate.findById(Long.valueOf(fciRequest.getMobileNumber()),
						AllowedCustomer.class);
			}
			if (StringUtils.isNotBlank(fciRequest.getRetailerMobileNumber())) {
				allowedRetailer = aerospikeTemplate.findById(Long.valueOf(fciRequest.getRetailerMobileNumber()),
						AllowedRetailer.class);
			}
			if (null != allowedCustomer || null != allowedRetailer) {
				log.info("LOW FCI charges applied inside saveFCIDetails for circleCode:{} ,retailerId:{} , customerId:{}",
						fciRequest.getCircle(), fciRequest.getRetailerMobileNumber(), fciRequest.getMobileNumber());
				if (fciConfig.getLowFciArr() != null)
					fciValuesFromAS = Arrays.asList(fciConfig.getLowFciArr().split(","));
				if (fciConfig.getLowAchArr() != null)
					activationChargesFromAS = Arrays.asList(fciConfig.getLowAchArr().split(","));
			} else {
				log.info("High FCI charges applied inside saveFCIDetails for circleCode:{} ,retailerId:{} , customerId:{}",
						fciRequest.getCircle(), fciRequest.getRetailerMobileNumber(), fciRequest.getMobileNumber());
				if (fciConfig.getHighFciArr() != null)
					fciValuesFromAS = Arrays.asList(fciConfig.getHighFciArr().split(","));
				if (fciConfig.getHighAchArr() != null)
					activationChargesFromAS = Arrays.asList(fciConfig.getHighAchArr().split(","));
			}

			// Security point issue, data coming from request and data coming should match
			// for AFC value i.e activationCharges
			// For example for this FCI charges [500, 1000, 2000, 5000]
			// this activation charges should apply [50, 100, 150, 200]
			if (fciValuesFromAS != null && activationChargesFromAS != null) {
				int depoistAmount = Integer.parseInt(fciRequest.getFci());
				int chargesFromRequest = Integer.parseInt(fciRequest.getAfc());

				if (depoistAmount <= Integer.parseInt(fciValuesFromAS.get(0))) {
					chargesFromAS = Integer.parseInt(activationChargesFromAS.get(0));

				} else if (depoistAmount > Integer.parseInt(fciValuesFromAS.get(0))
						&& depoistAmount < Integer.parseInt(fciValuesFromAS.get(1))) {
					chargesFromAS = Integer.parseInt(activationChargesFromAS.get(1));

				} else if (depoistAmount >= Integer.parseInt(fciValuesFromAS.get(1))
						&& depoistAmount < Integer.parseInt(fciValuesFromAS.get(2))) {
					chargesFromAS = Integer.parseInt(activationChargesFromAS.get(2));

				} else if (depoistAmount >= Integer.parseInt(fciValuesFromAS.get(2))) {
					chargesFromAS = Integer.parseInt(activationChargesFromAS.get(3));
				}

				if (chargesFromAS != chargesFromRequest) {
					// This fix is from Security point of view. activationcharges from request and database should be same 
					// If not then update activationcharges from aerospike set and update in DTO object
					fciRequest.setAfc(Integer.toString(chargesFromAS));
					totalAmount = Integer.parseInt(fciRequest.getTotalamount()) - chargesFromRequest;
					totalAmount = totalAmount + chargesFromAS;
					fciRequest.setTotalamount(Integer.toString(totalAmount));
				}
			}
			FCIInfoDetails fCIInfoDetails = FCIInfoDetails.builder().appId(fciDetailsRequest.getMeta().getAppId())
					.accountType(fciRequest.getAccountType()).afc(fciRequest.getAfc())
					.appType(fciDetailsRequest.getMeta().getAppType()).fci(fciRequest.getFci())
					.subscription(fciRequest.getSubscription()).totalamount(fciRequest.getTotalamount())
					.mobileNumber(fciRequest.getMobileNumber()).circle(fciRequest.getCircle())
					.retailerMobileNumber(fciRequest.getRetailerMobileNumber()).creationTime(dtf.format(now))
					.updationTime(dtf.format(now)).build();
			aerospikeTemplate.save(fCIInfoDetails);
			log.info("FCIDetails saved for appId:{}", fciDetailsRequest.getMeta().getAppId());
		} else {
			CommonUtils.getResponseMeta(meta, Constants.FAILED, Constants.STATUS_FAILURE, Constants.FAILED);
		}
		CommonUtils.getResponseMeta(meta, Constants.SUCCESS, Constants.STATUS_SUCCESS,
				Constants.SUCCESSFULLY_PROCESSED);
		response.setMeta(meta);
		return response;
	}

	@Override
	public com.airtelbank.transaction.model.ResponseDTO<FCIDetailResponse> getFCIDetailsById(String appId) {
		com.airtelbank.transaction.model.ResponseDTO<FCIDetailResponse> response = new com.airtelbank.transaction.model.ResponseDTO<>();

		Meta meta = new Meta();
		FCIInfoDetails fciInfoValue = null;
		try {
			fciInfoValue = aerospikeTemplate.findById(appId, FCIInfoDetails.class);
		} catch (Exception ex) {
			CommonUtils.getResponseMeta(meta, Constants.FAILED, Constants.STATUS_FAILURE,
					Constants.FCI_DETAILS_NOT_RETRIEVED);
			response.setMeta(meta);
			return response;
		}

		if (null != fciInfoValue) {
			FCIDetailResponse fciDetailResponse = FCIDetailResponse.builder().appId(fciInfoValue.getAppId())
					.appType(fciInfoValue.getAppType()).fci(fciInfoValue.getFci())
					.mobileNumber(fciInfoValue.getMobileNumber()).accountType(fciInfoValue.getAccountType())
					.afc(fciInfoValue.getAfc()).subscription(fciInfoValue.getSubscription())
					.totalamount(fciInfoValue.getTotalamount()).circle(fciInfoValue.getCircle())
					.retailerMobileNumber(fciInfoValue.getRetailerMobileNumber())
					.creationTime(fciInfoValue.getCreationTime()).updationTime(fciInfoValue.getUpdationTime()).build();

			response.setData(fciDetailResponse);
			CommonUtils.getResponseMeta(meta, Constants.SUCCESS, Constants.STATUS_SUCCESS,
					Constants.SUCCESSFULLY_PROCESSED);
		} else {
			CommonUtils.getResponseMeta(meta, Constants.FAILED, Constants.STATUS_FAILURE, Constants.FCI_NOT_EXIT);
		}
		response.setMeta(meta);
		return response;
	}
	
	private Retailer getRetailerProfileDetails(String retailerMobileNumber, String channel, String contentId) {
		Retailer retailerProfile = null;
		
		try {
			MultiValueMap<String, String> headers = RequestCreationUtil.getMultiValueMapHeader(contentId, channel);
			String finalUrl = CommonUtils.getURLfromUri(retailerProfileUrl, retailerMobileNumber);
			RestRequest<Retailer> restRequest = RequestCreationUtil.createRestRequest(finalUrl,
					HttpMethod.GET, null, Retailer.class, null, headers);
			ResponseEntity<com.airtelbank.transaction.model.ResponseDTO<Retailer>> retailerProfileResponse = restUtil
					.sendHttpRequest(restRequest);
			log.info("Retailer data recieved followed by {}", retailerProfileResponse.toString());
			if (null == retailerProfileResponse || null == retailerProfileResponse.getBody()
					|| null == retailerProfileResponse.getBody().getMeta()) {
				log.info("RetailerProfile service not responding!!");
				throw new GenericException(Constants.THIRD_PARTY_ERROR_CODE, Constants.THIRD_PARTY_ERROR_MSG);
			} else {
				if (null == retailerProfileResponse.getBody().getData()) {
					log.info("Retailer {} is not  registered for airtel payments bank", retailerMobileNumber);
					return null;
				} else {
					retailerProfile = retailerProfileResponse.getBody().getData();
					log.info("data recieved from the Retailer details as follows:- {}", retailerProfile.toString());
					log.info("Response received : code {}, message {} ",
							retailerProfileResponse.getBody().getMeta().getCode(),
							retailerProfileResponse.getBody().getMeta().getDescription());
				}
			}
		} catch (ResourceAccessException ex) {
			log.error("Potential timeout occurred while requesting for Retailer profile", ex);
			throw new GenericException(Constants.THIRD_PARTY_ERROR_CODE, Constants.THIRD_PARTY_ERROR_MSG);
		} catch (HttpStatusCodeException ex) {
			log.error("Retailer profile service request is unsuccessful.", ex);
			throw new GenericException(Constants.THIRD_PARTY_ERROR_CODE, Constants.THIRD_PARTY_ERROR_MSG);
		} catch (RestClientException ex) {
			log.error("Unable to process getRetailer profile service request.", ex);
			throw new GenericException(Constants.THIRD_PARTY_ERROR_CODE, Constants.THIRD_PARTY_ERROR_MSG);
		} catch (Exception ex) {
			log.error("Generic exception occured while fetching retailer profile.", ex);
			throw new GenericException(Constants.THIRD_PARTY_ERROR_CODE, Constants.THIRD_PARTY_ERROR_MSG);
		}
		log.info("Exiting the Get Retailer Profile NatlId :-{}",retailerProfile.getNatlId());
		return retailerProfile;
	}
	
	@Override
	public com.airtelbank.transaction.model.ResponseDTO<TransactionStateResponseDTO> getTransactionState(String appId) {
		log.info("Inside getTransactionState for appId {} " + appId);
		com.airtelbank.transaction.model.ResponseDTO<TransactionStateResponseDTO> response = new com.airtelbank.transaction.model.ResponseDTO<>();
		TransactionStore transactionStore = null;
		com.airtelbank.transaction.model.Meta meta = new com.airtelbank.transaction.model.Meta();
		try {
			AppIdToPaymentReqId transactionAppIdToPaymentReqId = aerospikeTemplate.findById(appId,
					AppIdToPaymentReqId.class);
			if (transactionAppIdToPaymentReqId != null
					&& !CollectionUtils.isEmpty(transactionAppIdToPaymentReqId.getPaymentReqId())) {
				log.info("Fetched paymentRequestId from transactionAppIdToPaymentReqId successfylly for appId {}",
						appId);

				transactionStore = aerospikeTemplate.findById(transactionAppIdToPaymentReqId.getPaymentReqId().get(0),
						TransactionStore.class);
				if (transactionStore != null) {
					log.info(
							"Fetched transaction data from transaction store successfylly for appId {} and paymentRequestId {} ",
							appId, transactionAppIdToPaymentReqId.getPaymentReqId());
					TransactionStateResponseDTO transactionStateResponseDTO = TransactionStateResponseDTO.builder()
							.amount(transactionStore.getAmount()).appId(transactionStore.getAppId())
							.createdDate(transactionStore.getCreatedDate())
							.depositerMobileNumber(transactionStore.getDepositerMobileNumber())
							.orderId(transactionStore.getOrderId()).paymentReqId(transactionStore.getPaymentReqId())
							.status(transactionStore.getStatus()).updateDate(transactionStore.getUpdateDate())
							.useCase(transactionStore.getUseCase()).build();
					response.setData(transactionStateResponseDTO);
					CommonUtils.getResponseMeta(meta, Constants.SUCCESS, Constants.STATUS_SUCCESS,
							Constants.GET_TRANSACTION_STATE_SUCCESS);
					response.setMeta(meta);
				}
			} else {
				log.info("There does not exists any transaction corresponding to this AppId {} !!", appId);
				CommonUtils.getResponseMeta(meta, Constants.FAILED, Constants.STATUS_FAILURE,
						Constants.GET_TRANSACTION_STATE_FAILURE);
				response.setMeta(meta);

			}
		} catch (Exception ex) {
			log.error("Generic exception occured while fetching transaction state for appId {}." + appId);
		}
		return response;
	}
	
	public void saveAppIdToPaymentReqIdInAerospike(String appId, String prId) {
		boolean isSuccess = false;
		int retryCounter = 0;
		AppIdToPaymentReqId appIdToPaymentReqId=null;
		List<String> paymentId=null;
		while (retryCounter <= aerospikeRetryCount) {
			try {
				log.info("Trying to insert entry into TransactionAppIdToPaymentReqId for prId :{}: appId :{}:", prId,appId);
				appIdToPaymentReqId=aerospikeTemplate.findById(appId,AppIdToPaymentReqId.class);
				if(Objects.isNull(appIdToPaymentReqId)) {
					appIdToPaymentReqId = new AppIdToPaymentReqId();
					appIdToPaymentReqId.setCreationTime(Constants.SIMPLEDATEFORMAT.format(new Date()));
				}
				paymentId=appIdToPaymentReqId.getPaymentReqId();
				if(CollectionUtils.isEmpty(paymentId))
					paymentId=new ArrayList<>();
				paymentId.add(prId);
				appIdToPaymentReqId = AppIdToPaymentReqId.builder().appId(appId)
						.paymentReqId(paymentId).updationTime(Constants.SIMPLEDATEFORMAT.format(new Date())).build();
				aerospikeTemplate.save(appIdToPaymentReqId);
				isSuccess = true;
				break;
			} catch (Exception ex) {
				try {
					Thread.sleep(100);
				} catch (InterruptedException e) {
					isSuccess = false;
					log.error("InterruptedException while putting entry into TransactionAppIdToPaymentReqId in Aerospike: for prId :{}:",
							prId, e);
				}
				isSuccess = false;
				log.error("Failed while putting entry into TransactionAppIdToPaymentReqId in Aerospike: for prId :{}:", prId, ex);
				retryCounter++;
				if (retryCounter > aerospikeRetryCount) {
					log.error("Max retries exceeded for creating entry into TransactionAppIdToPaymentReqId!");
				}
			}
		}
	}

	@Override
	public ResponseDTO<String> paymentEnquiry(TransactionEnquiryRequest transactionEnquiryRequest, HeaderRequestDTO headerRequestDTO) {
		TransactionRuleStrategy strategy = ruleStrategyFactory.getRuleStrategyFactory(headerRequestDTO.getAppType());
		return strategy.paymentHubEnquiry(transactionEnquiryRequest,headerRequestDTO);


	}
}
