package com.airtelbank.validation.config;

import java.util.Arrays;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.http.client.BufferingClientHttpRequestFactory;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.web.client.RestTemplate;

@Configuration
public class HttpConfig {

	@Value("${application.httpclient.pool.size:10}")
	private int httpClientPoolSize;

	/** Application HTTP client keepalive duration in seconds. */
	@Value("${application.httpclient.keepalive:120}")
	private int httpClientKeepAlive;

	@Value("${checktxn.connect.timeout.millis:3000}")
	private int checkTxnTimeout;

	@Value("${checktxn.read.timeout.millis:5000}")
	private int readTimeout;

	@Autowired
	private LoggingClientHttpRequestInterceptor loggingClientHttpRequestInterceptor;

	@Bean(name = "restTemplate")
	@Primary
	RestTemplate restTemplate(RestTemplateBuilder restTemplateBuilder) {
		RestTemplate restTemplate = restTemplateBuilder
				.additionalInterceptors(
						Arrays.asList(new CorrelationIdInterceptor(), loggingClientHttpRequestInterceptor))
				.setConnectTimeout(checkTxnTimeout).setReadTimeout(readTimeout).build();
		SimpleClientHttpRequestFactory requestFactory = new SimpleClientHttpRequestFactory();
		BufferingClientHttpRequestFactory bufferingClientHttpRequestFactory = new BufferingClientHttpRequestFactory(
				requestFactory);
		requestFactory.setOutputStreaming(false);
		restTemplate.setRequestFactory(bufferingClientHttpRequestFactory);
		return restTemplate;
	}

	@Bean(name = "restTemplateAadhaarVault")
	RestTemplate restTemplateAadhaarVault(RestTemplateBuilder restTemplateBuilder,
			@Value(value = "${aadhaarVault.readTimeout}") String aadhaarVaultReadTimeOut,
			@Value(value = "${aadhaarVault.connectionTimeout}") String aadhaarVaultConnectionTimeOut) {
		HttpComponentsClientHttpRequestFactory httpComponentsClientHttpRequestFactory = new HttpComponentsClientHttpRequestFactory();
		httpComponentsClientHttpRequestFactory.setConnectTimeout(Integer.parseInt(aadhaarVaultConnectionTimeOut));
		httpComponentsClientHttpRequestFactory.setReadTimeout(Integer.parseInt(aadhaarVaultReadTimeOut));
		RestTemplate restTemplate = restTemplateBuilder
				.additionalInterceptors(
						Arrays.asList(new CorrelationIdInterceptor(), loggingClientHttpRequestInterceptor))
				.build();
		restTemplate.setRequestFactory(httpComponentsClientHttpRequestFactory);
		return restTemplate;
	}

}
