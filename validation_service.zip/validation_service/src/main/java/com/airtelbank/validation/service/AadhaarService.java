package com.airtelbank.validation.service;

import javax.xml.bind.JAXBException;

import com.airtelbank.validation.dao.aerospike.model.AadhaarVerify;
import com.airtelbank.validation.exception.UIDAIAadhaarVerifyException;
import com.airtelbank.validation.exception.VerificationException;
import com.airtelbank.validation.model.AUARequest;
import com.airtelbank.validation.model.AUAResponse;
import com.airtelbank.validation.model.AadhaarVaultRequest;
import com.airtelbank.validation.model.AadhaarVaultResponse;
import com.airtelbank.validation.model.Document;
import com.airtelbank.validation.model.KUARequest;
import com.airtelbank.validation.model.ResponseDTO;

public interface AadhaarService {
    public AadhaarVerify verifyIdentity(String id, String verificationInput, String verificationType, String uniqueDeviceCode)
            throws JAXBException, VerificationException , UIDAIAadhaarVerifyException;

    public ResponseDTO<Document> generateAadhaarOTP(Document request) throws Exception;

    public AadhaarVaultResponse getAadhaarReference(AadhaarVaultRequest aadhaarVaultRequest);

    public ResponseDTO removeAadhaar(AadhaarVaultRequest aadhaarVaultRequest, String apptype, String customerId);

    public AadhaarVaultResponse getAadhaarNumber(AadhaarVaultRequest aadhaarVaultRequest);

    public ResponseDTO<AadhaarVerify> verifyAadhaarIdentity(Document request) throws UIDAIAadhaarVerifyException;

    public AUAResponse validateAUA(AUARequest auaRequest,String contentId);
    public ResponseDTO<AadhaarVerify> getAadhaarDetailsKUA(KUARequest kuaRequest, String contentId);
}