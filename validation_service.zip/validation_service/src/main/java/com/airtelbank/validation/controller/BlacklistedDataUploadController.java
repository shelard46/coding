
package com.airtelbank.validation.controller;

import org.apache.log4j.MDC;
import org.joda.time.DateTime;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.airtelbank.validation.constants.Constants;
import com.airtelbank.validation.model.Meta;
import com.airtelbank.validation.service.IBlacklistDataUploadService;
import com.airtelbank.validation.util.CommonUtil;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

/**
 * Controller class to expose REST api for uploading BL customers data.
 * 
 * @author B0214858
 *
 */

@RestController
@RequestMapping(value = {"/api/v1","/api/v2"})
public class BlacklistedDataUploadController {

	private static final Logger logger = LoggerFactory.getLogger(BlacklistedDataUploadController.class);

	@Autowired
	private IBlacklistDataUploadService dataUploadService;
	/**
	 * 
	 * @param filePath
	 * @return {@link ResponseEntity}
	 * @throws Exception
	 */
	@GetMapping(value = "/upload")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "BL data uploaded Successfully"),
			@ApiResponse(code = 400, message = "Bad request"),
			@ApiResponse(code = 403, message = "Accessing the resource you were trying to reach is forbidden"),
			@ApiResponse(code = 404, message = "The file you were trying to upload is not found") })
	@ApiOperation(value = "/upload")
	public ResponseEntity<String> uploadBlacklistedData(@RequestParam String filePath) throws Exception {
		logger.info("Uploading Blacklisted Data from file: {} at time: {}" , filePath, DateTime.now());
		CommonUtil.setMDCMap(Constants.CONTENT_ID, Constants.CHANNEL, Constants.CUSTOMER_ID, Constants.BLACKLIST_DATA_UPLOAD);
		try {
			dataUploadService.upload(filePath);
			MDC.put(Constants.ERRORS, CommonUtil.setLoggerError(Meta.builder().status(Constants.SUCCESS_STATUS).build()));
		} catch (Exception e) {
			MDC.put(Constants.ERRORS, CommonUtil.setLoggerError(Meta.builder().status(Constants.FAILURE_STATUS).build()));
			return new ResponseEntity("Something went wrong", HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return new ResponseEntity("Data uploaded successfully", HttpStatus.OK);
	}

}
