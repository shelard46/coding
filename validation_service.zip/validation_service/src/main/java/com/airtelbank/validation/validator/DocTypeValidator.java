package com.airtelbank.validation.validator;

import com.airtelbank.validation.constants.DocType;
import org.apache.commons.lang3.StringUtils;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

public class DocTypeValidator implements
  ConstraintValidator<DocTypeConstraint, String> {
 
    @Override
    public void initialize(DocTypeConstraint docType) {
    	// left blank
    }
 
    @Override
    public boolean isValid(String docTypeField,
      ConstraintValidatorContext cxt) {
    	
    	if(StringUtils.isBlank(docTypeField)) {
    		return false;
    	}
    	return docTypeField.equalsIgnoreCase(DocType.AADHAAR)|| docTypeField.equalsIgnoreCase(DocType.PAN);
    	
    }
}