package com.airtelbank.validation.model;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.*;


@Setter
@Getter
@ToString
@NoArgsConstructor
@XmlRootElement(name = "residentIdentity")
@XmlAccessorType(XmlAccessType.FIELD)
public class ResidentIdentity {

	private String name;
	@XmlElement(name = "dob")
	@JsonProperty("dob")
	private String dateOfBirth;
	private String gender;
	@XmlElement(name = "phone")
	@JsonProperty("phone")
	private String aadhaarRegMobile;
	private String email;
	private String careOf;
	private String house;
	private String street;
	private String landMark;
	private String locality;
	@XmlElement(name = "vtc")
	@JsonProperty("vtc")
	private String city;
	private String subDistrict;
	private String district;
	private String state;
	private String country;
	@XmlElement(name = "pincode")
	@JsonProperty("pincode")
	private String pinCode;
	private String postOfficeName;
	
}
