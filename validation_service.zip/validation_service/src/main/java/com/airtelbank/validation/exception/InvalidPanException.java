package com.airtelbank.validation.exception;

import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Setter
@Getter
@ToString
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class InvalidPanException extends RuntimeException {
    private String id;

    public InvalidPanException(String message, String id) {
        super(message);
        this.id = id;
    }

    public InvalidPanException(String message, Throwable cause, String id) {
        super(message, cause);
        this.id = id;
    }

    public InvalidPanException(Throwable cause, String id) {
        super(cause);
        this.id = id;
    }
}
