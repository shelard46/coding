package com.airtelbank.validation.util;

import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Level;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Map;
import java.util.Set;

@Slf4j
@Component
public class HttpUtil {
	@Autowired private RestTemplate restTemplate;

	@Autowired private ObjectMapper objectMapper;

	@Autowired private RestTemplate restTemplateAadhaarVault;

	@Value("${log.encryption.key}")
	private String publicKey;

	public <I, O> O sendRequest(String url, I requestObj, Class<I> classObj, Map<String, String> headers,
			HttpMethod method) throws IOException {
		Object resultObj = null;
		HttpHeaders httpHeaders = new HttpHeaders();
		HttpEntity<?> entity = null;

		if (headers != null && !headers.isEmpty()) {
			httpHeaders = new HttpHeaders();
			Set<String> headerKeySet = headers.keySet();
			for (String key : headerKeySet)
				httpHeaders.add(key, headers.get(key));
		}

		if (requestObj != null)
			entity = new HttpEntity<>(requestObj, httpHeaders);
		else
			entity = new HttpEntity<>(httpHeaders);

		try {
			// Send request with GET method, and Headers.
			ResponseEntity<?> response = restTemplate.exchange(url, method, entity, classObj);
			resultObj = response.getBody();
		} catch (RestClientException e) {
			String errorResponse = getErrorResponeMessage(e);
			if (!StringUtils.isEmpty(errorResponse)) {
				resultObj = convertResponseToType(classObj, errorResponse, httpHeaders);
			}

		}
		return (O) resultObj;
	}

	public <I, O> O sendRequest(String url, I requestObj, Class<I> classObj, Map<String, String> headers,
			HttpMethod method, MediaType mediaType) throws IOException {
		Object resultObj = null;
		HttpHeaders httpHeaders = new HttpHeaders();
		HttpEntity<?> entity = null;

		if (null != mediaType) {
			httpHeaders.setContentType(MediaType.APPLICATION_XML);
			httpHeaders.setAccept(Collections.singletonList(MediaType.APPLICATION_XML));
		}

		if (headers != null && !headers.isEmpty()) {
			httpHeaders = new HttpHeaders();
			Set<String> headerKeySet = headers.keySet();
			for (String key : headerKeySet)
				httpHeaders.add(key, headers.get(key));
		}

		if (requestObj != null)
			entity = new HttpEntity<>(requestObj, httpHeaders);
		else
			entity = new HttpEntity<>(httpHeaders);

		try {
			// Send request with GET method, and Headers.
			ResponseEntity<?> response = restTemplate.exchange(url, method, entity, classObj);
			resultObj = response.getBody();
		} catch (RestClientException e) {
			String errorResponse = getErrorResponeMessage(e);
			if (!StringUtils.isEmpty(errorResponse)) {
				resultObj = convertResponseToType(classObj, errorResponse, httpHeaders);

			}
		}
		return (O) resultObj;
	}

	public <T>Object handleRequest(String url, Object requestObj, Class<T> classObj, Map<String, String> httpHeaderMap,HttpMethod method) throws IOException {
		Object resultObj = null;
		// HttpHeaders
		HttpHeaders headers = getHttpHeaders(httpHeaderMap);
		HttpEntity<?> entity = null;

		if (requestObj != null)
			entity = new HttpEntity<>(requestObj, headers);
		else
			entity = new HttpEntity<>(headers);

		try {
			// Send request with GET method, and Headers.
			ResponseEntity<?> response = restTemplateAadhaarVault.exchange(url, method, entity, classObj);
			resultObj = response.getBody();
		} catch (RestClientException ex) {
			String errorResponse = getErrorResponeMessage(ex);
			if(log.isDebugEnabled()) {
				log.debug("Response : {}", errorResponse);
			}
			if (!StringUtils.isEmpty(errorResponse)) {
				resultObj = convertResponseToType(classObj, errorResponse, headers);
			}


		}
		return resultObj;
	}

	private HttpHeaders getHttpHeaders(Map<String, String> httpHeaderMap) {
		HttpHeaders headers = new HttpHeaders();
		if (httpHeaderMap != null) {
			headers = new HttpHeaders();
			Set<String> headerKeySet = httpHeaderMap.keySet();
			for (String key : headerKeySet) {
				headers.add(key, httpHeaderMap.get(key));
			}

			if (httpHeaderMap.get("Content-Type") != null && !"".equals(httpHeaderMap.get("Content-Type").trim())) {
				MediaType mediaType = MediaType.valueOf(httpHeaderMap.get("Content-Type"));
				MediaType acceptType = (httpHeaderMap.get("Accept") != null && !"".equals(httpHeaderMap.get("Accept"))) ? MediaType.valueOf(httpHeaderMap.get("Accept")) : mediaType;
				headers.setContentType(mediaType);
				if (headers.getAccept() != null) {
					if (!headers.getAccept().contains(acceptType))
						headers.getAccept().add(acceptType);
				} else {
					headers.setAccept(new ArrayList<MediaType>());
					headers.getAccept().add(acceptType);
				}
			}
		}
		return headers;
	}

	public <T> Object processHttpRequest(String url, Object requestObj, Class<T> classObj, Map<String, String> httpHeaderMap, HttpMethod method) throws IOException {
		HttpHeaders headers = getHttpHeaders(httpHeaderMap);
		HttpEntity<?> entity = null;
		if (requestObj != null)
			entity = new HttpEntity<>(requestObj, headers);
		else
			entity = new HttpEntity<>(headers);
		return restTemplateAadhaarVault.exchange(url, method, entity, classObj).getBody();
	}

	public String postXmlRequest(String requestXml, String url) {
		RestTemplate restTemplateForXml = new RestTemplate();
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_XML);
		headers.set("Authorization", "Basic dWlkYWlCYW5rOlVpREBpQDMyMQ==");
		HttpEntity<String> entity = new HttpEntity<>(requestXml, headers);
		log.info("HTTP Request URL : {}", url);
		log.info("HTTP Request Header: {}", headers);
		CommonUtil.encryptAndPrint(Level.INFO, "HTTP Request Data", requestXml, publicKey);
		return restTemplateForXml.postForObject(url, entity, String.class);
	}


	public <T>  T convertResponseToType(Class<T> classObj, Object errorResponse, HttpHeaders httpHeaders) throws IOException {
		T resultObj = null;
		if( String.class.equals(classObj) || Number.class.equals(classObj) || Boolean.class.equals(classObj) ) {
			resultObj = (T)errorResponse;
		} else {
			if (MediaType.APPLICATION_JSON.equals(httpHeaders.getContentType())) {
				resultObj = objectMapper.readValue(String.valueOf(errorResponse), classObj);
			} else if (MediaType.APPLICATION_XML.equals(httpHeaders.getContentType())) {
				resultObj = CommonUtil.convertToObjectFromXMLInJackson(String.valueOf(errorResponse), classObj);
			}else {
				resultObj = (T)errorResponse;
			}
		}

		return resultObj;
	}


	private String getErrorResponeMessage(RestClientException ex) {
		String errorResponse = null;

		// For error codes of 4XX
		if (ex instanceof HttpClientErrorException  ) {
			HttpClientErrorException exception = (HttpClientErrorException) ex;
			errorResponse = exception.getResponseBodyAsString();

		// For error codes of 5XX
		} else if(ex instanceof HttpServerErrorException) {
			//Boolean isTimeout = ((HttpServerErrorException) ex).getStatusCode() == HttpStatus.GATEWAY_TIMEOUT
			HttpServerErrorException exception = (HttpServerErrorException) ex;
			errorResponse = exception.getResponseBodyAsString();

		// in other cases rethrow the exception
		} else {
			throw ex;
		}
		return errorResponse;
	}
}
