package com.airtelbank.validation.model;

import java.util.Date;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonRootName;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Setter
@Getter
@ToString(of= {"status","responseCode","responseTimeStamp"})
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_EMPTY)
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "getCustomerAadhaarOTPResponse")
@JsonRootName("getCustomerAadhaarOTPResponse")
@JsonIgnoreProperties(ignoreUnknown = true)
public class GenerateAadhaarOTPResponse {
    @XmlElement(name = "responseCode")
    @JsonProperty("responseCode")
    private String responseCode;
    @XmlElement(name = "status")
    @JsonProperty("status")
    private Status status;
    @XmlElement(name = "responseTimeStamp")
    @JsonProperty("responseTimeStamp")
    private Date responseTimeStamp;
    @XmlElement(name = "mobileNumber")
    @JsonProperty("mobileNumber")
    private String mobileNumber;
    @XmlElement(name = "email")
    @JsonProperty("email")
    private String email;
    @XmlElement(name = "userIdentifierType")
    @JsonProperty("userIdentifierType")
    private String userIdentifierType;
}
