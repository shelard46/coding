package com.airtelbank.validation.model.cbs;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.xml.bind.annotation.*;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@XmlRootElement(name = "input")
@XmlAccessorType(XmlAccessType.FIELD)
public class DedupeRequestForCBS {

    @XmlElement(name = "SessionContext")
    @JsonProperty("SessionContext")
    private SessionContext sessionContext;

    @XmlElement(name = "NationalIdentificationCode")
    @JsonProperty("NationalIdentificationCode")
    private String NationalIdentificationCode;

    @XmlElement(name = "AadharCardNo")
    @JsonProperty("AadharCardNo")
    private String AadharCardNo;

    @XmlElement(name = "PanNo")
    @JsonProperty("PanNo")
    private String PanNo;

    @XmlElement(name = "EmailId")
    @JsonProperty("EmailId")
    private String EmailId;

    @XmlElement(name = "CustomerType")
    @JsonProperty("CustomerType")
    private String CustomerType;
}
