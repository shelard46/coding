package com.airtelbank.validation.dao.aerospike.repository;

import org.springframework.data.aerospike.repository.AerospikeRepository;

import com.airtelbank.validation.dao.aerospike.model.Blackout;

public interface BlackoutRepository extends AerospikeRepository<Blackout, String>{

}
