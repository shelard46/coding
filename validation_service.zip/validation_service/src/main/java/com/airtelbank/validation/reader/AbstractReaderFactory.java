package com.airtelbank.validation.reader;

import com.airtelbank.validation.constants.Constants;

public class AbstractReaderFactory {
    public IReader getReader(String fileType)  {
        switch (fileType)   {
            case Constants.CSV:
            default:
                return new CsvReaderBlacklist();
        }
    }
}
