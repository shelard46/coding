package com.airtelbank.validation.service.impl.helper;

import java.io.IOException;

import javax.xml.bind.JAXBException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;

import com.airtelbank.validation.util.CommonUtil;
import com.airtelbank.validation.util.HttpUtil;
import com.airtelbank.validation.util.LogMasker;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class AbstractBaseServiceImplHelper {
	
	@Autowired private HttpUtil httpUtil;
	@Autowired private LogMasker logMasker;
	
	public <I, O> O fetchResponseForXML(I requestObject, String url,  Class<I> requestType , Class<O> responseType) throws JAXBException, IOException {
		log.info("Processing request for URL : {}", url);
		if (log.isDebugEnabled()) {
			log.debug("Request : {}", logMasker.patternReplace(CommonUtil.jsonObjectToString(requestObject)));
		}
		O response = null;
		if (requestObject != null) {
			String strRequestXML = CommonUtil.convertToXMLInJAXB(requestObject, requestType);
			String strResponseXML = httpUtil.sendRequest(url, strRequestXML, String.class, null, HttpMethod.POST,MediaType.APPLICATION_XML);
			response = CommonUtil.convertToObjectFromXMLInJackson(strResponseXML, responseType);
		}
		if (log.isDebugEnabled()) {
			log.debug("Reponse : {}", logMasker.patternReplace(CommonUtil.jsonObjectToString(response)));
		}
		log.info("Processing done for URL : {}", url);
		return response;
	}
	
	
}
