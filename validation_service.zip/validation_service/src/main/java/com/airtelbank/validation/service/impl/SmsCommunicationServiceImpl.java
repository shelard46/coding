package com.airtelbank.validation.service.impl;

import java.util.Date;
import java.util.List;

import org.apache.commons.lang3.exception.ExceptionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Service;

import com.airtelbank.validation.dao.jpa.model.DocumentAuditLog;
import com.airtelbank.validation.dao.jpa.model.DocumentAuditLog.TransactionStatus;
import com.airtelbank.validation.dao.jpa.respository.DocumentAuditRepository;
import com.airtelbank.validation.enums.CommunicationType;
import com.airtelbank.validation.model.communication.CommunicationTemplate;
import com.airtelbank.validation.model.communication.SMSResponse;
import com.airtelbank.validation.model.communication.SMSTemplate;
import com.airtelbank.validation.model.communication.SmsData;
import com.airtelbank.validation.service.CommunicationService;
import com.airtelbank.validation.util.CommonUtil;
import com.airtelbank.validation.util.HttpUtil;
import com.airtelbank.validation.util.RequestCreationUtil;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class SmsCommunicationServiceImpl implements CommunicationService {
	
	@Value("${config.sms.url}")
	private String smsUrl;
	
	@Value("${config.sms.success.code}")
	private String smsSuccessCode;
	
	@Autowired private HttpUtil httpUtil;
	@Autowired private RequestCreationUtil requestCreation;
	@Autowired private DocumentAuditRepository documentAuditRepository;

	@Override
	public boolean sendCommunication(CommunicationType communicationType, String recipient, List<? extends CommunicationTemplate> smsTemplates, String contentId, String channel) {
		if(null == recipient) {
			log.info("recipient is empty so not sending sms");
			return false;
		}
		boolean isSuccess = false;
		String refNo = CommonUtil.generateUniqueId();
		String resCode = null;
		String resMsg = null;
		try {
			SmsData smsData = requestCreation.createSmsRequest(recipient, communicationType, (List<SMSTemplate>) smsTemplates, refNo);
			SMSResponse smsResponse = (SMSResponse) httpUtil.handleRequest(smsUrl, smsData, SMSResponse.class, null, HttpMethod.POST);
			if (null == smsResponse || null == smsResponse.getResponseCode()) {
				log.info("sms response is null");
				return isSuccess;
			} 
			resCode = smsResponse.getResponseCode();
			resMsg = smsResponse.getMessage();
			if (smsResponse.getResponseCode().equalsIgnoreCase(smsSuccessCode)) {
				isSuccess = true;
				log.info("{} sms sent successfully to {}", communicationType, recipient);
			}
		} catch (Exception e) {
			log.error("Exception in sendSMS {}", ExceptionUtils.getStackTrace(e));
		} finally {
			auditReqRes(contentId, recipient, channel, communicationType, refNo, resCode, resMsg);
		}
		return isSuccess;
	}

	private void auditReqRes(String contentId, String recipient, String channel, CommunicationType communicationType, String refNo, String resCode, String resMsg) {
		try {
			DocumentAuditLog auditLog = DocumentAuditLog.builder()
					.transactionId(contentId)
					.action(communicationType.toString())
					.docType("SMS")
					.docNumber(recipient)
					.mobile(recipient)
					.channel(channel)
					.partnerTransactionId(refNo)
					.transactionStatus(TransactionStatus.valueOf(communicationType.toString()))
					.requestTimestamp(new Date())
					.statusCode(resCode)
					.statusMessage(resMsg)
					.build();
			documentAuditRepository.save(auditLog);
		} catch (Exception e) {
			log.error("exception in CommunicationServiceImpl|auditReqRes {}", ExceptionUtils.getStackTrace(e));
		}
	}

}
