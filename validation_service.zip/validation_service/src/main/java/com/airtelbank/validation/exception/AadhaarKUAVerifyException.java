package com.airtelbank.validation.exception;

import com.airtelbank.validation.model.Meta;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.*;

/**
 * @author Chetan Raj
 * @implNote
 * @since : 25/09/18
 */

@Setter
@Getter
@ToString
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class AadhaarKUAVerifyException extends RuntimeException {
    private String id;
    private Meta meta;

    public AadhaarKUAVerifyException(String id) {
        this.id = id;
    }

    public AadhaarKUAVerifyException(String message, String id) {
        super(message);
        this.id = id;
    }

    public AadhaarKUAVerifyException(String message, Throwable cause, String id) {
        super(message, cause);
        this.id = id;
    }

    public AadhaarKUAVerifyException(Throwable cause, String id) {
        super(cause);
        this.id = id;
    }

    public AadhaarKUAVerifyException(Meta meta) {
        this.meta = meta;
    }
}
