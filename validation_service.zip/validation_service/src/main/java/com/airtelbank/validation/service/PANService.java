package com.airtelbank.validation.service;

import org.springframework.stereotype.Service;

import com.airtelbank.validation.model.PANDetails;
import com.airtelbank.validation.model.PANRequest;

@Service
public interface PANService {
	public PANDetails getPanDetails(PANRequest panReq);
	
}
