package com.airtelbank.validation.model.pan;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import com.airtelbank.validation.model.DataArea;
import com.airtelbank.validation.model.EbmHeader;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonRootName;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Setter
@Getter
@ToString
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_EMPTY)
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "verifyCustomerPanDetailsResMsg")
@JsonRootName(value = "verifyCustomerPanDetailsResMsg")
@JsonIgnoreProperties(ignoreUnknown = true)
public class VerifyCustomerPanDetailsResponseMesssage {
	 @XmlElement(name = "ebmHeader")
	    @JsonProperty("ebmHeader")
	    private EbmHeader ebmHeader;
	    @XmlElement(name = "dataArea")
	    @JsonProperty("dataArea")
	    private DataArea dataArea;
}
