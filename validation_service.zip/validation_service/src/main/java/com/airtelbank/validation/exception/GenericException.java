package com.airtelbank.validation.exception;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.*;

@Setter
@Getter
@ToString
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class GenericException extends RuntimeException {
    private String id;

    public GenericException(String message, String id) {
        super(message);
        this.id = id;
    }

    public GenericException(String message, Throwable cause, String id) {
        super(message, cause);
        this.id = id;
    }

    public GenericException(Throwable cause, String id) {
        super(cause);
        this.id = id;
    }
}
