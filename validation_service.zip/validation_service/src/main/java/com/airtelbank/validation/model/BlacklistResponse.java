package com.airtelbank.validation.model;

import com.airtelbank.validation.model.blacklist.REResult;
import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class BlacklistResponse {

	private String customerId;
	private String requestId;
	private String customerMatchCount;
	private String rematchCount;
	private String statusFromPosidex;
	private int status;
	private String message;
	private String errorCode;
	private REResult customers;
}
