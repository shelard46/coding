package com.airtelbank.validation.util;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.StringWriter;
import java.io.Writer;
import java.nio.charset.StandardCharsets;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.KeySpec;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import java.util.Random;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;
import javax.crypto.spec.SecretKeySpec;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;
import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamReader;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.apache.log4j.Level;
import org.apache.log4j.MDC;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.MessageSource;
import org.springframework.core.env.Environment;

import com.airtelbank.validation.constants.Constants;
import com.airtelbank.validation.dao.aerospike.model.ErrorCodeMapper;
import com.airtelbank.validation.exception.VaultException;
import com.airtelbank.validation.model.AadhaarVaultRequest;
import com.airtelbank.validation.model.AadhaarVaultResponse;
import com.airtelbank.validation.model.Document;
import com.airtelbank.validation.model.LoggerModel.LoggerError;
import com.airtelbank.validation.model.Meta;
import com.airtelbank.validation.model.cbs.SessionContext;
import com.airtelbank.validation.model.cbs.TransactionStatus;
import com.airtelbank.validation.service.AadhaarService;
import com.airtelbank.validation.service.ErrorCodeMapperService;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonToken;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.deser.std.StdDeserializer;
import com.fasterxml.jackson.dataformat.xml.XmlMapper;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import freemarker.template.Configuration;
import freemarker.template.Template;
import freemarker.template.TemplateException;
import freemarker.template.TemplateExceptionHandler;
import freemarker.template.Version;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class CommonUtil {

	private CommonUtil() {
	}

	private static final Logger LOGGER = LoggerFactory.getLogger(CommonUtil.class);

	private static final DateFormat sdf = new SimpleDateFormat("DDDMMyyyyHHmmssSSS");
	private static final DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss");
	private static final DateTimeFormatter formatterDob = DateTimeFormatter.ofPattern("yyyy-MM-dd");
	private static final DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");
	private static final SimpleDateFormat sdfDob = new SimpleDateFormat("yyyy-MM-dd");
	private static final Pattern ampPattern = Pattern.compile("&.{0,6}|'");
	private static final Pattern ampReluctant = Pattern.compile("&(lt|gt|amp|quote|apos|#xd);");
	private static final byte[] salt = { (byte) 0xA8, (byte) 0x9B, (byte) 0xC8, (byte) 0x32, (byte) 0x56, (byte) 0x34,
			(byte) 0xE3, (byte) 0x03 };

	private static final String PKCS5_PADDING = "AES/ECB/PKCS5Padding";
	private static final String SHA1= "PBKDF2WithHmacSHA1";

	public static String escapeSpecialCharacterInTextNodeOfXML(String inputXml) {
		StringBuilder strInputXml = new StringBuilder(inputXml);
		processInputSpecialSymbole(strInputXml);
		return strInputXml.toString();
	}

	public static void processInputSpecialSymbole(StringBuilder inputXml) {
		Matcher matcher = ampPattern.matcher(inputXml.toString());
		int startIndex = 0;
		while (matcher.find()) {
			String group = matcher.group();
			if (!ampReluctant.matcher(group).find()) {
				int index = inputXml.indexOf(group, startIndex);
				inputXml.delete(index, index + group.length());
				group = group.replace("&", "&amp;").replace("'", "&apos;");
				inputXml.insert(index, group);
				startIndex = index + 1;
			}
		}
	}

	public static boolean isEmpty(String str) {
		return (Objects.isNull(str) || str.trim().isEmpty());
	}

	public static <T> String convertToXMLInJAXB(T obj, Class<T> classObj) throws JAXBException {
		JAXBContext context = JAXBContext.newInstance(classObj);
		Marshaller m = context.createMarshaller();

		m.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);

		StringWriter xmlString = new StringWriter();
		m.marshal(obj, xmlString);
		return xmlString.toString();
	}

	public static <T> T convertToObjectFromXMLInJAXB(String xmlString, Class<T> classObj)
			throws JAXBException, XMLStreamException {

		JAXBContext context = JAXBContext.newInstance(classObj);
		Unmarshaller unmarshaller = context.createUnmarshaller();
		XMLStreamReader reader = XMLInputFactory.newInstance()
				.createXMLStreamReader(new ByteArrayInputStream(xmlString.getBytes()));
		return unmarshaller.unmarshal(reader, classObj).getValue();
	}

	public static <T> T convertToObjectFromXMLInJackson(String xmlString, Class<T> classObj) throws IOException {
		XmlMapper xmlMapper = new XmlMapper();
		xmlString = escapeSpecialCharacterInTextNodeOfXML(xmlString);
		return xmlMapper.readValue(xmlString, classObj);
	}

	public static String getValueByDefault(String value, String defaultValue) {
		return StringUtils.isNotBlank(value) ? value : defaultValue;
	}

	public static LocalDateTime getDateTime(String dateValue) {
		if (dateValue == null || dateValue.isEmpty())
			return null;
		return LocalDateTime.parse(dateValue, formatter);
	}

	public static Date getDateTime(LocalDateTime dateValue) {
		if (dateValue == null)
			return null;
		Instant instant = dateValue.toInstant(ZoneOffset.UTC);
		return Date.from(instant);
	}

	public static LocalDate getLocalDateDob(String dateValue) {
		if (dateValue == null || dateValue.isEmpty())
			return null;
		return LocalDate.parse(dateValue, formatterDob);
	}

	public static LocalDate getDateDobAua(String dateValue) {
		if (dateValue == null || dateValue.isEmpty())
			return null;
		return LocalDate.parse(dateValue, DateTimeFormatter.ofPattern("dd-MM-yyyy"));
	}

	public static Date getDate(String dateValue) {
		if (StringUtils.isBlank(dateValue))
			return null;
		try {
			return dateFormat.parse(dateValue);
		} catch (ParseException e) {
			return new Date();
		}
	}

	public static String maskedMobileNumber(String lastFourDigitsOfMobileNumber) {
		return "******" + lastFourDigitsOfMobileNumber;
	}

	public static String formatTimestampPattern(Date date) {
		SimpleDateFormat sdf = new SimpleDateFormat(Constants.GENERATE_AADHAAR_OTP_REQUEST_DATETIME_PATTERN);
		return sdf.format(date);
	}

	public static String generateUniqueId() {
		return new StringBuffer().append(sdf.format(new Date(System.currentTimeMillis())))
				.append(new Random().nextInt(10)).toString();
	}

	public static Date getDateDOB(String dateValue) {
		if (StringUtils.isBlank(dateValue))
			return null;
		try {
			return sdfDob.parse(dateValue);
		} catch (ParseException e) {
			return new Date();
		}
	}

	public static String dateToString(Date date, String format) {
		SimpleDateFormat sdf = new SimpleDateFormat(format);
		return sdf.format(date);
	}

	public static Meta createMeta(String errorCode, String msg, int status) {
		Meta meta = new Meta();
		meta.setCode(errorCode);
		meta.setDescription(msg);
		meta.setStatus(status);
		return meta;
	}

	public static LoggerError setLoggerError(Meta meta) {
		LoggerError logError = new LoggerError();
		if (null != meta) {
			logError.setStatus(String.valueOf(meta.getStatus()));
			logError.setErrorCode(meta.getCode());
			logError.setErrorDescription(meta.getDescription());
		}
		return logError;
	}

	public static boolean isUpgradeWalletAction(String action) {
		boolean isUpgradeAction = false;
		if (!StringUtils.isEmpty(action) && Constants.UPGRADE_ACTION.equalsIgnoreCase(action)) {
			isUpgradeAction = true;
		}
		return isUpgradeAction;
	}

	public static String jsonObjectToString(Object jsonObject) {
		String jsonOutput = null;
		try {
			Gson gson = new GsonBuilder().setPrettyPrinting().create();
			jsonOutput = gson.toJson(jsonObject);
		} catch (Exception ex) {
			log.info("Exception while converting json object to string.");
		}
		return jsonOutput;
	}

	public static boolean setOtpRequestType(Document document) {
		boolean isAadhaarRequest = false;
		try {
			if (document.getDocNumber().length() == Constants.AADHAAR_SIZE) {
				document.setUserIdentifierType(Constants.AADHAAR_IDENTIFIER);
				isAadhaarRequest = true;
			} else if (document.getDocNumber().length() == Constants.VID_SIZE) {
				document.setUserIdentifierType(Constants.VID_IDENTIFIER);
				isAadhaarRequest = true;
			}
		} catch (Exception ex) {
			log.info("Exception while adding OtpRequestType param in request.");
			return false;
		}
		return isAadhaarRequest;
	}

	public static boolean isAadhaarRequest(Document document) {
		boolean isAadhaarRequest = false;
		try {
			if (document.getUserIdentifierType().equalsIgnoreCase(Constants.AADHAAR_IDENTIFIER)) {
				isAadhaarRequest = true;
			}
		} catch (Exception ex) {
			log.info("Exception while checking aadhaar request.");
		}
		return isAadhaarRequest;
	}

	public static boolean isVidRequest(Document document) {
		boolean isVidRequest = false;
		try {
			if (document.getUserIdentifierType().equalsIgnoreCase(Constants.VID_IDENTIFIER)) {
				isVidRequest = true;
			}
		} catch (Exception ex) {
			log.info("Exception while checking vid request.");
		}
		return isVidRequest;
	}

	public static boolean isAadhaarRequest(String userIdentifierType) {
		boolean isAadhaarRequest = false;
		try {
			if (userIdentifierType.equalsIgnoreCase(Constants.AADHAAR_IDENTIFIER)) {
				isAadhaarRequest = true;
			}
		} catch (Exception ex) {
			log.info("Exception while checking aadhaar request.");
		}
		return isAadhaarRequest;
	}

	public static boolean isVidRequest(String userIdentifierType) {
		boolean isVidRequest = false;
		try {
			if (userIdentifierType.equalsIgnoreCase(Constants.VID_IDENTIFIER)) {
				isVidRequest = true;
			}
		} catch (Exception ex) {
			log.info("Exception while checking vid request.");
		}
		return isVidRequest;
	}

	public static String decryptData(final String str, String passphrase) throws NoSuchAlgorithmException, InvalidKeySpecException, NoSuchPaddingException, InvalidKeyException, IOException, IllegalBlockSizeException, BadPaddingException {
		int iterationCount = 20;
		passphrase = hash(passphrase);
		KeySpec keySpec = new PBEKeySpec(passphrase.toCharArray(), salt, iterationCount, 128);
		SecretKeyFactory keyFactory = SecretKeyFactory.getInstance(SHA1);
		byte[] keyBytes = keyFactory.generateSecret(keySpec).getEncoded();
		SecretKey key = new SecretKeySpec(keyBytes, "AES");
		Cipher dcipher = Cipher.getInstance(PKCS5_PADDING);
		dcipher.init(Cipher.DECRYPT_MODE, key);
		byte[] dec = new sun.misc.BASE64Decoder().decodeBuffer(str);
		byte[] utf8 = dcipher.doFinal(dec);
		String data = new String(utf8, StandardCharsets.UTF_8);
		return generateDataAfterDecrypt(data);
	}

	public static String encryptData(final String str, String passphrase) throws NoSuchAlgorithmException, InvalidKeySpecException, NoSuchPaddingException, InvalidKeyException, IllegalBlockSizeException, BadPaddingException {
		int iterationCount = 20;
		String data = generateDataToEncrypt(str, passphrase);
		passphrase = hash(passphrase);
		KeySpec keySpec = new PBEKeySpec(passphrase.toCharArray(), salt, iterationCount, 128);
		SecretKeyFactory keyFactory = SecretKeyFactory.getInstance(SHA1);
		byte[] keyBytes = keyFactory.generateSecret(keySpec).getEncoded();
		SecretKey key = new SecretKeySpec(keyBytes, "AES");
		Cipher ecipher = Cipher.getInstance(PKCS5_PADDING);
		ecipher.init(Cipher.ENCRYPT_MODE, key);
		byte[] utf8 = data.getBytes(StandardCharsets.UTF_8);
		byte[] enc = ecipher.doFinal(utf8);
		return new sun.misc.BASE64Encoder().encode(enc);
	}

	public static String hash(String number) {
		long x = Long.parseLong(number);
		long y = (long) (x * Math.pow(7, 3)) + (long) (x * Math.pow(7, 2)) + (long) (x * Math.pow(7, 1))
				+ (long) (x * Math.pow(7, 0));
		return "" + y;
	}

	public static String generateDataToEncrypt(String vid, String mobile) {
		String data = null;
		StringBuilder stringBuilder = new StringBuilder();
		stringBuilder.append(vid.substring(0, 8));
		stringBuilder.append(mobile);
		stringBuilder.append(vid.substring(8, 16));
		data = stringBuilder.toString();
		return data;
	}

	public static String generateDataAfterDecrypt(String vid) {
		String data = null;
		StringBuilder stringBuilder = new StringBuilder();
		stringBuilder.append(vid.substring(0, 8));
		stringBuilder.append(vid.substring(18, 26));
		data = stringBuilder.toString();
		return data;
	}

	public static String getAadhaarNumberFromReferenceNumber(Document request, AadhaarService aadhaarService,
			Environment environment) {
		String aadhaarNumber = null;
		try {
			// generate aadhaar number
			AadhaarVaultRequest aadhaarVaultRequest = new AadhaarVaultRequest();
			aadhaarVaultRequest.setReferenceKey(request.getDocNumber());
			aadhaarVaultRequest.setApiKey(environment.getProperty("aadhaarVault.apikey"));
			String uniqueId = CommonUtil.generateUniqueId();
			aadhaarVaultRequest.setRequestId(uniqueId);
			AadhaarVaultResponse aadhaarVaultResponse = aadhaarService.getAadhaarNumber(aadhaarVaultRequest);
			if (aadhaarVaultResponse == null || aadhaarVaultResponse.getUid() == null) {
				throw new VaultException();
			}
			aadhaarNumber = aadhaarVaultResponse.getUid();
		} catch (Exception ex) {
			log.info("Exception while calling aadhaar vault service.");
			throw new VaultException();
		}
		return aadhaarNumber;
	}

	public static String getAadhaarReferenceNumberFromAadhaar(String aadhaarNumber, AadhaarService aadhaarService,
			Environment environment) {
		String aadhaarReferenceNumber = null;
		try {
			// generate aadhaar reference number
			AadhaarVaultRequest aadhaarVaultRequest = new AadhaarVaultRequest();
			aadhaarVaultRequest.setUid(aadhaarNumber);
			aadhaarVaultRequest.setApiKey(environment.getProperty("aadhaarVault.apikey"));
			String uniqueId = CommonUtil.generateUniqueId();
			aadhaarVaultRequest.setRequestId(uniqueId);
			AadhaarVaultResponse aadhaarVaultResponse = aadhaarService.getAadhaarReference(aadhaarVaultRequest);
			if (aadhaarVaultResponse == null || aadhaarVaultResponse.getReferenceKey() == null) {
				throw new VaultException();
			}
			aadhaarReferenceNumber = aadhaarVaultResponse.getReferenceKey();
		} catch (Exception ex) {
			log.info("Exception while calling aadhaar vault service.");
			throw new VaultException();
		}
		return aadhaarReferenceNumber;

	}

	public static String getFtlResponse(String fileName, Map<String, Object> mapObj)
			throws TemplateException, IOException {
		Configuration cfg = new Configuration();
		cfg.setClassForTemplateLoading(CommonUtil.class, "\\templates");
		cfg.setIncompatibleImprovements(new Version(2, 3, 20));
		cfg.setDefaultEncoding("UTF-8");
		cfg.setLocale(Locale.US);
		cfg.setTemplateExceptionHandler(TemplateExceptionHandler.RETHROW_HANDLER);
		Template template = cfg.getTemplate(fileName);
		Writer out = new StringWriter();
		template.process(mapObj, out);
		String transformedTemplate = out.toString();
		out.flush();
		return transformedTemplate;
	}

	public static SessionContext createSessionContext(String bankCode, String serviceCode, String transactionBranch,
			String channel) {
		return new SessionContext(serviceCode, bankCode, transactionBranch, channel, channel, getCBSReference());
	}

	public static String getCBSReference() {
		return new StringBuffer().append(sdf.format(new Date(System.currentTimeMillis())))
				.append(new Random().nextInt(10)).toString();
	}

	public static Meta retrieveCBSErrorDetails(TransactionStatus txnStatus) {
		Meta meta = new Meta();
		// Error code handling
		if (txnStatus.getValidationErrorsList() != null && !txnStatus.getValidationErrorsList().isEmpty()) {
			meta.setDescription(txnStatus.getValidationErrorsList().get(0).getErrorMessage());
			meta.setCode(txnStatus.getValidationErrorsList().get(0).getErrorCode());
		} else if (txnStatus.getExtendedReply() != null && txnStatus.getExtendedReply().getMessagesArray() != null
				&& txnStatus.getExtendedReply().getMessagesArray().getMessagesList() != null
				&& !txnStatus.getExtendedReply().getMessagesArray().getMessagesList().isEmpty()) {
			meta.setDescription(txnStatus.getExtendedReply().getMessagesArray().getMessagesList().get(0).getMessage());
			meta.setCode(txnStatus.getExtendedReply().getMessagesArray().getMessagesList().get(0).getCode());
		} else {
			meta.setDescription(txnStatus.getReplyText());
			meta.setCode(txnStatus.getErrorCode());
		}

		return meta;
	}

	public static Meta setErrorCode(Meta meta, String apiName, ErrorCodeMapperService errorCodeMapperService,
			MessageSource messageSource) {
		Meta errorCodeMeta = null;
		if (meta != null) {

			// to reduce further null pointer exception
			errorCodeMeta = new Meta();
			ErrorCodeMapper errorCodeMapper = errorCodeMapperService
					.getErrorCodeByApiNameAndOrgErrorCode(meta.getCode(), apiName);
			if (errorCodeMapper != null) {
				errorCodeMeta.setCode(errorCodeMapper.getErrorCode());
				errorCodeMeta.setDescription(messageSource.getMessage(errorCodeMapper.getErrorCode(), null, Locale.ENGLISH));
				errorCodeMeta.setStatus(Constants.FAILURE_STATUS);
			} else {
				// Changes for handling cases where codes are not defined in aero spike
				log.info("error code {} is not defined in aerospike, setting default error code.", meta.getCode());
				errorCodeMeta.setCode(messageSource.getMessage("config.generic.errorCode", null, Locale.ENGLISH));
				errorCodeMeta.setDescription(messageSource.getMessage("config.generic.errorMessage", null, Locale.ENGLISH));
				errorCodeMeta.setStatus(Constants.FAILURE_STATUS);

			}
		}
		return errorCodeMeta;
	}

	public static String getChannel(String userAgent) {
		try {
			if (StringUtils.isNotBlank(userAgent)) {
				String channel = userAgent.split("\\,")[1].split("\\/")[0];
				return channel;
			} else {
				log.info("user agent header is incorrect");
				return "WEB";
			}
		} catch (Exception e) {
			log.info("user agent header is incorrect");
			return "WEB";
		}
	}

	public static String infoPrefixSuffix(String message) {
		String finalMessage = null;
		if (message != null) {
			finalMessage = Constants.INFO_MSG_PREFIX + message + Constants.INFO_MSG_SUFFIX;
		}
		return finalMessage;
	}

	public static void setMDCMap(String contentId, String channel, String customerId, String apiId) {
		MDC.put(Constants.CONTENT_ID, contentId != null ? contentId : "");
		MDC.put(Constants.CHANNEL, channel != null ? channel : "");
		MDC.put(Constants.CUSTOMER_ID, customerId != null ? customerId : "");
		MDC.put(Constants.API_ID, apiId != null ? apiId : "");
	}

	public static String trimCustomerId(String customerId) {
		if (customerId.contains("DL")) {
			return customerId;
		}
		String trimmedCustomerId = null;
		if (customerId.length() == 12) {
			trimmedCustomerId = customerId.substring(2, customerId.length());
			return trimmedCustomerId;
		} else if (customerId.length() == 11) {
			trimmedCustomerId = customerId.substring(1, customerId.length());
			return trimmedCustomerId;
		}
		return customerId;
	}

	public static void encryptAndPrint(Level level, String prefix, String message, String key) {
		if (StringUtils.isNotEmpty(message)) {
			try {
				String printString = Constants.EMPTY_BRACKET;
				String encMessage = encryptLogs(message, key);
				if (level.equals(Level.INFO))
					LOGGER.info(printString, prefix, encMessage);
				if (level.equals(Level.DEBUG))
					LOGGER.debug(printString, prefix, encMessage);
				if (level.equals(Level.WARN))
					LOGGER.warn(printString, prefix, encMessage);
			} catch (Exception ex) {
				LOGGER.info(CommonUtil.infoPrefixSuffix("Exception while encrypting String"));
				ExceptionUtils.printRootCauseStackTrace(ex);
			}
		}
	}

	public static void encryptAndPrint(Level level, String prefix, Object message, String key) {
		if (null != message) {
			try {
				String printString = Constants.EMPTY_BRACKET;
				String encMessage = encryptLogs(jsonObjectToString(message), key);
				if (level.equals(Level.INFO))
					LOGGER.info(printString, prefix, encMessage);
				if (level.equals(Level.DEBUG))
					LOGGER.debug(printString, prefix, encMessage);
				if (level.equals(Level.WARN))
					LOGGER.warn(printString, prefix, encMessage);
			} catch (Exception ex) {
				LOGGER.info(CommonUtil.infoPrefixSuffix("Exception in encryptAndPrint"));
				ExceptionUtils.printRootCauseStackTrace(ex);
			}
		}
	}

	public static void decryptAndPrint(Level level, String prefix, Object message, String key) {
		if (null != message) {
			try {
				String printString = Constants.EMPTY_BRACKET;
				String encMessage = decryptLogs(jsonObjectToString(message), key);
				if (level.equals(Level.INFO))
					LOGGER.info(printString, prefix, encMessage);
				if (level.equals(Level.DEBUG))
					LOGGER.debug(printString,prefix, encMessage);
				if (level.equals(Level.WARN))
					LOGGER.warn(printString, prefix, encMessage);
			} catch (Exception ex) {
				LOGGER.info(CommonUtil.infoPrefixSuffix("Exception in decryptAndPrint"));
				ExceptionUtils.printRootCauseStackTrace(ex);
			}
		}
	}

	public static String encryptLogs(final String data, String passphrase) {
		try {
			int iterationCount = 20;
			KeySpec keySpec = new PBEKeySpec(passphrase.toCharArray(), salt, iterationCount, 128);
			SecretKeyFactory keyFactory = SecretKeyFactory.getInstance(SHA1);
			byte[] keyBytes = keyFactory.generateSecret(keySpec).getEncoded();
			SecretKey key = new SecretKeySpec(keyBytes, "AES");
			Cipher ecipher = Cipher.getInstance(PKCS5_PADDING);
			ecipher.init(Cipher.ENCRYPT_MODE, key);
			byte[] utf8 = data.getBytes(StandardCharsets.UTF_8);
			byte[] enc = ecipher.doFinal(utf8);
			return new sun.misc.BASE64Encoder().encode(enc);
		} catch (Exception ex) {
			LOGGER.info(CommonUtil.infoPrefixSuffix("Exception in encryptLogs"));
			ExceptionUtils.printRootCauseStackTrace(ex);
			return null;
		}
	}

	public static String decryptLogs(final String str, String passphrase) {
		try {
			int iterationCount = 20;
			KeySpec keySpec = new PBEKeySpec(passphrase.toCharArray(), salt, iterationCount, 128);
			SecretKeyFactory keyFactory = SecretKeyFactory.getInstance(SHA1);
			byte[] keyBytes = keyFactory.generateSecret(keySpec).getEncoded();
			SecretKey key = new SecretKeySpec(keyBytes, "AES");
			Cipher dcipher = Cipher.getInstance(PKCS5_PADDING);
			dcipher.init(Cipher.DECRYPT_MODE, key);
			byte[] dec = new sun.misc.BASE64Decoder().decodeBuffer(str);
			byte[] utf8 = dcipher.doFinal(dec);
			return new String(utf8, StandardCharsets.UTF_8);
		} catch (Exception ex) {
			LOGGER.info(CommonUtil.infoPrefixSuffix("Exception in decryptLogs"));
			ExceptionUtils.printRootCauseStackTrace(ex);
			return null;
		}
	}
	
	public static String maskedAadhaarNumber(String aadhaarNumber) {
		String maskedAadhaar = "";
		int userIdLen = aadhaarNumber.length();
		for (int i = 0; i < aadhaarNumber.length() - 4; i++) {
			char a = aadhaarNumber.charAt(i);
			if (Character.isDigit(a)) {
				maskedAadhaar = maskedAadhaar + "X";
			}
		}
		for (int i = aadhaarNumber.length() - 4; i < aadhaarNumber.length(); i++) {
			maskedAadhaar = maskedAadhaar + aadhaarNumber.charAt(i);
		}
		if (userIdLen == 12) {
			maskedAadhaar = "aadhaar " + maskedAadhaar;
		} else if (userIdLen == 16){
			maskedAadhaar = "vid " + maskedAadhaar;
		} else {
			maskedAadhaar = "aadhaar ";
		}
		return maskedAadhaar;
	}
}


class StringDeserializer extends StdDeserializer<String> {
	protected StringDeserializer(Class<String> vc) {
		super(vc);
	}

	static final String VALID_ESCAPE_CODE = "&#60|&#62|&lt;|&gt;|&amp;|&#38|&#34|&#39";
	static final String INVALID_ESCAPE_CODE = "(&(.+ && !(amp;|gt;|&lt;)))|<|>|'";

	@Override
	public String deserialize(JsonParser jp, DeserializationContext arg1) throws IOException {
		if (jp.currentToken() == JsonToken.VALUE_STRING) {
			String value = jp.getText();
			if (value != null) {
				if (!value.matches(VALID_ESCAPE_CODE) && value.matches(INVALID_ESCAPE_CODE)) {
					value = value.replaceAll("&", "&#38").replaceAll("<", "&#60").replaceAll(">", "&#62")
							.replaceAll("'", "&#39");
					return value;
				}
				return value;
			}

		}
		return null;
	}

}

