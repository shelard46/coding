package com.airtelbank.validation.model;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonRootName;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_EMPTY)
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "verifyCustomerPanDetailsResMsg")
@JsonRootName(value = "verifyCustomerPanDetailsResMsg")
@JsonIgnoreProperties(ignoreUnknown = true)
public class PanEsbResponse {
	@XmlElement(name = "ebmHeader")
	@JsonProperty("ebmHeader")
	private EbmHeader panHeader;
	
	@XmlElement(name = "dataArea")
	@JsonProperty("dataArea")
	private DataArea panData;
}
