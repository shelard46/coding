package com.airtelbank.validation.dao.aerospike;

import java.util.List;

import com.airtelbank.validation.dao.aerospike.model.PosidexRules;

public interface PosidexRulesDao {
	public List<PosidexRules> getAllRules();
	public List<PosidexRules> getRulesByAccountTypes(String accountType);
}
