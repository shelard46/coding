package com.airtelbank.validation.exception;

public class JsonCustomParsingException extends Exception {

	public JsonCustomParsingException() {
		super();
	}

	public JsonCustomParsingException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		
	}

	public JsonCustomParsingException(String message, Throwable cause) {
		super(message, cause);
		
	}

	public JsonCustomParsingException(String message) {
		super(message);
		
	}

	public JsonCustomParsingException(Throwable cause) {
		super(cause);
	}

}
