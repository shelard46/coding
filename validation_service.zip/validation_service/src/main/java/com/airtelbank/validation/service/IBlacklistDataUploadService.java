package com.airtelbank.validation.service;

public interface IBlacklistDataUploadService {
    public void upload(String filePath) throws Exception;
}
