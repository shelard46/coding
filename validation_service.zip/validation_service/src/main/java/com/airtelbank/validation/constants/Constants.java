package com.airtelbank.validation.constants;

public final class Constants {

	public static final String AEROSPIKE_KEY_JOINER = "~";
	public static final String SUCCESS = "Success";
	public static final String UTF8 = "UTF-8";
	public static final String NPCI_DATE_FORMAT = "yyyy-MM-dd'T'HH:mm:ssXXX";
	public static final String LOCAL_ADDRESS = "localAddress";
	public static final String PERMANENT_ADDRESS = "permanentAddress";
	public static final String PRIMARY_COMMUNICATION = "primaryCommunication";
	public static final String CORRESPONDENCE_COMMUNICATION = "correspondenceCommunication";
	public static final String ALTERNATE_COMMUNICATION = "alternateCommunication";
	public static final String YES = "YES";
	public static final String NO = "NO";
	public static final String Y = "Y";
	public static final String N = "N";
	public static final String DEFAULT_COUNTRY = "IN";
	public static final String DEFAULT_NATIONALITY = "IN";
	public static final String DEFAULT_ICTYPE = "I";
	public static final String DEFAULT_CLASSIFICATION = "I";
	public static final String DEFAULT_EDUCATIONLEVEL = "0";
	public static final String NA = "NA";
	public static final String DEFAULT_PREFIX = "CDR";
	public static final String DEFAULT_LANG = "ENG";
	public static final String DEFAULT_CIFTYPE = "C";
	public static final String DEFAULT_CUST_CATEGORY = "90015";
	public static final String DEFAULT_CHANNEL = "IOS";
	public static final String DEFAULT_GENERATE_OTP_REQUEST_TYPE = "A";
	public static final String DEFAULT_STATUS_CODE_SPLITTER = "-";
	public static final String AADHAAR_VERIFY_SUCCESS_STATUS_CODE = "0001";
	public static final String AADHAAR_VERIFY_KUA_SUCCESS_STATUS_CODE = "0001";
	public static final String PAN = "PAN";
	public static final String AADHAAR = "AADHAAR";
	public static final String GENERATE_AADHAAR_OTP_ACTION = "GENERATE_AADHAAR_OTP";
	public static final String VERIFY_AADHAAR_OTP_ACTION = "VERIFY_AADHAAR_OTP";
	public static final int AADHAAR_VERIFY_SUCCESS_TXN_CODE = 0;
	public static final int AADHAAR_VERIFY_FAILURE_TXN_CODE = 1;
	public static final boolean SUCCESS_RESPONSE = true;
	public static final boolean FAILED_RESPONSE = false;
	public static final String AADHAAR_VERIFY_SUCCESS_CODE = "GetUserAadhaarProfile-0001-S";
	public static final String AADHAAR_VERIFY_INVALID_CODE = "GetUserAadhaarProfile-0002-S";
	public static final String AUA_SUCCESS_CODE = "VerifyCustomerAadhaarDetails-0001-S";

	// PAN codes
	public static final String PAN_ESB_SUCCESS_CODE = "VerifyCustomerPanDetails-0001-S";
	public static final String PAN_ESB_INVALID_CODE = "VerifyCustomerPanDetails-0002-S";
	public static final String PAN_ESB_INVALID_REQ_CODE = "VerifyCustomerPanDetails-4501-V";
	public static final String PAN_ESB_SERVICE_UNAVAILABLE_CODE = "VerifyCustomerPanDetails-2501-F";
	public static final String PAN_ESB_SYSTEM_ERROR_CODE = "VerifyCustomerPanDetails-3501-E";
	public static final String PAN_ESB_NOT_ENOUGH_BALANCE_CODE = "VerifyCustomerPanDetails-3507-E";

	public static final String PAN_INVALID_DETAILS_MESSAGE = "Invalid PAN Details.";
	public static final String PAN_INVALID_MESSAGE = "Customer Pan Details are invalid";
	public static final String PAN_INVALID_DETAILS_CODE = "101";

	public static final String PAN_GENERIC_FAILURE_MESSAGE = "Request cannot be completed at this point of time. Please try after sometime.";
	public static final String PAN_GENERIC_FAILURE_CODE = "102";

	public static final String TIMEOUT_MESSAGE = "Request timeout.";
	public static final String TIMEOUT_ERROR_CODE = "124";

	// Generate Aadhaar OTP constants
	public static final String GENERATE_AADHAAR_OTP_SUCCESS_STATUS_CODE = "GetCustomerAadhaarOTP-0001-S";
	public static final String GENERATE_AADHAAR_OTP_FAILURE_STATUS_CODE = "GetCustomerAadhaarOTP-4501-V";
	public static final String GENERATE_AADHAAR_OTP_FAILURE_SERVICE_DOWN_STATUS_CODE = "GetCustomerAadhaarOTP-2501-F";

	public static final int GENERATE_AADHAAR_OTP_SUCCESS = 0;
	public static final int GENERATE_AADHAAR_OTP_FAILED = 1;
	public static final int GENERATE_AADHAAR_OTP_TIMEOUT = 2;

	public static final String GENERATE_AADHAAR_OTP_REQUEST_DATETIME_PATTERN = "dd-MM-yyyy HH:mm:ss";
	public static final String GENERATE_AADHAAR_OTP_REQUEST_TIME_PATTERN = "HH:mm:ss";

	public static final String AADHAAR_CASE = "AADHAAR";

	public static final String AEROSPIKE_EXCEPTION = "Aerospike exception";

	public static final String NAME = "name";
	public static final String FIRST_NAME = "firstName";
	public static final String LAST_NAME = "lastName";
	public static final String MIDDLE_NAME = "middleName";

	public static final String WALLET_LKY = "LKY";
	public static final String WALLET_FKY = "FKY";
	public static final String WALLET_MKYA = "MKYA";

	public static final String RULE_NAME = "ruleName";

	public static final String MESSAGE = "message";

	public static final String ERROR_CODE = "errorCode";

	public static final String ACTION = "action";

	public static final String UPGRADE_ACTION = "UPGRADE";

	public static final String CUSTOMER = "customer";

	public static final String SOURCE_TYPE = "sourceType";

	public static final String CUSTOMER_ID = "customerId";

	public static final String WALLET_TYPE = "walletType";

	public static final String POI_NUMBER_POI_TYPE = "POI_NUMBER_POI_TYPE";

	public static final String NAME_DOB_PINCODE = "NAME_DOB_PINCODE";
	public static final String PHONEorMOBILE = "PHONEorMOBILE";

	public static final int SUCCESS_STATUS = 0;
	public static final int FAILURE_STATUS = 1;
	public static final String CONTENT_ID = "contentId";
	public static final String REQUEST_ID = "requestId";
	public static final String TRANSACTION_ID = "transactionId";
	public static final String CHANNEL = "channel";
	public static final String JSON = "json";
	public static final String XML = "xml";
	public static final String TEXT = "text";

	public static final String VID_IDENTIFIER = "V";
	public static final String AADHAAR_IDENTIFIER = "A";
	public static final String UID_IDENTIFIER = "T";

	public static final int VID_SIZE = 16;
	public static final int AADHAAR_SIZE = 12;

	public static final String DOT_SEPARATOR = "\\.";
	public static final String SPACE_SEPARATOR = " ";
	public static final String ONLY_APLHANUMERIC = "[ ](?=[ ])|[^A-Za-z0-9 ]+";

	public static final String CHANGE = "chg";
	public static final String DELETE = "del";
	public static final String CSV = "csv";
	public static final String HTTP = "http";
	public static final String COUNTRY = "country";
	public static final String ID = "id";
	public static final String BLACKLISTED = "blacklisted";
	public static final String CHARGE = "charge";
	public static final String ADDRESS = "address";

	public static final String AUA_API_NAME = "AUA";
	public static final String KUA_API_NAME = "KUA";
	public static final String CBS_DEDUPE_API_NAME = "CBS_DEDUPE";
	public static final String KUA = "KUA";
	public static final int AADHAAR_KUA_SUCCESS_TXN_CODE = 0;
	public static final int AADHAAR_KUA_FAILURE_TXN_CODE = 1;

	public static final String KIBANA_ARGUMENT_SEPARATOR = "~#~";

	public static final String INFO_MSG_PREFIX = "<=== ";
	public static final String INFO_MSG_SUFFIX = " ===>";

	public static final String API_ID = "apiId";
	public static final String ERRORS = "errors";

	public static final String VALIDATE_DOCUMENT = "VALIDATE_DOCUMENT";
	public static final String GET_AADHAAR_REFERENCE = "GET_AADHAAR_REFERENCE";
	public static final String DELETE_AADHAAR_REFERENCE = "DELETE_AADHAAR_BY_REFERENCE";
	public static final String GET_AADHAAR_NUMBER = "GET_AADHAAR_NUMBER";
	public static final String VALIDATE_AUA = "VALIDATE_AUA";
	public static final String GET_AADHAAR_DETAILS_KUA = "GET_AADHAAR_DETAILS_KUA";
	public static final String VALIDATE_PAN_DETAILS = "VALIDATE_PAN_DETAILS";
	public static final String VALIDATE_NAME_MATCH_DETAILS = "VALIDATE_NAME_MATCH_DETAILS";
	public static final String CHECK_BLACKLIST = "CHECK_BLACKLIST";
	public static final String POSIDEX_DEDUPE = "POSIDEX_DEDUPE";
	public static final String POSIDEX_DEDUPE_POI = "POSIDEX_DEDUPE_POI";
	public static final String CBS_DEDUPE = "CBS_DEDUPE";
	public static final String VALIDATE_PIN_CODE = "VALIDATE_PIN_CODE";
	public static final String LOAD_PIN_CODE = "LOAD_PIN_CODE";
	public static final String GET_BLACKOUT = "GET_BLACKOUT";
	public static final String ADD_BLACKOUT = "ADD_BLACKOUT";
	public static final String BLACKLIST_DATA_UPLOAD = "BLACKLIST_DATA_UPLOAD";
	public static final String ENTITY_BLACKLIST = "ENTITY_BLACKLIST";
	public static final String GET_ERROR_CODE_MAPPING = "GET_ERROR_CODE_MAPPING";
	public static final String CREATE_ERROR_CODE_MAPPING = "CREATE_ERROR_CODE_MAPPING";
	public static final String UIDAI_GENERATE_AADHAR_OTP = "UIDAI_GENERATE_AADHAR_OTP";
	public static final String UIDAI_VERIFY_AADHAR_OTP = "UIDAI_VERIFY_AADHAR_OTP";
	
	public static final String CONTENT_TYPE = "Content-Type";
	public static final String ACCEPT = "Accept";
	public static final String ORG_ERROR_CODE = "orgErrorCode";
	public static final String MESSAGE_SIGNATURE = "Message_Signature";

	public static final String DOC_NUBMER = "document.docNumber";
	public static final String DEDUPE_CREATE_MSG = "config.dedupe.create.msg";
	public static final String DEDUPE_REJECT_MSG = "config.dedupe.reject.msg";
	public static final String GENERIC_ERROR_MSG = "config.generic.errorCode";
	public static final String AADHAR_OTP_ERROR_MSG = "generate.aadhaar.otp.validation.error.msg";
	public static final String DEDUPE_FAILURE_MSG = "config.dedupe.aerospike.failure.msg";
	public static final String AADHAR_OTP_ERROR_CODE = "generate.aadhaar.otp.validation.error.code";
	public static final String CONFIG_GENERIC_ERROR_MSG = "config.generic.errorMessage";
	public static final String EXCEPTION_RESPONSE_DTO = "Exception Response DTO : {}";
	public static final String SERVICE_POSIDEX = "http://service.ws.posidex.com/";
	public static final String APPLICATION_JSON = "application/json";
	public static final String MASKED_AADHAAR = "maskedAadhaar";
	public static final String TIMESTAMP = "timestamp";
	public static final String RESPONSE_CODE = "responseCode";
	public static final String RESPONSE_MSG = "responseMsg";
	public static final String ERROR = "Error : {}";
	public static final String AUA_ERROR_RESPONSE = "AUA error response : {}";
	public static final String KUA_ERROR = "KUA Error : {}";
	public static final String ROOT_CAUSE = "\n Root cause: ";
	public static final String ERROR_MESSAGE = "\n Error message: ";
	public static final String STACK_TRACE = "\n Stack Trace: ";
	public static final String EXCEPTION = "\n Exception: ";
	public static final String EMPTY_BRACKET = "{} : {}";
	public static final String CONFIG_DEDUPE_CREATE_MSG = "config.dedupe.create.msg";

	public static final String FAILED = "FAILED";

	public static final String TECHNICAL_ISSUE_MSG = "Technical Issue";
	public static final String TECHNICAL_ISSUE_CODE = "1791";
	public static final String HMAC256ALGORITHM = "HmacSHA256";
	public static final String AUTH_HEADER_PARAMETER_AUTHERIZATION = "authorization";
	public static final String BASIC = "basic";
	public static final String COLON = ":";
	public static final String BIOMETRIC_TYPE="biometricType";

	public interface Sms {
		String TYPE = "SMS";
		String MODE = "I";
		String LANGUAGE_ID = "001";
		String UCID = "VALIDATION";
		String SUBJECT = "SMS";
		int INDEX = 1;
		String CATEGORY = "transaction";
		String PRIORITY = "p1";
	}
	
	/* Kibana Error Logger Constants */
	public static final String GENERATE_OTP_RESPONSE_NULL = "GENERATE_OTP_RESPONSE_NULL";
	public static final String UIDAI_STATUS_CODE = "UIDAI_STATUS_CODE";
	public static final String UIDAI_STATUS_DESCRIPTION = "UIDAI_STATUS_DESCRIPTION";
	public static final String CONSUMER_TRANSACTION_ID = "CONSUMER_TRANSACTION_ID";

}
