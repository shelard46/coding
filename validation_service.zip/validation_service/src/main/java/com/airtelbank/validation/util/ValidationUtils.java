package com.airtelbank.validation.util;

import java.util.HashSet;
import java.util.Set;

import javax.validation.ConstraintViolation;
import javax.validation.ConstraintViolationException;
import javax.validation.Validation;
import javax.validation.Validator;
import javax.validation.ValidatorFactory;

import org.springframework.stereotype.Component;

import com.airtelbank.validation.constants.Constants;
import com.airtelbank.validation.constants.DocType;
import com.airtelbank.validation.validator.AadhaarOtpGroup;
import com.airtelbank.validation.validator.AadhaarVerifyGroup;
import com.airtelbank.validation.validator.PanGroup;

@Component
public class ValidationUtils<T> {

	public  void validate(T data, String type, String action) {
		ValidatorFactory vf = null;
		Set<ConstraintViolation<T>> violations = new HashSet<>();
		try {
			vf = Validation.buildDefaultValidatorFactory();
			Validator validator = vf.getValidator();
			if(type == null) {
				violations = validator.validate(data);
			} else {
				switch(type) {
					case DocType.AADHAAR:
						if(action.equalsIgnoreCase(Constants.GENERATE_AADHAAR_OTP_ACTION))
							violations = validator.validate(data,AadhaarOtpGroup.class);
						else if(action.equalsIgnoreCase(Constants.VERIFY_AADHAAR_OTP_ACTION))
							violations = validator.validate(data,AadhaarVerifyGroup.class);
						else
							violations = validator.validate(data);
						break;
					case DocType.PAN:
						violations = validator.validate(data,PanGroup.class);
						break;
					default:
						violations = validator.validate(data);
				}
			}
			if(!violations.isEmpty())
				throw new ConstraintViolationException(violations);
		} finally {
			if (null != vf)
				vf.close();
		}
	}
	
	public  void validate(T data) {
		ValidatorFactory vf = null;
		Set<ConstraintViolation<T>> violations = new HashSet<>();
		try {
			vf = Validation.buildDefaultValidatorFactory();
			Validator validator = vf.getValidator();
			violations = validator.validate(data);
			if(!violations.isEmpty())
				throw new ConstraintViolationException(violations);
		} finally {
			if (null != vf)
				vf.close();
		}
	}
}
