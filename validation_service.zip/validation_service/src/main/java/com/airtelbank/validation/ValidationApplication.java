package com.airtelbank.validation;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.actuate.autoconfigure.metrics.MeterRegistryCustomizer;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.PropertySource;
import org.springframework.web.WebApplicationInitializer;

import io.micrometer.core.instrument.MeterRegistry;
import lombok.extern.slf4j.Slf4j;

@SpringBootApplication
@Slf4j
//@PropertySource({"file:${spring.config.location}/validation_application.properties", "file:${spring.config.location}/validation_masking.properties"})
@ComponentScan("com.airtelbank")
public class ValidationApplication extends SpringBootServletInitializer implements WebApplicationInitializer {

    public static void main(String[] args) {
        log.info("Going to start application");
        SpringApplication.run(ValidationApplication.class, args);
        log.info("application started");
    }

    @Override
    protected SpringApplicationBuilder configure(SpringApplicationBuilder builder) {
        return builder.sources(ValidationApplication.class);
    }

    @Bean
    MeterRegistryCustomizer<MeterRegistry> metricsCommonTags() {
        return registry -> registry.config().commonTags("application", "Validation-microservice", "vertical", "BOP");
    }
}