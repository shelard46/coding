package com.airtelbank.validation.model;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.stereotype.Component;
import org.springframework.web.context.WebApplicationContext;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

/*
The scope prototype would ensure that, there is a new object of LoggerModel being created
every time, the new request/response comes-in.
 */

@Getter
@Setter
@ToString
@NoArgsConstructor
@AllArgsConstructor
@Component
@Scope(proxyMode = ScopedProxyMode.TARGET_CLASS, value = WebApplicationContext.SCOPE_REQUEST, scopeName = WebApplicationContext.SCOPE_REQUEST)
public class LoggerModel {
	private String serviceId;
	private String contentId;
	private List<String> ids = new ArrayList<>();
	private List<BigDecimal> numbers = new ArrayList<>();
	private List<Date> dates = new ArrayList<>();
	private List<LoggerError> errors;
	private List<MethodStats> methods;

	@Getter
	@Setter
	@ToString
	@NoArgsConstructor
	@AllArgsConstructor
	public static class LoggerError {
		private String errorCode;
		private String errorDescription;
		private String status;
	}

	@Getter
	@Setter
	@ToString
	@NoArgsConstructor
	@AllArgsConstructor
	public static class MethodStats {
		private String methodName;
		private long methodTime;
	}
}
