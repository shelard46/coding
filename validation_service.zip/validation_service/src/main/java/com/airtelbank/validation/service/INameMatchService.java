package com.airtelbank.validation.service;

import org.springframework.stereotype.Service;

import com.airtelbank.validation.model.NameMatchRequest;
import com.airtelbank.validation.model.NameMatchResponse;

@Service
public interface INameMatchService {
	public NameMatchResponse checkNames(NameMatchRequest nameMatchRequest);
}
