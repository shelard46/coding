package com.airtelbank.validation.service;

import com.airtelbank.validation.dao.aerospike.model.ErrorCodeMapper;

public interface ErrorCodeMapperService {
    public boolean addNewErrorCode(ErrorCodeMapper errorCodeMapper);

    public ErrorCodeMapper getErrorCodeByApiNameAndOrgErrorCode(String orgErrorCode, String apiName);
}