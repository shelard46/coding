package com.airtelbank.validation.controller;

import java.util.Locale;

import javax.validation.Valid;

import org.apache.log4j.Level;
import org.apache.log4j.MDC;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.MessageSource;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.airtelbank.validation.constants.Constants;
import com.airtelbank.validation.dao.aerospike.model.AadhaarVerify;
import com.airtelbank.validation.dao.aerospike.model.ErrorCodeMapper;
import com.airtelbank.validation.exception.ClientSideException;
import com.airtelbank.validation.exception.GenericException;
import com.airtelbank.validation.model.AUARequest;
import com.airtelbank.validation.model.AUAResponse;
import com.airtelbank.validation.model.AadhaarVaultRequest;
import com.airtelbank.validation.model.AadhaarVaultResponse;
import com.airtelbank.validation.model.Document;
import com.airtelbank.validation.model.KUARequest;
import com.airtelbank.validation.model.Meta;
import com.airtelbank.validation.model.ResponseDTO;
import com.airtelbank.validation.service.AadhaarService;
import com.airtelbank.validation.service.ErrorCodeMapperService;
import com.airtelbank.validation.service.PinCodeService;
import com.airtelbank.validation.util.CommonUtil;
import com.airtelbank.validation.util.LogMasker;
import com.airtelbank.validation.util.ValidationUtils;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;


@RestController
@RequestMapping(value = {"/api/v1","/api/v2"})
public class ValidationController {

	@Autowired
	private AadhaarService aadhaarService;

	@Autowired
	private ValidationUtils<Document> validationUtils;

	@Autowired
	private MessageSource messageSource;

	@Autowired
	private ErrorCodeMapperService errorCodeService;

	@Autowired
	private PinCodeService pinCodeService;

	@Autowired
	private LogMasker logMasker;

	@Value("${log.encryption.key}")
	private String key;
	
	@Value("${enable.delete.aadhaar.data.api}")
	private boolean enableDeleteApi;

	private static final Logger logger = LoggerFactory.getLogger(ValidationController.class);

	@PostMapping(value = "/validateDocument")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Successfully retrieved customer data"),
			@ApiResponse(code = 201, message = "Successfully created"),
			@ApiResponse(code = 400, message = "Bad request"),
			@ApiResponse(code = 500, message = "Internal Server Error ") })
	@ApiOperation(value = "/validateDocument", response = ValidationController.class)
	public ResponseEntity<?> validateDocument(@RequestBody Document document, @RequestHeader String contentId,
			@RequestHeader String channel, @RequestHeader(required = false) String whetherRegenerateOTPRequest,@RequestHeader(required = false) String circle,BindingResult bindingResult) throws Exception {
		ResponseDTO<?> response = null;
		CommonUtil.setMDCMap(contentId, channel, document.getMobile(), Constants.UIDAI_GENERATE_AADHAR_OTP);
		if (logger.isDebugEnabled()) {
			CommonUtil.encryptAndPrint(Level.DEBUG, "validate ...document object", document, key);
		}
		validationUtils.validate(document, document.getDocType(), document.getAction());
		String docType = document.getDocType().toUpperCase();
		String action = document.getAction().toUpperCase();
		boolean isAadhaarOrVid = CommonUtil.setOtpRequestType(document);
		if (!isAadhaarOrVid) {
			throw new ClientSideException(
					messageSource.getMessage("generate.aadhaar.otp.invalid.aadhaar.or.vid.error.msg", null, Locale.ENGLISH));
		}
		switch (docType) {
		case Constants.PAN:
			break;
		case Constants.AADHAAR:
			if (action.equals(Constants.GENERATE_AADHAAR_OTP_ACTION)) {
				response = aadhaarService.generateAadhaarOTP(document);
				MDC.put(Constants.ERRORS, CommonUtil.setLoggerError(response.getMeta()));
			} else {
				throw new ClientSideException();
			}
			break;
		default:
			throw new ClientSideException();
		}
		return ResponseEntity.ok().body(response);
	}

	@PostMapping(path = "/getAadhaarReference")
	public ResponseEntity<?> getAadhaarReference(@Valid @RequestBody AadhaarVaultRequest aadhaarVaultRequest,
			@RequestHeader String contentId, @RequestHeader String channel) {
		logger.info("In controller");
		CommonUtil.setMDCMap(contentId, channel, null, Constants.GET_AADHAAR_REFERENCE);
		ResponseDTO<AadhaarVaultResponse> responseDTO = new ResponseDTO<>();
		Meta meta = new Meta();
		AadhaarVaultResponse aadhaarVaultResponse = aadhaarService.getAadhaarReference(aadhaarVaultRequest);
		meta.setCode(messageSource.getMessage("vault.success.code", null, Locale.ENGLISH));
		meta.setDescription(messageSource.getMessage("vault.success.msg", null, Locale.ENGLISH));
		meta.setStatus(Constants.SUCCESS_STATUS);
		responseDTO.setMeta(meta);
		responseDTO.setData(aadhaarVaultResponse);
		MDC.put(Constants.ERRORS, CommonUtil.setLoggerError(meta));
		return ResponseEntity.ok().body(responseDTO);
	}

	@DeleteMapping(path = "/deleteAadhaar")
	public ResponseEntity<?> removeAadhaar(@Valid @RequestBody AadhaarVaultRequest aadhaarVaultRequest,
			@RequestHeader String contentId, @RequestHeader String channel, @RequestHeader String appType,
			@RequestHeader String customerId) {
		if (enableDeleteApi) {
			logger.info("Request received in order to remove the corresponding aadhaar :: {} ",
					logMasker.patternReplace(aadhaarVaultRequest));
			CommonUtil.setMDCMap(contentId, channel, null, Constants.DELETE_AADHAAR_REFERENCE);
			ResponseDTO response = aadhaarService.removeAadhaar(aadhaarVaultRequest, appType, customerId);
			MDC.put(Constants.ERRORS, CommonUtil.setLoggerError(response.getMeta()));
			return ResponseEntity.ok().body(response);
		} else {
			return ResponseEntity.status(HttpStatus.UNAVAILABLE_FOR_LEGAL_REASONS)
					.body("Caution::This API is not enabled on this server.");
		}

	}

	@PostMapping(path = "/getAadhaarNumber")
	public ResponseEntity<?> getAadhaarNumber(@Valid @RequestBody AadhaarVaultRequest aadhaarVaultRequest,
			@RequestHeader String contentId, @RequestHeader String channel) {
		logger.info("In controller");
		CommonUtil.setMDCMap(contentId, channel, null, Constants.GET_AADHAAR_NUMBER);
		ResponseDTO<AadhaarVaultResponse> responseDTO = new ResponseDTO<>();
		Meta meta = new Meta();
		AadhaarVaultResponse aadhaarVaultResponse = aadhaarService.getAadhaarNumber(aadhaarVaultRequest);
		meta.setCode(messageSource.getMessage("vault.success.code", null, Locale.ENGLISH));
		meta.setDescription(messageSource.getMessage("vault.success.msg", null, Locale.ENGLISH));
		meta.setStatus(Constants.SUCCESS_STATUS);
		responseDTO.setMeta(meta);
		responseDTO.setData(aadhaarVaultResponse);
		MDC.put(Constants.ERRORS, CommonUtil.setLoggerError(meta));
		return ResponseEntity.ok().body(responseDTO);
	}

	@PutMapping(value = "/validateDocument")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Successfully retrieved customer data"),
			@ApiResponse(code = 201, message = "Successfully created"),
			@ApiResponse(code = 400, message = "Bad request"),
			@ApiResponse(code = 500, message = "Internal Server Error ") })
	@ApiOperation(value = "/validateDocument", response = ValidationController.class)
	public ResponseEntity<?> verifyDocument(@RequestBody Document request, @RequestHeader String contentId,
			@RequestHeader String channel,@RequestHeader(required = false) String circle ,BindingResult bindingResult) throws Exception {
		CommonUtil.setMDCMap(contentId, channel, request.getMobile(), Constants.UIDAI_VERIFY_AADHAR_OTP);
		ResponseDTO<?> response = null;
		validationUtils.validate(request, request.getDocType(), request.getAction());
		if (logger.isDebugEnabled()) {
			CommonUtil.encryptAndPrint(Level.DEBUG, "request object", request, key);
		}
		String docType = request.getDocType().toUpperCase();
		String action = request.getAction().toUpperCase();
		switch (docType) {
		case Constants.PAN:
			break;
		case Constants.AADHAAR:
			if (action.equalsIgnoreCase(Constants.VERIFY_AADHAAR_OTP_ACTION)) {
				response = aadhaarService.verifyAadhaarIdentity(request);
				MDC.put(Constants.ERRORS, CommonUtil.setLoggerError(response.getMeta()));
			} else {
				throw new ClientSideException();
			}
			break;
		default:
			throw new ClientSideException();
		}
		return ResponseEntity.ok().body(response);
	}

	@PostMapping(value = "/validateAUA")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Successfully retrieved customer data"),
			@ApiResponse(code = 201, message = "Successfully created"),
			@ApiResponse(code = 400, message = "Bad request"),
			@ApiResponse(code = 500, message = "Internal Server Error ") })
	@ApiOperation(value = "/validateAUA", response = ValidationController.class)
	public ResponseEntity<?> validateAUA(@Valid @RequestBody AUARequest auaRequest, @RequestHeader String contentId,
			@RequestHeader String channel,@RequestHeader(required = false) String circle) {
		CommonUtil.setMDCMap(contentId, channel, null, Constants.VALIDATE_AUA);
		ResponseDTO<AUAResponse> response = new ResponseDTO<>();
		AUAResponse auaResponse = null;
		Meta meta = new Meta();
		auaResponse = aadhaarService.validateAUA(auaRequest, contentId);
		ErrorCodeMapper errorCodeMapper = errorCodeService
				.getErrorCodeByApiNameAndOrgErrorCode(auaResponse.getStatusCode(), Constants.AUA_API_NAME);
		if (errorCodeMapper == null) {
			logger.error("error mapper is null");
			throw new GenericException();
		} else {
			meta.setCode(errorCodeMapper.getErrorCode());
			meta.setDescription(errorCodeMapper.getErrorMsg());
		}
		if (meta.getCode().equalsIgnoreCase(messageSource.getMessage("config.aua.success.code", null, Locale.ENGLISH))) {
			meta.setStatus(Constants.SUCCESS_STATUS);
		} else {
			meta.setStatus(Constants.FAILURE_STATUS);
		}
		response.setMeta(meta);
		response.setData(auaResponse);
		if (logger.isDebugEnabled()) {
			logger.debug("<-- Exiting validationController::validateDocument");
			logger.debug("Exit Response DTO :" + response);
		}
		MDC.put(Constants.ERRORS, CommonUtil.setLoggerError(meta));
		return ResponseEntity.ok().body(response);
	}

	@PostMapping(value = "/getAadhaarDetailsKUA")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Successfully retrieved customer data"),
			@ApiResponse(code = 201, message = "Successfully created"),
			@ApiResponse(code = 400, message = "Bad request"),
			@ApiResponse(code = 500, message = "Internal Server Error ") })
	@ApiOperation(value = "/getAadhaarDetailsKUA", response = ValidationController.class)
	public ResponseEntity<ResponseDTO<AadhaarVerify>> getAadhaarDetails(@Valid @RequestBody KUARequest kuaRequest,
			@RequestHeader String contentId, @RequestHeader String channel,@RequestHeader(required = false) String circle) {
		ResponseDTO<AadhaarVerify> response = new ResponseDTO<>();
		CommonUtil.setMDCMap(contentId, channel, kuaRequest.getMobile(), Constants.GET_AADHAAR_DETAILS_KUA);
		Meta meta = new Meta();
		kuaRequest.setChannel(channel);
		kuaRequest.setContentId(contentId);
		response = aadhaarService.getAadhaarDetailsKUA(kuaRequest, contentId);
		CommonUtil.encryptAndPrint(Level.INFO, "KUA response", response, key);
		ErrorCodeMapper errorCodeMapper = errorCodeService
				.getErrorCodeByApiNameAndOrgErrorCode(response.getMeta().getCode(), Constants.KUA_API_NAME);
		if (errorCodeMapper == null) {
			logger.error("error mapper is null");
			throw new GenericException();
		} else {
			meta.setCode(errorCodeMapper.getErrorCode());
			meta.setDescription(errorCodeMapper.getErrorMsg());
		}
		if (meta.getCode().equalsIgnoreCase(messageSource.getMessage("config.kua.success.code", null, Locale.ENGLISH))) {
			meta.setStatus(Constants.SUCCESS_STATUS);
		} else {
			meta.setStatus(Constants.FAILURE_STATUS);
		}
		response.setMeta(meta);
		if (logger.isDebugEnabled()) {
			logger.debug("<-- Exiting validationController::getAadhaarDetailsKUA");
		}
		MDC.put(Constants.ERRORS, CommonUtil.setLoggerError(meta));
		return ResponseEntity.ok().body(response);
	}

	@GetMapping(path = "/validate/{pincode}")
	public ResponseEntity<?> validatePinCode(@PathVariable String pincode, @RequestHeader String contentId,
			@RequestHeader(value = "User-Agent") String userAgent)  {
		CommonUtil.setMDCMap(contentId, Constants.CHANNEL, Constants.CUSTOMER_ID, Constants.VALIDATE_PIN_CODE);
		ResponseDTO<?> response = pinCodeService.validatePinCode(contentId, userAgent, pincode);
		MDC.put(Constants.ERRORS, CommonUtil.setLoggerError(response.getMeta()));
		return ResponseEntity.ok().body(response);
	}
	

	@GetMapping(value = "/loadPincodeDetailsSet")
	public ResponseEntity<?> loadPincodeData(@RequestHeader String channel, @RequestHeader String contentId,
			@RequestHeader(value = "User-Agent") String userAgent) {
		CommonUtil.setMDCMap(contentId, Constants.CHANNEL, Constants.CUSTOMER_ID, Constants.LOAD_PIN_CODE);
		pinCodeService.loadPincodeDataToAerospike();
		MDC.put(Constants.ERRORS, CommonUtil.setLoggerError(Meta.builder().status(Constants.SUCCESS_STATUS).build()));
		return ResponseEntity.ok().body(null);
	}
}
