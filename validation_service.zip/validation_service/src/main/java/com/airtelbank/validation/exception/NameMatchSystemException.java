package com.airtelbank.validation.exception;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Setter
@Getter
@NoArgsConstructor
public class NameMatchSystemException extends NameMatchException {
	
	
	public NameMatchSystemException(String id, String message) {
		super(id,message);
		
	}
	
	public NameMatchSystemException(String id, String message, Throwable t) {
		super(id,message, t);
		
	}
}
