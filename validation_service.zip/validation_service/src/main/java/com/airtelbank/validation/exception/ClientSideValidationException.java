package com.airtelbank.validation.exception;

import lombok.Getter;
import lombok.Setter;

/**
 * @author Hitesh Khatri
 * @date 18/06/21
 */

@Getter
@Setter
public class ClientSideValidationException extends RuntimeException {

    private static final long serialVersionUID = 1329153696866826357L;
    private String errorCode;
    private String errorMessage;

    public ClientSideValidationException(String errorCode, String errorMessage) {
        super(errorMessage);
        this.errorCode = errorCode;
        this.errorMessage = errorMessage;
    }

}
