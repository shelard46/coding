
package com.airtelbank.validation.controller;

import org.apache.log4j.MDC;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.airtelbank.validation.constants.Constants;
import com.airtelbank.validation.exception.ThirdPartyApiException;
import com.airtelbank.validation.model.BlacklistEntityResponse;
import com.airtelbank.validation.model.BlacklistRequest;
import com.airtelbank.validation.model.BlacklistResponse;
import com.airtelbank.validation.model.ResponseDTO;
import com.airtelbank.validation.model.blacklist.BlacklistEntity;
import com.airtelbank.validation.service.BlacklistService;
import com.airtelbank.validation.util.CommonUtil;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
@RequestMapping(value = {"/api/v1","/api/v2"})
public class BlacklistController {
	private static final Logger logger = LoggerFactory.getLogger(BlacklistController.class);

	@Autowired private BlacklistService blService;

	@PostMapping(value = "/customer/blacklist")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Successfully posted BLRequest"),
			@ApiResponse(code = 401, message = "You are not authorized to view the resource"),
			@ApiResponse(code = 403, message = "Accessing the resource you were trying to reach is forbidden"),
			@ApiResponse(code = 404, message = "The resource you were trying to reach is not found") })
	@ApiOperation(value = "/customer/blacklist", response = BlacklistController.class)
	public ResponseDTO<BlacklistResponse> checkCustomerBlacklisting(String id, @RequestBody BlacklistRequest blRequest,
			@RequestHeader String contentId, @RequestHeader String channel) {
		CommonUtil.setMDCMap(contentId, channel, blRequest.getCustomerId(), Constants.CHECK_BLACKLIST);
		logger.info("Inside Blacklist Controller. contentId: {}, customerId: {}",contentId, blRequest.getCustomerId());
		ResponseDTO<BlacklistResponse> response = blService.getCustomerBlacklistInfo(blRequest, contentId);
		if (null != response) {
			logger.info("response generated: {}", response.getData());
		} else {
			throw new ThirdPartyApiException();
		}
		logger.info("Executed Blacklist Service ");
		MDC.put(Constants.ERRORS, CommonUtil.setLoggerError(response.getMeta()));
		return response;
	}

	@PostMapping(value = "/entity/blacklist")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Successfully posted BLRequest"),
			@ApiResponse(code = 401, message = "You are not authorized to view the resource"),
			@ApiResponse(code = 403, message = "Accessing the resource you were trying to reach is forbidden"),
			@ApiResponse(code = 404, message = "The resource you were trying to reach is not found") })
	@ApiOperation(value = "/entity/blacklist", response = BlacklistController.class)
	public ResponseDTO<BlacklistEntityResponse> checkEntityBlacklisting(@RequestBody BlacklistEntity blRequest,
																		@RequestHeader String contentId, @RequestHeader String channel) {
		ResponseDTO<BlacklistEntityResponse> response;
		CommonUtil.setMDCMap(contentId, channel, Constants.CUSTOMER_ID, Constants.ENTITY_BLACKLIST);
		try {
			logger.info("Inside Blacklist Controller. contentId: {}, entity: {}", contentId, blRequest.getName());
			response = blService.getEntityBlacklistInfo(blRequest, contentId);
		} catch (Exception ex) {
			logger.error("exception occurred while getting data for entity: {}", blRequest.getName());
			throw ex;
		}
		MDC.put(Constants.ERRORS, CommonUtil.setLoggerError(response.getMeta()));
		logger.info("response generated for entity: {} is: {}",blRequest.getName(), response.getData());
		return response;
	}

}
