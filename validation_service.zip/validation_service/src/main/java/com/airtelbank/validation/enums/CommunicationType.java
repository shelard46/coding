package com.airtelbank.validation.enums;

public enum CommunicationType {
	
	ALERT_AUA_SUCCESS,
	ALERT_AUA_FAILED,
	ALERT_KUA_SUCCESS,
	ALERT_KUA_FAILED,
	ALERT_OTP_SUCCESS,
	ALERT_OTP_FAILED

}
