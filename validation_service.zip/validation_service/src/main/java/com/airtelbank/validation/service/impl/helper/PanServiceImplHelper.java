package com.airtelbank.validation.service.impl.helper;

import java.io.IOException;
import java.util.List;

import javax.xml.bind.JAXBException;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.web.client.ResourceAccessException;

import com.airtelbank.validation.constants.Constants;
import com.airtelbank.validation.exception.ESBPanVerificationException;
import com.airtelbank.validation.exception.InvalidPanException;
import com.airtelbank.validation.exception.InvalidPanNumberException;
import com.airtelbank.validation.exception.ObjectConversionException;
import com.airtelbank.validation.model.DataArea;
import com.airtelbank.validation.model.EbmHeader;
import com.airtelbank.validation.model.Meta;
import com.airtelbank.validation.model.PANDetails;
import com.airtelbank.validation.model.PANRequest;
import com.airtelbank.validation.model.PANStatus;
import com.airtelbank.validation.model.PanEsbRequest;
import com.airtelbank.validation.model.PanEsbResponse;
import com.airtelbank.validation.model.VerifyPANDetailsRequest;
import com.airtelbank.validation.util.CommonUtil;

import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class PanServiceImplHelper extends AbstractBaseServiceImplHelper {
	
	

	@Value("${pan.consumerName.value}")
	private String strESBPanConsumerName;

	@Value("${pan.lob.value}")
	private String strESBPanLineOfBusinessName;

	@Value("${pan.programmeName.value}")
	private String strESBPanProgramName;

	@Value("${pan.esb.url}")
	private String strEsbPanUrl;
	
	@Value("${pan.esb.api.ver}")
	private String apiVersion;
	
	private static final String PAN_GENERIC_ERROR_CODE = "1951";
	
	public boolean validatePanRequest(PANRequest panReq) {
		if( panReq != null && panReq.getPanNumber() != null) {
			panReq.setPanNumber(panReq.getPanNumber().trim());
			if(panReq.getPanNumber().matches("^[A-Za-z]{5}[0-9]{4}[A-Za-z]$")) {
				panReq.setPanNumber(panReq.getPanNumber().toUpperCase());
				return true;
			}
		}
		throw new InvalidPanNumberException(Constants.PAN_INVALID_DETAILS_MESSAGE);
	}

	public PanEsbRequest createPANEsbRequest(PANRequest panReq) {
		EbmHeader header = new EbmHeader();
		header.setConsumerName(strESBPanConsumerName);
		if(StringUtils.isNotBlank(panReq.getContentId())) {
			header.setConsumerTransactionId(panReq.getContentId());
		}else {
			header.setConsumerTransactionId(CommonUtil.generateUniqueId());
		}		
		header.setLob(strESBPanLineOfBusinessName);
		header.setProgrammeName(strESBPanProgramName);

		VerifyPANDetailsRequest panDetails = new VerifyPANDetailsRequest();
		panDetails.setPanNumber(panReq.getPanNumber());
		panDetails.setVersion(apiVersion);
		DataArea dataArea = new DataArea();
		dataArea.setPanRequestDetails(panDetails);
		
		PanEsbRequest panEsbReq = new PanEsbRequest();
		panEsbReq.setPanHeader(header);
		panEsbReq.setPanData(dataArea);

		return panEsbReq;
	}


	public PanEsbResponse fetchResponseForXML(PanEsbRequest panReq)  {
		PanEsbResponse panEsbResponse = null;
		try {
			panEsbResponse = super.fetchResponseForXML(panReq, strEsbPanUrl, PanEsbRequest.class, PanEsbResponse.class);
		} catch (ResourceAccessException | IOException e) {
			log.error("Timeout during CBS request.",e);
			throw new ESBPanVerificationException(Meta.builder().code(PAN_GENERIC_ERROR_CODE).build());
		} catch (JAXBException  e) {
			log.error("Error while converting object ", e);
			throw new ObjectConversionException();
		}

		if (panEsbResponse == null) {
			throw new ESBPanVerificationException(Meta.builder().code(PAN_GENERIC_ERROR_CODE).build());
		}
		return panEsbResponse;//

	}
	
	
	public PANDetails getPanDetails(PanEsbResponse panEsbResponse) {
		if ( panEsbResponse != null && panEsbResponse.getPanData() != null && panEsbResponse.getPanData().getPanResponseDetails() != null) {
            PANStatus status = panEsbResponse.getPanData().getPanResponseDetails().getStatus();
            log.debug("status : {}", status);
            if (StringUtils.isNotBlank(status.getCode())) {
                String statusCode = status.getCode().trim();
                if (Constants.PAN_ESB_SUCCESS_CODE.equalsIgnoreCase(statusCode)) {
                    log.info("PAN request is successful");
                    List<PANDetails> panDetailsList = panEsbResponse.getPanData().getPanResponseDetails().getPanDetails();
                    if (panDetailsList != null && !panDetailsList.isEmpty()) {
                        PANDetails panDetails = panDetailsList.get(0);
                        if (panDetails.getPanStatus().equals("E")) {
                            return panDetails;
                        }
                       throw new  InvalidPanNumberException(Constants.PAN_INVALID_DETAILS_MESSAGE);
                    }
                // Added for invalid pan response from ESB
                }else if(Constants.PAN_ESB_INVALID_CODE.equals(statusCode)) {
                	throw new InvalidPanException(Constants.PAN_INVALID_MESSAGE);
                }else if(Constants.PAN_ESB_INVALID_REQ_CODE.equals(statusCode)){
                	throw new  InvalidPanNumberException(Constants.PAN_INVALID_DETAILS_MESSAGE);
                }else {
                	throw new ESBPanVerificationException(Meta.builder().code(statusCode).description(status.getDescription()).build());
                }
                
            } else {
                log.error("Status Code is missing in response");
                throw new  ESBPanVerificationException(Meta.builder().code(PAN_GENERIC_ERROR_CODE).build());
            }
        }
		log.debug("pan data is null");
		throw new ESBPanVerificationException(Meta.builder().code(PAN_GENERIC_ERROR_CODE).build());
	}
	
	
	
}
