package com.airtelbank.validation.exception;

import com.airtelbank.validation.model.Meta;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.*;

@Setter
@Getter
@ToString
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class UIDAIAadhaarVerifyException extends Exception {
    private String id;
    private Meta meta;

    public UIDAIAadhaarVerifyException(String id) {
        this.id = id;
    }

    public UIDAIAadhaarVerifyException(String message, String id) {
        super(message);
        this.id = id;
    }

    public UIDAIAadhaarVerifyException(String message, Throwable cause, String id) {
        super(message, cause);
        this.id = id;
    }

    public UIDAIAadhaarVerifyException(Throwable cause, String id) {
        super(cause);
        this.id = id;
    }

    public UIDAIAadhaarVerifyException(Meta meta) {
        this.meta = meta;
    }
}
