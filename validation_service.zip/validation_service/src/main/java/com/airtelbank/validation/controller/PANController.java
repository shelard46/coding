package com.airtelbank.validation.controller;

import java.util.Locale;

import org.apache.log4j.MDC;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.MessageSource;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RestController;

import com.airtelbank.validation.constants.Constants;
import com.airtelbank.validation.model.Meta;
import com.airtelbank.validation.model.PANDetails;
import com.airtelbank.validation.model.PANRequest;
import com.airtelbank.validation.model.ResponseDTO;
import com.airtelbank.validation.service.PANService;
import com.airtelbank.validation.util.CommonUtil;
import com.airtelbank.validation.util.RSAUtil;

@RestController
public class PANController {

	private static final Logger logger = LoggerFactory.getLogger(PANController.class);

	@Value("${rsa.private.key}")
	private String privateKey;
	
	@Autowired
	private PANService panService;

	@Autowired
	private MessageSource messageSource;

	@GetMapping("/api/v1/customers/{customerId}/identities/pan/{pan}")
	@Deprecated
	public ResponseEntity<ResponseDTO<PANDetails>> validateCustomerPANDetails(
			@PathVariable String customerId,
			@PathVariable String pan, 
			@RequestHeader String contentId, 
			@RequestHeader String channel) {
		CommonUtil.setMDCMap(contentId, channel, null, Constants.VALIDATE_PAN_DETAILS);
		ResponseDTO<PANDetails> response = getPanDetails(customerId, pan, contentId, channel);
		MDC.put(Constants.ERRORS, CommonUtil.setLoggerError(response.getMeta()));
		return ResponseEntity.ok().body(response);
	}
	
	public ResponseDTO<PANDetails> getPanDetails(String customerId, String pan, String contentId, String channel) {
		PANRequest panReq = PANRequest.builder().mobile(customerId).channel(channel).contentId(contentId).panNumber(pan)
				.build();
		PANDetails panDetails = panService.getPanDetails(panReq);
		if (logger.isDebugEnabled()) {
			logger.debug(" Pan Response : {}", panDetails);
		}
		Meta meta = Meta.builder().status(Constants.SUCCESS_STATUS)
				.code(messageSource.getMessage("pan.success.code", null, Locale.ENGLISH))
				.description(messageSource.getMessage("pan.success.msg", null, Locale.ENGLISH)).build();
		ResponseDTO<PANDetails> responseDTO = new ResponseDTO<>();
		responseDTO.setMeta(meta);
		responseDTO.setData(panDetails);
		return responseDTO;
	}

	
	@GetMapping("/api/v2/pan")
	public ResponseEntity<ResponseDTO<PANDetails>> validatePANDetails(
			@RequestHeader String contentId, 
			@RequestHeader String channel, 
			@RequestHeader String pan) {
		CommonUtil.setMDCMap(contentId, channel, null, Constants.VALIDATE_PAN_DETAILS);
		pan = RSAUtil.decrypt(pan, RSAUtil.getPrivateKey(privateKey));
		ResponseDTO<PANDetails> response = getPanDetails(pan, contentId, channel);
		MDC.put(Constants.ERRORS, CommonUtil.setLoggerError(response.getMeta()));
		return ResponseEntity.ok().body(response);
	}
	
	
	public ResponseDTO<PANDetails> getPanDetails(String pan, String contentId, String channel) {
		PANRequest panReq = PANRequest.builder().channel(channel).contentId(contentId).panNumber(pan)
				.build();
		PANDetails panDetails = panService.getPanDetails(panReq);
		if (logger.isDebugEnabled()) {
			logger.debug(" Pan Response : {}", panDetails);
		}
		Meta meta = Meta.builder().status(Constants.SUCCESS_STATUS)
				.code(messageSource.getMessage("pan.success.code", null, Locale.ENGLISH))
				.description(messageSource.getMessage("pan.success.msg", null, Locale.ENGLISH)).build();
		ResponseDTO<PANDetails> responseDTO = new ResponseDTO<>();
		responseDTO.setMeta(meta);
		responseDTO.setData(panDetails);
		return responseDTO;
	}

}
