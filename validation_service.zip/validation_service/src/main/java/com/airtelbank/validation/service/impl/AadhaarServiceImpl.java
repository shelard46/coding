package com.airtelbank.validation.service.impl;


import static com.airtelbank.validation.constants.Constants.ACCEPT;
import static com.airtelbank.validation.constants.Constants.APPLICATION_JSON;
import static com.airtelbank.validation.constants.Constants.CONTENT_TYPE;
import static com.airtelbank.validation.constants.Constants.MESSAGE_SIGNATURE;

import java.io.IOException;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import javax.xml.bind.JAXBException;
import javax.xml.stream.XMLStreamException;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.apache.log4j.Level;
import org.apache.log4j.MDC;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.MessageSource;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.client.ResourceAccessException;
import org.springframework.web.client.RestClientException;

import com.airtelbank.validation.constants.Constants;
import com.airtelbank.validation.dao.aerospike.AadharVerifyDao;
import com.airtelbank.validation.dao.aerospike.IdentitiesDao;
import com.airtelbank.validation.dao.aerospike.IdentitiesRepository;
import com.airtelbank.validation.dao.aerospike.model.AadhaarVerify;
import com.airtelbank.validation.dao.aerospike.model.Identities;
import com.airtelbank.validation.dao.jpa.model.DocumentAuditLog;
import com.airtelbank.validation.dao.jpa.model.DocumentAuditLog.TransactionStatus;
import com.airtelbank.validation.dao.jpa.respository.DocumentAuditRepository;
import com.airtelbank.validation.enums.CommunicationType;
import com.airtelbank.validation.exception.AadhaarKUAVerifyException;
import com.airtelbank.validation.exception.AadharVerificationException;
import com.airtelbank.validation.exception.ClientSideException;
import com.airtelbank.validation.exception.ClientSideValidationException;
import com.airtelbank.validation.exception.GenerateAadhaarOTPRequestLimitExceeded;
import com.airtelbank.validation.exception.GenericException;
import com.airtelbank.validation.exception.JsonCustomParsingException;
import com.airtelbank.validation.exception.ObjectConversionException;
import com.airtelbank.validation.exception.ThirdPartyApiException;
import com.airtelbank.validation.exception.UIDAIAadhaarVerifyException;
import com.airtelbank.validation.exception.VaultException;
import com.airtelbank.validation.exception.VerificationException;
import com.airtelbank.validation.exception.VerifyAadhaarOTPRequestLimitExceededException;
import com.airtelbank.validation.model.AUARequest;
import com.airtelbank.validation.model.AUAResponse;
import com.airtelbank.validation.model.AUAUidaiResponse;
import com.airtelbank.validation.model.AadhaarVaultRequest;
import com.airtelbank.validation.model.AadhaarVaultResponse;
import com.airtelbank.validation.model.DeviceDetails;
import com.airtelbank.validation.model.Document;
import com.airtelbank.validation.model.GenerateAadhaarOTPResponse;
import com.airtelbank.validation.model.KUARequest;
import com.airtelbank.validation.model.Meta;
import com.airtelbank.validation.model.ResponseDTO;
import com.airtelbank.validation.model.aadhar.generate.otp.GenerateAadhaarOTPData;
import com.airtelbank.validation.model.aadhar.generate.otp.GenerateAadharOTPDataResponse;
import com.airtelbank.validation.model.aadhar.validate.otp.ValidateAadharOTPData;
import com.airtelbank.validation.model.aadhar.validate.otp.ValidateAadharOTPDataResponse;
import com.airtelbank.validation.model.communication.SMSTemplate;
import com.airtelbank.validation.service.AadhaarService;
import com.airtelbank.validation.service.CommunicationService;
import com.airtelbank.validation.util.AuditUtil;
import com.airtelbank.validation.util.CipherUtil;
import com.airtelbank.validation.util.CommonUtil;
import com.airtelbank.validation.util.HttpUtil;
import com.airtelbank.validation.util.KibanaUtil;
import com.airtelbank.validation.util.LogMasker;
import com.airtelbank.validation.util.ValidationUtil;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.base.VerifyException;

import freemarker.template.TemplateException;

@Service
public class AadhaarServiceImpl implements AadhaarService {
    
	@Autowired private HttpUtil httpUtil;
	@Autowired private LogMasker logMasker;
	@Autowired private Environment environment;
	@Autowired private MessageSource messageSource;
    @Autowired private IdentitiesDao identitiesDao;
    @Autowired private AadhaarService aadhaarService;
    @Autowired private ValidationUtil validationUtil;
    @Autowired private AadharVerifyDao aadharVerifyDao;
    @Autowired private IdentitiesRepository identitiesRepository;
    @Autowired private CommunicationService communicationService;
    @Autowired private DocumentAuditRepository documentAuditRepository;
    @Autowired private AuditUtil auditUtil;
	@Autowired private KibanaUtil kibanaUtil;

    //Generate Aadhaar OTP config
    @Value("${config.generate.aadhaar.otp.url}")
    private String generateAadhaarOTPUrl;
    @Value("${config.generate.aadhaar.otp.maxcount}")
    private int maxGenerateAadhaarOTPCount;
    @Value("${config.generate.aadhaar.otp.max.retry.count.reached.msg}")
    private String maxGenerateAadhaarOTPExceededMaxCountMessage;
    @Value("${config.generate.aadhaar.otp.success.msg}")
    private String maxGenerateAadhaarOTPSuccessMessage;
    @Value("${config.generate.aadhaar.otp.user.waiting.time}")
    private int userWaitingTime;

    //Verify Aadhaar OTP config
    @Value("${config.aadhaar.otp.verify}")
    private String otpVerifyUrl;


    @Value("${config.aadhaar.otp.residentconsent}")
    private String residentConsent;
    @Value("${config.aadhaar.otp.printformatrequest}")
    private String printFormatRequest;
    @Value("${config.aadhaar.otp.locallangrequired}")
    private String localLangRequired;
    @Value("${config.aadhaar.otp.verify.default.code}")
    private String errorCode;
    @Value("${config.aadhaar.otp.verify.default.msg}")
    private String errorMessage;
    @Value("${config.aadhaar.otp.verify.maxcount}")
    private int maxVerifyCount;
    @Value(value = "${aadhaarVault.passphrase}")
    private String aadhaarVaultPassphrase;
    @Value(value = "${aadhaarVault.apiKey}")
    private String aadhaarVaultApiKey;
    @Value(value = "${aadhaarVault.baseURL}")
    private String aadhaarVaultBaseUrl;
    @Value(value = "${aadhaarVault.readTimeout}")
    private String aadhaarVaultReadTimeOut;
    @Value(value = "${aadhaarVault.connectionTimeout}")
    private String aadhaarVaultConnectionTimeOut;
    @Value("${config.aadhaar.verify.device.default}")
    private String defaultDeviceCode;
    @Value("${aadhaarVault.apikey}")
    private String vaultApiKey;
    @Value("${aadhaarVault.fetchRefContext}")
    private String vaultRefContext;
    @Value("${aadhaarVault.removeAadhaarContext}")
    private String vaultRemoveAadhaarContext;
    @Value("${aadhaarVault.fetchAadhaarContext}")
    private String vaultAadhaarContext;
    @Value("${config.aadhaar.verify.max.fail}")
    private String maxVerifyError;
    @Value("${config.aadhaar.verify.max.msg}")
    private String maxVerifyMsg;
    @Value("${log.encryption.key}")
    private String key;
    @Value("#{'${valid.biometric.types}'.split(';')}")
    private List<String> validBiomerticTypes;
    @Value("${default.biometric.type:FMR}")
    private String defaultBiometricType;

    private static final Logger logger = LoggerFactory.getLogger(AadhaarServiceImpl.class);


    @Override
    public ResponseDTO<Document> generateAadhaarOTP(Document request) throws Exception {
        if (request == null) {
            throw new ClientSideException();
        }
        GenerateAadhaarOTPData uidaiRequest = null;
        GenerateAadharOTPDataResponse uidaiResponse = null;
        Document response = null;
        String responseString = null;
        DocumentAuditLog documentAuditLog = null;
        String id = null;
        String aadhaarRequestId = null;
        Identities identity = null;
        try {
            String mobile = request.getMobile();
            String docReferenceNumber = null;
            String docNumber = null;
            if (CommonUtil.isAadhaarRequest(request)) {
                docNumber = CommonUtil.getAadhaarNumberFromReferenceNumber(request, aadhaarService, environment);
                docReferenceNumber = request.getDocNumber();
                request.setDocReferenceNumber(docReferenceNumber);
            } else {
                docReferenceNumber = CommonUtil.encryptData(request.getDocNumber(), request.getMobile());
                request.setDocReferenceNumber(docReferenceNumber);
            }
            if (mobile != null && docReferenceNumber != null) {
                List<Identities> identities = identitiesRepository.findByMobileNumberAndDocNumber(mobile, docNumber);
                int generationCount = (identities != null && !identities.isEmpty()) ? identities.get(0).getGenCount() : 0;
                if (generationCount >= maxGenerateAadhaarOTPCount) {
                    throw new GenerateAadhaarOTPRequestLimitExceeded();
                } else {
                    //Generate Aadhaar id to store in aerospike
                    aadhaarRequestId = CommonUtil.generateUniqueId();
                    if (generationCount > 0) {
                        identity = identities.get(0);
                        id = identity.getId();
                        identity.setAid(aadhaarRequestId);
                        identity.setGenCount(generationCount + 1);
                        identitiesDao.updateIdentityInRepo(identity, false);
                        if (logger.isDebugEnabled()) {
                            logger.debug("Update Identity: {}" , logMasker.patternReplace(CommonUtil.jsonObjectToString(identity)));
                        }
                    } else {
                        //Generate id to return back to client
                        id = CommonUtil.generateUniqueId();
                        identity = ValidationUtil.createIdentityRequest(id, aadhaarRequestId, generationCount, request);
                        identitiesDao.addAndSaveIdentityInRepo(identity);
                    }
                    //Set unique id for UIDAI request
                    request.setId(aadhaarRequestId);
                    MDC.put(Constants.TRANSACTION_ID, request.getId() != null ? request.getId() : "");
                    uidaiRequest = validationUtil.createAadhaarOTPRequest(request, docNumber);
                    documentAuditLog = new DocumentAuditLog();
                    documentAuditLog = ValidationUtil.createDocumentAuditLogForRequest(request, documentAuditLog);
                    documentAuditRepository.save(documentAuditLog);

                    if(logger.isDebugEnabled()) {
                        CommonUtil.encryptAndPrint(Level.DEBUG, "UIDAI Request", logMasker.patternReplace(uidaiRequest.toString()), key);
                    }
                    Map<String, String> headersMap = new HashMap<>();
                    headersMap.put("Authorization", "Basic dWlkYWlCYW5rOlVpREBpQDMyMQ==");
                    headersMap.put(CONTENT_TYPE, "application/xml");
                    responseString = httpUtil.sendRequest(generateAadhaarOTPUrl,
                            CommonUtil.convertToXMLInJAXB(uidaiRequest, GenerateAadhaarOTPData.class), String.class,
                            headersMap, HttpMethod.POST, MediaType.APPLICATION_XML);
                    if (responseString == null) {
                    	kibanaUtil.setKibanaId(Constants.GENERATE_OTP_RESPONSE_NULL);
                        throw new ThirdPartyApiException();
                    }
                    uidaiResponse = CommonUtil.convertToObjectFromXMLInJackson(responseString.trim(),
                    		GenerateAadharOTPDataResponse.class);
                    
                    triggerGenerateOtpKibanaLogging(request, uidaiResponse);
                    
                    response = ValidationUtil.validateGenerateAadhaarOTPResponse(uidaiResponse);

                    //Set max retry count, current count and message
                    response.setMaxRetryCount(maxGenerateAadhaarOTPCount);
                    response.setCurrentRetryCount(generationCount + 1);
                    response.setMessage(maxGenerateAadhaarOTPSuccessMessage);
                    response.setUserWaitingTime(userWaitingTime);
                    response.setId(id);

                    //Update document audit log
                    // do this in finally block
                    documentAuditLog = ValidationUtil.updateDocumentAuditLog(uidaiResponse, documentAuditLog);

                    Meta meta = new Meta();
                    meta.setCode(messageSource.getMessage("generate.aadhaar.otp.success.response.code", null, null));
                    meta.setDescription(messageSource.getMessage("generate.aadhaar.otp.success.response.msg", null, null));
                    meta.setStatus(Constants.SUCCESS_STATUS);
                    ResponseDTO<Document> responseDTO = new ResponseDTO<>();
                    responseDTO.setMeta(meta);
                    responseDTO.setData(response);
                    return responseDTO;
                }
            } else {
                logger.info("CustomerId or document reference number is null");
                throw new ClientSideException();
            }
        } catch (ResourceAccessException e) {
            logger.info("Third party exception : {}", ExceptionUtils.getStackTrace(e));
            throw new ThirdPartyApiException();
        } catch (JAXBException | XMLStreamException | JsonCustomParsingException e) {
            logger.info("Exception while parsing generate OTP XML request/response: {}", ExceptionUtils.getStackTrace(e));
            throw new ObjectConversionException();
        } finally {
            logger.info("Updating documentAuditLog for generating Aadhaar OTP.");
            try {
            	documentAuditLog = ValidationUtil.updateDocumentAuditLog(uidaiResponse, documentAuditLog);
            	documentAuditRepository.save(documentAuditLog);
            }catch (ObjectConversionException o){
            	throw o;
            }
        }
    }

    @Override
    public AadhaarVerify verifyIdentity(String id, String verificationInput, String verificationType, String uniqueDeviceCode)
            throws JAXBException, VerificationException , UIDAIAadhaarVerifyException {

    	Identities identity = identitiesRepository.findOne(id);
        if (identity == null) {
            throw new VerificationException();
        }
        AadhaarVerify aadhaarVerify = null;
        Boolean verifySuccess = false;
        String docType = identity.getDocType();
        if (StringUtils.isEmpty(docType)) {
            throw new VerificationException();
        }
        int verifyCount = identity.getVerifyCount();
        docType = docType.toUpperCase();

        switch (docType) {
            case Constants.AADHAAR_CASE:
                if (verifyCount > maxVerifyCount) throw new VerifyException();
                String docOriginalNum = "";//to call aadhaar Vault
                ValidateAadharOTPData getUserAadhaarProfileReqMsg = validationUtil.getAadhaarProfileRequest(identity, residentConsent,
                        printFormatRequest, localLangRequired, docOriginalNum, verificationType, uniqueDeviceCode);
                String requestString = CommonUtil.convertToXMLInJAXB(getUserAadhaarProfileReqMsg, ValidateAadharOTPData.class);
                if (logger.isDebugEnabled()) {
                    logger.info("Request :{}", logMasker.patternReplace(requestString));
                }
                String responseString = null;
                ValidateAadharOTPDataResponse getAadhaarProfileResponse = null;
                try {
                    responseString = httpUtil.sendRequest(otpVerifyUrl, requestString, String.class, null, HttpMethod.POST);
                    if (logger.isDebugEnabled()) {
                        logger.info("Response :{}", logMasker.patternReplace(responseString));
                    }
                    getAadhaarProfileResponse = CommonUtil.convertToObjectFromXMLInJackson(responseString, ValidateAadharOTPDataResponse.class);
                    verifySuccess = ValidationUtil.getAadhaarProfileStatus(getAadhaarProfileResponse, errorCode);

                } catch (Exception e) {
                	logger.error("Exception : {}", ExceptionUtils.getStackTrace(e));
                    throw new VerificationException();
                } finally {
                    if (verifySuccess) {
                        identity.setIsVerified(true);
                        identity.setGenCount(0);
                    } else {
                        identity.setIsVerified(false);
                        identity.setVerifyCount(++verifyCount);
                    }
                    
                }
                aadhaarVerify = ValidationUtil.getAadhaarProfileResponse(getAadhaarProfileResponse);
                break;
            default:
                throw new VerificationException();
        }
        return aadhaarVerify;
    }

    public AadhaarVaultResponse getAadhaarReference(AadhaarVaultRequest aadhaarVaultRequest) {
        AadhaarVaultResponse aadhaarVaultResponse = new AadhaarVaultResponse();
        ObjectMapper objectMapper = new ObjectMapper();
        try {
            String aadhaarVaultRequestString = objectMapper.writeValueAsString(aadhaarVaultRequest);

            if(logger.isDebugEnabled()) {
            	logger.debug("request string : {}", logMasker.patternReplace(aadhaarVaultRequestString));
            }
            Map<String, String> headersMap = new HashMap<>();
            headersMap.put(CONTENT_TYPE, APPLICATION_JSON);
            headersMap.put(ACCEPT, APPLICATION_JSON);
            headersMap.put(MESSAGE_SIGNATURE,
                    CipherUtil.encryptData(String.valueOf(aadhaarVaultRequestString.hashCode()), aadhaarVaultPassphrase));
            aadhaarVaultResponse = (AadhaarVaultResponse) httpUtil.handleRequest(aadhaarVaultBaseUrl.concat(vaultRefContext),
                    aadhaarVaultRequestString, AadhaarVaultResponse.class, headersMap, HttpMethod.POST);
        } catch (ResourceAccessException ex) {
            logger.error("Potential timeout occurred in aadhaar vault request {} ", ExceptionUtils.getStackTrace(ex));
            throw new ThirdPartyApiException();
        } catch (RestClientException ex) {
            logger.error("Aadhaar vault request is unsuccessful. {} ", ExceptionUtils.getStackTrace(ex));
            throw new GenericException();
        } catch (Exception e) {
            logger.error("Exception in aadhaar vault request {} ", ExceptionUtils.getStackTrace(e));
            throw new GenericException();
        }
        if (aadhaarVaultResponse == null || aadhaarVaultResponse.getResult() == null) {
            logger.error("Response is null from aadhaar vault");
            throw new GenericException();
        }
        if (aadhaarVaultResponse.getResult().getStatusCode().equalsIgnoreCase("uid-00")) {
            return aadhaarVaultResponse;
        } else {
            Meta meta = new Meta();
            meta.setCode(aadhaarVaultResponse.getResult().getStatusCode());
            meta.setDescription(aadhaarVaultResponse.getResult().getStatusDescription());
            meta.setStatus(Constants.FAILURE_STATUS);
            throw new VaultException(meta);
        }
    }

    public ResponseDTO removeAadhaar(AadhaarVaultRequest aadhaarVaultRequest, String apptype, String customerId) {
        validateAadhaarRemoveRequest(aadhaarVaultRequest, apptype, customerId);
        ObjectMapper objectMapper = new ObjectMapper();
        try {
            String aadhaarVaultRequestString = objectMapper.writeValueAsString(aadhaarVaultRequest);
            if (logger.isDebugEnabled()) {
                logger.debug("remove aadhaar request string : {}", logMasker.patternReplace(aadhaarVaultRequestString));
            }
            Map<String, String> headersMap = new HashMap<>();
            headersMap.put(CONTENT_TYPE, APPLICATION_JSON);
            headersMap.put(ACCEPT, APPLICATION_JSON);
            headersMap.put(MESSAGE_SIGNATURE,
                    CipherUtil.encryptData(String.valueOf(aadhaarVaultRequestString.hashCode()), aadhaarVaultPassphrase));
            String response = (String) httpUtil.processHttpRequest(aadhaarVaultBaseUrl.concat(vaultRemoveAadhaarContext),
                    aadhaarVaultRequestString, String.class, headersMap, HttpMethod.DELETE);
            AadhaarVaultResponse aadhaarVaultResponse = AadhaarVaultResponse.builder().referenceKey(response).build();
            auditUtil.doAudit(apptype, customerId, logMasker.patternReplace(aadhaarVaultRequestString), Constants.DELETE_AADHAAR_REFERENCE, "Successfully Removed Aadhaar", "SUCCESS");
            return new ResponseDTO(Meta.builder().code(messageSource.getMessage("vault.success.code", null, Locale.ENGLISH)).description(messageSource.getMessage("vault.success.msg", null, Locale.ENGLISH)).build(),
                    aadhaarVaultResponse, null);
        } catch (ResourceAccessException ex) {
            logger.error("Potential timeout occurred in remove aadhaar vault request :: {}", ExceptionUtils.getStackTrace(ex));
            auditUtil.doAudit(apptype, customerId, null, Constants.DELETE_AADHAAR_REFERENCE, ex.getMessage(), Constants.FAILED);
            throw new ThirdPartyApiException();
        } catch (RestClientException ex) {
            if (ex instanceof HttpClientErrorException) {
                Meta meta = handleHttpClientErrorException(objectMapper, ex);
                auditUtil.doAudit(apptype, customerId, null, Constants.DELETE_AADHAAR_REFERENCE, meta.getDescription(), Constants.FAILED);
                throw new VaultException(meta);
            } else {
                logger.error("Remove Aadhaar vault request is unsuccessful :: {}", ExceptionUtils.getStackTrace(ex));
                auditUtil.doAudit(apptype, customerId, null, Constants.DELETE_AADHAAR_REFERENCE, ex.getMessage(), Constants.FAILED);
                throw new GenericException();
            }
        } catch (Exception e) {
            logger.error("Exception in remove aadhaar vault request :: {}", ExceptionUtils.getStackTrace(e));
            auditUtil.doAudit(apptype, customerId, null, Constants.DELETE_AADHAAR_REFERENCE, e.getMessage(), Constants.FAILED);
            throw new GenericException();
        }
    }

    public void validateAadhaarRemoveRequest(AadhaarVaultRequest aadhaarVaultRequest, String appType, String customerId) {
        if (StringUtils.isEmpty(appType)) {
            logger.error("AppType not valid with remove aadhaar request");
            throw new ClientSideValidationException(getErrorCodeForAadhaarRemoveRequest(), messageSource.getMessage("aadhaar.removal.request.apptype.error", null, Locale.ENGLISH));
        }
        if (StringUtils.isEmpty(customerId)) {
            logger.error("CustomerId not valid with remove aadhaar request");
            throw new ClientSideValidationException(getErrorCodeForAadhaarRemoveRequest(), messageSource.getMessage("aadhaar.removal.request.customerid.error", null, Locale.ENGLISH));
        }
        if (StringUtils.isEmpty(aadhaarVaultRequest.getReferenceKey())) {
            logger.error("ReferenceKey not valid with remove aadhaar request");
            throw new ClientSideValidationException(getErrorCodeForAadhaarRemoveRequest(), messageSource.getMessage("aadhaar.removal.request.referencekey.error", null, Locale.ENGLISH));
        }
    }

    private String getErrorCodeForAadhaarRemoveRequest(){
        return messageSource.getMessage("aadhaar.removal.validation.error.response.code", null, Locale.ENGLISH);
    }

    private Meta handleHttpClientErrorException(ObjectMapper objectMapper, RestClientException ex) {
        try {
            HttpClientErrorException exception = (HttpClientErrorException) ex;
            String errorResponseAsString = exception.getResponseBodyAsString();
            ResponseDTO errorResponse = objectMapper.readValue(errorResponseAsString, ResponseDTO.class);
            return errorResponse.getMeta();
        } catch (Exception e) {
            logger.error("Exception while converting the errorResponse to AadhaarVaultResponse : {}", ExceptionUtils.getStackTrace(ex));
            throw new GenericException();
        }
    }

    public AadhaarVaultResponse getAadhaarNumber(AadhaarVaultRequest aadhaarVaultRequest) {
        AadhaarVaultResponse aadhaarVaultResponse = new AadhaarVaultResponse();
        ObjectMapper objectMapper = new ObjectMapper();
        try {
            String aadhaarVaultRequestString = objectMapper.writeValueAsString(aadhaarVaultRequest);
            Map<String, String> headersMap = new HashMap<>();
            headersMap.put(CONTENT_TYPE, APPLICATION_JSON);
            headersMap.put(ACCEPT, APPLICATION_JSON);
            headersMap.put(MESSAGE_SIGNATURE,
                    CipherUtil.encryptData(String.valueOf(aadhaarVaultRequestString.hashCode()), aadhaarVaultPassphrase));
            aadhaarVaultResponse = (AadhaarVaultResponse) httpUtil.handleRequest(aadhaarVaultBaseUrl.concat(vaultAadhaarContext),
                    aadhaarVaultRequestString, AadhaarVaultResponse.class, headersMap, HttpMethod.POST);
        } catch (ResourceAccessException ex) {
            logger.error("Potential timeout occurred in aadhaar vault request : {}", ExceptionUtils.getStackTrace(ex));
            throw new ThirdPartyApiException();
        } catch (RestClientException ex) {
            logger.error("Aadhaar vault request is unsuccessful.:  {}", ExceptionUtils.getStackTrace(ex));
            throw new GenericException();
        } catch (Exception e) {
            logger.error("Exception in aadhaar vault request : {}", ExceptionUtils.getStackTrace(e));
            throw new GenericException();
        }
        if (aadhaarVaultResponse == null || aadhaarVaultResponse.getResult() == null) {
            logger.error("Response is null from aadhaar vault");
            throw new GenericException();
        }
        if (aadhaarVaultResponse.getResult().getStatusCode().equalsIgnoreCase("uid-00")) {
            return aadhaarVaultResponse;
        } else {
            Meta meta = new Meta();
            meta.setCode(aadhaarVaultResponse.getResult().getStatusCode());
            meta.setDescription(aadhaarVaultResponse.getResult().getStatusDescription());
            meta.setStatus(Constants.FAILURE_STATUS);
            throw new VaultException(meta);
        }
    }

    // Verify UIDAI OTP
    @Override
    public ResponseDTO<AadhaarVerify> verifyAadhaarIdentity(Document request) throws UIDAIAadhaarVerifyException {
        ResponseDTO<AadhaarVerify> responseDTO = new ResponseDTO<>();
        boolean verifySuccess = false;
        int verifyCount = 0;
        Identities identity = null;
        String aadhaarNumber = "";
        String responseCode = Constants.TECHNICAL_ISSUE_CODE;
        String responseMsg = Constants.TECHNICAL_ISSUE_MSG;
        DocumentAuditLog documentAuditLog = new DocumentAuditLog();
        try {
            identity = identitiesRepository.findOne(request.getId());
            if (identity == null) {
                throw new AadharVerificationException();
            }
            verifyCount = identity.getVerifyCount();

            //Getting reference number or encrypted VID
            String docReferenceNumber = identity.getDocNumber();
            aadhaarNumber = docReferenceNumber;
            request.setUserIdentifierType(identity.getUserIdentifierType());
            request.setDocNumber(docReferenceNumber);
            if (verifyCount >= maxVerifyCount) {
                throw new VerifyAadhaarOTPRequestLimitExceededException();
            }
            String docOriginalNum = null;
            if (CommonUtil.isAadhaarRequest(request)) {
                //Generate Aadhaar number from Vault
                docOriginalNum = CommonUtil.getAadhaarNumberFromReferenceNumber(request, aadhaarService, environment);
            } else {
                docOriginalNum = CommonUtil.decryptData(identity.getDocNumber(), identity.getMobileNumber());
            }
            aadhaarNumber = docOriginalNum;

            String uniqueDeviceCode = CommonUtil.getValueByDefault(request.getUniqueDeviceCode(), defaultDeviceCode);
            ValidateAadharOTPData getUserAadhaarProfileReqMsg = validationUtil.getAadhaarProfileRequest(identity, residentConsent,
                    printFormatRequest, localLangRequired, docOriginalNum, request.getVerificationToken(), uniqueDeviceCode);

            String requestString = CommonUtil.convertToXMLInJAXB(getUserAadhaarProfileReqMsg, ValidateAadharOTPData.class);
            String responseString = null;
            if (request.getMobile() == null || request.getMobile().isEmpty()) {
                request.setMobile(identity.getMobileNumber());
            }
            ValidateAadharOTPDataResponse getAadhaarProfileResponse = null;
            request.setDocReferenceNumber(identity.getDocNumber());
            documentAuditLog = ValidationUtil.createDocumentAuditLogForRequest(request, documentAuditLog);
            documentAuditRepository.save(documentAuditLog);
            Map<String, String> headersMap = new HashMap<>();
            headersMap.put("Authorization", "Basic dWlkYWlCYW5rOlVpREBpQDMyMQ==");
            headersMap.put(CONTENT_TYPE, "application/xml");
            responseString = httpUtil.sendRequest(otpVerifyUrl, requestString, String.class, headersMap, HttpMethod.POST, MediaType.APPLICATION_XML);
            getAadhaarProfileResponse = CommonUtil.convertToObjectFromXMLInJackson(responseString, ValidateAadharOTPDataResponse.class);
            if(logger.isDebugEnabled()) {
                CommonUtil.encryptAndPrint(Level.DEBUG, "AadhaarProfile response ", getAadhaarProfileResponse, key);
            }
            if(null != getAadhaarProfileResponse && null != getAadhaarProfileResponse.getDataArea() && null != getAadhaarProfileResponse.getDataArea().getAadharProfileResponse()) {
            	responseCode = getAadhaarProfileResponse.getDataArea().getAadharProfileResponse().getResponseCode();
                responseMsg = getAadhaarProfileResponse.getDataArea().getAadharProfileResponse().getStatus().getStatusDescription();
                
                // kibana loging
                getAadharProfileResponseKibanaLogging(getAadhaarProfileResponse, request.getChannel()); 
            	
            } else {
            	logger.info("Improper Aadhaar Profile Response");
            }
            verifySuccess = ValidationUtil.getAadhaarProfileStatus(getAadhaarProfileResponse, errorCode);
            documentAuditLog = ValidationUtil.updateVerifyDocumentAuditLog(getAadhaarProfileResponse, documentAuditLog, verifySuccess);
            AadhaarVerify aadhaarVerify = ValidationUtil.getAadhaarProfileResponse(getAadhaarProfileResponse);
            aadhaarVerify.setTransactionId(request.getId());
            MDC.put(Constants.TRANSACTION_ID, request.getId() != null ? request.getId() : "");
            if (aadhaarVerify.getUserIdentifierType().equalsIgnoreCase(Constants.VID_IDENTIFIER)) {
                //VID response
                docReferenceNumber = CommonUtil.getAadhaarReferenceNumberFromAadhaar(aadhaarVerify.getAadhaarNumber(), aadhaarService, environment);
                docOriginalNum = aadhaarVerify.getAadhaarNumber();
                aadhaarVerify.setAadhaarNumber(docReferenceNumber);
                documentAuditLog.setDocNumber(Constants.NA);
            } else {
                //Aadhaar response
                aadhaarVerify.setAadhaarNumber(docReferenceNumber);
                documentAuditLog.setDocNumber(Constants.NA);
            }
            identity.setUidToken(aadhaarVerify.getUidToken());
            identity.setDocNumber(docReferenceNumber);
            Boolean isAadhaarVerifySaved = aadharVerifyDao.saveAadhaarVerifyResponse(aadhaarVerify);
            aadhaarVerify.setAadhaarNumber(docOriginalNum);
            aadhaarVerify.setAadharRefNumber(docReferenceNumber);
            Meta meta = new Meta();
            meta.setCode(messageSource.getMessage("verify.aadhaar.otp.success.response.code", null, null));
            meta.setDescription(messageSource.getMessage("verify.aadhaar.otp.success.response.msg", null, null));
            meta.setStatus(Constants.SUCCESS_STATUS);
            responseDTO.setData(aadhaarVerify);
            responseDTO.setMeta(meta);
        } catch (UIDAIAadhaarVerifyException e) {
        	throw e;
		} catch (Exception e) {
            logger.info("Exception while verifying Aaadhaar OTP: ");
            String message = messageSource.getMessage("verify.aadhaar.otp.uidai.failure.msg", null, Locale.ENGLISH);
            String id = messageSource.getMessage("verify.aadhaar.otp.uidai.failure.code", null, Locale.ENGLISH);
            throw new AadharVerificationException(message, e, id);
        } finally {
            try {
                if(identity!=null) {
                    if (verifySuccess) {
                        identity.setIsVerified(true);
                        identity.setGenCount(0);
                        identity.setVerifyCount(0);
                    } else {
                        identity.setIsVerified(false);
                        identity.setVerifyCount(++verifyCount);
                    }
                    identity.setModifyDate(LocalDateTime.now());
                    identitiesDao.updateIdentityInRepo(identity, verifySuccess);
                    logger.info("Storing data in identity");
                } else {
                    logger.info("Identity does not exist to update");
                }
                documentAuditRepository.save(documentAuditLog);
                logger.info("Storing data in documentAuditLog");
                if (verifySuccess) {
                	List<SMSTemplate> data = new ArrayList<>();
                	data.add(SMSTemplate.builder().key(Constants.MASKED_AADHAAR).val(CommonUtil.maskedAadhaarNumber(aadhaarNumber)).build());
                	data.add(SMSTemplate.builder().key(Constants.TIMESTAMP).val(LocalDateTime.now().toString()).build());
                	data.add(SMSTemplate.builder().key(Constants.RESPONSE_CODE).val(responseCode).build());
                	communicationService.sendCommunication(CommunicationType.ALERT_OTP_SUCCESS, request.getMobile(), data, request.getId(), request.getChannel());
                } else {
                	List<SMSTemplate> data = new ArrayList<>();
                	data.add(SMSTemplate.builder().key(Constants.MASKED_AADHAAR).val(CommonUtil.maskedAadhaarNumber(aadhaarNumber)).build());
                	data.add(SMSTemplate.builder().key(Constants.TIMESTAMP).val(LocalDateTime.now().toString()).build());
                	data.add(SMSTemplate.builder().key(Constants.RESPONSE_CODE).val(responseCode).build());
                	data.add(SMSTemplate.builder().key(Constants.RESPONSE_MSG).val(responseMsg).build());
                    communicationService.sendCommunication(CommunicationType.ALERT_OTP_FAILED, request.getMobile(), data, request.getId(), request.getChannel());
                    
                }
            }catch (Exception ex) {
                logger.info("Exception while storing data in identity and documentAudit : {}", ExceptionUtils.getStackTrace(ex));
            }
        }
        return responseDTO;
    }

    @Override
    public AUAResponse validateAUA(AUARequest auaRequest, String contentId) {
        AUAUidaiResponse auaUidaiResponse = new AUAUidaiResponse();
        AUAResponse auaResponse = new AUAResponse();
        Map<String, Object> map = new HashMap<>();
        String auaURL = environment.getProperty("config.aua.url.old");
        String responseCode = Constants.TECHNICAL_ISSUE_CODE;
        String responseMsg = Constants.TECHNICAL_ISSUE_MSG;
        map.put(Constants.CONTENT_ID, CommonUtil.generateUniqueId());
        map.put("userIdentifier", auaRequest.getUserIdentifier());
        map.put("userIdentifierType", auaRequest.getUserIdentifierType());
        map.put("aadhaarTimestamp", auaRequest.getAadhaarTimestamp());
        map.put("biometricData", auaRequest.getBiometricData());
        map.put("skey", auaRequest.getSkey());
        map.put("hmac", auaRequest.getHmac());
        logger.info("AUARequest with BiometricType={}",auaRequest.getBiometricType());
        if(auaRequest.getBiometricType() == null) {
            map.put(Constants.BIOMETRIC_TYPE, defaultBiometricType);
            logger.info("BiometricType is missing in AUARequest setting default BiometricType={}",map.get(Constants.BIOMETRIC_TYPE));
        }else if(isValidBiometricType(auaRequest.getBiometricType())){
            map.put(Constants.BIOMETRIC_TYPE, auaRequest.getBiometricType());
        }else{
            logger.error("The BiometricType={} is Invalid for AUA call, valid BiometricTypes are {}",auaRequest.getBiometricType(),validBiomerticTypes);
            throw new GenericException();
        }
        logger.info("Sending AUARequest with BiometricType={} to UIDAI",map.get(Constants.BIOMETRIC_TYPE));
        if (StringUtils.isNotBlank(auaRequest.getServiceCode())) {
            map.put("serviceCode", auaRequest.getServiceCode());
            if (auaRequest.getServiceCode().equals("2")) {
                auaURL = environment.getProperty("config.aua.url.new");
            }
        }
        if (StringUtils.isNotBlank(auaRequest.getCertificateIdentifier())) {
            map.put("certificateIdentifier", auaRequest.getCertificateIdentifier());
        }
        if (auaRequest.getDeviceDetails() != null) {
            DeviceDetails deviceDetails = auaRequest.getDeviceDetails();
            if (StringUtils.isNotBlank(deviceDetails.getRegisteredDeviceProviderCode())) {
                map.put("registeredDeviceProviderCode", deviceDetails.getRegisteredDeviceProviderCode());
            }
            if (StringUtils.isNotBlank(deviceDetails.getRegisteredDeviceServiceID())) {
                map.put("registeredDeviceServiceID", deviceDetails.getRegisteredDeviceServiceID());
            }
            if (StringUtils.isNotBlank(deviceDetails.getRegisteredDeviceServiceVersion())) {
                map.put("registeredDeviceServiceVersion", deviceDetails.getRegisteredDeviceServiceVersion());
            }
            if (StringUtils.isNotBlank(deviceDetails.getRegisteredDeviceCode())) {
                map.put("registeredDeviceCode", deviceDetails.getRegisteredDeviceCode());
            }
            if (StringUtils.isNotBlank(deviceDetails.getRegisteredDeviceModelID())) {
                map.put("registeredDeviceModelID", deviceDetails.getRegisteredDeviceModelID());
            }
            if (StringUtils.isNotBlank(deviceDetails.getRegisteredDevicePublicKeyCertificate())) {
                map.put("registeredDevicePublicKeyCertificate", deviceDetails.getRegisteredDevicePublicKeyCertificate());
            }
            if (StringUtils.isNotBlank(deviceDetails.getUniqueDeviceCode())) {
                map.put("uniqueDeviceCode", deviceDetails.getUniqueDeviceCode());
            }
        }
        try {
            String auaRequestString = CommonUtil.getFtlResponse("checkAadhaarRequest.ftl", map);

            String auaResponseString = httpUtil.postXmlRequest(auaRequestString, auaURL);
            CommonUtil.encryptAndPrint(Level.INFO, "AUA response", auaResponseString, key);
            auaUidaiResponse = CommonUtil.convertToObjectFromXMLInJackson(auaResponseString, AUAUidaiResponse.class);
            if (auaUidaiResponse == null) {
                logger.error("response null from AUA");
                throw new GenericException();
            } else {
                CommonUtil.encryptAndPrint(Level.INFO, "AUA object", auaUidaiResponse, key);
                MDC.put(Constants.TRANSACTION_ID, map.get(Constants.CONTENT_ID) != null ? (String) map.get(Constants.CONTENT_ID) : "");
                auaResponse.setStatusCode(auaUidaiResponse.getDataArea().getVerifyCustomerAadhaarDetailsResponse().getStatus().getStatusCode());
                auaResponse.setStatusDescription(auaUidaiResponse.getDataArea().getVerifyCustomerAadhaarDetailsResponse().getStatus().getStatusDescription());
                auaResponse.setResponseCode(auaUidaiResponse.getDataArea().getVerifyCustomerAadhaarDetailsResponse().getResponseCode());
                responseCode = auaUidaiResponse.getDataArea().getVerifyCustomerAadhaarDetailsResponse().getResponseCode();
                responseMsg = auaUidaiResponse.getDataArea().getVerifyCustomerAadhaarDetailsResponse().getStatus().getStatusDescription();
                auaResponse.setUidToken(auaUidaiResponse.getDataArea().getVerifyCustomerAadhaarDetailsResponse().getUidToken());
                
                // kibana loging
                triggerAUAKibanaLogging(auaUidaiResponse, auaRequest.getChannel());
                return auaResponse;
            }
        } catch (TemplateException | IOException e) {
            logger.error("xml parsing error : {}", ExceptionUtils.getStackTrace(e));
            throw new GenericException();
        } catch (ResourceAccessException ex) {
            logger.error("Potential timeout occurred in update nominee request");
            logger.error(Constants.ERROR, ExceptionUtils.getStackTrace(ex));
            throw new ThirdPartyApiException();
        } catch (RestClientException ex) {
            logger.error("AUA request is unsuccessful.");
            if (ex instanceof HttpClientErrorException) {
                HttpClientErrorException exception = (HttpClientErrorException) ex;
                String errorResponse = exception.getResponseBodyAsString();
                if (!StringUtils.isEmpty(errorResponse)) {
                    try {
                        auaUidaiResponse = CommonUtil.convertToObjectFromXMLInJackson(errorResponse, AUAUidaiResponse.class);
                        auaResponse.setStatusCode(auaUidaiResponse.getDataArea().getVerifyCustomerAadhaarDetailsResponse().getStatus().getStatusCode());
                        auaResponse.setStatusDescription(auaUidaiResponse.getDataArea().getVerifyCustomerAadhaarDetailsResponse().getStatus().getStatusDescription());
                        auaResponse.setResponseCode(auaUidaiResponse.getDataArea().getVerifyCustomerAadhaarDetailsResponse().getResponseCode());
                        auaResponse.setUidToken(auaUidaiResponse.getDataArea().getVerifyCustomerAadhaarDetailsResponse().getUidToken());
                        
                        triggerAUAKibanaLogging(auaUidaiResponse, auaRequest.getChannel()); 
                        
                        logger.error(Constants.AUA_ERROR_RESPONSE, errorResponse);
                    } catch (Exception e) {
                        logger.error(Constants.ERROR, ExceptionUtils.getStackTrace(ex));
                        throw new GenericException();
                    }
                    return auaResponse;
                } else {
                    logger.error(Constants.ERROR, ExceptionUtils.getStackTrace(ex));
                    throw new GenericException();
                }
            }  else  if (ex instanceof HttpServerErrorException) {
            	HttpServerErrorException exception = (HttpServerErrorException) ex;
                String errorResponse = exception.getResponseBodyAsString();
                if (!StringUtils.isEmpty(errorResponse)) {
                    try {
                        logger.error(Constants.AUA_ERROR_RESPONSE, errorResponse);
                        AUAUidaiResponse aadhaarProfileResponse = CommonUtil.convertToObjectFromXMLInJackson(errorResponse, AUAUidaiResponse.class);
                        auaResponse.setStatusCode(aadhaarProfileResponse.getDataArea().getVerifyCustomerAadhaarDetailsResponse().getStatus().getStatusCode());
                        auaResponse.setStatusDescription(aadhaarProfileResponse.getDataArea().getVerifyCustomerAadhaarDetailsResponse().getStatus().getStatusDescription());
                        auaResponse.setResponseCode(aadhaarProfileResponse.getDataArea().getVerifyCustomerAadhaarDetailsResponse().getResponseCode());
                        auaResponse.setUidToken(aadhaarProfileResponse.getDataArea().getVerifyCustomerAadhaarDetailsResponse().getUidToken());
                        
                        triggerAUAKibanaLogging(auaUidaiResponse, auaRequest.getChannel()); 
                        
                        logger.error(Constants.AUA_ERROR_RESPONSE, errorResponse);
                        return auaResponse;
                    } catch (Exception e) {
                        logger.error("AUA Error : {}", ExceptionUtils.getStackTrace(ex));
                        throw new GenericException();
                    }
                } else {
                    logger.error("AUA Error : {}", ExceptionUtils.getStackTrace(ex));
                    throw new GenericException();
                }
            }else {
                logger.error(Constants.ERROR, ExceptionUtils.getStackTrace(ex));
                throw new GenericException();
            }
        } finally {
        	if (null == auaResponse || null == auaResponse.getStatusCode() || !Constants.AUA_SUCCESS_CODE.equalsIgnoreCase(auaResponse.getStatusCode())) {
        		List<SMSTemplate> data = new ArrayList<>();
            	data.add(SMSTemplate.builder().key(Constants.MASKED_AADHAAR).val(CommonUtil.maskedAadhaarNumber(auaRequest.getUserIdentifier())).build());
            	data.add(SMSTemplate.builder().key(Constants.TIMESTAMP).val(LocalDateTime.now().toString()).build());
            	data.add(SMSTemplate.builder().key(Constants.RESPONSE_CODE).val(responseCode).build());
            	data.add(SMSTemplate.builder().key(Constants.RESPONSE_MSG).val(responseMsg).build());
                communicationService.sendCommunication(CommunicationType.ALERT_AUA_FAILED, auaRequest.getCustomerId(), data, contentId, auaRequest.getChannel());
            } else {
            	List<SMSTemplate> data = new ArrayList<>();
            	data.add(SMSTemplate.builder().key(Constants.MASKED_AADHAAR).val(CommonUtil.maskedAadhaarNumber(auaRequest.getUserIdentifier())).build());
            	data.add(SMSTemplate.builder().key(Constants.TIMESTAMP).val(LocalDateTime.now().toString()).build());
            	data.add(SMSTemplate.builder().key(Constants.RESPONSE_CODE).val(responseCode).build());
                communicationService.sendCommunication(CommunicationType.ALERT_AUA_SUCCESS, auaRequest.getCustomerId(), data, contentId, auaRequest.getChannel());
            }
		}
    }

    private boolean isValidBiometricType(String bioMetricType){
        return StringUtils.isNotBlank(bioMetricType) && validBiomerticTypes.stream()
                .anyMatch(validType-> validType.equals(bioMetricType));
    }

    private void triggerAUAKibanaLogging(AUAUidaiResponse auaUidaiResponse) {
		kibanaUtil.setKibanaId(Constants.UIDAI_STATUS_CODE);
		kibanaUtil.setKibanaId(auaUidaiResponse.getDataArea().getVerifyCustomerAadhaarDetailsResponse().getStatus().getStatusCode());
		
		kibanaUtil.setKibanaId(Constants.UIDAI_STATUS_DESCRIPTION);
		kibanaUtil.setKibanaId(auaUidaiResponse.getDataArea().getVerifyCustomerAadhaarDetailsResponse().getStatus().getStatusDescription());
		
		// Conditional check for transaction Id
		if(null != auaUidaiResponse.getEbmHeader() && null != auaUidaiResponse.getEbmHeader().getConsumerTransactionId()) {
			String uidaiTransactionId = auaUidaiResponse.getEbmHeader().getConsumerTransactionId();
			
			kibanaUtil.setKibanaId(Constants.CONSUMER_TRANSACTION_ID);
		 	kibanaUtil.setKibanaId(uidaiTransactionId);
		}
	}

    @Override
    public ResponseDTO<AadhaarVerify> getAadhaarDetailsKUA(KUARequest kuaRequest, String contentId) {
    	logger.info("Inside Aadhaar KUA Validate method AadhaarServiceImpl::getAadhaarDetailsKUA");
        ResponseDTO<AadhaarVerify> responseDTO = new ResponseDTO<>();
        boolean verifySuccess = false;
        String responseCode = Constants.TECHNICAL_ISSUE_CODE;
        String responseMsg = Constants.TECHNICAL_ISSUE_MSG;
        Map<String, Object> map = new HashMap<>();
        DocumentAuditLog documentAuditLog = null;
        String kuaURL = environment.getProperty("config.kua.url");
        map.put(Constants.CONTENT_ID, CommonUtil.generateUniqueId());
        map.put("userIdentifier", kuaRequest.getUserIdentifier());
        map.put("userIdentifierType", kuaRequest.getUserIdentifierType());
        map.put("aadhaarTimestamp", kuaRequest.getAadhaarTimestamp());
        map.put("biometricData", kuaRequest.getBiometricData());
        map.put("skey", kuaRequest.getSkey());
        map.put("hmac", kuaRequest.getHmac());
        logger.info("KUARequest with BiometricType={}",kuaRequest.getBiometricType());
        if(kuaRequest.getBiometricType() == null) {
            map.put(Constants.BIOMETRIC_TYPE, defaultBiometricType);
            logger.info("BiometricType is missing in KUARequest setting up default BiometricType={}",map.get(Constants.BIOMETRIC_TYPE));
        }else if(isValidBiometricType(kuaRequest.getBiometricType())){
            map.put(Constants.BIOMETRIC_TYPE, kuaRequest.getBiometricType());
        }else{
            logger.error("The BiometricType={} is Invalid for KUA call, valid BiometricTypes are {}",kuaRequest.getBiometricType(),validBiomerticTypes);
            throw new GenericException();
        }
        logger.info("Sending KUARequest with BiometricType={} to UIDAI",map.get(Constants.BIOMETRIC_TYPE));
        if (StringUtils.isNotBlank(kuaRequest.getServiceCode())) {
            map.put("serviceCode", kuaRequest.getServiceCode());
            if (kuaRequest.getServiceCode().equals("2")) {
                kuaURL = environment.getProperty("config.kua.url");
            }
        }
        if (StringUtils.isNotBlank(kuaRequest.getCertificateIdentifier())) {
            map.put("certificateIdentifier", kuaRequest.getCertificateIdentifier());
        }

        if (kuaRequest.getDeviceDetails() != null) {
            DeviceDetails deviceDetails = kuaRequest.getDeviceDetails();
            if (StringUtils.isNotBlank(deviceDetails.getRegisteredDeviceProviderCode())) {
                map.put("registeredDeviceProviderCode", deviceDetails.getRegisteredDeviceProviderCode());
            }
            if (StringUtils.isNotBlank(deviceDetails.getRegisteredDeviceServiceID())) {
                map.put("registeredDeviceServiceID", deviceDetails.getRegisteredDeviceServiceID());
            }
            if (StringUtils.isNotBlank(deviceDetails.getRegisteredDeviceServiceVersion())) {
                map.put("registeredDeviceServiceVersion", deviceDetails.getRegisteredDeviceServiceVersion());
            }
            if (StringUtils.isNotBlank(deviceDetails.getRegisteredDeviceCode())) {
                map.put("registeredDeviceCode", deviceDetails.getRegisteredDeviceCode());
            }
            if (StringUtils.isNotBlank(deviceDetails.getRegisteredDeviceModelID())) {
                map.put("registeredDeviceModelID", deviceDetails.getRegisteredDeviceModelID());
            }
            if (StringUtils.isNotBlank(deviceDetails.getRegisteredDevicePublicKeyCertificate())) {
                map.put("registeredDevicePublicKeyCertificate", deviceDetails.getRegisteredDevicePublicKeyCertificate());
            }
            if (StringUtils.isNotBlank(deviceDetails.getUniqueDeviceCode())) {
                map.put("uniqueDeviceCode", deviceDetails.getUniqueDeviceCode());
            }
        }
        String docReferenceNumber = null;
        try {
            String kuaRequestString = CommonUtil.getFtlResponse("KUAAadhaarRequest.ftl", map);
            CommonUtil.encryptAndPrint(Level.INFO, "KUA request", logMasker.patternReplace(kuaRequestString), key);
            String kuaResponseString = httpUtil.postXmlRequest(kuaRequestString, kuaURL);
            if (StringUtils.isEmpty(kuaResponseString)) {
                logger.error("response null from KUA");
                throw new GenericException();
            } else {
                if (logger.isDebugEnabled()) {
                    CommonUtil.encryptAndPrint(Level.INFO, "KUA response", logMasker.patternReplace(kuaResponseString), key);
                }

                ValidateAadharOTPDataResponse getAadhaarProfileResponse = null;

                documentAuditLog = new DocumentAuditLog();
                documentAuditLog = ValidationUtil.createDocumentAuditLogForRequestForKUA(kuaRequest, documentAuditLog);

                getAadhaarProfileResponse = CommonUtil.convertToObjectFromXMLInJackson(kuaResponseString, ValidateAadharOTPDataResponse.class);
                if (getAadhaarProfileResponse != null && getAadhaarProfileResponse.getDataArea() != null
                        && getAadhaarProfileResponse.getDataArea().getAadharProfileResponse() != null
                        && getAadhaarProfileResponse.getDataArea().getAadharProfileResponse().getStatus() != null
                        && getAadhaarProfileResponse.getDataArea().getAadharProfileResponse().getStatus().getStatusCode() != null) {
                    responseCode = getAadhaarProfileResponse.getDataArea().getAadharProfileResponse().getResponseCode();
                    responseMsg = getAadhaarProfileResponse.getDataArea().getAadharProfileResponse().getStatus().getStatusDescription();
                    
                    getAadharProfileResponseKibanaLogging(getAadhaarProfileResponse, kuaRequest.getChannel()); 
                    
                    logger.info("responseCode {} and responseMsg {}", responseCode, responseMsg);
                } else {
                    logger.info("improper responseCode {} and responseMsg {}", responseCode, responseMsg);
                }

                verifySuccess = ValidationUtil.getAadhaarProfileStatusForKUA(getAadhaarProfileResponse,
                        messageSource.getMessage("aadhaar.kua.failure.code", null, null));
                documentAuditLog = ValidationUtil.updateVerifyDocumentAuditLogForKUA(getAadhaarProfileResponse, documentAuditLog, verifySuccess);

                AadhaarVerify aadhaarVerify = ValidationUtil.getAadhaarProfileResponse(getAadhaarProfileResponse);
                aadhaarVerify.setTransactionId((String) map.get(Constants.CONTENT_ID));
                MDC.put(Constants.TRANSACTION_ID, map.get(Constants.CONTENT_ID) != null ? (String) map.get(Constants.CONTENT_ID) : "");
                docReferenceNumber = CommonUtil.getAadhaarReferenceNumberFromAadhaar(aadhaarVerify.getAadhaarNumber(), aadhaarService, environment);
                aadhaarVerify.setAadhaarNumber(docReferenceNumber);
                documentAuditLog.setDocNumber(Constants.NA);

                Meta meta = new Meta();
                meta.setCode(messageSource.getMessage("config.kua.success.code", null, null));
                meta.setDescription(messageSource.getMessage("config.kua.success.msg", null, null));
                meta.setStatus(Constants.SUCCESS_STATUS);
                responseDTO.setData(aadhaarVerify);
                responseDTO.setMeta(meta);
                return responseDTO;
            }
        } catch (AadhaarKUAVerifyException ex) {
            throw ex;
        } catch (TemplateException | IOException e) {
            logger.error("TemplateException | xml parsing error in KUA : {}", e);
            throw new GenericException();
        } catch (ResourceAccessException ex) {
            logger.error("Potential timeout occurred in update nominee request");
            logger.error("ResourceAccessException | Error : {}", ex);
            throw new ThirdPartyApiException();
        } catch (RestClientException ex) {
            logger.error("RestClientException | KUA request is unsuccessful.");
            if (ex instanceof HttpClientErrorException) {
                HttpClientErrorException exception = (HttpClientErrorException) ex;
                String errorResponse = exception.getResponseBodyAsString();
                if (!StringUtils.isEmpty(errorResponse)) {
                    try {
                        logger.error("RestClientException | KUA error response : {}", logMasker.patternReplace(errorResponse));
                        ValidateAadharOTPDataResponse aadhaarProfileResponse = CommonUtil.convertToObjectFromXMLInJackson(errorResponse, ValidateAadharOTPDataResponse.class);
                        Meta meta = new Meta();
                        meta.setCode( aadhaarProfileResponse.getDataArea().getAadharProfileResponse().getStatus().getStatusCode());
                        meta.setDescription( aadhaarProfileResponse.getDataArea().getAadharProfileResponse().getStatus().getStatusDescription());
                        meta.setStatus(Constants.FAILURE_STATUS);
                        responseDTO.setMeta(meta);
                        return responseDTO;
                    } catch (Exception e) {
                        logger.error(Constants.KUA_ERROR, ExceptionUtils.getStackTrace(ex));
                        throw new GenericException();
                    }
                } else {
                    logger.error(Constants.KUA_ERROR, ex);
                    throw new GenericException();
                }
            }  else  if (ex instanceof HttpServerErrorException) {
            	HttpServerErrorException exception = (HttpServerErrorException) ex;
                String errorResponse = exception.getResponseBodyAsString();
                if (!StringUtils.isEmpty(errorResponse)) {
                    try {
                        logger.error("HttpServerErrorException | KUA error response : {}", logMasker.patternReplace(errorResponse));
                        ValidateAadharOTPDataResponse aadhaarProfileResponse = CommonUtil.convertToObjectFromXMLInJackson(errorResponse, ValidateAadharOTPDataResponse.class);
                        Meta meta = new Meta();
                        meta.setCode( aadhaarProfileResponse.getDataArea().getAadharProfileResponse().getStatus().getStatusCode());
                        meta.setDescription( aadhaarProfileResponse.getDataArea().getAadharProfileResponse().getStatus().getStatusDescription());
                        meta.setStatus(Constants.FAILURE_STATUS);
                        responseDTO.setMeta(meta);
                        return responseDTO;
                    } catch (Exception e) {
                        logger.error(Constants.KUA_ERROR, ex);
                        throw new GenericException();
                    }
                } else {
                    logger.error(Constants.KUA_ERROR, ex);
                    throw new GenericException();
                }
            }else {
                logger.error(Constants.KUA_ERROR, ex);
                throw new GenericException();
            }
        } catch (Exception ex) {
            logger.error(Constants.KUA_ERROR, ex);
            throw new GenericException();
        } finally {
            try {
            	if (null == responseDTO || null == responseDTO.getMeta() || Constants.FAILURE_STATUS == responseDTO.getMeta().getStatus()) {
            		List<SMSTemplate> data = new ArrayList<>();
                	data.add(SMSTemplate.builder().key(Constants.MASKED_AADHAAR).val(CommonUtil.maskedAadhaarNumber(kuaRequest.getUserIdentifier())).build());
                	data.add(SMSTemplate.builder().key(Constants.TIMESTAMP).val(LocalDateTime.now().toString()).build());
                	data.add(SMSTemplate.builder().key(Constants.RESPONSE_CODE).val(responseCode).build());
                	data.add(SMSTemplate.builder().key(Constants.RESPONSE_MSG).val(responseMsg).build());
                    communicationService.sendCommunication(CommunicationType.ALERT_KUA_FAILED, kuaRequest.getMobile(), data, contentId, kuaRequest.getChannel());
                } else {
                	List<SMSTemplate> data = new ArrayList<>();
                	data.add(SMSTemplate.builder().key(Constants.MASKED_AADHAAR).val(CommonUtil.maskedAadhaarNumber(kuaRequest.getUserIdentifier())).build());
                	data.add(SMSTemplate.builder().key(Constants.TIMESTAMP).val(LocalDateTime.now().toString()).build());
                	data.add(SMSTemplate.builder().key(Constants.RESPONSE_CODE).val(responseCode).build());
                    communicationService.sendCommunication(CommunicationType.ALERT_KUA_SUCCESS, kuaRequest.getMobile(), data, contentId, kuaRequest.getChannel());
                }
            	if(null != documentAuditLog) {
            		documentAuditRepository.save(documentAuditLog);
            	} else {
            		documentAuditLog = new DocumentAuditLog();
                    documentAuditLog = ValidationUtil.createDocumentAuditLogForRequestForKUA(kuaRequest, documentAuditLog);
                    docReferenceNumber = CommonUtil.getAadhaarReferenceNumberFromAadhaar(kuaRequest.getUserIdentifier(), aadhaarService, environment);
                    documentAuditLog.setDocNumber(Constants.NA);
                    documentAuditLog.setTransactionStatus(TransactionStatus.AADHAAR_KUA_FAILURE);
                    documentAuditLog.setTransactionId(CommonUtil.generateUniqueId());
                    documentAuditRepository.save(documentAuditLog);
            	}
                logger.info("Storing data in documentAuditLog for KUA");
                logger.info("Exiting Aadhaar KUA Validate method AadhaarServiceImpl::getAadhaarDetailsKUA");
            } catch (Exception ex) {
                logger.info("Exception while storing data in documentAudit for KUA: {}", ex);
            }
        }
    }
    
 // Used for Verify-OTP call and KUA call.
    private void getAadharProfileResponseKibanaLogging(ValidateAadharOTPDataResponse getAadhaarProfileResponse, String channelValue) {
        // kibana loging
        kibanaUtil.setKibanaId(Constants.UIDAI_STATUS_CODE);
        kibanaUtil.setKibanaId(getAadhaarProfileResponse.getDataArea().getAadharProfileResponse().getStatus().getStatusCode());

        kibanaUtil.setKibanaId(Constants.UIDAI_STATUS_DESCRIPTION);
        kibanaUtil.setKibanaId(getAadhaarProfileResponse.getDataArea().getAadharProfileResponse().getStatus().getStatusDescription());

        // Conditional check for transaction Id
        if (null != getAadhaarProfileResponse.getEbmHeader() && null != getAadhaarProfileResponse.getEbmHeader().getConsumerTransactionId()) {
            String uidaiTransactionId = getAadhaarProfileResponse.getEbmHeader().getConsumerTransactionId();

            kibanaUtil.setKibanaId(Constants.CONSUMER_TRANSACTION_ID);
            kibanaUtil.setKibanaId(uidaiTransactionId);
        }

        kibanaUtil.setKibanaId(Constants.CHANNEL);
        kibanaUtil.setKibanaId(channelValue);

    }
    
    private void triggerAUAKibanaLogging(AUAUidaiResponse auaUidaiResponse, String channelValue) {
        kibanaUtil.setKibanaId(Constants.UIDAI_STATUS_CODE);
        kibanaUtil.setKibanaId(auaUidaiResponse.getDataArea().getVerifyCustomerAadhaarDetailsResponse().getStatus().getStatusCode());

        kibanaUtil.setKibanaId(Constants.UIDAI_STATUS_DESCRIPTION);
        kibanaUtil.setKibanaId(auaUidaiResponse.getDataArea().getVerifyCustomerAadhaarDetailsResponse().getStatus().getStatusDescription());

        // Conditional check for transaction Id
        if (null != auaUidaiResponse.getEbmHeader() && null != auaUidaiResponse.getEbmHeader().getConsumerTransactionId()) {
            String uidaiTransactionId = auaUidaiResponse.getEbmHeader().getConsumerTransactionId();

            kibanaUtil.setKibanaId(Constants.CONSUMER_TRANSACTION_ID);
            kibanaUtil.setKibanaId(uidaiTransactionId);
        }

        kibanaUtil.setKibanaId(Constants.CHANNEL);
        kibanaUtil.setKibanaId(channelValue);

    }
	
	private void triggerGenerateOtpKibanaLogging(Document request, GenerateAadharOTPDataResponse uidaiResponse) {
        // UIDAI Response kibana Logging
        if (null != uidaiResponse && null != uidaiResponse.getDataArea() && null != uidaiResponse.getDataArea().getGenerateAadhaarOTPResponse()) {

            logger.trace("[AadhaarServiceImpl.generateAadhaarOTP ] | Initiated kibana logging");
            GenerateAadhaarOTPResponse generateAadharProfileResponse = uidaiResponse.getDataArea().getGenerateAadhaarOTPResponse();

            String uidaiStatusCode = generateAadharProfileResponse.getStatus().getStatusCode();
            String uidaiStatusDescription = generateAadharProfileResponse.getStatus().getStatusDescription();

            kibanaUtil.setKibanaId(Constants.UIDAI_STATUS_CODE);
            kibanaUtil.setKibanaId(uidaiStatusCode);

            kibanaUtil.setKibanaId(Constants.UIDAI_STATUS_DESCRIPTION);
            kibanaUtil.setKibanaId(uidaiStatusDescription);

            kibanaUtil.setKibanaId(Constants.CHANNEL);
            kibanaUtil.setKibanaId(request.getChannel());

            // Conditional check for transaction Id
            if (null != uidaiResponse.getEbmHeader() && null != uidaiResponse.getEbmHeader().getConsumerTransactionId()) {
                String uidaiTransactionId = uidaiResponse.getEbmHeader().getConsumerTransactionId();

                kibanaUtil.setKibanaId(Constants.CONSUMER_TRANSACTION_ID);
                kibanaUtil.setKibanaId(uidaiTransactionId);
            }
            logger.trace("[AadhaarServiceImpl.generateAadhaarOTP ] | Completed kibana logging");
        }
    }
}