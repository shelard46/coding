package com.airtelbank.validation.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonRootName;

import lombok.*;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@Setter
@Getter
@Builder
@ToString
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_EMPTY)
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "dataArea")
@JsonRootName("dataArea")
@JsonIgnoreProperties(ignoreUnknown = true)
public class DataArea {
    @XmlElement(name = "getCustomerAadhaarOTPRequest")
    @JsonProperty("getCustomerAadhaarOTPRequest")
    private AadhaarInfo aadhaarInfo;    
    @XmlElement(name = "getCustomerAadhaarOTPResponse")
    @JsonProperty("getCustomerAadhaarOTPResponse")
    private GenerateAadhaarOTPResponse generateAadhaarOTPResponse;
    

    // Aadhaar verify
    @XmlElement(name = "getUserAadhaarProfileRequest")
    @JsonProperty("getUserAadhaarProfileRequest")
    private UserAadharProfile aadhaarProfileRequest;
    @XmlElement(name = "getUserAadharProfileResponse")
    @JsonProperty("getUserAadharProfileResponse")
    private UserAadharProfileResponse aadharProfileResponse;
    
    //Pan verify
    @XmlElement(name = "verifyCustomerPanDetailsRequest")
    @JsonProperty("verifyCustomerPanDetailsRequest")
    private VerifyPANDetailsRequest panRequestDetails;    
    @XmlElement(name = "verifyCustomerPanDetailsResponse")
    @JsonProperty("verifyCustomerPanDetailsResponse")
    private VerifyPANDetailsResponse panResponseDetails;
    
}
