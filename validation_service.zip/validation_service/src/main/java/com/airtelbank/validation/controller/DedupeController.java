package com.airtelbank.validation.controller;

import java.util.List;

import org.apache.log4j.MDC;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RestController;

import com.airtelbank.validation.constants.Constants;
import com.airtelbank.validation.dao.aerospike.PosidexCacheCustomerDao;
import com.airtelbank.validation.dao.aerospike.model.PosidexCacheCustomerDetails;
import com.airtelbank.validation.model.CBSDedupeRequest;
import com.airtelbank.validation.model.DedupeRequest;
import com.airtelbank.validation.model.DedupeResponse;
import com.airtelbank.validation.model.Meta;
import com.airtelbank.validation.model.ResponseDTO;
import com.airtelbank.validation.service.DedupeService;
import com.airtelbank.validation.util.CommonUtil;
import com.airtelbank.validation.util.RSAUtil;
import com.airtelbank.validation.util.ValidationUtils;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
public class DedupeController {
	
	@Value("${rsa.private.key}")
	private String privateKey;

	@Autowired
	private DedupeService dedupeService;

	@Autowired
	private ValidationUtils<DedupeRequest> validationUtils;

	@Autowired
	PosidexCacheCustomerDao posidexCacheCustomerDao;

	private static final Logger logger = LoggerFactory.getLogger(DedupeController.class);

	@PostMapping(value = "/api/v1/dedupe")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Successfully posted dedupe"),
			@ApiResponse(code = 401, message = "You are not authorized to view the resource"),
			@ApiResponse(code = 403, message = "Accessing the resource you were trying to reach is forbidden"),
			@ApiResponse(code = 404, message = "The resource you were trying to reach is not found") })
	@ApiOperation(value = "/api/v1/dedupe", response = DedupeController.class)
	@Deprecated
	public ResponseEntity<ResponseDTO<DedupeResponse>> dedupeCustomer(@RequestBody DedupeRequest dedupeRequest, @RequestHeader String contentId,
			@RequestHeader String channel) {
		CommonUtil.setMDCMap(contentId, channel, dedupeRequest.getCustomerId(), Constants.POSIDEX_DEDUPE);
		validationUtils.validate(dedupeRequest);
		ResponseDTO<DedupeResponse> response = dedupeService.fullKycDedupe(dedupeRequest,contentId);
		MDC.put(Constants.ERRORS, CommonUtil.setLoggerError(response.getMeta()));
		return ResponseEntity.ok().body(response);
	}
	
	@PostMapping(value = "/api/v2/dedupe")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Successfully posted dedupe"),
			@ApiResponse(code = 401, message = "You are not authorized to view the resource"),
			@ApiResponse(code = 403, message = "Accessing the resource you were trying to reach is forbidden"),
			@ApiResponse(code = 404, message = "The resource you were trying to reach is not found") })
	@ApiOperation(value = "/api/v2/dedupe", response = DedupeController.class)
	public ResponseEntity<ResponseDTO<DedupeResponse>> dedupeCustomerApi(@RequestBody DedupeRequest dedupeRequest, @RequestHeader String contentId,
			@RequestHeader String channel) {
		CommonUtil.setMDCMap(contentId, channel, dedupeRequest.getCustomerId(), Constants.POSIDEX_DEDUPE);
		validationUtils.validate(dedupeRequest);
		ResponseDTO<DedupeResponse> response = dedupeService.fullKycDedupe(dedupeRequest,contentId);
		MDC.put(Constants.ERRORS, CommonUtil.setLoggerError(response.getMeta()));
		return ResponseEntity.ok().body(response);
	}


	@PostMapping(value = "/api/v1/cbsDedupe")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Successfully posted dedupe"),
			@ApiResponse(code = 401, message = "You are not authorized to view the resource"),
			@ApiResponse(code = 403, message = "Accessing the resource you were trying to reach is forbidden"),
			@ApiResponse(code = 404, message = "The resource you were trying to reach is not found") })
	@ApiOperation(value = "/api/v1/cbsDedupe", response = DedupeController.class)
	@Deprecated
	public ResponseEntity<?> dedupeCustomer(@RequestBody CBSDedupeRequest dedupeRequest, @RequestHeader String contentId,
											@RequestHeader String channel) {
		logger.info("Calling CBS Dedupe for customerId {} and contentId {}", dedupeRequest.getMobileNo(), contentId);
		CommonUtil.setMDCMap(contentId, channel, dedupeRequest.getMobileNo(), Constants.CBS_DEDUPE);
		ResponseDTO<?> response = dedupeService.checkCbsDedupe(dedupeRequest,channel);
		MDC.put(Constants.ERRORS, CommonUtil.setLoggerError(response.getMeta()));
		return ResponseEntity.ok().body(response);
	}
	
	@PostMapping(value = "/api/v2/cbsDedupe")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Successfully posted dedupe"),
			@ApiResponse(code = 401, message = "You are not authorized to view the resource"),
			@ApiResponse(code = 403, message = "Accessing the resource you were trying to reach is forbidden"),
			@ApiResponse(code = 404, message = "The resource you were trying to reach is not found") })
	@ApiOperation(value = "/api/v2/cbsDedupe", response = DedupeController.class)
	public ResponseEntity<?> cbsDedupeCustomer(@RequestBody CBSDedupeRequest dedupeRequest, @RequestHeader String contentId,
											@RequestHeader String channel) {
		logger.info("Calling CBS Dedupe for customerId {} and contentId {}", dedupeRequest.getMobileNo(), contentId);
		CommonUtil.setMDCMap(contentId, channel, dedupeRequest.getMobileNo(), Constants.CBS_DEDUPE);
		ResponseDTO<?> response = dedupeService.checkCbsDedupe(dedupeRequest,channel);
		MDC.put(Constants.ERRORS, CommonUtil.setLoggerError(response.getMeta()));
		return ResponseEntity.ok().body(response);
	}
	
	@GetMapping(value = "/api/v1/dedupeForPoi/{poiNumber}")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Successfully posted dedupe"),
			@ApiResponse(code = 401, message = "You are not authorized to view the resource"),
			@ApiResponse(code = 403, message = "Accessing the resource you were trying to reach is forbidden"),
			@ApiResponse(code = 404, message = "The resource you were trying to reach is not found") })
	@ApiOperation(value = "/dedupeForPoi/{poiNumber}", response = DedupeController.class)
	@Deprecated
	public ResponseEntity<List<PosidexCacheCustomerDetails>> getDetailsFromAerospikeForPoiNumber(
			@PathVariable(value = "poiNumber") String poiNumber,
			@RequestHeader String contentId, 
			@RequestHeader String channel) {
		CommonUtil.setMDCMap(contentId, channel, null, Constants.POSIDEX_DEDUPE);
		List<PosidexCacheCustomerDetails> response = posidexCacheCustomerDao.getPosidexDataFromAeroForPoiNumber(poiNumber);
		if(null == response || response.isEmpty()) {
			MDC.put(Constants.ERRORS, CommonUtil.setLoggerError(Meta.builder().status(Constants.FAILURE_STATUS).build()));
		} else {
			MDC.put(Constants.ERRORS, CommonUtil.setLoggerError(Meta.builder().status(Constants.SUCCESS_STATUS).build()));
		}
		return ResponseEntity.ok().body(response);
	}
	
	@GetMapping(value = "/api/v2/dedupeForPoi")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Successfully posted dedupe"),
			@ApiResponse(code = 401, message = "You are not authorized to view the resource"),
			@ApiResponse(code = 403, message = "Accessing the resource you were trying to reach is forbidden"),
			@ApiResponse(code = 404, message = "The resource you were trying to reach is not found") })
	@ApiOperation(value = "/dedupeForPoi", response = DedupeController.class)
	public ResponseEntity<List<PosidexCacheCustomerDetails>> getPoiDetailsFromAerospike(
			@RequestHeader String contentId, 
			@RequestHeader String channel,
			@RequestHeader String poiNumber) {
		CommonUtil.setMDCMap(contentId, channel, null, Constants.POSIDEX_DEDUPE);
		poiNumber = RSAUtil.decrypt(poiNumber, RSAUtil.getPrivateKey(privateKey));
		List<PosidexCacheCustomerDetails> response = posidexCacheCustomerDao.getPosidexDataFromAeroForPoiNumber(poiNumber);
		if(null == response || response.isEmpty()) {
			MDC.put(Constants.ERRORS, CommonUtil.setLoggerError(Meta.builder().status(Constants.FAILURE_STATUS).build()));
		} else {
			MDC.put(Constants.ERRORS, CommonUtil.setLoggerError(Meta.builder().status(Constants.SUCCESS_STATUS).build()));
		}
		return ResponseEntity.ok().body(response);
	}
}