package com.airtelbank.validation.controller;

import java.util.Locale;

import org.apache.log4j.MDC;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.airtelbank.validation.constants.Constants;
import com.airtelbank.validation.dao.aerospike.model.ErrorCodeMapper;
import com.airtelbank.validation.model.Meta;
import com.airtelbank.validation.model.ResponseDTO;
import com.airtelbank.validation.service.ErrorCodeMapperService;
import com.airtelbank.validation.util.CommonUtil;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
@RequestMapping(value = {"/api/v1","/api/v2"})
public class ErrorCodeMapperController {

    @Autowired
    private MessageSource messageSource;

    @Autowired
    private ErrorCodeMapperService service;

    private static final Logger logger = LoggerFactory.getLogger(ErrorCodeMapperController.class);

    @GetMapping(value = "/errorCodeMapper/{apiName}/{errorCode}")
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "Successfully retrieved data"),
            @ApiResponse(code = 400, message = "Bad request"),
            @ApiResponse(code = 404, message = "The resource you were trying to reach is not found"),
            @ApiResponse(code = 500, message = "Internal Server Error ")
    })
    @ApiOperation(value = "/api/v1/errorCodeMapper/{apiName}/{errorCode}", response = ErrorCodeMapperController.class)
    public ResponseEntity<ResponseDTO<ErrorCodeMapper>> getErrorCodeEntry(@PathVariable(value = "errorCode") String errorCode,
                                                                          @PathVariable(value = "apiName") String apiName)
    {
        ResponseDTO<ErrorCodeMapper> responseDTO = new ResponseDTO<>();
		CommonUtil.setMDCMap(Constants.CONTENT_ID, Constants.CHANNEL, Constants.CUSTOMER_ID, Constants.GET_ERROR_CODE_MAPPING);
        ErrorCodeMapper accountResponse = service.getErrorCodeByApiNameAndOrgErrorCode(errorCode, apiName);
        Meta meta = new Meta();
        meta.setCode(messageSource.getMessage("config.error.mapper.success.code", null, Locale.ENGLISH));
        meta.setDescription(messageSource.getMessage("config.error.mapper.success.msg", null, Locale.ENGLISH));
        meta.setStatus(Constants.SUCCESS_STATUS);
        responseDTO.setMeta(meta);
        responseDTO.setData(accountResponse);
		MDC.put(Constants.ERRORS, CommonUtil.setLoggerError(responseDTO.getMeta()));
        return new ResponseEntity<>(responseDTO, HttpStatus.OK);
    }

    @PostMapping(value = "/errorCodeMapper")
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "Successfully retrieved data"),
            @ApiResponse(code = 201, message = "Successfully created"),
            @ApiResponse(code = 400, message = "Bad request"),
            @ApiResponse(code = 500, message = "Internal Server Error ")
    })
    @ApiOperation(value = "/api/v1/errorCodeMapper", response = ErrorCodeMapperController.class)
    public ResponseEntity<ResponseDTO<ErrorCodeMapper>> createNewErrorCode(@RequestBody ErrorCodeMapper errorCodeMapper) {
        logger.info("In Create error code mapper controller");
		CommonUtil.setMDCMap(Constants.CONTENT_ID, Constants.CHANNEL, Constants.CUSTOMER_ID, Constants.CREATE_ERROR_CODE_MAPPING);
        ResponseDTO<ErrorCodeMapper> responseDTO = new ResponseDTO<>();
        Meta meta = new Meta();
        boolean isSuccess = service.addNewErrorCode(errorCodeMapper);
        if (isSuccess) {
            meta.setCode(messageSource.getMessage("config.error.mapper.success.code", null, Locale.ENGLISH));
            meta.setDescription(messageSource.getMessage("config.error.mapper.success.msg", null, Locale.ENGLISH));
            meta.setStatus(Constants.SUCCESS_STATUS);
        } else {
            meta.setCode(messageSource.getMessage("config.error.mapper.failure.code", null, Locale.ENGLISH));
            meta.setDescription(messageSource.getMessage("config.error.mapper.failure.msg", null, Locale.ENGLISH));
            meta.setStatus(Constants.FAILURE_STATUS);
        }
        responseDTO.setMeta(meta);
		MDC.put(Constants.ERRORS, CommonUtil.setLoggerError(responseDTO.getMeta()));
        return new ResponseEntity<>(responseDTO, HttpStatus.CREATED);
    }

}
