package com.airtelbank.validation.dao.aerospike;

import java.util.List;

import org.springframework.data.aerospike.repository.AerospikeRepository;

import com.airtelbank.validation.dao.aerospike.model.Identities;

public interface IdentitiesRepository extends AerospikeRepository<Identities, String> {
	public List<Identities> findByMobileNumberAndDocNumber(String mobileNumber, String docNumber);
}
