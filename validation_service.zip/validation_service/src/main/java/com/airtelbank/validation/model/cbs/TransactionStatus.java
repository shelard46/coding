package com.airtelbank.validation.model.cbs;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonRootName;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlElementWrapper;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import java.util.List;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_EMPTY)
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "TransactionStatus")
@JsonRootName("TransactionStatus")
@JsonIgnoreProperties(ignoreUnknown = true)
public class TransactionStatus {

    @XmlElement(name = "ErrorCode")
    @JsonProperty("ErrorCode")
    private String ErrorCode;

    @XmlElement(name = "ExternalReferenceNo")
    @JsonProperty("ExternalReferenceNo")
    private String ExternalReferenceNo;

    @XmlElement(name = "IsOverriden")
    @JsonProperty("IsOverriden")
    private boolean IsOverriden;

    @XmlElement(name = "IsServiceChargeApplied")
    @JsonProperty("IsServiceChargeApplied")
    private boolean IsServiceChargeApplied;

    @XmlElement(name = "ReplyCode")
    @JsonProperty("ReplyCode")
    private Integer ReplyCode;

    @XmlElement(name = "ReplyText")
    @JsonProperty("ReplyText")
    private String ReplyText;

    @XmlElement(name = "ValidationErrors")
    @JsonProperty("ValidationErrors")
    @JacksonXmlElementWrapper(localName = "ValidationErrors", useWrapping = false)
    private List<ValidationErrors> ValidationErrorsList;

    @XmlElement(name = "ExtendedReply")
    @JsonProperty("ExtendedReply")
    private ExtendedReply ExtendedReply;

    public boolean isIsOverriden() {
        return IsOverriden;
    }

    public void setIsOverriden(boolean isOverriden) {
        IsOverriden = isOverriden;
    }

    public boolean isIsServiceChargeApplied() {
        return IsServiceChargeApplied;
    }

    public void setIsServiceChargeApplied(boolean isServiceChargeApplied) {
        IsServiceChargeApplied = isServiceChargeApplied;
    }
}
