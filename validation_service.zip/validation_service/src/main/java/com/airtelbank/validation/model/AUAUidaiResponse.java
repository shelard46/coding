package com.airtelbank.validation.model;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonRootName;

import lombok.ToString;


@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "verifyCustomerAadhaarDetailsResMsg")
@JsonRootName("verifyCustomerAadhaarDetailsResMsg")
@JsonIgnoreProperties(ignoreUnknown = true)
@ToString
public class AUAUidaiResponse {
	@XmlElement(name = "dataArea")
	@JsonProperty("dataArea")
	private DataAreaAUA dataArea;
	
	 @XmlElement(name = "ebmHeader")
	 @JsonProperty("ebmHeader")
	 private EbmHeader ebmHeader;

	public DataAreaAUA getDataArea() {
		return dataArea;
	}

	public void setDataArea(DataAreaAUA dataArea) {
		this.dataArea = dataArea;
	}

	public EbmHeader getEbmHeader() {
		return ebmHeader;
	}

	public void setEbmHeader(EbmHeader ebmHeader) {
		this.ebmHeader = ebmHeader;
	}

	 
}

