package com.airtelbank.validation.controller;

import org.apache.log4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RestController;

import com.airtelbank.validation.constants.Constants;
import com.airtelbank.validation.model.BlackoutRequest;
import com.airtelbank.validation.model.BlackoutResponse;
import com.airtelbank.validation.model.ResponseDTO;
import com.airtelbank.validation.service.BlackoutService;
import com.airtelbank.validation.util.CommonUtil;
import com.airtelbank.validation.util.RSAUtil;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
public class BlackoutController {
	
	@Value("${rsa.private.key}")
	private String privateKey;

	@Autowired private BlackoutService blackoutService;

	@GetMapping(value = "/api/v1/blackout/{customerId}")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Successfully retrieved customer data"),
			@ApiResponse(code = 201, message = "Successfully created"),
			@ApiResponse(code = 400, message = "Bad request"),
			@ApiResponse(code = 500, message = "Internal Server Error ") })
	@ApiOperation(value = "/blackout/{customerId}", response = BlackoutController.class)
	@Deprecated
	public ResponseEntity<ResponseDTO<BlackoutResponse>> getBlackout(
			@PathVariable String customerId,
			@RequestHeader String contentId,
			@RequestHeader String channel) {
		ResponseDTO<BlackoutResponse> response = null;
		CommonUtil.setMDCMap(contentId, channel, customerId, Constants.GET_BLACKOUT);
		if (log.isDebugEnabled()) {
			log.debug("Doing blackout check for ", customerId);
		}
		response = blackoutService.getBlackout(customerId);
		MDC.put(Constants.ERRORS, CommonUtil.setLoggerError(response.getMeta()));
		return ResponseEntity.ok().body(response);
	}
	
	@GetMapping(value = "/api/v2/blackout")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Successfully retrieved customer data"),
			@ApiResponse(code = 201, message = "Successfully created"),
			@ApiResponse(code = 400, message = "Bad request"),
			@ApiResponse(code = 500, message = "Internal Server Error ") })
	@ApiOperation(value = "/blackout/{customerId}", response = BlackoutController.class)
	public ResponseEntity<ResponseDTO<BlackoutResponse>> getBlackoutCustomer( 
			@RequestHeader String contentId,
			@RequestHeader String channel,
			@RequestHeader String customerId) {
		ResponseDTO<BlackoutResponse> response = null;
		CommonUtil.setMDCMap(contentId, channel, customerId, Constants.GET_BLACKOUT);
		customerId = RSAUtil.decrypt(customerId, RSAUtil.getPrivateKey(privateKey));
		if (log.isDebugEnabled()) {
			log.debug("Doing blackout check for ", customerId);
		}
		response = blackoutService.getBlackout(customerId);
		MDC.put(Constants.ERRORS, CommonUtil.setLoggerError(response.getMeta()));
		return ResponseEntity.ok().body(response);
	}

	@PostMapping(value = "/api/v1/blackout")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Successfully retrieved customer data"),
			@ApiResponse(code = 201, message = "Successfully created"),
			@ApiResponse(code = 400, message = "Bad request"),
			@ApiResponse(code = 500, message = "Internal Server Error ") })
	@ApiOperation(value = "/blackout", response = BlackoutController.class)
	public ResponseEntity<ResponseDTO<BlackoutResponse>> postBlackout(@RequestBody BlackoutRequest request, @RequestHeader String contentId,
			@RequestHeader String channel, BindingResult bindingResult) {
		ResponseDTO<BlackoutResponse> response = null;
		CommonUtil.setMDCMap(contentId, channel, request.getIdentifierValue(), Constants.ADD_BLACKOUT);
		if (log.isDebugEnabled()) {
			log.debug("Adding blackout details for ", request.toString());
		}
		String customerId = null;
		if(request.getIdentifierType().equalsIgnoreCase("MOBILE")) {
			customerId = CommonUtil.trimCustomerId(request.getIdentifierValue());
			request.setIdentifierValue(customerId);
		}
		response = blackoutService.postBlackout(request);
		MDC.put(Constants.ERRORS, CommonUtil.setLoggerError(response.getMeta()));
		return ResponseEntity.ok().body(response);
	}
	
	@PostMapping(value = "/api/v2/blackout")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Successfully retrieved customer data"),
			@ApiResponse(code = 201, message = "Successfully created"),
			@ApiResponse(code = 400, message = "Bad request"),
			@ApiResponse(code = 500, message = "Internal Server Error ") })
	@ApiOperation(value = "/blackout", response = BlackoutController.class)
	public ResponseEntity<ResponseDTO<BlackoutResponse>> postBlackoutCustomer(@RequestBody BlackoutRequest request, @RequestHeader String contentId,
			@RequestHeader String channel, BindingResult bindingResult) {
		ResponseDTO<BlackoutResponse> response = null;
		CommonUtil.setMDCMap(contentId, channel, request.getIdentifierValue(), Constants.ADD_BLACKOUT);
		if (log.isDebugEnabled()) {
			log.debug("Adding blackout details for ", request.toString());
		}
		String customerId = null;
		if(request.getIdentifierType().equalsIgnoreCase("MOBILE")) {
			customerId = CommonUtil.trimCustomerId(request.getIdentifierValue());
			request.setIdentifierValue(customerId);
		}
		response = blackoutService.postBlackout(request);
		MDC.put(Constants.ERRORS, CommonUtil.setLoggerError(response.getMeta()));
		return ResponseEntity.ok().body(response);
	}
	
	
}
