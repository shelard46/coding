package com.airtelbank.validation.util;

import java.util.Locale;

import javax.xml.bind.JAXBElement;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.core.env.Environment;
import org.springframework.oxm.jaxb.Jaxb2Marshaller;
import org.springframework.stereotype.Component;
import org.springframework.web.client.ResourceAccessException;
import org.springframework.ws.client.core.support.WebServiceGatewaySupport;
import org.springframework.ws.soap.client.SoapFaultClientException;

import com.airtelbank.validation.exception.NameMatchSystemException;
import com.airtelbank.validation.model.posidex.customer.CustomerResponse;
import com.airtelbank.validation.model.posidex.namematch.NameRequest;
import com.airtelbank.validation.model.posidex.namematch.NameResult;
import com.airtelbank.validation.model.posidex.namematch.ObjectFactory;

@Component
public class NameMatchPosidexClient extends WebServiceGatewaySupport{
	
	private ObjectFactory objectFactory = new ObjectFactory();
	private static final Logger log = LoggerFactory.getLogger(NameMatchPosidexClient.class);
	@Autowired
    Environment environment;

    @Autowired
    private MessageSource messageSource;
	
	public NameMatchPosidexClient() {
		super();
		Jaxb2Marshaller marshaller = new Jaxb2Marshaller();
		marshaller.setContextPath("com.airtelbank.validation.model.posidex.namematch");
		getWebServiceTemplate().setMarshaller(marshaller);
		getWebServiceTemplate().setUnmarshaller(marshaller);
	}
	
	public NameResult nameMatch(NameRequest nameRequest, String posidexUrl, int posidexProfileId) {
		log.info("Calling nameMatch...");
		NameResult nameResult = null;
		
		log.info("Name Match Request request Id : {}" , nameRequest);
		
		JAXBElement<?> requestObj = objectFactory.createNameRequest(nameRequest);
		logger.info("sending request to posidex ...");
		if(log.isDebugEnabled()) {
			try {
				log.debug("name request : {}", CommonUtil.jsonObjectToString(nameRequest));
			}catch(Exception e) {
				logger.error("errro : " + e.getMessage());
			}
		}
		try {
			JAXBElement<?> responseObject = (JAXBElement<CustomerResponse>)getWebServiceTemplate().marshalSendAndReceive(posidexUrl,requestObj);
			nameResult = (NameResult)responseObject.getValue();
			if(log.isDebugEnabled()) {
				log.debug("name response : {}", CommonUtil.jsonObjectToString(nameResult));
			}
		} catch (ResourceAccessException e) {
			log.error("Timeout during Posidex request.");
			String errorMessage = messageSource.getMessage("config.dedupe.posidex.timeout.error.msg",null,Locale.ENGLISH);
			String errorCode = environment.getProperty("config.dedupe.posidex.timeout.error.code");
			throw new NameMatchSystemException(errorCode,errorMessage , e);
		} catch (SoapFaultClientException e) {
			log.error("ERROR while sending request to Posidex");
			String errorMessage = messageSource.getMessage("config.posidex.error.soap.msg",null,Locale.ENGLISH);
			String errorCode = environment.getProperty("config.posidex.error.soap.code");
			throw new NameMatchSystemException(errorCode,errorMessage , e);
		}
		if( nameResult == null) {
			String errorMessage = messageSource.getMessage("config.posidex.namematch.error.empty.msg",null,Locale.ENGLISH);
			String errorCode = environment.getProperty("config.posidex.namematch.error.empty.code");
			throw new NameMatchSystemException(errorCode, errorMessage);
		}
		logger.info("name match is done.");
		return nameResult;
	}
}
