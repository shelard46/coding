package com.airtelbank.validation.validator;

import javax.validation.constraints.NotBlank;

import javax.validation.Constraint;
import javax.validation.Payload;
import javax.validation.ReportAsSingleViolation;
import javax.validation.constraints.Pattern;
import java.lang.annotation.Documented;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

import static java.lang.annotation.ElementType.*;

@Target({METHOD, FIELD, ANNOTATION_TYPE, CONSTRUCTOR, PARAMETER})
@Retention(RetentionPolicy.RUNTIME)
@Documented
@NotBlank
@Pattern(regexp = "[0-9]{12}")
@ReportAsSingleViolation
@Constraint(validatedBy = {})
public @interface Aadhaar {
	
	String message() default "{invalid aadhaar number}";

	Class<?>[] groups() default {};

	Class<? extends Payload>[] payload() default {};

}
