package com.airtelbank.validation.config;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.ModelAndView;

import com.airtelbank.validation.constants.Constants;
import com.airtelbank.validation.util.CommonUtil;


@Component
public class LogInterceptor implements HandlerInterceptor{

	Logger log = LoggerFactory.getLogger(this.getClass());
	
	@Override
	public void afterCompletion(HttpServletRequest arg0, HttpServletResponse arg1, Object arg2, Exception arg3)
			throws Exception {
		log.info("Request Completed!");
		
	}

	@Override
	public void postHandle(HttpServletRequest arg0, HttpServletResponse arg1, Object arg2, ModelAndView arg3)
			throws Exception {
		log.info("Method executed");
		
	}

	@Override
	public boolean preHandle(HttpServletRequest request, HttpServletResponse arg1, Object arg2) throws Exception {
		log.info("Before process request");
		String contentId=request.getHeader(Constants.CONTENT_ID);	
		MDC.put(Constants.CONTENT_ID, contentId);
		String requestId=request.getRequestedSessionId();
		MDC.put(Constants.REQUEST_ID, requestId);
		MDC.put(Constants.CHANNEL, request.getHeader(Constants.CHANNEL));
		return true;
	}

}
