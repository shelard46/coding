package com.airtelbank.validation.model;

import lombok.*;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class KUAResponse {
    private String statusCode;
    private String statusDescription;
    private String responseCode;
    private String uidToken;
}
