package com.airtelbank.validation.service.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.airtelbank.validation.dao.aerospike.PosidexCacheCustomerDao;
import com.airtelbank.validation.dao.aerospike.model.PosidexCacheCustomerDetails;
import com.airtelbank.validation.service.PosidexCacheCustomerService;

@Service
public class PosidexCacheCustomerServiceImpl implements PosidexCacheCustomerService {

	@Autowired
	PosidexCacheCustomerDao posidexCacheCustomerDAO;
	
	private static final Logger logger = LoggerFactory.getLogger(PosidexCacheCustomerServiceImpl.class);
	
	@Override
	public PosidexCacheCustomerDetails getPosidexCacheCustomerDetails(String id) {
		// TODO Auto-generated method stub
		PosidexCacheCustomerDetails posidexCacheCustomerDetails= null;
		try {
		posidexCacheCustomerDetails = posidexCacheCustomerDAO.getPosidexDataAero(id);
		}catch(NullPointerException ex) {
			logger.error("No record found with id:{}",id);
		}
		return posidexCacheCustomerDetails;
	}

	@Override
	public void save(PosidexCacheCustomerDetails posidexCacheCustomerDetails) {
		// TODO Auto-generated method stub
	}

}
