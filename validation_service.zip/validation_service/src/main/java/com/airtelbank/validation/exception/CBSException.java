package com.airtelbank.validation.exception;

import com.airtelbank.validation.model.Meta;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.*;

@Setter
@Getter
@ToString
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class CBSException extends RuntimeException {
    private String id;
    private Meta meta;

    public CBSException(String id) {
        this.id = id;
    }

    public CBSException(String message, String id) {
        super(message);
        this.id = id;
    }

    public CBSException(String message, Throwable cause, String id) {
        super(message, cause);
        this.id = id;
    }

    public CBSException(Throwable cause, String id) {
        super(cause);
        this.id = id;
    }

    public CBSException(Meta meta) {
        this.meta = meta;
    }
}
