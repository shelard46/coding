package com.airtelbank.validation.constants;

public interface DocType {
	
	String AADHAAR = "AADHAAR";
	String PAN = "PAN";
	String DRIVING_LICENSE = "DRIVING_LICENSE";
	String NREGA_ID = "NREGA_ID";
	String PASSPORT = "PASSPORT";
	String VOTER_ID = "VOTER_ID";


	
	

	
	
}
