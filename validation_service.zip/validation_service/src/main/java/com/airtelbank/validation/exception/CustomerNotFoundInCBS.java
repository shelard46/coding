package com.airtelbank.validation.exception;

import com.airtelbank.validation.model.Meta;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.*;

@Setter
@Getter
@ToString
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class CustomerNotFoundInCBS extends RuntimeException {
    private String id;
    private Meta meta;

    public CustomerNotFoundInCBS(String message, String id) {
        super(message);
        this.id = id;
    }

    public CustomerNotFoundInCBS(String message, Throwable cause, String id) {
        super(message, cause);
        this.id = id;
    }

    public CustomerNotFoundInCBS(Throwable cause, String id) {
        super(cause);
        this.id = id;
    }

    public CustomerNotFoundInCBS(Meta meta) {
        this.meta = meta;
    }
}
