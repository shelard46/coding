package com.airtelbank.validation.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.*;

@Setter
@Getter
@Builder
@ToString
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class AadhaarVaultResponse {
	private String requestId;
	private String uid;
	private String referenceKey;
	private AadhaarVaultResponseResult result;
	private Meta meta;
}