package com.airtelbank.validation.util;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.MessageSource;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

import com.airtelbank.validation.constants.Constants;
import com.airtelbank.validation.dao.aerospike.PosidexCacheCustomerDao;
import com.airtelbank.validation.dao.aerospike.PosidexRulesDao;
import com.airtelbank.validation.dao.aerospike.model.PosidexCacheCustomerDetails;
import com.airtelbank.validation.dao.aerospike.model.PosidexRules;
import com.airtelbank.validation.exception.ThirdPartyApiException;
import com.airtelbank.validation.model.DedupeResponse;
import com.airtelbank.validation.model.posidex.customer.Customer;
import com.airtelbank.validation.model.posidex.customer.CustomerResponse;
import com.airtelbank.validation.model.posidex.customer.DemographicsResult;
import com.airtelbank.validation.service.PosidexCacheCustomerService;

@Component
public class RuleExecutor {

    private static Logger log = LoggerFactory.getLogger(RuleExecutor.class);

    @Autowired
    Environment environment;

    @Autowired
    PosidexCacheCustomerService posidexCacheCustomerService;

    @Autowired
    PosidexCacheCustomerDao posidexCacheCustomerDao;

    @Autowired
    PosidexRulesDao posidexRulesDao;

    @Value("${config.posidex.partner.apb.id}")
    private String apbPartnerID;

    @Value("${config.posidex.partner.hike.id}")
    private String hikePartnerID;

    @Value("${config.dedupe.create.code}")
    private String createCode;

    @Value("${config.dedupe.failure.code}")
    private String failureCode;

    @Value("${config.dedupe.reject.code}")
    private String rejectCode;

    @Value("${config.dedupe.create.action.code}")
    private String createWithActionCode;

    @Value("${config.dedupe.create.msg}")
    private String createMsg;

    @Value("${config.dedupe.reject.msg}")
    private String rejectMsg;

    @Value("${config.dedupe.create.action.msg}")
    private String createWithActionMsg;

    @Value("${config.dedupe.failure.msg}")
    private String failureMsg;

    @Autowired
    private MessageSource messageSource;

    public DedupeResponse applyRules(String action, CustomerResponse customerResponse, String poiType, String poiNumber, String accountType, String customerMobileNumber) {

        DedupeResponse dataAfterApplyRules = null;
        try {
            try {
                List<PosidexCacheCustomerDetails> listOfLocalPosidexCacheCustomers = posidexCacheCustomerDao.getPosidexDataFromAeroForPoiNumber(poiNumber);
                log.debug("listOfLocalPosidexCacheCustomers size : {}", (listOfLocalPosidexCacheCustomers != null ? listOfLocalPosidexCacheCustomers.size() : 0));
                if(listOfLocalPosidexCacheCustomers!=null) {
                    for (PosidexCacheCustomerDetails customer : listOfLocalPosidexCacheCustomers) {
                        String sourceType = customer.getSourceType();
                        String walletType = customer.getWalletType();
                        if (sourceType != null && walletType != null && sourceType.equalsIgnoreCase(apbPartnerID)) {
                        	if( Constants.WALLET_FKY.equalsIgnoreCase(walletType)) {
                        		log.info("Found FKY for requested POI Type : {}", poiType);
                        		dataAfterApplyRules = new DedupeResponse(null, null, null, null, rejectCode, messageSource.getMessage(Constants.DEDUPE_REJECT_MSG, null, Locale.ENGLISH), Constants.POI_NUMBER_POI_TYPE, Constants.FAILURE_STATUS);
                        		return dataAfterApplyRules;
                        	} else if( Constants.WALLET_MKYA.equalsIgnoreCase(walletType) && !customer.getSno().startsWith(customerMobileNumber)) {
                        		log.info("Found MKYA for requested POI Type : {}", poiType);
                        		dataAfterApplyRules = new DedupeResponse(null, null, null, null, rejectCode, messageSource.getMessage(Constants.DEDUPE_REJECT_MSG, null, Locale.ENGLISH), Constants.POI_NUMBER_POI_TYPE, Constants.FAILURE_STATUS);
                        		return dataAfterApplyRules;

							} else if (Constants.WALLET_LKY.equalsIgnoreCase(walletType) && !customer.getSno().startsWith(customerMobileNumber)) {
								//handling for LKY freeze
								log.info("getting lky for same poi and different mobile number in posidexCacheDetails");
								String custMobileFreeze = customer.getSno().substring(0,customer.getSno().indexOf(apbPartnerID));
								log.info("Customer: {} found for freeze in posidexCacheDetails.", custMobileFreeze);
								dataAfterApplyRules = new DedupeResponse(null, custMobileFreeze, walletType, null,
										createWithActionCode,
										messageSource.getMessage("config.dedupe.create.action.msg", null, Locale.ENGLISH),
										Constants.POI_NUMBER_POI_TYPE, Constants.SUCCESS_STATUS);
								return dataAfterApplyRules;

							}
                        } else  {
                            log.error("Customer id {} doesn't exist in PosidexCacheCustomerDetails in aerospike", customer.getCustomerId());
                        }
                    }
                }
            } catch (Exception e) {
                log.error("Exception while fetching data for customer from PosidexCacheCustomerDetails in aerospike  : {}", e.getMessage());
                throw e;
            }
         
            if (customerResponse.getCutomermatchcount().equals("0")) {
                dataAfterApplyRules = new DedupeResponse(null, null, null, null, createCode, messageSource.getMessage(Constants.DEDUPE_CREATE_MSG, null, Locale.ENGLISH), null, Constants.SUCCESS_STATUS);
                return dataAfterApplyRules;
            }

            String ruleName;
            int rulePriority;
            String ruleAction;
            Map<Integer, String> posidexMap = new HashMap<>();
            List<PosidexRules> posidexRules = posidexRulesDao.getRulesByAccountTypes(accountType);
            posidexRules.sort(Comparator.comparing(PosidexRules::getRulePriority));
            Map<String, List<Customer>> ruleWiseCustomers = filterCustomersByRules(customerResponse);

            for (PosidexRules rule : posidexRules) {
                rulePriority = rule.getRulePriority();
                ruleName = rule.getRuleName();
                ruleAction = rule.getAction();
                posidexMap.put(rulePriority, ruleName);
                List<Customer> customerList = ruleWiseCustomers.get(ruleName);
                if (customerList == null || customerList.isEmpty()) {
                    log.info("customer list empty for rule :{}", ruleName);
                    continue;
                }

                String walletType = null;
                String customerId = null;

                switch (ruleName) {
                    case Constants.NAME_DOB_PINCODE:
                        log.info("Applying Rule:{}", Constants.NAME_DOB_PINCODE);
                        Boolean isPoiSame = false;
                        Boolean isApb = false;
                        for (Customer customerObj : customerList) {
                            DemographicsResult demographics = customerObj.getDemographics();
                            log.info("demographics poi type :{} and source type :{}", demographics.getPoiType(), demographics.getSourceType());
                            log.info("request poi type :{} and source type :{}", poiType, apbPartnerID);

                            if (poiType.equalsIgnoreCase(demographics.getPoiType())) {
                                isPoiSame = true;
                            } else {
                                if (apbPartnerID.equalsIgnoreCase(demographics.getSourceType())) {
                                    isApb = true;
                                    break;
                                }
                            }
                        }
                        if (isPoiSame) {
                            dataAfterApplyRules = new DedupeResponse(null, null, null, ruleAction, createCode, messageSource.getMessage(Constants.CONFIG_DEDUPE_CREATE_MSG, null, Locale.ENGLISH), ruleName, Constants.SUCCESS_STATUS);
                        } else if (isApb) {
                            dataAfterApplyRules = new DedupeResponse(null, null, null, ruleAction, rejectCode, messageSource.getMessage("config.dedupe.reject.msg", null, Locale.ENGLISH), ruleName, Constants.FAILURE_STATUS);
                            return dataAfterApplyRules;
                        } else {
                            dataAfterApplyRules = new DedupeResponse(null, null, null, ruleAction, createCode, messageSource.getMessage(Constants.CONFIG_DEDUPE_CREATE_MSG, null, Locale.ENGLISH), ruleName, Constants.SUCCESS_STATUS);
                        }
                        break;

                    case Constants.POI_NUMBER_POI_TYPE:
                        log.info("Applying Rule:{}", Constants.POI_NUMBER_POI_TYPE);
                        Boolean isFky = false;
                        Boolean isLky = false;
                        Boolean isWalletTypePresent = false;
                        Customer customer = null;
                        for (Customer customerObj : customerList) {
                            DemographicsResult demographics = customerObj.getDemographics();
                            String walletTypePosidex = demographics.getWalletType();
                            if (walletTypePosidex == null || walletTypePosidex.isEmpty()) {
                                PosidexCacheCustomerDetails posidexCacheCustomerDetails = posidexCacheCustomerDao.getPosidexDataAero(customerObj.getContact().get(0).getCustMsisdn() + apbPartnerID);
                                if (posidexCacheCustomerDetails != null) {
                                    walletTypePosidex = posidexCacheCustomerDetails.getWalletType();
                                    if (!CommonUtil.isUpgradeWalletAction(action)) {
                                        isWalletTypePresent = true;
                                    }
                                } else {
                                    log.info("Wallet Type not found in Posidex as well as in Aerospike.");
                                    continue;
                                }
                            }
                            if (apbPartnerID.equalsIgnoreCase(demographics.getSourceType())) {

                                if (Constants.WALLET_FKY.equalsIgnoreCase(walletTypePosidex)) {
                                    isFky = true;
                                    isWalletTypePresent = true;
                                    break;
                                }
                                if (Constants.WALLET_LKY.equalsIgnoreCase(walletTypePosidex)) {
                                    isLky = true;
                                    customer = customerObj;
                                    walletType = walletTypePosidex;
                                    isWalletTypePresent = true;
                                }
                            }
                        }
                        if (!isWalletTypePresent && !CommonUtil.isUpgradeWalletAction(action)) {
                            dataAfterApplyRules = new DedupeResponse(null, null, null, ruleAction, createCode, messageSource.getMessage(Constants.CONFIG_DEDUPE_CREATE_MSG, null, Locale.ENGLISH), ruleName, Constants.SUCCESS_STATUS);
                        } else if (isFky) {
                            dataAfterApplyRules = new DedupeResponse(null, null, null, ruleAction, rejectCode, messageSource.getMessage("config.dedupe.reject.msg", null, Locale.ENGLISH), ruleName, Constants.FAILURE_STATUS);
                            return dataAfterApplyRules;
                        } else if (isLky) {
                            String id = customer.getContact().get(0).getCustMsisdn();
                            if(!id.equals(customerMobileNumber)) {
                            	customerId = id;
                            	dataAfterApplyRules = new DedupeResponse(customer, customerId, walletType, ruleAction, createWithActionCode, messageSource.getMessage("config.dedupe.create.action.msg", null, Locale.ENGLISH), ruleName, Constants.SUCCESS_STATUS);
                            	return dataAfterApplyRules;
                            }else {
                            	dataAfterApplyRules = new DedupeResponse(null, null, null, ruleAction, createCode, messageSource.getMessage(Constants.CONFIG_DEDUPE_CREATE_MSG, null, Locale.ENGLISH), ruleName, Constants.SUCCESS_STATUS);
                            }
                        } else {
                            dataAfterApplyRules = new DedupeResponse(null, null, null, ruleAction, createCode, messageSource.getMessage(Constants.CONFIG_DEDUPE_CREATE_MSG, null, Locale.ENGLISH), ruleName, Constants.SUCCESS_STATUS);
                        }
                        break;
                }
            }
        } catch (Exception e) {
            String errorMessage = messageSource.getMessage("config.dedupe.rules.failure.msg", null, Locale.ENGLISH);
            String errorCode = environment.getProperty("config.dedupe.rules.failure.code");
            throw new ThirdPartyApiException(errorMessage, errorCode, e);
        }

        if (dataAfterApplyRules == null) {
            dataAfterApplyRules = new DedupeResponse(null, null, null, null, createCode, messageSource.getMessage(Constants.CONFIG_DEDUPE_CREATE_MSG, null, Locale.ENGLISH), null, Constants.SUCCESS_STATUS);
        }
        return dataAfterApplyRules;
    }

    public Map<String, Object> setRuleDecision(Customer customer, String customerId, String walletType, String action, String errorCode, String message, String ruleName) {
        Map<String, Object> dataAfterApplyRules = new HashMap<>();
        dataAfterApplyRules.put(Constants.CUSTOMER_ID, customerId);
        dataAfterApplyRules.put(Constants.WALLET_TYPE, walletType);
        dataAfterApplyRules.put(Constants.CUSTOMER, customer);
        dataAfterApplyRules.put(Constants.ACTION, action);
        dataAfterApplyRules.put(Constants.ERROR_CODE, errorCode);
        dataAfterApplyRules.put(Constants.MESSAGE, message);
        dataAfterApplyRules.put(Constants.RULE_NAME, ruleName);
        return dataAfterApplyRules;
    }


    private Map<String, List<Customer>> filterCustomersByRules(CustomerResponse customerResponse) {
        log.info("Filtering Customers rulewise.");
        Map<String, List<Customer>> ruleWiseCustomers = new HashMap<>();
        List<Customer> posidexCustomers = customerResponse.getResults().getCustomerResults().getCustomer();

        for (Customer customer : posidexCustomers) {
            String[] rules = customer.getMatchRule().split(",");
            for (String rule : rules) {
                List<Customer> customers = ruleWiseCustomers.get(rule);
                if (customers == null)
                    customers = new ArrayList<>();

                customers.add(customer);
                ruleWiseCustomers.put(rule, customers);
            }
        }

        return ruleWiseCustomers;
    }
}
 