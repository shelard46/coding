package com.airtelbank.validation.model.cbs;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonRootName;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_EMPTY)
@XmlRootElement(name = "XfaceAccountDTO")
@XmlAccessorType(XmlAccessType.FIELD)
@JsonRootName("XfaceAccountDTO")
@JsonIgnoreProperties(ignoreUnknown = true)
public class XfaceAccountDTO {

    @XmlElement(name = "CustomerType")
    @JsonProperty("CustomerType")
    private String customerType;

    @XmlElement(name = "ProductCode")
    @JsonProperty("ProductCode")
    private String productCode;

    @XmlElement(name = "ProductCodeDescription")
    @JsonProperty("ProductCodeDescription")
    private String productCodeDescription;

    @XmlElement(name = "AccountNumber")
    @JsonProperty("AccountNumber")
    private String accountNumber;

    @XmlElement(name = "ProductType")
    @JsonProperty("ProductType")
    private String productType;

    @XmlElement(name = "AccountStatus")
    @JsonProperty("AccountStatus")
    private String accountStatus;

    @XmlElement(name = "AvailableBalance")
    @JsonProperty("AvailableBalance")
    private String availableBalance;

    @XmlElement(name = "HoldBalance")
    @JsonProperty("HoldBalance")
    private String holdBalance;

    @XmlElement(name = "NetBalance")
    @JsonProperty("NetBalance")
    private String netBalance;
}
