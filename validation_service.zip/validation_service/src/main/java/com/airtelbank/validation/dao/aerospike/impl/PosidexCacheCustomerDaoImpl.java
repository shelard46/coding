package com.airtelbank.validation.dao.aerospike.impl;

import com.aerospike.client.query.IndexType;
import com.aerospike.helper.query.Qualifier;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.data.aerospike.core.AerospikeTemplate;
import org.springframework.data.aerospike.repository.query.AerospikeCriteria;
import org.springframework.data.aerospike.repository.query.Query;
import org.springframework.stereotype.Repository;

import com.airtelbank.validation.dao.aerospike.PosidexCacheCustomerDao;
import com.airtelbank.validation.dao.aerospike.model.PosidexCacheCustomerDetails;
import com.airtelbank.validation.exception.AeroSpikeException;

import java.util.List;
import java.util.Locale;

@Repository
public class PosidexCacheCustomerDaoImpl implements PosidexCacheCustomerDao{
   
   @Autowired
   AerospikeTemplate aerospikeTemplate;
   
   @Autowired
   private MessageSource messageSource;

   @Override
   public PosidexCacheCustomerDetails getPosidexDataAero(String id) {
      try {
      PosidexCacheCustomerDetails posidexCacheCustomerDetails = aerospikeTemplate.findById(id, PosidexCacheCustomerDetails.class);
      return posidexCacheCustomerDetails;
      }catch (Exception e) {
         String message =messageSource.getMessage("config.dedupe.aerospike.failure.msg",null, Locale.ENGLISH);
         String errorCode = messageSource.getMessage("config.dedupe.aerospike.failure.code",null, Locale.ENGLISH);
         throw new AeroSpikeException(message, e, errorCode);
      }
   }

   @Override
   public List<PosidexCacheCustomerDetails> getPosidexDataFromAeroForPoiNumber(String poiNumber) {
      try {
         AerospikeCriteria criteria=new AerospikeCriteria("poiNumber", Qualifier.FilterOperation.EQ, true, com.aerospike.client.Value.get(poiNumber));
         Query query = new Query(criteria);
         if(!aerospikeTemplate.indexExists("poiNumberIndex"))
            aerospikeTemplate.createIndex(PosidexCacheCustomerDetails.class, "poiNumberIndex", "poiNumber", IndexType.STRING);
         return (List<PosidexCacheCustomerDetails>) aerospikeTemplate.find(query, PosidexCacheCustomerDetails.class);
      }catch (Exception e) {
         String message =messageSource.getMessage("config.dedupe.aerospike.failure.msg",null, Locale.ENGLISH);
         String errorCode = messageSource.getMessage("config.dedupe.aerospike.failure.code",null, Locale.ENGLISH);
         return null;
      }
   }
   
}