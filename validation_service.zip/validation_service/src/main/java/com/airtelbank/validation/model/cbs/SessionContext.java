package com.airtelbank.validation.model.cbs;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.beans.factory.annotation.Value;

import javax.xml.bind.annotation.*;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_EMPTY)
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "SessionContext")
@XmlType(propOrder = {"bankCode","channel","externalBatchNumber","externalReferenceNo","externalSystemAuditTrailNumber","localDateTimeText",
		"originalReferenceNo","overridenWarnings","postingDateText","serviceCode","sessionTicket","transactionBranch","userId","userReferenceNumber","valueDateText"})
public class SessionContext {
	
	@Value(value = "${config.cbs.bank.code}")
	@XmlElement(name = "BankCode")
	private String bankCode;
	
	@XmlElement(name = "Channel")
	private String channel;
	
	@XmlElement(name = "ExternalBatchNumber")
	private String externalBatchNumber;
	
	@XmlElement(name = "ExternalReferenceNo")
	private String externalReferenceNo;
	
	@XmlElement(name = "ExternalSystemAuditTrailNumber")
	private String externalSystemAuditTrailNumber;
	
	@XmlElement(name = "LocalDateTimeText")
	private String localDateTimeText;
			
	@XmlElement(name = "OriginalReferenceNo")
	private String originalReferenceNo;
	
	@XmlElement(name = "OverridenWarnings")
	private String overridenWarnings;
	
	@XmlElement(name = "PostingDateText")
	private String postingDateText;
	
	@XmlElement(name = "ServiceCode")
	private String serviceCode;
	
	@XmlElement(name = "SessionTicket")
	private String sessionTicket;
	
	@Value(value = "${config.cbs.transaction.branch}")
	@XmlElement(name = "TransactionBranch")
	private String transactionBranch;
	
	@XmlElement(name = "UserId")
	private String userId;
	
	@XmlElement(name = "UserReferenceNumber")
	private String userReferenceNumber;
	
	@XmlElement(name = "ValueDateText")
	private String valueDateText;
	
	public SessionContext(String serviceCode, String bankCode, String transactionBranch, String channel, String userId, String refNo) {
		this.serviceCode = serviceCode;
		this.bankCode = bankCode;
		this.transactionBranch = transactionBranch;
		this.channel = channel;
		this.userId = userId;
		this.externalReferenceNo = refNo;
	}
}
