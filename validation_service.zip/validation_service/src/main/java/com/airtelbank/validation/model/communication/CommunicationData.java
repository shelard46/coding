package com.airtelbank.validation.model.communication;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@Builder
@ToString
@NoArgsConstructor
@AllArgsConstructor
public class CommunicationData {
	
	private String custId;
	private String campaignName;
	private String max;
	private String menuId;
	private String frequency;
	private String type;
	private String circleName;
	private String mode;
	private String ref4;
	private String ref3;
	private String username;
	private String ref5;
	private int retryCount;
	private String ref2;
	private String ref1;
	private String langId;
	private String externalRefNo;
	List<SMSTemplate> tamplateDataModel;
	private String templateCode;
	private String customClassName;
	private String ucId;
	private String content;
	private String maskingRegex;
	private boolean deliveryReportRequired;
	private List<String> recipient;
	private String subject;
	private String sender;
	private int index;
	private String category;
	private String applicationCode;
	private boolean maskingRequired;
	private int maxRetryCount;
	private String applicationKey;
	private String priority;
	private String attachment;
	
}
