package com.airtelbank.validation.exception;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Setter
@Getter
@NoArgsConstructor
public class NameMatchException extends RuntimeException{
	String errorCode;
	String errorMessage;
	
	public NameMatchException(String id, String message) {
		this.errorCode = id;
		this.errorMessage = message;
	}
	
	public NameMatchException(String id, String message, Throwable t) {
		super(message, t);
		this.errorCode = id;
		this.errorMessage = message;
	}
	
	
}
