package com.airtelbank.validation.dao.aerospike.model;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class PincodeMasterCBS {
	private String pincode;
	private String city;
	private String state;
	private String circle;
	private String source;
	private String cod_cc_brn;
}
