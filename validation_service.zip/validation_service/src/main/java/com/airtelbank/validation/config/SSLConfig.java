package com.airtelbank.validation.config;

import org.apache.http.client.HttpClient;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.ssl.SSLContextBuilder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.client.ClientHttpRequestFactory;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.util.ResourceUtils;
import org.springframework.web.client.RestTemplate;

/**
 * Class provides beans for external communication over ssl.
 * 
 * In order to make ssl work, following properties need to be define in
 * environment. <br />
 * <strong>server.ssl.trust-store </strong>: location of trust store file <br />
 * <strong>server.ssl.trust-store-password </strong>: password of trust store
 * file <br />
 * <strong>server.ssl.key-store </strong>: password of key store file <br />
 * <strong>server.ssl.key-password </strong>: password of key store file <br />
 * <strong>app.ssl.enabled </strong>: Boolean value weather ssl is enabled for
 * externa system <br />
 * 
 * @author B0206676
 *
 */
@Configuration
public class SSLConfig {

	/*
	private static Logger logger = LoggerFactory.getLogger(SSLConfig.class);
	@Value("${server.ssl.trust-store:#{null}}")
	private String trustStoreLocation;

	@Value("${server.ssl.trust-store-password:#{null}}")
	private String trustStorePassPhrase;

	@Value("${server.ssl.key-store:#{null}}")
	private String keyStoreLocation;

	@Value("${server.ssl.key-password:#{null}}")
	private String keyStorePassPhrase;

	@Value("${app.ssl.enabled:false}")
	private boolean sslEnabled;
	
//	@Value("#{'${app.ssl.trusted.host}'.split(',')}")
//	private List<String> trustedHostList;


	

	@Bean
	public ClientHttpRequestFactory requestFactory() {
		HttpClient httpClient = null;
		if (sslEnabled) {
			try {
				
				SSLContextBuilder sslContextBuilder = SSLContextBuilder.create();
				
				if( keyStoreLocation != null && keyStorePassPhrase != null) {
					sslContextBuilder.loadKeyMaterial(ResourceUtils.getFile(keyStoreLocation), keyStorePassPhrase.toCharArray(),
							keyStorePassPhrase.toCharArray());
				}
				if( trustStoreLocation != null && trustStorePassPhrase != null) {
					sslContextBuilder.loadTrustMaterial(ResourceUtils.getFile(trustStoreLocation),
							trustStorePassPhrase.toCharArray());
					
					
				}
				
			//	SSLConnectionSocketFactory.getDefaultHostnameVerifier();
				
				//HostnameVerifier hostnameVerifier = (host,sslSession) -> { return trustedHostList != null &&  trustedHostList.contains(host);};
				javax.net.ssl.SSLContext sslContext = sslContextBuilder.build();

				RequestConfig requestConfig = RequestConfig.custom().setConnectionRequestTimeout(3000)
						.setConnectTimeout(3000).setSocketTimeout(3000).build();
				httpClient = HttpClients.custom().setSSLContext(sslContext).setDefaultRequestConfig(requestConfig)
						//.setSSLHostnameVerifier(hostnameVerifier)
						.build();
				
			
				

			} catch (Exception e) {
				logger.error(e.getMessage(),e);
			}
		} else {
			httpClient = HttpClients.createDefault();
		}

		ClientHttpRequestFactory clientHttpRequestFactory = new HttpComponentsClientHttpRequestFactory(httpClient);

		return clientHttpRequestFactory;
	}

	@Bean
	public RestTemplate restTemplate() {
		return new RestTemplate(requestFactory());
	}*/

}
