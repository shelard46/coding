package com.airtelbank.validation.service.impl;

import com.airtelbank.validation.constants.Constants;
import com.airtelbank.validation.model.BlacklistEntityResponse;
import com.airtelbank.validation.model.blacklist.BlacklistData;
import com.airtelbank.validation.model.blacklist.BlacklistEntity;
import com.airtelbank.validation.util.BlackListEntityUtil;
import org.apache.commons.lang3.StringUtils;
import org.elasticsearch.action.search.SearchResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Service;

import com.airtelbank.validation.exception.ThirdPartyApiException;
import com.airtelbank.validation.model.BlacklistRequest;
import com.airtelbank.validation.model.BlacklistResponse;
import com.airtelbank.validation.model.ResponseDTO;
import com.airtelbank.validation.model.blacklist.CustomerResponse;
import com.airtelbank.validation.service.BlacklistService;
import com.airtelbank.validation.util.BlackListClient;
import com.airtelbank.validation.util.CommonUtil;
import com.airtelbank.validation.util.RequestCreationUtil;

import java.util.List;

@Service
public class BlacklistServiceImpl implements BlacklistService {
	@Autowired
	private BlackListClient blacklistClient;
	@Autowired
	private MessageSource messageSource;
	@Autowired
	RequestCreationUtil requestCreationUtil;
	@Autowired
	BlackListEntityUtil blackListUtil;

	@Value("${config.posidex.blacklist.url}")
	private String posidexUrl;
	@Value("${config.posidex.blacklist.profile.id}")
	private int posidexProfileId;
	@Value("${config.posidex.blacklist.error.soap.code}")
	private String defaultBlackListErrorCode;

	private static final Logger logger = LoggerFactory.getLogger(BlacklistServiceImpl.class);

	@Override
	public ResponseDTO<BlacklistResponse> getCustomerBlacklistInfo(BlacklistRequest request, String contentId) {
		CustomerResponse customerResponse = null;
		BlacklistResponse blResponse = null;
		logger.info("Inside BlacklistServiceImpl::getCustomerBlacklistInfo for contentId: {}, customerId: {}", contentId, request.getCustomerId());
		try {
			customerResponse = blacklistClient.findBlacklistCustomers(request, posidexUrl, posidexProfileId, contentId);
			if (customerResponse == null) {
				String errorMessage = messageSource.getMessage("config.blacklist.error.soap.msg", null, null);
				throw new ThirdPartyApiException(defaultBlackListErrorCode, errorMessage);
			} else {
				blResponse = requestCreationUtil.transformResponseFromPosidex(customerResponse);
				logger.info("Successful Response from BlackList API for Transaction Id {}:"+blResponse.getRequestId());
			}
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
		}
		ResponseDTO<BlacklistResponse> responseDTO = new ResponseDTO<>(blResponse);
		responseDTO.setMeta(
				CommonUtil.createMeta(blResponse.getErrorCode(), blResponse.getMessage(), blResponse.getStatus()));
		blResponse.setErrorCode("");
		blResponse.setStatusFromPosidex(blResponse.getStatusFromPosidex());
		blResponse.setMessage(customerResponse.getMessage());
		responseDTO.setData(blResponse);
		return responseDTO;
	}

	@Override
	public ResponseDTO<BlacklistEntityResponse> getEntityBlacklistInfo(BlacklistEntity blRequest, String contentId) {
		BlacklistEntityResponse blacklistEntityResponse;
		SearchResponse searchResponse;
		List<BlacklistData> entities;
		int factor = 0;
		try {
			if (StringUtils.isBlank(blRequest.getName()) || StringUtils.isBlank(blRequest.getPan())) {
				blacklistEntityResponse = blackListUtil.getValidationFailureResponse();
				blacklistEntityResponse.setRequestId(contentId);
				return new ResponseDTO<>(blacklistEntityResponse);
			}
			if (StringUtils.isNotEmpty(blRequest.getPan())) {
				 searchResponse = blackListUtil.getSearchResponse(Constants.PAN.toLowerCase(), blRequest.getPan().toUpperCase());
				 entities = blackListUtil.getEntities(searchResponse, factor);
				 if (entities.size() > 0) {
				 	blacklistEntityResponse = blackListUtil.getSuccessResponse(entities, blRequest.getName());
					 blacklistEntityResponse.setRequestId(contentId);
					 return new ResponseDTO<>(blacklistEntityResponse);
				 }
			}
			String entityName = blRequest.getName().toLowerCase().replaceAll(Constants.ONLY_APLHANUMERIC,"");
			searchResponse = blackListUtil.getSearchResponse(Constants.NAME, entityName);
			factor = entityName.split(Constants.SPACE_SEPARATOR).length;
			entities = blackListUtil.getEntities(searchResponse, factor);
			if (entities.size() > 0) {
				blacklistEntityResponse = blackListUtil.getSuccessResponse(entities, blRequest.getName());
			} else {
				blacklistEntityResponse = blackListUtil.getFailureResponse();
			}
		} catch (Exception e) {
			logger.error("exception occurred while fetching data from elasticSearch for requestId {}: ",contentId, e);
			blacklistEntityResponse = blackListUtil.getErrorResponse();
		}
		blacklistEntityResponse.setRequestId(contentId);
		logger.info("Successful Response from BlackList API for Transaction Id {}",blacklistEntityResponse.getRequestId());
		return new ResponseDTO<>(blacklistEntityResponse);
	}
}