package com.airtelbank.validation.dao.aerospike.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.MessageSource;
import org.springframework.data.aerospike.core.AerospikeTemplate;
import org.springframework.stereotype.Repository;

import com.aerospike.client.policy.WritePolicy;
import com.airtelbank.validation.dao.aerospike.AadharVerifyDao;
import com.airtelbank.validation.dao.aerospike.model.AadhaarVerify;
import com.airtelbank.validation.exception.AeroSpikeException;

import java.util.Locale;

@Repository
public class AadharVerifyDaoImpl implements AadharVerifyDao{
	
	@Autowired
    AerospikeTemplate aerospikeTemplate;
    
    @Autowired
	private MessageSource messageSource;

    @Value("${config.aerospike.expiration}")
    public long expiration;

    @Value("${config.aerospike.expiration.no}")
    public long noExpiration;

    private static final Logger logger = LoggerFactory.getLogger(AadharVerifyDaoImpl.class);
    
	@Override
	public boolean saveAadhaarVerifyResponse(AadhaarVerify aadhaarVerify) {
		Boolean savedSuccessfully = false;
        WritePolicy writePolicy = new WritePolicy();
        writePolicy.expiration = (int) Math.min(noExpiration, Integer.MAX_VALUE);
        try {
            aerospikeTemplate.persist(aadhaarVerify, writePolicy);
            savedSuccessfully = true;
            return savedSuccessfully;
        } catch (Exception ex) {
            logger.info("Exception while adding Identity in Aerospike.");
            String message =messageSource.getMessage("config.dedupe.aerospike.failure.msg",null, Locale.ENGLISH);
			String id = messageSource.getMessage("config.dedupe.aerospike.failure.code",null,Locale.ENGLISH);;
			throw new AeroSpikeException(message, ex, id);
        }
	}

	@Override
	public AadhaarVerify getAadhaarVerifyResponse(String id) {
		try {
    		return aerospikeTemplate.findById(id, AadhaarVerify.class);
    	}catch (Exception e) {
    		String message =messageSource.getMessage("verify.aadhaar.otp.aerospike.failure.msg",null, Locale.ENGLISH);
			String errorCode = messageSource.getMessage("verify.aadhaar.otp.aerospike.failure.code",null, Locale.ENGLISH);
			throw new AeroSpikeException(message, e, errorCode);
    	}
	}

}
