package com.airtelbank.validation.exception;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import javax.validation.ConstraintViolation;
import javax.validation.ConstraintViolationException;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.ServletRequestBindingException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.client.ResourceAccessException;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;
import org.springframework.ws.client.WebServiceIOException;

import com.airtelbank.validation.constants.Constants;
import com.airtelbank.validation.dao.aerospike.model.ErrorCodeMapper;
import com.airtelbank.validation.model.CustomError;
import com.airtelbank.validation.model.LoggerModel;
import com.airtelbank.validation.model.Meta;
import com.airtelbank.validation.model.ResponseDTO;
import com.airtelbank.validation.service.ErrorCodeMapperService;
import com.airtelbank.validation.util.CommonUtil;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@ControllerAdvice
public class GlobalExceptionHandler extends ResponseEntityExceptionHandler {
	
	@Autowired private Environment environment;
	@Autowired private LoggerModel loggerModel;
	@Autowired private MessageSource messageSource;
	@Autowired private ErrorCodeMapperService errorCodeMapperService;

	@ExceptionHandler(value = { AeroSpikeException.class })
	protected ResponseEntity<Object> aeroSpikeExcetion(AeroSpikeException ex) {
		Meta meta = null;
		String errorCode = ex.getId();
		String errorMsg = ex.getMessage();
		if (StringUtils.isNotBlank(errorCode) && StringUtils.isNotBlank(errorMsg)) {
			meta = CommonUtil.createMeta(errorCode, errorMsg, Constants.FAILURE_STATUS);
		} else {
			meta = new Meta();
			meta.setCode(messageSource.getMessage("generate.aadhaar.otp.aerospike.error.code", null, Locale.ENGLISH));
			meta.setDescription(messageSource.getMessage("generate.aadhaar.otp.aerospike.error.msg", null, Locale.ENGLISH));
			meta.setStatus(Constants.FAILURE_STATUS);
		}
		ResponseDTO<?> error = new ResponseDTO<>();
		error.setMeta(meta);
		log.error("Exception Response DTO aeroSpikeExcetion {}", error);
		MDC.put(Constants.ERRORS, CommonUtil.setLoggerError(meta));
		return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(error);
	}

	@ExceptionHandler(value = { DBException.class })
	protected ResponseEntity<Object> dbException() {
		Meta meta = new Meta();
		meta.setCode(messageSource.getMessage("generate.aadhaar.otp.db.error.code", null, Locale.ENGLISH));
		meta.setDescription(messageSource.getMessage("generate.aadhaar.otp.db.error.msg", null, Locale.ENGLISH));
		meta.setStatus(Constants.FAILURE_STATUS);
		ResponseDTO<?> error = new ResponseDTO<>();
		error.setMeta(meta);
		log.error("Exception Response DTO dbException {}", error);
		MDC.put(Constants.ERRORS, CommonUtil.setLoggerError(meta));
		return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(error);
	}

	@ExceptionHandler(value = { ObjectConversionException.class })
	protected ResponseEntity<Object> objectConversion() {
		Meta meta = new Meta();
		meta.setCode(messageSource.getMessage("generate.aadhaar.otp.object.conversion.error.code", null, Locale.ENGLISH));
		meta.setDescription(messageSource.getMessage("generate.aadhaar.otp.object.conversion.error.msg", null, Locale.ENGLISH));
		meta.setStatus(Constants.FAILURE_STATUS);
		ResponseDTO<?> error = new ResponseDTO<>();
		error.setMeta(meta);
		log.error("Exception Response DTO objectConversion {}", error);
		MDC.put(Constants.ERRORS, CommonUtil.setLoggerError(meta));
		return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(error);
	}

	@ExceptionHandler(value = { ThirdPartyApiException.class })
	protected ResponseEntity<Object> handleTimeouts(ThirdPartyApiException ex) {
		Throwable throwable = ex.getCause();
		String errorCode = ex.getErrorCode();
		String errorMsg = ex.getErrorMessage();
		ResponseDTO<?> error = new ResponseDTO<>();
		Meta meta = new Meta();
		if (StringUtils.isNotBlank(errorCode) && StringUtils.isNotBlank(errorMsg)) {
			meta = CommonUtil.createMeta(errorCode, errorMsg, Constants.FAILURE_STATUS);
		} else if (throwable != null
				&& (throwable instanceof WebServiceIOException || throwable instanceof ResourceAccessException || throwable instanceof ThirdPartyApiException)) {
			meta.setCode(messageSource.getMessage("generate.aadhaar.otp.timeout.error.code", null, Locale.ENGLISH));
			meta.setDescription(messageSource.getMessage("generate.aadhaar.otp.timeout.error.msg", null, Locale.ENGLISH));
		} else {
			meta.setCode(messageSource.getMessage("generate.aadhaar.otp.third.party.error.code", null, Locale.ENGLISH));
			meta.setDescription(messageSource.getMessage("generate.aadhaar.otp.third.party.error.msg", null, Locale.ENGLISH));
		}
		meta.setStatus(Constants.FAILURE_STATUS);
		error.setMeta(meta);
		log.error("Exception Response DTO handleTimeouts {}", error);
		MDC.put(Constants.ERRORS, CommonUtil.setLoggerError(meta));
		return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(error);
	}

	@ExceptionHandler(value = { NameMatchException.class, NameMatchSystemException.class })
	protected ResponseEntity<Object> handleNameMatchException(NameMatchException ex) {
		String errorCode = ex.getErrorCode();
		String errorMsg = ex.getErrorMessage();
		ResponseDTO<?> error = new ResponseDTO<>();
		Meta meta = new Meta();
		if (StringUtils.isNotBlank(errorCode) && StringUtils.isNotBlank(errorMsg)) {
			meta = CommonUtil.createMeta(errorCode, errorMsg, Constants.FAILURE_STATUS);
		} else {
			meta.setCode(messageSource.getMessage("config.posidex.namematch.error.generic.code", null, Locale.ENGLISH));
			meta.setDescription(messageSource.getMessage("config.posidex.namematch.error.generic.msg", null, Locale.ENGLISH));
		}
		meta.setStatus(Constants.FAILURE_STATUS);
		error.setMeta(meta);
		log.error("Exception Response DTO handleNameMatchException {}", error);
		MDC.put(Constants.ERRORS, CommonUtil.setLoggerError(meta));
		if (ex instanceof NameMatchException)
			return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(error);
		else
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(error);
	}

	@ExceptionHandler(value = { ClientSideException.class })
	protected ResponseEntity<Object> badRequestException(ClientSideException ex) {
		Meta meta = new Meta();
		if (ex.getId() != null) {
			meta.setDescription(messageSource.getMessage(ex.getId(), null, Locale.ENGLISH));
		} else {
			meta.setDescription(messageSource.getMessage(Constants.AADHAR_OTP_ERROR_MSG, null, Locale.ENGLISH));
		}
		meta.setCode(messageSource.getMessage(Constants.AADHAR_OTP_ERROR_CODE, null, Locale.ENGLISH));
		meta.setStatus(Constants.FAILURE_STATUS);
		ResponseDTO<?> error = new ResponseDTO<>();
		error.setMeta(meta);
		log.error("Exception Response DTO badRequestException {}", error);
		MDC.put(Constants.ERRORS, CommonUtil.setLoggerError(meta));
		return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(error);
	}

	@ExceptionHandler(value = {ClientSideValidationException.class})
	protected ResponseEntity<?> handleClientSideValidationException(ClientSideValidationException ex) {
		ResponseDTO<?> responseDTO = new ResponseDTO<>();
		Meta meta = new Meta(ex.getErrorCode(), ex.getErrorMessage(), Constants.FAILURE_STATUS);
		responseDTO.setMeta(meta);
		log.error("ClientSideValidationException Response DTO :" + responseDTO);
		MDC.put(Constants.ERRORS, CommonUtil.setLoggerError(meta));
		return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(responseDTO);
	}

	@ExceptionHandler(value = { GenerateAadhaarOTPRequestLimitExceeded.class })
	protected ResponseEntity<Object> generateAadhaarOTPMaxCountExceeded() {
		Meta meta = new Meta();
		meta.setCode(messageSource.getMessage("generate.aadhaar.otp.max.retry.count.reached.code", null, Locale.ENGLISH));
		meta.setDescription(messageSource.getMessage("generate.aadhaar.otp.max.retry.count.reached.msg", null, Locale.ENGLISH));
		meta.setStatus(Constants.FAILURE_STATUS);
		ResponseDTO<?> error = new ResponseDTO<>();
		error.setMeta(meta);
		log.error("Exception Response DTO generateAadhaarOTPMaxCountExceeded {}" + error);
		MDC.put(Constants.ERRORS, CommonUtil.setLoggerError(meta));
		return ResponseEntity.status(HttpStatus.OK).body(error);
	}

	@ExceptionHandler(value = { VerifyAadhaarOTPRequestLimitExceededException.class })
	protected ResponseEntity<Object> verifyAadhaarOTPMaxCountExceeded() {
		Meta meta = new Meta();
		meta.setCode(messageSource.getMessage("verify.aadhaar.otp.max.retry.count.fail.code", null, Locale.ENGLISH));
		meta.setDescription(messageSource.getMessage("verify.aadhaar.otp.max.retry.count.fail.msg", null, Locale.ENGLISH));
		meta.setStatus(Constants.FAILURE_STATUS);
		ResponseDTO<?> error = new ResponseDTO<>();
		error.setMeta(meta);
		log.error("Exception Response DTO verifyAadhaarOTPMaxCountExceeded {}", error);
		MDC.put(Constants.ERRORS, CommonUtil.setLoggerError(meta));
		return ResponseEntity.status(HttpStatus.OK).body(error);
	}

	@ExceptionHandler(value = { AadharVerificationException.class })
	protected ResponseEntity<Object> handleAadhaarVerificationException(AadharVerificationException ex) {
		Meta meta = null;
		String errorCode = CommonUtil.getValueByDefault(ex.getId(),
				messageSource.getMessage("verify.aadhaar.otp.failed.response.code", null, Locale.ENGLISH));
		String errorMsg = CommonUtil.getValueByDefault(ex.getMessage(),
				messageSource.getMessage("verify.aadhaar.otp.failed.response.msg", null, Locale.ENGLISH));
		meta = CommonUtil.createMeta(errorCode, errorMsg, Constants.FAILURE_STATUS);
		ResponseDTO<?> error = new ResponseDTO<>();
		error.setMeta(meta);
		log.error("Exception Response DTO handleAadhaarVerificationException {}", error);
		MDC.put(Constants.ERRORS, CommonUtil.setLoggerError(meta));
		return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(error);
	}

	@ExceptionHandler(value = { VaultException.class })
	protected ResponseEntity<Object> handleAadhaarVaultException(VaultException ex) {
		ResponseDTO<?> error = new ResponseDTO<>();
		HttpStatus httpStatus;
		if (ex.getMeta() != null) {
			error.setMeta(ex.getMeta());
			httpStatus = HttpStatus.OK;
			MDC.put(Constants.ERRORS, CommonUtil.setLoggerError(ex.getMeta()));
		} else {
			Meta meta = new Meta();
			meta.setCode(messageSource.getMessage("vault.error.code", null, Locale.ENGLISH));
			meta.setDescription(messageSource.getMessage("vault.error.msg", null, Locale.ENGLISH));
			meta.setStatus(Constants.FAILURE_STATUS);
			error.setMeta(meta);
			log.error("Exception Response DTO handleAadhaarVaultException {}", error);
			MDC.put(Constants.ERRORS, CommonUtil.setLoggerError(meta));
			httpStatus = HttpStatus.INTERNAL_SERVER_ERROR;
		}
		return ResponseEntity.status(httpStatus).body(error);
	}

	@ExceptionHandler(value = { InvalidPanNumberException.class })
	protected ResponseEntity<Object> handleInvalidPanNumber() {
		Meta meta = new Meta();
		meta.setCode(messageSource.getMessage("pan.verification.error.code", null, Locale.ENGLISH));
		meta.setDescription(messageSource.getMessage("pan.verification.error.msg", null, Locale.ENGLISH));
		meta.setStatus(Constants.FAILURE_STATUS);
		ResponseDTO<?> error = new ResponseDTO<>();
		error.setMeta(meta);
		log.error("Exception Response DTO handleInvalidPanNumber {}", error);
		MDC.put(Constants.ERRORS, CommonUtil.setLoggerError(meta));
		return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(error);
	}


	@ExceptionHandler(value = { InvalidPanException.class })
	protected ResponseEntity<Object> handlePanNumber() {
		Meta meta = new Meta();
		meta.setCode(messageSource.getMessage("pan.verification.error.code", null, Locale.ENGLISH));
		meta.setDescription(messageSource.getMessage("pan.verification.invalid.error.msg", null, Locale.ENGLISH));
		meta.setStatus(Constants.FAILURE_STATUS);
		ResponseDTO<?> error = new ResponseDTO<>();
		error.setMeta(meta);
		log.error("Exception Response DTO handlePanNumber {}", error);
		MDC.put(Constants.ERRORS, CommonUtil.setLoggerError(meta));
		return ResponseEntity.status(HttpStatus.OK).body(error);
	}

	@ExceptionHandler(value = { ESBPanVerificationException.class })
	protected ResponseEntity<Object> handlePanVerificationException(ESBPanVerificationException e) {
		Meta meta = null;
		if (e.getMeta() != null) {
			meta = e.getMeta();
		}
		boolean isMetaSet = false;
		if (meta != null) {
			if (meta.getCode() != null) {
				ErrorCodeMapper errorCodeMapper = errorCodeMapperService.getErrorCodeByApiNameAndOrgErrorCode(
						meta.getCode(), environment.getProperty("config.pan.esb.error.code.mapper.api.name"));
				if (errorCodeMapper != null) {
					meta.setCode(errorCodeMapper.getErrorCode());
					meta.setDescription(messageSource.getMessage(errorCodeMapper.getErrorCode(), null, null));
					isMetaSet = true;
				}
			}

		} else {
			meta = new Meta();
		}
		if (!isMetaSet) {
			meta.setCode(messageSource.getMessage("pan.generic.error.code", null, Locale.ENGLISH));
			meta.setDescription(messageSource.getMessage("pan.generic.error.msg", null, Locale.ENGLISH));
		}
		meta.setStatus(Constants.FAILURE_STATUS);
		ResponseDTO<?> error = new ResponseDTO<>();
		error.setMeta(meta);
		log.error("Exception Response DTO handlePanVerificationException {}", error);
		MDC.put(Constants.ERRORS, CommonUtil.setLoggerError(meta));
		return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(error);
	}

	@ExceptionHandler(value = { ConstraintViolationException.class })
	protected ResponseEntity<ResponseDTO<?>> handleConstraintViolationException(ConstraintViolationException ex) {
		HttpStatus status = HttpStatus.BAD_REQUEST;
		ResponseDTO<?> dto = new ResponseDTO<>();
		Meta meta = new Meta();
		meta.setCode(messageSource.getMessage(Constants.AADHAR_OTP_ERROR_CODE, null, Locale.ENGLISH));
		meta.setDescription(messageSource.getMessage(Constants.AADHAR_OTP_ERROR_MSG, null, Locale.ENGLISH));
		meta.setStatus(Constants.FAILURE_STATUS);
		dto.setMeta(meta);
		List<CustomError> errors = new ArrayList<>();
		for (ConstraintViolation violation : ex.getConstraintViolations()) {
			CustomError error = new CustomError();
			error.setDescription(violation.getMessage());
			error.setField(violation.getPropertyPath().toString());
			errors.add(error);
		}
		dto.setErrors(errors);
		log.error("Exception Response DTO {} handleConstraintViolationException {}", dto, ex);
		MDC.put(Constants.ERRORS, CommonUtil.setLoggerError(meta));
		return ResponseEntity.status(status).body(dto);
	}

	@ExceptionHandler(value = { VerificationException.class })
	protected ResponseEntity<Object> handleVerificationException() {
		Meta meta = new Meta();
		meta.setCode(messageSource.getMessage("identity.verification.error.code", null, Locale.ENGLISH));
		meta.setDescription(messageSource.getMessage("identity.verification.error.msg", null, Locale.ENGLISH));
		meta.setStatus(Constants.FAILURE_STATUS);
		ResponseDTO<?> error = new ResponseDTO<>();
		error.setMeta(meta);
		log.error("Exception Response DTO handleVerificationException {}", error);
		MDC.put(Constants.ERRORS, CommonUtil.setLoggerError(meta));
		return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(error);
	}

	@Override
	protected ResponseEntity<Object> handleExceptionInternal(Exception exception, Object body, HttpHeaders headers,
			HttpStatus status, WebRequest request) {
		log.info("In handleExceptionInternal");
		ResponseDTO<?> responseDTO = new ResponseDTO<>();
		Meta meta = new Meta();
		if (exception instanceof MethodArgumentNotValidException) {
			log.info("validation error");

			List<CustomError> errors = new ArrayList<>();

			for (FieldError error : ((MethodArgumentNotValidException) exception).getBindingResult().getFieldErrors()) {
				errors.add(new CustomError(error.getField(), error.getDefaultMessage(), null));
			}

			meta.setCode(messageSource.getMessage(Constants.AADHAR_OTP_ERROR_CODE, null, Locale.ENGLISH));
			meta.setDescription(messageSource.getMessage(Constants.AADHAR_OTP_ERROR_MSG, null, Locale.ENGLISH));
			meta.setStatus(Constants.FAILURE_STATUS);
			responseDTO.setErrors(errors);
			responseDTO.setMeta(meta);
			MDC.put(Constants.ERRORS, CommonUtil.setLoggerError(meta));
			log.error("Exception Response DTO MethodArgumentNotValidException {}", responseDTO);
			return ResponseEntity.badRequest().body(responseDTO);
		} else if (exception instanceof ServletRequestBindingException) {
			log.info("headers missing");

			meta.setCode(messageSource.getMessage("config.headersMissing.errorCode", null, Locale.ENGLISH));
			meta.setDescription(messageSource.getMessage("config.headersMissing.errorMessage", null, Locale.ENGLISH));
			meta.setStatus(Constants.FAILURE_STATUS);
			responseDTO.setMeta(meta);
			MDC.put(Constants.ERRORS, CommonUtil.setLoggerError(meta));
			log.error("Exception Response DTO ServletRequestBindingException {}", responseDTO);
			loggerModel.getErrors().add(CommonUtil.setLoggerError(meta));
			return ResponseEntity.badRequest().body(responseDTO);
		} else {
			meta.setCode(messageSource.getMessage(Constants.GENERIC_ERROR_MSG, null, Locale.ENGLISH));
			meta.setDescription(messageSource.getMessage(Constants.CONFIG_GENERIC_ERROR_MSG, null, Locale.ENGLISH));
			meta.setStatus(Constants.FAILURE_STATUS);
			responseDTO.setMeta(meta);
			MDC.put(Constants.ERRORS, CommonUtil.setLoggerError(meta));
			log.error("Exception Response DTO {}", responseDTO);
			loggerModel.getErrors().add(CommonUtil.setLoggerError(meta));
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(responseDTO);
		}

	}

	@ExceptionHandler(value = { GenericException.class })
	protected ResponseEntity<Object> handleGenericException(GenericException ex) {
		HttpStatus status = HttpStatus.INTERNAL_SERVER_ERROR;
		Meta meta = new Meta();
		meta.setCode(messageSource.getMessage(Constants.GENERIC_ERROR_MSG, null, Locale.ENGLISH));
		meta.setDescription(messageSource.getMessage(Constants.CONFIG_GENERIC_ERROR_MSG, null, Locale.ENGLISH));
		meta.setStatus(Constants.FAILURE_STATUS);
		ResponseDTO<?> error = new ResponseDTO<>();
		error.setMeta(meta);
		log.error("Exception Response DTO :" + error);
		MDC.put(Constants.ERRORS, CommonUtil.setLoggerError(meta));
		return ResponseEntity.status(status).body(error);
	}

	@ExceptionHandler(value = { UIDAIException.class })
	protected ResponseEntity<Object> handleGenerateAadhaarOTPUIDAIError(UIDAIException ex) {
		Meta meta = new Meta();
		if (ex.getMeta() != null) {
			meta = ex.getMeta();
		} else {
			if (ex.getId() != null) {
				ErrorCodeMapper errorCodeMapper;
				errorCodeMapper = errorCodeMapperService.getErrorCodeByApiNameAndOrgErrorCode(ex.getId(),
						environment.getProperty("config.generate.error.code.mapper.api.name"));

				if (errorCodeMapper != null) {
					meta.setCode(errorCodeMapper.getErrorCode());
					meta.setDescription(messageSource.getMessage(errorCodeMapper.getErrorCode(), null, Locale.ENGLISH));
				} else {
					meta.setCode(messageSource.getMessage("generate.aadhaar.otp.uidai.failure.code", null, Locale.ENGLISH));
					meta.setDescription(messageSource.getMessage("generate.aadhaar.otp.uidai.failure.msg", null, Locale.ENGLISH));
				}
			} else {
				meta.setCode(messageSource.getMessage("generate.aadhaar.otp.uidai.failure.code", null, Locale.ENGLISH));
				meta.setDescription(messageSource.getMessage("generate.aadhaar.otp.uidai.failure.msg", null, Locale.ENGLISH));
			}

		}
		meta.setStatus(Constants.FAILURE_STATUS);
		ResponseDTO<?> error = new ResponseDTO<>();
		error.setMeta(meta);
		log.error(Constants.EXCEPTION_RESPONSE_DTO, error);
		MDC.put(Constants.ERRORS, CommonUtil.setLoggerError(meta));
		return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(error);
	}

	@ExceptionHandler(value = { UIDAIAadhaarVerifyException.class })
	protected ResponseEntity<Object> handleVerifyAadhaarOTPUIDAIError(UIDAIAadhaarVerifyException ex) {
		Meta meta = new Meta();
		if (ex.getMeta() != null) {
			meta = ex.getMeta();
		} else {
			if (log.isDebugEnabled()) {
				log.debug("id : {}", ex.getId());
			}
			if (ex.getId() != null) {
				ErrorCodeMapper errorCodeMapper;
				errorCodeMapper = errorCodeMapperService.getErrorCodeByApiNameAndOrgErrorCode(ex.getId(),
						environment.getProperty("config.verify.error.code.mapper.api.name"));
				if (log.isDebugEnabled()) {
					log.debug("aerospike message: {}", errorCodeMapper);
				}
				if (errorCodeMapper != null) {
					meta.setCode(errorCodeMapper.getErrorCode());
					meta.setDescription(messageSource.getMessage(errorCodeMapper.getErrorCode(), null, Locale.ENGLISH));
				} else {
					meta.setCode(messageSource.getMessage("verify.aadhaar.otp.uidai.failure.code", null, Locale.ENGLISH));
					meta.setDescription(messageSource.getMessage("verify.aadhaar.otp.uidai.failure.msg", null, Locale.ENGLISH));
				}
			} else {
				meta.setCode(messageSource.getMessage("verify.aadhaar.otp.uidai.failure.code", null, Locale.ENGLISH));
				meta.setDescription(messageSource.getMessage("verify.aadhaar.otp.uidai.failure.msg", null, Locale.ENGLISH));
			}

        }
        meta.setStatus(Constants.FAILURE_STATUS);
        ResponseDTO<?> error = new ResponseDTO<>();
        error.setMeta(meta);
        log.error(Constants.EXCEPTION_RESPONSE_DTO , error);
        MDC.put(Constants.ERRORS, CommonUtil.setLoggerError(meta));
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(error);
    }


    @ExceptionHandler(value = {CBSException.class})
    protected ResponseEntity<Object> handleCBSError(CBSException ex) {
        Meta meta = new Meta();
        if (ex.getMeta() != null) {
            meta = ex.getMeta();
        } else {
            if (ex.getId() != null) {
                meta.setDescription(ex.getId());
            } else {
                meta.setDescription(messageSource.getMessage(Constants.CONFIG_GENERIC_ERROR_MSG, null, Locale.ENGLISH));
            }
            meta.setCode(messageSource.getMessage(Constants.GENERIC_ERROR_MSG, null, Locale.ENGLISH));
            meta.setStatus(Constants.FAILURE_STATUS);
        }

        ResponseDTO<?> error = new ResponseDTO<>();
        error.setMeta(meta);
        log.error("Exception Response DTO :" + error);
        MDC.put(Constants.ERRORS, CommonUtil.setLoggerError(meta));
        return ResponseEntity.status(HttpStatus.OK).body(error);
    }

    @ExceptionHandler(value = {CustomerNotFoundInCBS.class})
    protected ResponseEntity<Object> customerNotFoundInCBS(CustomerNotFoundInCBS ex) {
        Meta meta = new Meta();
        meta.setDescription(messageSource.getMessage("config.cbs.dedupe.customer.not.found.msg", null, Locale.ENGLISH));
        meta.setCode(messageSource.getMessage("config.cbs.dedupe.customer.not.found.code", null, Locale.ENGLISH));
        meta.setStatus(Constants.FAILURE_STATUS);
        ResponseDTO<?> error = new ResponseDTO<>();
        error.setMeta(meta);
        log.info("Exception Response DTO {} ", error);
        MDC.put(Constants.ERRORS, CommonUtil.setLoggerError(meta));
        return ResponseEntity.status(HttpStatus.OK).body(error);
    }

    @ExceptionHandler(value = {AadhaarKUAVerifyException.class})
    protected ResponseEntity<Object> handleVerifyAadhaarKUAError(AadhaarKUAVerifyException ex) {
        Meta meta = new Meta();
        if (ex.getMeta() != null) {
            meta = ex.getMeta();
        } else {
            if(log.isDebugEnabled()) {
                log.debug("id : {}", ex.getId());
            }
            if (ex.getId() != null) {
                ErrorCodeMapper errorCodeMapper;
                errorCodeMapper = errorCodeMapperService.getErrorCodeByApiNameAndOrgErrorCode(ex.getId(), Constants.KUA_API_NAME);
                if(log.isDebugEnabled()) {
                    log.debug("aerospike message: {}", errorCodeMapper);
                }
                if (errorCodeMapper != null) {
                    meta.setCode(errorCodeMapper.getErrorCode());
                    meta.setDescription(errorCodeMapper.getErrorMsg());
                } else {
                    meta.setCode(messageSource.getMessage("aadhaar.kua.failure.code", null, Locale.ENGLISH));
                    meta.setDescription(messageSource.getMessage("aadhaar.kua.failure.msg", null, Locale.ENGLISH));
                }
            } else {
                meta.setCode(messageSource.getMessage("aadhaar.kua.failure.code", null, Locale.ENGLISH));
                meta.setDescription(messageSource.getMessage("aadhaar.kua.failure.msg", null, Locale.ENGLISH));
            }
        }
        meta.setStatus(Constants.FAILURE_STATUS);
        ResponseDTO<?> error = new ResponseDTO<>();
        error.setMeta(meta);
        log.error(Constants.EXCEPTION_RESPONSE_DTO , error);
        MDC.put(Constants.ERRORS, CommonUtil.setLoggerError(meta));
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(error);
    }
}
