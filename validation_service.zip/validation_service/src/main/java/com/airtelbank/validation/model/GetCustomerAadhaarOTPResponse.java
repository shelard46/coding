package com.airtelbank.validation.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.*;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@Setter
@Getter
@ToString
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_EMPTY)
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "getCustomerAadhaarOTPResponse")
@JsonIgnoreProperties(ignoreUnknown = true)
public class GetCustomerAadhaarOTPResponse {
    @XmlElement(name = "responseCode")
    private String responseCode;
    @XmlElement(name = "status")
    private Status status;
    @XmlElement(name = "responseTimeStamp")
    private String responseTimeStamp;
}
