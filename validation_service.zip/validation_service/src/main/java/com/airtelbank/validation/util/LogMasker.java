package com.airtelbank.validation.util;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.airtelbank.validation.config.LogMaskingConfiguration;

@Component
public class LogMasker {

	@Autowired private LogMaskingConfiguration logMaskingConfiguration;

	private static final String MASK = "****";
	private Pattern pattern = null;
	private String maskPattern = null;

	@PostConstruct
	public void setPatterns() {
		maskPattern = logMaskingConfiguration.getPattern();
		String regex = logMaskingConfiguration.getRegex();
		pattern = Pattern.compile(regex);
	}

	public String patternReplace(Object message) {
		if( message == null || message.toString() == null) {
			return String.valueOf("NULL");
		}else {
			return patternReplace(message.toString());
					
		}
	}
	
	public String patternReplace(String message) {
		try {
			message = message.replaceAll("\\s?:\\s?", ":");
			Matcher matcher = pattern.matcher(message);
			StringBuffer result = new StringBuffer();
			while (matcher.find()) {
				String replacement = "";
				String group = matcher.group(0);
				if (group != null) {
					if (group.contains("<") && group.contains("</") && group.contains(">")) {
						replacement = group.substring(0, group.indexOf('>') + 1) + MASK
								+ group.substring(group.lastIndexOf("</"));
					} else {
						String[] patternsToBeMasked = maskPattern.split("\\|");
						for (String pattern : patternsToBeMasked) {
							if (group.contains(pattern)) {
								char lastChar = group.charAt(group.length() - 1);
								group = group.subSequence(pattern.length(), group.length() - 1).toString();
								replacement = MASK;
								replacement = pattern + replacement + lastChar;
							}
						}
					}
				} else {
					replacement = MASK;
				}
				matcher.appendReplacement(result, replacement);
			}
			matcher.appendTail(result);
			return result.toString();
		} catch (Exception e) {
			return message;
		}
	}
}