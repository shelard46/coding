package com.airtelbank.validation.reader;

import java.util.List;

public interface IReader {
    <T> List<T> readFile(String filePath, Class<T> type) throws Exception;
}
