package com.airtelbank.validation.reader;

import com.airtelbank.validation.model.blacklist.BlacklistData;
import com.univocity.parsers.common.ParsingContext;
import com.univocity.parsers.common.ResultIterator;
import com.univocity.parsers.csv.CsvParserSettings;
import com.univocity.parsers.csv.CsvRoutines;
import com.univocity.parsers.csv.UnescapedQuoteHandling;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.io.Reader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.LinkedList;
import java.util.List;
import java.util.concurrent.atomic.AtomicBoolean;

@Component
public class CsvReaderBlacklist implements IReader{

    private static final Logger logger = LoggerFactory.getLogger(CsvReaderBlacklist.class);
    private AtomicBoolean isEntity = new AtomicBoolean(false);

    @Override
    public <T> List<T> readFile(String filePath, Class<T> type) throws Exception{
        Reader reader = null;
        try {
            reader = Files.newBufferedReader(Paths.get(filePath), StandardCharsets.UTF_16);
            List<BlacklistData> list = new LinkedList<>();

            CsvParserSettings settings = new CsvParserSettings();
            settings.getFormat().setLineSeparator("\n");
            settings.setIgnoreLeadingWhitespacesInQuotes(true);
            settings.setIgnoreTrailingWhitespaces(true);
            settings.setUnescapedQuoteHandling(UnescapedQuoteHandling.STOP_AT_DELIMITER);
            settings.selectIndexes(0,1,4,8,12,37,38,48,50);
            settings.setSkipEmptyLines(true);
            settings.setHeaderExtractionEnabled(false);
            settings.setEmptyValue("");

            CsvRoutines parser = new CsvRoutines(settings);
            ResultIterator<BlacklistData, ParsingContext> iterator = parser.iterate(BlacklistData.class, reader).iterator();

            while (iterator.hasNext()) {
                BlacklistData data = iterator.next();
                boolean isValid = isValidEntity(data);
                if (isValid) {
                    list.add(data);
                }

            }
            return (List<T>)list;

        } catch (Exception ex) {
            logger.error("Exception occurred while reading file: {} is: ", filePath, ex);
            throw ex;
        } finally {
            try {
                reader.close();
            } catch (IOException e) {
                logger.error("Exception occurred while closing reader for file: {}", filePath);
                throw e;
            }
        }
    }

    private boolean isValidEntity(BlacklistData data) {
        if (StringUtils.isNotEmpty(data.getName())) {
            if (StringUtils.isNotEmpty(data.getCharge()) && data.getCharge().contains("(SIE)")) {
                isEntity.set(true);
                logger.info("processing valid data ");
                return true;
            } else if (StringUtils.isEmpty(data.getCharge()) && isEntity.get()) {
                logger.info("processing valid data ");
                return true;
            } else {
                isEntity.set(false);
            }
        }
        return false;
    }
}
