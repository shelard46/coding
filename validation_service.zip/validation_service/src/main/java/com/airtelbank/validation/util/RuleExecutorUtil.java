package com.airtelbank.validation.util;

import com.airtelbank.validation.constants.Constants;
import com.airtelbank.validation.model.DedupeResponse;
import com.airtelbank.validation.model.posidex.customer.Customer;

public class RuleExecutorUtil {
	private static DedupeResponse commonResponse(String ruleName, String ruleAction, String errorCode, String message) {
		return DedupeResponse.builder().ruleName(ruleName).action(ruleAction).errorCode(errorCode).message(message)
				.build();
	}

	public static DedupeResponse dedupeSuccess(String ruleName, String ruleAction, String errorCode, String message) {
		DedupeResponse dedupeResponse = commonResponse(ruleName, ruleAction, errorCode, message);
		dedupeResponse.setStatus(Constants.SUCCESS_STATUS);
		return dedupeResponse;
	}

	public static DedupeResponse dedupeFailure(String ruleName, String ruleAction, String errorCode, String message) {
		DedupeResponse dedupeResponse = commonResponse(ruleName, ruleAction, errorCode, message);
		dedupeResponse.setStatus(Constants.FAILURE_STATUS);
		return dedupeResponse;
	}

	private static DedupeResponse commonResponse(Customer customer, String customerId, String walletType,
			String ruleName, String ruleAction, String errorCode, String message) {
		return DedupeResponse.builder().ruleName(ruleName).action(ruleAction).errorCode(errorCode).message(message)
				.customer(customer).customerId(customerId).walletType(walletType).build();
	}

	public static DedupeResponse dedupeSuccess(Customer customer, String customerId, String walletType, String ruleName,
			String ruleAction, String errorCode, String message) {
		DedupeResponse dedupeResponse = commonResponse(customer,customerId, walletType, ruleName, ruleAction, errorCode, message);
		dedupeResponse.setStatus(Constants.SUCCESS_STATUS);
		return dedupeResponse;
	}
	
	public static DedupeResponse dedupeFailure(Customer customer, String customerId, String walletType, String ruleName,
			String ruleAction, String errorCode, String message) {
		DedupeResponse dedupeResponse = commonResponse(customer,customerId, walletType, ruleName, ruleAction, errorCode, message);
		dedupeResponse.setStatus(Constants.FAILURE_STATUS);
		return dedupeResponse;
	}
}
