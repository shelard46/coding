package com.airtelbank.validation.exception;

import com.airtelbank.validation.model.Meta;
import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Setter
@Getter
@ToString
@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class ESBPanVerificationException extends RuntimeException {
    private Meta meta;

    public ESBPanVerificationException(Meta meta) {
    	super("Pan Verfication Exception ");
        this.meta = meta;
    }



}
