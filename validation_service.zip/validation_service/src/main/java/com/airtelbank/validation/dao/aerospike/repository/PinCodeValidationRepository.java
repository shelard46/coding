package com.airtelbank.validation.dao.aerospike.repository;

import org.springframework.data.aerospike.repository.AerospikeRepository;
import org.springframework.stereotype.Repository;

import com.airtelbank.validation.dao.aerospike.model.PinCode;

@Repository
public interface PinCodeValidationRepository extends AerospikeRepository<PinCode, String>{


}
