package com.airtelbank.validation.model;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonRootName;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;


@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_EMPTY)
@XmlRootElement(name = "getUserAadharProfileResponse")
@JsonRootName("getUserAadharProfileResponse")
@JsonIgnoreProperties(ignoreUnknown = true)
@XmlAccessorType(XmlAccessType.FIELD)
public class UserAadharProfileResponse {

    private String userIdentifier;
    private String userIdentifierType;
    private String residentConsent;
    private String printFormatRequest;
    private String localLangRequired;
    private String oneTimePassword;
    private String uniqueDeviceCode;
    private Status status;
    private ResidentIdentity residentIdentity;
    private String responseCode;
    private String responseTimeStamp;
    private String action;
    private String photo;
    @XmlElement(name = "eAadhaarPDF")
    @JsonProperty("eAadhaarPDF")
    private String eAadhaarPDF;
    private String uidToken;
    private String aadhaarNumber;
    
    
	@Override
	public String toString() {
		return "UserAadhaarProfile [residentConsent=" + residentConsent + ", printFormatRequest=" + printFormatRequest
				+ ", localLangRequired=" + localLangRequired + ", oneTimePassword = " + (oneTimePassword != null ? "*******" : "NA") 
				+ ", uniqueDeviceCode=" + uniqueDeviceCode + ", status=" + status + ", residentIdentity="
				+ residentIdentity + ", responseCode=" + responseCode + ", responseTimeStamp=" + responseTimeStamp
				+ ", action=" + action + ", photo=" + (photo == null ? "null" : "[*** encoded image ***]") + ", eAadhaarPDF=" + ( eAadhaarPDF == null ? "NA": "[***Binary Data***]") + "]"
				+ ", uidToken=" + (uidToken != null ? "[*** secure text ***]": "null") + ", aadhaarNumber=" + (aadhaarNumber == null ? "null": "[*** secure text ***]");
	}
}
