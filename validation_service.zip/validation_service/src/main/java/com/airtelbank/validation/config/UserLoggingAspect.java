package com.airtelbank.validation.config;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.Signature;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.util.StopWatch;

import com.airtelbank.validation.model.LoggerModel;
import com.airtelbank.validation.model.LoggerModel.MethodStats;

@Aspect
@Configuration
public class UserLoggingAspect {

	@Autowired
	LoggerModel loggerModel;
	@Pointcut("execution(* com.airtelbank.validation.service..*.*(..))")
	public void serviceLayerExecution(){}
	
	@Pointcut("execution(* com.airtelbank.validation.controller..*.*(..))")
	public void controllerLayerExecution(){}
	
	@Pointcut("execution(* com.airtelbank.validation.util..*.*(..))")
	public void utilLayerExecution(){}
	
	@Pointcut("execution(* com.airtelbank.validation.validator..*.*(..))")
	public void validatorLayerExecution(){}
	
	@Pointcut("execution(* com.airtelbank.validation.dao..*.*(..))")
	public void daoLayerExecution(){}
	
	@Pointcut("execution(* com.airtelbank.validation.repositiories..*.*(..))")
	public void repoLayerExecution(){}

	@Around("serviceLayerExecution()")
	public Object aroundService(ProceedingJoinPoint joinPoint) throws Throwable {
		Logger logger = LoggerFactory.getLogger(joinPoint.getSignature().getDeclaringType());
		Signature methodSignature = joinPoint.getSignature();
		logger.info("Entering Service method... {} : {}() ", methodSignature.getDeclaringType().getCanonicalName(), methodSignature.getName());
		StopWatch stopWatch = new StopWatch();
		stopWatch.start();
		Object ret=joinPoint.proceed();
		stopWatch.stop();
		logger.info("Exiting Service method... {} : {}(), Time Taken: {} ms.", methodSignature.getDeclaringType().getCanonicalName(), methodSignature.getName(), stopWatch.getTotalTimeMillis());
		if(loggerModel != null && loggerModel.getMethods() != null )
			loggerModel.getMethods().add(new MethodStats(String.valueOf(methodSignature.getDeclaringTypeName()) + "." + String.valueOf(methodSignature.getName()),stopWatch.getTotalTimeMillis()));
		return ret;
	}

	@Around("controllerLayerExecution()")
	public Object aroundController(ProceedingJoinPoint joinPoint) throws Throwable {
		Object[] argsArray= joinPoint.getArgs();
		Logger logger = LoggerFactory.getLogger(joinPoint.getSignature().getDeclaringType());
		Signature methodSignature = joinPoint.getSignature();
		logger.info("Entering Controller... {} : {}() : ", methodSignature.getDeclaringType().getCanonicalName(), methodSignature.getName());
		StopWatch stopWatch = new StopWatch();
		stopWatch.start();
		Object ret = joinPoint.proceed();
		stopWatch.stop();
		logger.info("Exiting Controller method... {} : {}(), Time Taken: {} ms", methodSignature.getDeclaringType().getCanonicalName(), methodSignature.getName(), stopWatch.getTotalTimeMillis());
		return ret;
	}

	@Around("utilLayerExecution()")
	public Object aroundUtil(ProceedingJoinPoint joinPoint) throws Throwable {
		Logger logger = LoggerFactory.getLogger(joinPoint.getSignature().getDeclaringType());
		Signature methodSignature = joinPoint.getSignature();
		logger.info("Entering Util method... {} : {}()", methodSignature.getDeclaringType().getCanonicalName(), methodSignature.getName());
		StopWatch stopWatch = new StopWatch();
		stopWatch.start();
		Object ret = joinPoint.proceed();
		stopWatch.stop();
		logger.info("Exiting Util method... {} : {}(), Time Taken: {} ms", methodSignature.getDeclaringType().getCanonicalName(), methodSignature.getName(), stopWatch.getTotalTimeMillis());
		return ret;
	}
	
	@Around("validatorLayerExecution()")
	public Object aroundValidator(ProceedingJoinPoint joinPoint) throws Throwable {
		Logger logger = LoggerFactory.getLogger(joinPoint.getSignature().getDeclaringType());
		Signature methodSignature = joinPoint.getSignature();
		logger.info("Entering HTTP method... {} : {}()", methodSignature.getDeclaringType().getCanonicalName(), methodSignature.getName());
		StopWatch stopWatch = new StopWatch();
		stopWatch.start();
		Object ret = joinPoint.proceed();
		stopWatch.stop();
		logger.info("Entering HTTP method... {} : {}(), Time Taken: {} ms", methodSignature.getDeclaringType().getCanonicalName(), methodSignature.getName(), stopWatch.getTotalTimeMillis());
		return ret;
	}
	
	@Around("daoLayerExecution()")
	public Object aroundDao(ProceedingJoinPoint joinPoint) throws Throwable {
		Logger logger = LoggerFactory.getLogger(joinPoint.getSignature().getDeclaringType());
		Signature methodSignature = joinPoint.getSignature();
		logger.info("Entering HTTP method... {} : {}()", methodSignature.getDeclaringType().getCanonicalName(), methodSignature.getName());
		StopWatch stopWatch = new StopWatch();
		stopWatch.start();
		Object ret = joinPoint.proceed();
		stopWatch.stop();
		logger.info("Entering HTTP method... {} : {}(), Time Taken: {} ms", methodSignature.getDeclaringType().getCanonicalName(), methodSignature.getName(), stopWatch.getTotalTimeMillis());
		return ret;
	}
	
	
	@Around("repoLayerExecution()")
	public Object aroundRepo(ProceedingJoinPoint joinPoint) throws Throwable {
		Logger logger = LoggerFactory.getLogger(joinPoint.getSignature().getDeclaringType());
		Signature methodSignature = joinPoint.getSignature();
		logger.info("Entering HTTP method... {} : {}()", methodSignature.getDeclaringType().getCanonicalName(), methodSignature.getName());
		StopWatch stopWatch = new StopWatch();
		stopWatch.start();
		Object ret = joinPoint.proceed();
		stopWatch.stop();
		logger.info("Entering HTTP method... {} : {}(), Time Taken: {} ms", methodSignature.getDeclaringType().getCanonicalName(), methodSignature.getName(), stopWatch.getTotalTimeMillis());
		return ret;
	}

	/*@AfterThrowing(pointcut = "controllerLayerExecution()", throwing = "ex")
	public void serviceExceptionHandler(JoinPoint joinPoint, Throwable ex) {
		Logger logger = LoggerFactory.getLogger(joinPoint.getSignature().getDeclaringType());
		Signature methodSignature = joinPoint.getSignature();
		logger.info("In method... {} : {}()", methodSignature.getDeclaringType().getCanonicalName(), methodSignature.getName());
		Signature signature = joinPoint.getSignature();
		String methodName = signature.getName();
		String stuff = signature.toString();
		String arguments = Arrays.toString(joinPoint.getArgs());
		logger.error("ERROR: We have caught exception in method: {}  with arguments {} and the full toString: {},  exception is: {}" , methodName, arguments, stuff, ex.getMessage());

	}*/
}
