package com.airtelbank.validation.dao.aerospike.model;

import java.time.LocalDate;

import org.springframework.data.aerospike.mapping.Field;
import org.springframework.data.annotation.Id;

import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_EMPTY)
@ToString
public class AadhaarVerify {
	  @Id
      private String transactionId;
      // @Field(value = "docNumber")
      private String aadhaarNumber;
      @Field(value = "otp")
      private String oneTimePassword;
      @Field(value = "unqDeviceCode")
      private String uniqueDeviceCode;
      private String firstName;
      private String middleName;
      private String lastName;
      private LocalDate dateOfBirth;
      private String gender;
      @Field(value = "aadhaarMob")
      private String aadhaarRegMobile;
      private String email;
      private String careOf;
      private String house;
      private String street;
      private String landMark;
      private String locality;
      private String city;
      private String subDistrict;
      private String district;
      private String state;
      private String country;
      private String pinCode;
      private String postOfficeName;
      private String photo;
      private String eAadhaarPdf;
      private String uidToken;
      @Field(value = "reqType")
      private String userIdentifierType;
      private String responseCode;
      @Field(value = "resTimeStamp")
      private String responseTimeStamp;
      @Field(value = "uidaiRawRes")
	  private String uidaiRawResponse;
      private String aadharRefNumber;
}
