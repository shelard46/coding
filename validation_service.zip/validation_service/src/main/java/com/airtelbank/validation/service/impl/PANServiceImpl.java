package com.airtelbank.validation.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.airtelbank.validation.model.PANDetails;
import com.airtelbank.validation.model.PANRequest;
import com.airtelbank.validation.model.PanEsbRequest;
import com.airtelbank.validation.model.PanEsbResponse;
import com.airtelbank.validation.service.PANService;
import com.airtelbank.validation.service.impl.helper.PanServiceImplHelper;

@Component
public class PANServiceImpl implements PANService {

	@Autowired
	private PanServiceImplHelper panServiceImplHelper;

	@Override
	public PANDetails getPanDetails(PANRequest panReq) {
		boolean result = panServiceImplHelper.validatePanRequest(panReq);
		PanEsbRequest panEsbReq = panServiceImplHelper.createPANEsbRequest(panReq);
		PanEsbResponse panEsbRes = panServiceImplHelper.fetchResponseForXML(panEsbReq);
		PANDetails panDetails = panServiceImplHelper.getPanDetails(panEsbRes);
		return panDetails;

	}

}