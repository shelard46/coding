package com.airtelbank.validation.model;

public class PosidexPanDetails {

}
