package com.airtelbank.validation.model;

import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonRootName;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlElementWrapper;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@ToString
@Getter
@Setter
@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_EMPTY)
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "verifyCustomerPanDetailsResponse")
@JsonRootName("verifyCustomerPanDetailsResponse")
@JsonIgnoreProperties(ignoreUnknown = true)
public class VerifyPANDetailsResponse {
	@XmlElement(name = "status")
	@JsonProperty("status")
	private PANStatus status;

	@XmlElement(name = "panDetails")
	@JsonProperty("panDetails")
	@JacksonXmlElementWrapper(localName="panDetails", useWrapping=false)
	private List<PANDetails> panDetails;
}
