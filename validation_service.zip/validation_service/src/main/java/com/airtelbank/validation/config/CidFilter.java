package com.airtelbank.validation.config;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;

import org.slf4j.MDC;

import com.airtelbank.validation.constants.Constants;


public class CidFilter implements Filter{

	@Override
	public void destroy() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
			throws IOException, ServletException {
		if (request instanceof HttpServletRequest) {

			HttpServletRequest httpRequest = (HttpServletRequest) request;
			String requestCid = httpRequest.getHeader(Constants.CONTENT_ID);
 
			// add cid to the MDC
			MDC.put(Constants.CONTENT_ID, requestCid);

		}

        try {
			// call filter(s) upstream for the real processing of the request
            chain.doFilter(request, response);
        } finally {
			// it's important to always clean the cid from the MDC, 
			// this Thread goes to the pool but it's loglines would still contain the cid.
        	MDC.remove(Constants.CONTENT_ID);
        }
	}

	@Override
	public void init(FilterConfig arg0) throws ServletException {
		// TODO Auto-generated method stub
		
	}
	
}
