package com.airtelbank.validation.exception;

import com.airtelbank.validation.model.Meta;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.*;

@Setter
@Getter
@ToString
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class VaultException extends RuntimeException{
	private Meta meta;
}
