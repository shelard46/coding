package com.airtelbank.validation.util;

import java.time.format.DateTimeFormatter;
import java.util.Locale;

import javax.xml.bind.JAXBElement;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.oxm.jaxb.Jaxb2Marshaller;
import org.springframework.stereotype.Component;
import org.springframework.web.client.ResourceAccessException;
import org.springframework.ws.client.core.support.WebServiceGatewaySupport;
import org.springframework.ws.soap.client.SoapFaultClientException;

import com.airtelbank.validation.exception.ThirdPartyApiException;
import com.airtelbank.validation.model.BlacklistRequest;
import com.airtelbank.validation.model.blacklist.Address;
import com.airtelbank.validation.model.blacklist.CustomerRequest;
import com.airtelbank.validation.model.blacklist.CustomerResponse;
import com.airtelbank.validation.model.blacklist.Demographics;
import com.airtelbank.validation.model.blacklist.Email;
import com.airtelbank.validation.model.blacklist.ObjectFactory;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
public class BlackListClient extends WebServiceGatewaySupport {

	private static DateTimeFormatter dateformatterDob = DateTimeFormatter.ofPattern("dd/MM/yyyy");
	private ObjectFactory objectFactory = new ObjectFactory();

	@Autowired
	private MessageSource messageSource;

	public BlackListClient() {
		super();
		Jaxb2Marshaller marshaller = new Jaxb2Marshaller();
		marshaller.setContextPath("com.airtelbank.validation.model.blacklist");
		getWebServiceTemplate().setMarshaller(marshaller);
		getWebServiceTemplate().setUnmarshaller(marshaller);
	}

	public CustomerResponse findBlacklistCustomers(BlacklistRequest blRequest, String posidexUrl, int posidexProfileId, String contentId) {
		log.info("Calling Third Party for Blacklisting. contentId: {}, customerId: {}", contentId, blRequest.getCustomerId());
		CustomerResponse customerResponse = null;
		CustomerRequest customerRequest = new CustomerRequest();
		Demographics demographic = new Demographics();
		if(StringUtils.isBlank(contentId)){
			contentId = CommonUtil.generateUniqueId();
		}
		demographic.setRequestid(contentId);
		log.info("Blacklist request Id : {}", demographic.getRequestid());
		demographic.setCustFname(blRequest.getFirstName());
		demographic.setCustLname(blRequest.getLastName());
		demographic.setCustDob(
				blRequest.getDateOfBirth() != null ? blRequest.getDateOfBirth().format(dateformatterDob) : null);
		demographic.setCustMsisdn(blRequest.getCustomerId());
		demographic.setProfileId(posidexProfileId);
		demographic.setPoiType(blRequest.getPoiType());
		demographic.setPoiNumber(blRequest.getPoiNumber());

		customerRequest.setDemographics(demographic);
		Address address = new Address();
		address.setPermanentPostalCode(blRequest.getPermPostalCode());
		customerRequest.getAddress().add(address);
		customerRequest.getEmail().add(new Email());
		JAXBElement<?> requestObjBL = objectFactory.createFindCustomer(customerRequest);
		log.info("sending request to thirdParty API ...");
		try {
			log.debug("Blacklist request : {}", CommonUtil.jsonObjectToString(customerRequest));
		} catch (Exception e) {
			log.error("Error while printing Blacklist Request: {} ", ExceptionUtils.getStackTrace(e));
		}
		try {
			JAXBElement<?> responseObject = (JAXBElement<CustomerResponse>) getWebServiceTemplate()
					.marshalSendAndReceive(posidexUrl, requestObjBL);
			customerResponse = (CustomerResponse) responseObject.getValue();
			log.debug("Blacklist response : {}", CommonUtil.jsonObjectToString(customerResponse));
		} catch (ResourceAccessException ex) {

			log.error("ResourceAccessException Exception. Timeout during BlackList request occurred in BlackListClient::findBlacklistCustomers", ExceptionUtils.getStackTrace(ex));

			String errorMessage = messageSource.getMessage("config.blacklist.posidex.timeout.error.msg", null, Locale.ENGLISH);
			String errorCode = messageSource.getMessage("config.blacklist.posidex.timeout.error.code", null, Locale.ENGLISH);
			throw new ThirdPartyApiException(errorMessage, errorCode, ex);
		} catch (SoapFaultClientException ex) {

			log.error("SoapFaultClientException Exception while sending request to ThirdParty for BlackList occurred in BlackListClient::findBlacklistCustomers {}", ExceptionUtils.getStackTrace(ex));

			String errorMessage = messageSource.getMessage("config.blacklist.error.soap.msg", null, Locale.ENGLISH);
			String errorCode = messageSource.getMessage("config.blacklist.error.soap.code", null, Locale.ENGLISH);
			throw new ThirdPartyApiException(errorMessage, errorCode, ex);
		} catch (Exception ex) {

			log.error("Exception while sending request to thirdParty for BlackList occurred in BlackListClient::findBlacklistCustomers {}", ExceptionUtils.getStackTrace(ex));

			String errorMessage = messageSource.getMessage("config.blacklist.failure.msg", null, Locale.ENGLISH);
			String errorCode = messageSource.getMessage("config.blacklist.failure.code", null, Locale.ENGLISH);
			throw new ThirdPartyApiException(errorMessage, errorCode, ex);
		}
		log.info("Customer check for Blacklist completed.");
		return customerResponse;
	}

}
