package com.airtelbank.validation.util;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

import javax.annotation.PostConstruct;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class GenericApiCodeMapper {

	@Value("${config.service.id}")
	private String serviceId;

	@Value("${config.service.common.code.mapping:}")
	private String commonCodeMapping;

	private static final Map<String, String> apiToGenericCodeMap = new HashMap<>();

	@PostConstruct
	public void updateCodeMap() {
		if (!StringUtils.isBlank(commonCodeMapping)) {
			Arrays.stream(commonCodeMapping.split(",")).forEach(data -> {
				String[] t = data.split(":");
				apiToGenericCodeMap.put(t[0], t[1]);
			});
		}
	}
	
	
	public String getCodeForKibana(String originalCode) {
		if(!StringUtils.isBlank(originalCode)) {
			return apiToGenericCodeMap.get(originalCode) != null 
					? apiToGenericCodeMap.get(originalCode) 
							: String.join("_", serviceId.toUpperCase(),originalCode);
				
		}
		return "";
	}

}
