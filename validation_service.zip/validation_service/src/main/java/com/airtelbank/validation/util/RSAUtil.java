package com.airtelbank.validation.util;

import java.security.InvalidKeyException;
import java.security.KeyFactory;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;
import java.util.Base64;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;

import com.airtelbank.validation.exception.ObjectConversionException;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class RSAUtil {
	public static PublicKey getPublicKey(String base64publicKey) {
		PublicKey publicKey = null;
		try {
			X509EncodedKeySpec keySpec = new X509EncodedKeySpec(Base64.getDecoder().decode(base64publicKey.getBytes()));
			KeyFactory keyFactory = KeyFactory.getInstance("RSA");
			publicKey = keyFactory.generatePublic(keySpec);
		} catch (Exception e) {
			log.error("Exception in RSAUtil|getPublicKey {}", ExceptionUtils.getStackTrace(e));
		}
		return publicKey;
	}
	
	public static PrivateKey getPrivateKey(String base64privateKey) {
		PrivateKey privateKey = null;
		try {
			PKCS8EncodedKeySpec keySpec = new PKCS8EncodedKeySpec(Base64.getDecoder().decode(base64privateKey.getBytes()));
			KeyFactory keyFactory = KeyFactory.getInstance("RSA");
			privateKey = keyFactory.generatePrivate(keySpec);
		} catch (Exception e) {
			log.error("Exception in RSAUtil|getPrivateKey {}", ExceptionUtils.getStackTrace(e));
		}
		return privateKey;
	}
	
	public static String encrypt(String data, String publicKey)
			throws NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeyException, IllegalBlockSizeException, BadPaddingException {
		String encryptedString = StringUtils.EMPTY;
		try {
			Cipher cipher = Cipher.getInstance("RSA/ECB/PKCS1Padding");
			cipher.init(Cipher.ENCRYPT_MODE, getPublicKey(publicKey));
			encryptedString = Base64.getEncoder().encodeToString(cipher.doFinal(data.getBytes()));
		} catch (Exception e) {
			log.error("exception in RSAUtil|encrypt", e);
			throw new ObjectConversionException();
		}
		return encryptedString;
	}
	
	public static String decrypt(String data, PrivateKey privateKey) {
		String decryptedString = StringUtils.EMPTY;
		try {
			Cipher cipher = Cipher.getInstance("RSA/ECB/PKCS1Padding");
			cipher.init(Cipher.DECRYPT_MODE, privateKey);
			decryptedString = new String(cipher.doFinal(Base64.getDecoder().decode(data.getBytes())));
		} catch (Exception e) {
			log.error("exception in RSAUtil|decrypt", e);
			throw new ObjectConversionException();
		}
		return decryptedString;
	}
}