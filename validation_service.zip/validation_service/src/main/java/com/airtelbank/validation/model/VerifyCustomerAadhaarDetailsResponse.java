package com.airtelbank.validation.model;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonRootName;

import lombok.ToString;


@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "verifyCustomerAadhaarDetailsResponse")
@JsonRootName("verifyCustomerAadhaarDetailsResponse")
@JsonIgnoreProperties(ignoreUnknown=true)
@ToString
public class VerifyCustomerAadhaarDetailsResponse {
	@XmlElement(name = "status")
	@JsonProperty("status")
	private Status status;
	
	@XmlElement(name = "uidToken")
	@JsonProperty("uidToken")
	private String uidToken;
	
	@XmlElement(name = "responseCode")
	@JsonProperty("responseCode")
	private String responseCode;

	public Status getStatus() {
		return status;
	}

	public void setStatus(Status status) {
		this.status = status;
	}

	public String getUidToken() {
		return uidToken;
	}

	public void setUidToken(String uidToken) {
		this.uidToken = uidToken;
	}

	public String getResponseCode() {
		return responseCode;
	}

	public void setResponseCode(String responseCode) {
		this.responseCode = responseCode;
	}

	
}

