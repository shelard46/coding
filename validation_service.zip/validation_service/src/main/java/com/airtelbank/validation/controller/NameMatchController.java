package com.airtelbank.validation.controller;

import java.util.Locale;

import org.apache.log4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.airtelbank.validation.constants.Constants;
import com.airtelbank.validation.model.Meta;
import com.airtelbank.validation.model.NameMatchRequest;
import com.airtelbank.validation.model.NameMatchResponse;
import com.airtelbank.validation.model.ResponseDTO;
import com.airtelbank.validation.service.INameMatchService;
import com.airtelbank.validation.util.CommonUtil;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
@RequestMapping(value = {"/api/v1","/api/v2"})
public class NameMatchController {

	@Autowired
	private INameMatchService nameMatchService;

	@Autowired
	private MessageSource messageSource;

	@PostMapping(value = "/validate/namematch/")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Successfully posted dedupe"),
			@ApiResponse(code = 401, message = "You are not authorized to view the resource"),
			@ApiResponse(code = 403, message = "Accessing the resource you were trying to reach is forbidden"),
			@ApiResponse(code = 404, message = "The resource you were trying to reach is not found") })
	@ApiOperation(value = "/validate/namematch/", response = NameMatchController.class)
	public ResponseEntity<ResponseDTO<NameMatchResponse>> nameMatch(@RequestBody NameMatchRequest nameMatchRequest,
			@RequestHeader String contentId, @RequestHeader String channel) {
		CommonUtil.setMDCMap(contentId, channel, nameMatchRequest.getSource(), Constants.VALIDATE_NAME_MATCH_DETAILS);
		NameMatchResponse nameMatchResponse = nameMatchService.checkNames(nameMatchRequest);
		ResponseDTO<NameMatchResponse> responseDTO = success(nameMatchResponse);
		MDC.put(Constants.ERRORS, CommonUtil.setLoggerError(responseDTO.getMeta()));
		return ResponseEntity.ok().body(responseDTO);
	}

	private ResponseDTO<NameMatchResponse> success(NameMatchResponse nameMatchResponse) {
		String successCode = CommonUtil.getValueByDefault(
				messageSource.getMessage("config.posidex.namematch.success.code", null, Locale.ENGLISH), "2200");
		String successMessage = CommonUtil.getValueByDefault(
				messageSource.getMessage("config.posidex.namematch.success.msg", null, Locale.ENGLISH), "Success");
		Meta meta = CommonUtil.createMeta(successCode, successMessage, Constants.SUCCESS_STATUS);
		ResponseDTO<NameMatchResponse> response = new ResponseDTO<>();
		response.setMeta(meta);
		response.setData(nameMatchResponse);
		return response;
	}

}
