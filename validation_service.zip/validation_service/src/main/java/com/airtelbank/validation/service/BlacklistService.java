package com.airtelbank.validation.service;

import com.airtelbank.validation.model.BlacklistEntityResponse;
import com.airtelbank.validation.model.BlacklistRequest;
import com.airtelbank.validation.model.BlacklistResponse;
import com.airtelbank.validation.model.ResponseDTO;
import com.airtelbank.validation.model.blacklist.BlacklistEntity;

public interface BlacklistService {

	public ResponseDTO<BlacklistResponse> getCustomerBlacklistInfo(BlacklistRequest blacklistRequest, String contentId);

	ResponseDTO<BlacklistEntityResponse> getEntityBlacklistInfo(BlacklistEntity blRequest, String contentId);
}
