package com.airtelbank.validation.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.airtelbank.validation.dao.aerospike.model.PincodeMasterCBS;

public class PincodeMasterMapper implements RowMapper<PincodeMasterCBS> {

	@Override
	public PincodeMasterCBS mapRow(ResultSet rs, int rowNum) throws SQLException {
		PincodeMasterCBS pincodeMaster = new PincodeMasterCBS();
		pincodeMaster.setPincode(rs.getString("PIN_CODE"));
		pincodeMaster.setCity(rs.getString("CITY"));
		pincodeMaster.setState(rs.getString("STATE"));
		pincodeMaster.setCircle(rs.getString("CIRCLE"));
		pincodeMaster.setSource(rs.getString("SOURCE"));
		pincodeMaster.setCod_cc_brn(rs.getString("COD_CC_BRN"));
		return pincodeMaster;
	}

}
