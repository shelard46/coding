package com.airtelbank.validation.model;

import java.time.LocalDate;

import javax.validation.constraints.NotBlank;
import org.springframework.format.annotation.DateTimeFormat;

import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter@Setter@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class DedupeRequest {
	@NotBlank(message="customer ID is mandatory")
	private String customerId;
	@NotBlank(message="account type is mandatory")
	private String accountType;
	@NotBlank(message="doc type is mandatory")
	private String docType;
	@NotBlank(message="doc number is mandatory")
	private String docNumber;
	@NotBlank(message="first name is mandatory")
	private String firstName;
	private String middleName;
	//@NotBlank(message="last name is mandatory")
	private String lastName;
	@DateTimeFormat
	private LocalDate dateOfBirth;
	private String house;
	private String street;
	private String landMark;
	private String locality;
	private String city;
	private String subDistrict;
	private String district;
	private String state;
	private String country;
	@NotBlank(message="pincode is mandatory")
	private String pincode;
	@NotBlank(message="partner Id is mandatory")
	private String partnerId;
	private String action;

	@Override
	public String toString() {
		return "DedupeRequest [custId=" + customerId + ", accountType=" + accountType + ", documentType=" + docType
				+ ", documentNumber=" + docNumber + ", firstName=" + firstName + ", middleName=" + middleName
				+ ", lastName=" + lastName + ", dateOfBirth=" + dateOfBirth + ", house=" + house + ", street=" + street
				+ ", landMark=" + landMark + ", locality=" + locality + ", city=" + city + ", subDistrict="
				+ subDistrict + ", district=" + district + ", state=" + state + ", country=" + country + ", pincode="
				+ pincode + ", partnerId=" + partnerId + "]";
	}
	
	
}
