package com.airtelbank.validation.util;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public final class CollectionUtil {
	
	private CollectionUtil(){}

	public static List<String> toList(String s) {
		return toList(s, ",");
	}

	public static List<String> toList(String s, boolean ignoreDuplicates) {
		return toList(s, ",", ignoreDuplicates);
	}

	public static List<String> toList(String s, String delimiter) {
		return toList(s, delimiter, false);
	}

	public static List<String> toList(String s, String delimiter, boolean ignoreDuplicates) {
		ArrayList<String> list = new ArrayList<>();
		if (s != null) {
			String[] split = s.split(delimiter);
			for (int i = 0; i < split.length; i++) {
				String trimmed = split[i].trim();
				if (trimmed.length() > 0 && (!ignoreDuplicates || !list.contains(trimmed))) list.add(trimmed);
			}
		}
		return list;
	}

	public static Set<String> toSet(String s) {
		return toSet(s, ",");
	}

	public static Set<String> toSet(String s, String delimiter) {
		HashSet<String> list = new HashSet<>();
		if (s != null) {
			String[] split = s.split(delimiter);
			for (int i = 0; i < split.length; i++) {
				String trimmed = split[i].trim();
				if (trimmed.length() > 0) list.add(trimmed);
			}
		}
		return list;
	}
}
