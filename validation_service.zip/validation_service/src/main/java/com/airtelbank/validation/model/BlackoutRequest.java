package com.airtelbank.validation.model;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class BlackoutRequest {
	private String customerId;
	private String identifierValue;
	private String identifierType;
}
