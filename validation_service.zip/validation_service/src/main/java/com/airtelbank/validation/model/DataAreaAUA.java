package com.airtelbank.validation.model;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonRootName;

import lombok.ToString;


@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "dataArea")
@JsonRootName("dataArea")
@JsonIgnoreProperties(ignoreUnknown = true)
@ToString
public class DataAreaAUA {
	@XmlElement(name = "verifyCustomerAadhaarDetailsResponse")
	@JsonProperty("verifyCustomerAadhaarDetailsResponse")
	private VerifyCustomerAadhaarDetailsResponse verifyCustomerAadhaarDetailsResponse;

	public VerifyCustomerAadhaarDetailsResponse getVerifyCustomerAadhaarDetailsResponse() {
		return verifyCustomerAadhaarDetailsResponse;
	}

	public void setVerifyCustomerAadhaarDetailsResponse(
			VerifyCustomerAadhaarDetailsResponse verifyCustomerAadhaarDetailsResponse) {
		this.verifyCustomerAadhaarDetailsResponse = verifyCustomerAadhaarDetailsResponse;
	}
    
}
