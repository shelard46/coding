package com.airtelbank.validation.service.impl;

import java.util.List;
import java.util.Locale;
import java.util.Optional;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.MessageSource;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.stereotype.Service;

import com.airtelbank.validation.constants.Constants;
import com.airtelbank.validation.dao.aerospike.model.PinCode;
import com.airtelbank.validation.dao.aerospike.model.PincodeMasterCBS;
import com.airtelbank.validation.dao.aerospike.repository.PinCodeValidationRepository;
import com.airtelbank.validation.exception.GenericException;
import com.airtelbank.validation.mapper.PincodeMasterMapper;
import com.airtelbank.validation.model.Meta;
import com.airtelbank.validation.model.ResponseDTO;
import com.airtelbank.validation.service.PinCodeService;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class PinCodeServiceImpl implements PinCodeService {

	@Autowired
	PinCodeValidationRepository pincodeValidationRepo;

	@Autowired
	private MessageSource messageSource;
	
	@Value("${cbs.spring.datasource.driver-class-name}")
	private String driverClassName;

	@Value("${cbs.spring.datasource.url}")
	private String url;

	@Value("${cbs.spring.datasource.username}")
	private String dbUsername;

	@Value("${cbs.spring.datasource.password}")
	private String dbPassword;

	@Value("${cbs.pincode.sql.query}")
	private String pincodeQuery;


	
	private DriverManagerDataSource getDataSource() {

		DriverManagerDataSource dataSource = new DriverManagerDataSource();
		dataSource.setDriverClassName(driverClassName);
		dataSource.setUrl(url);
		dataSource.setUsername(dbUsername);
		dataSource.setPassword(dbPassword);

		return dataSource;
	}
	
	private List<PincodeMasterCBS> getPincodeDataFromCBS() {
		log.info("GETTING PINCODE DATA FROM CBS");
		try {
			DataSource dataSource = getDataSource();
			JdbcTemplate template = new JdbcTemplate(dataSource);
			List<PincodeMasterCBS> data = template.query(pincodeQuery, new PincodeMasterMapper());
			return data;
		} catch (DataAccessException e) {
			log.info("Exception while fetching data from CBS", e);
		}
		return null;
	}
	
	public void loadPincodeDataToAerospike() {
		List<PincodeMasterCBS> pincodeDetails = getPincodeDataFromCBS();
		if (null != pincodeDetails) {

			for (PincodeMasterCBS data : pincodeDetails) {
				PinCode pincode = PinCode.builder().circle(data.getCircle()).id(data.getPincode()).city(data.getCity()).pinCode(data.getPincode()).source(data.getSource()).state(data.getState()).build();
				pincodeValidationRepo.save(pincode);
			}
		}
	}

	@Override
	public ResponseDTO<PinCode> validatePinCode(String contentId, String userAgent, String pinCode) {
		try {
			ResponseDTO<PinCode> responseDTO = new ResponseDTO<>();
			Meta meta = new Meta();
			Optional<PinCode> pincodeResp = pincodeValidationRepo.findById(pinCode);
			if (pincodeResp.isPresent()) {
				PinCode pincode = new PinCode();
				pincode.setCircle(pincodeResp.get().getCircle());
				pincode.setCity(pincodeResp.get().getCity());
				pincode.setState(pincodeResp.get().getState());
				meta.setCode(messageSource.getMessage("validate.pincode.success.response.code", null, Locale.ENGLISH));
				meta.setDescription(messageSource.getMessage("validate.pincode.success.response.message", null, Locale.ENGLISH));
				meta.setStatus(Constants.SUCCESS_STATUS);
				responseDTO.setData(pincode);
			} else {
				meta.setCode(messageSource.getMessage("validate.pincode.error.response.code", null, Locale.ENGLISH));
				meta.setDescription(messageSource.getMessage("validate.pincode.error.response.message", null, Locale.ENGLISH));
				meta.setStatus(Constants.FAILURE_STATUS);
			}
			responseDTO.setMeta(meta);
			return responseDTO;
		} catch (Exception e) {
			throw new GenericException();
		}

	}

}
