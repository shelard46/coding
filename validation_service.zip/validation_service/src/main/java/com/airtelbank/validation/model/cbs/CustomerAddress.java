package com.airtelbank.validation.model.cbs;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonRootName;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_EMPTY)
@XmlRootElement(name = "CustomerAddress")
@XmlAccessorType(XmlAccessType.FIELD)
@JsonRootName("CustomerAddress")
@JsonIgnoreProperties(ignoreUnknown = true)
public class CustomerAddress {

    private String city;
    private String country;
    private String line1;
    private String line2;
    private String line3;
    private String line4;
    private String state;

    @NotNull
    @Size(min = 1, message = "Can not be empty")
    private String zip;
    private String district;

    @Override
    public String toString() {
        return "Address [city=" + city + ", country=" + country + ", line1=" + line1 + ", line2=" + line2 + ", line3="
                + line3 + ", line4=" + line4 + ", state=" + state + ", zip=" + zip + ", district=" + district + "]";
    }

}
