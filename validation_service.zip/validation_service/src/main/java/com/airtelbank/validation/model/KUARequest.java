package com.airtelbank.validation.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;
import javax.validation.constraints.NotBlank;

import javax.validation.Valid;
import javax.validation.constraints.Pattern;

@Getter
@Setter
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class KUARequest {
    @NotBlank
    private String serviceCode;
    @NotBlank
    private String aadhaarTimestamp;
    @NotBlank
    private String biometricData;
    @NotBlank
    @Pattern(regexp = "[2-9][0-9]{11}|[0-9]{16}|.{72}", message = "invalid aadhaarId or VID or UID")
    private String userIdentifier;
    @NotBlank
    @Pattern(regexp = "[AVT]", message = "invalid identifier Type use (A/V/T)")
    private String userIdentifierType;
    @NotBlank
    private String certificateIdentifier;
    @NotBlank
    private String skey;
    @NotBlank
    private String hmac;
    @Valid
    private DeviceDetails deviceDetails;
    @NotBlank
    @JsonProperty("customerId")
    private String mobile;
    private String channel;
    private String source;
    private String contentId;
    private String biometricType;
}
