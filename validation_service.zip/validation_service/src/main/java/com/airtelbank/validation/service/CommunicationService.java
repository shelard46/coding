package com.airtelbank.validation.service;

import java.util.List;

import com.airtelbank.validation.enums.CommunicationType;
import com.airtelbank.validation.model.communication.CommunicationTemplate;


public interface CommunicationService {
	
	boolean sendCommunication(CommunicationType communicationType, String recipient, List<? extends CommunicationTemplate> commTemplates, String contentId, String channel);

}
