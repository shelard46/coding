package com.airtelbank.validation.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.*;

@Setter
@Getter
@ToString(exclude = "uid")
@NoArgsConstructor
@AllArgsConstructor
@Builder
@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class AadhaarVaultRequest {
	private String requestId;
	private String uid;
	private String apiKey;
	private String referenceKey;
}