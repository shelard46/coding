package com.airtelbank.validation.service.impl.helper;

import java.util.Locale;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Component;

import com.airtelbank.validation.exception.NameMatchException;
import com.airtelbank.validation.model.NameMatchRequest;
import com.airtelbank.validation.model.NameMatchResponse;
import com.airtelbank.validation.model.posidex.namematch.NameRequest;
import com.airtelbank.validation.model.posidex.namematch.NameResult;
import com.airtelbank.validation.util.NameMatchPosidexClient;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
public class NameMatchServiceHelper {

	@Value("${config.posidex.namematch.url}")
	private String strPosidexNameMatchURL;

	@Value("${config.posidex.namematch.profile.id}")
	private int strPosidexNameMatchProfileId;

	@Value("${config.posidex.namematch.partner.id}")
	private String strPosidexNameMatchPartnerId;

	@Autowired
	private NameMatchPosidexClient nameMatchPosidexClient;

	@Autowired
	private MessageSource messageSource;

	public enum NameMatchValidation {
		SUCCESS, FAILED, EMPTY, EMPTY_SOURCE, EMPTY_TARGET;
	}

	public NameMatchResponse matchNameWithPosidex(String strSourceTrimmed, String strTargetTrimmed,
			NameMatchRequest nameMatchRequest) {
		NameRequest nameRequest = new NameRequest();
		nameRequest.setSourceName(strSourceTrimmed);
		nameRequest.setTargetName(strTargetTrimmed);
		if (log.isDebugEnabled()) {
			log.debug("Posidex name request : {}", nameRequest);
		}
		NameResult nameResult = nameMatchPosidexClient.nameMatch(nameRequest, strPosidexNameMatchURL,
				strPosidexNameMatchProfileId);
		if (log.isDebugEnabled()) {
			log.debug("Posidex name response : {}", nameResult);
		}
		return NameMatchResponse.builder().source(nameMatchRequest.getSource()).target(nameMatchRequest.getTarget())
				.percentageMatch(nameResult.getMatchPercentage()).message(nameResult.getMessage()).build();

	}

	public NameMatchException generateNameMatchValidationException(NameMatchValidation nameMatchValidation) {
		if (nameMatchValidation != null) {
			switch (nameMatchValidation) {
			case EMPTY:
				return new NameMatchException(
						messageSource.getMessage("config.posidex.namematch.error.empty.request.code", null, Locale.ENGLISH),
						messageSource.getMessage("config.posidex.namematch.error.empty.request.msg", null, Locale.ENGLISH));
			case EMPTY_SOURCE:
				return new NameMatchException(
						messageSource.getMessage("config.posidex.namematch.error.empty.request.source.code", null, Locale.ENGLISH),
						messageSource.getMessage("config.posidex.namematch.error.empty.request.source.msg", null, Locale.ENGLISH));
			case EMPTY_TARGET:
				return new NameMatchException(
						messageSource.getMessage("config.posidex.namematch.error.empty.request.target.code", null, Locale.ENGLISH),
						messageSource.getMessage("config.posidex.namematch.error.empty.request.target.msg", null, Locale.ENGLISH));

			default:
				return new NameMatchException(
						messageSource.getMessage("config.posidex.namematch.error.generic.code", null, Locale.ENGLISH),
						messageSource.getMessage("config.posidex.namematch.error.generic.msg", null, Locale.ENGLISH));

			}
		}
		return new NameMatchException(
				messageSource.getMessage("config.posidex.namematch.error.generic.code", null, Locale.ENGLISH),
				messageSource.getMessage("config.posidex.namematch.error.generic.msg", null, Locale.ENGLISH));

	}
}
