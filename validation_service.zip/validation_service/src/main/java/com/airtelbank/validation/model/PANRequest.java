package com.airtelbank.validation.model;


import javax.validation.constraints.NotEmpty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class PANRequest {
	@NotEmpty
	private String panNumber;
	private String refNumber;
	private String channel;
	private String mobile;
	private String contentId;
}
