package com.airtelbank.validation.model.audit;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

import java.io.Serializable;

/**
 * @author Hitesh Khatri
 * @date 18/06/21
 */
@Getter
@Setter
@Builder
@AllArgsConstructor
@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_EMPTY)
@ToString
public class AuditLogRequest implements Serializable {
    private static final long serialVersionUID = 460002515707714318L;

    private String auditId;
    private String app;
    private String custId;
    private String appId;
    private String appType;//mendatory
    private String accId;
    private String channel;
    private String sessId;
    private String msisdn;
    private String partId;
    private String creatTime;
    private String ipAddress;
    private String action;
    private String logBy;
    private String desc;
    private String txnStatus;
    private String resCode;
    private String request;
}
