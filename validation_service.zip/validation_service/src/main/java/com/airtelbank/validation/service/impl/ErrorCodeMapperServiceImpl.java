package com.airtelbank.validation.service.impl;

import com.airtelbank.validation.dao.aerospike.ErrorCodeMapperDao;
import com.airtelbank.validation.dao.aerospike.ErrorCodeMapperRepository;
import com.airtelbank.validation.dao.aerospike.model.ErrorCodeMapper;
import com.airtelbank.validation.exception.AeroSpikeException;
import com.airtelbank.validation.service.ErrorCodeMapperService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.util.Date;
import java.util.Random;

@Service
public class ErrorCodeMapperServiceImpl implements ErrorCodeMapperService {

    @Autowired
    ErrorCodeMapperDao errorCodeMapperDao;

    @Autowired
    ErrorCodeMapperRepository errorCodeMapperRepository;

    private static final DateFormat sdf = new SimpleDateFormat("DDDMMyyyyHHmmssSSS");

    @Override
    public boolean addNewErrorCode(ErrorCodeMapper errorCodeMapper) {
        boolean isSuccess = false;
        try {
            String id = generateUniqueId();
            errorCodeMapper.setErrorId(id);
            errorCodeMapper.setCreateDate(LocalDateTime.now());
            errorCodeMapper.setModifyDate(LocalDateTime.now());
            isSuccess = errorCodeMapperDao.addNewErrorCode(errorCodeMapper);
            return isSuccess;
        } catch (Exception ex) {
            throw new AeroSpikeException();
        }
    }

    @Override
    public ErrorCodeMapper getErrorCodeByApiNameAndOrgErrorCode(String orgErrorCode, String apiName) {
        ErrorCodeMapper errorCodeMapper = null;
        try {
            errorCodeMapper = new ErrorCodeMapper();
            errorCodeMapper = errorCodeMapperRepository.findByApiNameAndOrgErrorCode(apiName, orgErrorCode);
            return errorCodeMapper;
        } catch (Exception ex) {
            throw new AeroSpikeException();
        }
    }

    public static String generateUniqueId() {
        return new StringBuffer().append(sdf.format(new Date(System.currentTimeMillis()))).append(new Random().nextInt(10)).toString();
    }
}
