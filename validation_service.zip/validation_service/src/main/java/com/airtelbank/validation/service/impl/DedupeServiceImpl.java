package com.airtelbank.validation.service.impl;

import com.airtelbank.validation.constants.Constants;
import com.airtelbank.validation.exception.CBSException;
import com.airtelbank.validation.model.*;
import com.airtelbank.validation.model.cbs.*;
import com.airtelbank.validation.model.posidex.customer.CustomerResponse;
import com.airtelbank.validation.service.ErrorCodeMapperService;
import com.airtelbank.validation.util.*;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.MessageSource;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;

import com.airtelbank.validation.exception.GenericException;
import com.airtelbank.validation.exception.ThirdPartyApiException;
import com.airtelbank.validation.model.DedupeRequest;
import com.airtelbank.validation.model.DedupeResponse;
import com.airtelbank.validation.model.ResponseDTO;
import com.airtelbank.validation.service.DedupeService;
import org.springframework.web.client.ResourceAccessException;

import javax.xml.bind.JAXBException;
import java.util.Locale;

@Service
public class DedupeServiceImpl implements DedupeService{

	@Autowired
	HttpUtil httpUtil;

	@Autowired
	Environment environment;

	@Autowired
	private PosidexClient posidexClient;
	
	@Autowired
	private RuleExecutor ruleEngine;
	
    @Autowired
    private MessageSource messageSource;

	@Autowired
	private ErrorCodeMapperService errorCodeMapperService;

	@Autowired
	private LogMasker logMasker;

    @Value("${config.posidex.error.soap.code}")
	private String defaultPosidexErrorCode;
    
	@Value("${config.posidex.partner.apb.id}")
	private String defaultPartnerId;
	@Value("${config.posidex.url}")
	private String posidexUrl;
	@Value("${config.posidex.profile.id}")
	private int posidexProfileId;

	//CBS Dedupe params
	@Value("${config.cbs.url}")
	private String cbsUrl;
	@Value(value = "${config.cbs.bank.code}")
	private String bankCode;
	@Value(value = "${config.cbs.transaction.branch}")
	private String transactionBranch;
	@Value("${config.cbs.service.code.dedupe}")
	private String cbsDedupeServiceCode;

	private static final Logger logger = LoggerFactory.getLogger(DedupeServiceImpl.class);
	@Override
	public ResponseDTO<DedupeResponse> fullKycDedupe(DedupeRequest request, String contentId) {
		CustomerResponse customerResponse = null;
		String partnerId = CommonUtil.getValueByDefault(request.getPartnerId(), defaultPartnerId);
		DedupeResponse dataAfterApplyRules = null;
		try {
			customerResponse = posidexClient.findCustomers(request, partnerId , posidexUrl, posidexProfileId, contentId);
			if(customerResponse == null) {
				String errorMessage = messageSource.getMessage("config.posidex.error.soap.msg",null, Locale.ENGLISH);
				throw new ThirdPartyApiException(defaultPosidexErrorCode, errorMessage);
			}
			if(customerResponse.getStatus().equalsIgnoreCase("F") || customerResponse.getCutomermatchcount().equals("-1"))
			{
				throw new ThirdPartyApiException(customerResponse.getErrorCode().toString(), customerResponse.getMessage());
			}
			logger.info("Start Applying rules");
			if(CommonUtil.isUpgradeWalletAction(request.getAction())){
				dataAfterApplyRules = ruleEngine.applyRules(request.getAction(), customerResponse, request.getDocType(), request.getDocNumber(),request.getAccountType(),request.getCustomerId());
			} else {
				dataAfterApplyRules = ruleEngine.applyRules(null, customerResponse, request.getDocType(), request.getDocNumber(),request.getAccountType(),request.getCustomerId());
			}
			logger.info("Result after Applying rules: {}", dataAfterApplyRules);
			logger.info("End Applying rules");
		} catch(ThirdPartyApiException thirdPartyApiException) {
			throw thirdPartyApiException;
		}catch (Exception e) {
			logger.error("Error while getting data from posidex",e);
			throw new GenericException();
		}
		ResponseDTO<DedupeResponse> responseDTO = new ResponseDTO<>(dataAfterApplyRules);
        responseDTO.setMeta(CommonUtil.createMeta(dataAfterApplyRules.getErrorCode(), dataAfterApplyRules.getMessage(), dataAfterApplyRules.getStatus()));
        dataAfterApplyRules.setErrorCode("");
        dataAfterApplyRules.setMessage("");
		return responseDTO;
	}

	public ResponseDTO<?> checkCbsDedupe(CBSDedupeRequest cbsDedupeRequest, String channel) {
		ResponseDTO<CustomerDedupeDetailsDTOArray> responseDTO = new ResponseDTO<>();
		boolean isCustomerFound = false;
		DedupeResponseFromCBS dedupeResponseFromCBS = null;
		try {
			logger.info("Calling CBS dedupe");
			if (logger.isDebugEnabled()) {
				logger.debug("Request for CBS dedupe is {}", logMasker.patternReplace(CommonUtil.jsonObjectToString(cbsDedupeRequest)));
			}
			Meta meta = null;
			SessionContext session = CommonUtil.createSessionContext(bankCode, cbsDedupeServiceCode, transactionBranch, channel);
			logger.info("CBS Dedupe transaction id:: {}", session.getExternalReferenceNo());
			DedupeRequestForCBS dedupeRequestForCBS = ValidationUtil.getRequestForCBSDedupe(cbsDedupeRequest, session);
			String requestString = CommonUtil.convertToXMLInJAXB(dedupeRequestForCBS, DedupeRequestForCBS.class);
			String responseString = null;
			responseString = httpUtil.sendRequest(cbsUrl, requestString, String.class, null, HttpMethod.POST, MediaType.APPLICATION_XML);
			if (responseString == null) {
				throw new CBSException();
			} else {
				dedupeResponseFromCBS = CommonUtil.convertToObjectFromXMLInJackson(responseString, DedupeResponseFromCBS.class);
				if (dedupeRequestForCBS == null) {
					throw new CBSException();
				} else {
					if (logger.isDebugEnabled()) {
						logger.debug("CBS Dedupe response: {}", logMasker.patternReplace(responseString));
					}
					TransactionStatus txnStatus = dedupeResponseFromCBS.getTransactionStatusObject();
					Boolean isReqSuccessful = (txnStatus.getReplyCode() >= 0 && txnStatus.getReplyCode() < 10) ? true : false;
					if (!isReqSuccessful) {
						meta = CommonUtil.retrieveCBSErrorDetails(txnStatus);
						meta = CommonUtil.setErrorCode(meta, Constants.CBS_DEDUPE_API_NAME, errorCodeMapperService, messageSource);
						throw new CBSException(meta);
					} else {
						if (dedupeResponseFromCBS.getDedupeStatus() != null) {
							if (dedupeResponseFromCBS.getDedupeStatus().equalsIgnoreCase("0")) {
								if (dedupeResponseFromCBS.getCustomerDedupeDetailsDTOArray() !=null
										&& dedupeResponseFromCBS.getCustomerDedupeDetailsDTOArray().getCustomerDedupeDetailsDTO() !=null
										&& dedupeResponseFromCBS.getCustomerDedupeDetailsDTOArray().getCustomerDedupeDetailsDTO().size() != 0) {
									isCustomerFound = true;
								} else {
									isCustomerFound = false;
								}
							} else {
								isCustomerFound = true;
							}
						} else {
							throw new CBSException();
						}
					}
				}
			}
			if (isCustomerFound) {
				meta = CommonUtil.createMeta(messageSource.getMessage("config.cbs.dedupe.customer.found.code", null, Locale.ENGLISH),
						messageSource.getMessage("config.cbs.dedupe.customer.found.msg", null, Locale.ENGLISH), Constants.SUCCESS_STATUS);
				responseDTO.setMeta(meta);
				responseDTO.setData(dedupeResponseFromCBS.getCustomerDedupeDetailsDTOArray());
			} else {
				meta = CommonUtil.createMeta(messageSource.getMessage("config.cbs.dedupe.customer.not.found.code", null, Locale.ENGLISH),
						messageSource.getMessage("config.cbs.dedupe.customer.not.found.msg", null, Locale.ENGLISH), Constants.FAILURE_STATUS);
				responseDTO.setMeta(meta);
			}
			return responseDTO;
		} catch (CBSException ex) {
			logger.error("CBS exception at CBS Dedupe. Exception in DedupeServiceImpl::checkCbsDedupe"
					+ Constants.ROOT_CAUSE + ExceptionUtils.getRootCause(ex)
					+ Constants.ERROR_MESSAGE + ExceptionUtils.getMessage(ex)
					+ Constants.STACK_TRACE + ex.getStackTrace()
					+ Constants.EXCEPTION + ex);
			throw ex;
		} catch (ResourceAccessException ex) {
			logger.error("Timeout during CBS request. Exception in DedupeServiceImpl::checkCbsDedupe"
					+ Constants.ROOT_CAUSE + ExceptionUtils.getRootCause(ex)
					+ Constants.ERROR_MESSAGE + ExceptionUtils.getMessage(ex)
					+ Constants.STACK_TRACE + ex.getStackTrace()
					+ Constants.EXCEPTION + ex);
			throw new ThirdPartyApiException();
		} catch (JAXBException ex) {
			logger.error("xml parsing error. Exception in Exception in DedupeServiceImpl::checkCbsDedupe"
					+ Constants.ROOT_CAUSE + ExceptionUtils.getRootCause(ex)
					+ Constants.ERROR_MESSAGE + ExceptionUtils.getMessage(ex)
					+ Constants.STACK_TRACE + ex.getStackTrace()
					+ Constants.EXCEPTION + ex);
			throw new GenericException();
		} catch (Exception ex) {
			logger.error("Exception in DedupeServiceImpl::checkCbsDedupe"
					+ Constants.ROOT_CAUSE + ExceptionUtils.getRootCause(ex)
					+ Constants.ERROR_MESSAGE + ExceptionUtils.getMessage(ex)
					+ Constants.STACK_TRACE + ex.getStackTrace()
					+ Constants.EXCEPTION + ex);
			throw new GenericException();
		}
	}

}
