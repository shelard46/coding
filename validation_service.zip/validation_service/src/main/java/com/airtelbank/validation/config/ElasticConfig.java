package com.airtelbank.validation.config;

import java.util.ArrayList;
import java.util.List;


import org.apache.http.HttpHost;
import org.apache.http.auth.AuthScope;
import org.apache.http.auth.UsernamePasswordCredentials;
import org.apache.http.client.CredentialsProvider;
import org.apache.http.impl.client.BasicCredentialsProvider;
import org.elasticsearch.client.RestClient;
import org.elasticsearch.client.RestHighLevelClient;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.airtelbank.validation.constants.Constants;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Configuration
public class ElasticConfig  {

    @Value("#{'${elasticsearch.host}'.split(',')}")
    private List<String> hosts;
    @Value("${elastic.auth.enabled}")
	private boolean authEnabled;
	@Value("${elastic.auth.username}")
	private String username;
	@Value("${elastic.auth.password}")
	private String password;
    @Value("${elastic.http.config:http}")
    private String httpConfig;

    @Bean
    public  RestHighLevelClient client() {
        List<HttpHost> hostList = new ArrayList<>();
        for (String host : hosts) {
            String[] hostDetails  = host.split("\\:");
            hostList.add(new HttpHost(hostDetails[0], Integer.parseInt(hostDetails[1]), httpConfig));
        }
        final CredentialsProvider credentialsProvider = new BasicCredentialsProvider();
        if(authEnabled) {
            credentialsProvider.setCredentials(AuthScope.ANY, new UsernamePasswordCredentials(username, password));
        }
        log.info("connecting to {} elastic clusters", hostList.size());
        return new RestHighLevelClient(RestClient.builder(hostList.toArray(new HttpHost[hostList.size()]))
        		.setHttpClientConfigCallback(httpClientBuilder -> httpClientBuilder.setDefaultCredentialsProvider(credentialsProvider)));
    }
}
