package com.airtelbank.validation.dao.aerospike;

import com.airtelbank.validation.dao.aerospike.model.AadhaarVerify;

public interface AadharVerifyDao {
	
	public boolean saveAadhaarVerifyResponse(AadhaarVerify aadhaarVerify);
	public AadhaarVerify getAadhaarVerifyResponse(String id);
}
