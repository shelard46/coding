package com.airtelbank.validation.exception;

import com.airtelbank.validation.model.Meta;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.*;

@Setter
@Getter
@ToString
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class UIDAIException extends Exception {
    private String id;
    private Meta meta;

    public UIDAIException(String id) {
        this.id = id;
    }

    public UIDAIException(String message, String id) {
        super(message);
        this.id = id;
    }

    public UIDAIException(String message, Throwable cause, String id) {
        super(message, cause);
        this.id = id;
    }

    public UIDAIException(Throwable cause, String id) {
        super(cause);
        this.id = id;
    }

    public UIDAIException(Meta meta) {
        this.meta = meta;
    }
}
