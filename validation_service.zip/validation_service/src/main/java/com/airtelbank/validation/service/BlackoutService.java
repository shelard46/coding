package com.airtelbank.validation.service;

import com.airtelbank.validation.model.BlackoutRequest;
import com.airtelbank.validation.model.BlackoutResponse;
import com.airtelbank.validation.model.ResponseDTO;

public interface BlackoutService {

	public ResponseDTO<BlackoutResponse> getBlackout(String customerId);
	public ResponseDTO<BlackoutResponse> postBlackout(BlackoutRequest request);
}
