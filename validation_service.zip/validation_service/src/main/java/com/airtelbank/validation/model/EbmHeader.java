package com.airtelbank.validation.model;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonRootName;

import lombok.ToString;


@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "ebmHeader" )
@JsonRootName("ebmHeader")
@JsonIgnoreProperties(ignoreUnknown = true)
@ToString
public class EbmHeader {
    @XmlElement(name = "consumerName")
    @JsonProperty("consumerName")
    private String consumerName;
    
    @XmlElement(name = "lob")
    @JsonProperty("lob")
    private String lob;
    
    @JsonProperty("consumerTransactionId")
    @XmlElement(name = "consumerTransactionId")
    private String consumerTransactionId;
    
    
    @XmlElement(name = "programmeName")
    @JsonProperty("programmeName")
    private String programmeName;
	public String getConsumerName() {
		return consumerName;
	}
	public void setConsumerName(String consumerName) {
		this.consumerName = consumerName;
	}
	public String getLob() {
		return lob;
	}
	public void setLob(String lob) {
		this.lob = lob;
	}
	public String getConsumerTransactionId() {
		return consumerTransactionId;
	}
	public void setConsumerTransactionId(String consumerTransactionId) {
		this.consumerTransactionId = consumerTransactionId;
	}
	public String getProgrammeName() {
		return programmeName;
	}
	public void setProgrammeName(String programmeName) {
		this.programmeName = programmeName;
	}
    
    
}
