package com.airtelbank.validation.dao.aerospike;

import org.springframework.data.aerospike.repository.AerospikeRepository;

import com.airtelbank.validation.dao.aerospike.model.AadhaarVerify;

public interface AadharVerifyRepository extends AerospikeRepository<AadhaarVerify, String> {

}
