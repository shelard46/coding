package com.airtelbank.validation.dao.aerospike;

import org.springframework.data.aerospike.repository.AerospikeRepository;

import com.airtelbank.validation.dao.aerospike.model.ErrorCodeMapper;

public interface ErrorCodeMapperRepository extends AerospikeRepository<ErrorCodeMapper, String> {

	public ErrorCodeMapper findByApiNameAndOrgErrorCode(String apiName,String orgErrorCode);

}
