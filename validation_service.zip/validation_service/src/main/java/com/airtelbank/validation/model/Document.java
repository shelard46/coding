package com.airtelbank.validation.model;

import javax.validation.constraints.Pattern;

import javax.validation.constraints.NotBlank;

import com.airtelbank.validation.validator.AadhaarVerifyGroup;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Setter
@Getter
@ToString
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class Document {
    // for request and response both
    @NotBlank(message = "Document Id cannot be empty", groups = AadhaarVerifyGroup.class)
    private String id;

    //only for request
    @NotBlank(message = "Document type can't be null")
    //@DocTypeConstraint(message = "Invalid docType")
    private String docType;

    @NotBlank(message = "Doc number can't be null")
    private String docNumber;

    @NotBlank(message = "Action can't be null")
    private String action;

    @JsonProperty("customerId")
    private String mobile;

    private String docReferenceNumber;

    @NotBlank(message="Pan can not be empty")
    @Pattern(message="Invalid Pan", regexp= "^[A-Z]{5}[0-9]{4}[A-Z]$")
    private String panNumber;
    
    @NotBlank(message = "Verification Token can't be null", groups = AadhaarVerifyGroup.class)
    private String verificationToken;
    private String channel;
    private String source;

    private String userIdentifierType;

    //for response
    private String maskedEmailId;
    private String maskedMobileNumber;
    private int userWaitingTime;
    private String uniqueDeviceCode;
    private int maxRetryCount;
    private int currentRetryCount;

    @JsonProperty("responseDescription")
    private String message;
}
