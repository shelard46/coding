package com.airtelbank.validation.dao.aerospike.model;



import org.springframework.data.annotation.Id;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class PosidexRules  {
	
	@Id
	private String id;
	private String ruleName;
	private int rulePriority;
	private String accountType;
	private String action;
	private String sourceType;
}
