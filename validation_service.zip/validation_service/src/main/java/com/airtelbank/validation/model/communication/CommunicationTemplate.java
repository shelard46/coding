package com.airtelbank.validation.model.communication;

public class CommunicationTemplate {

}
