package com.airtelbank.validation.config;

import org.springframework.beans.factory.annotation.Configurable;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.transaction.annotation.EnableTransactionManagement;

@Configurable
@EnableJpaRepositories(basePackages="com.airtelbank.validation.jpa")
@EnableAutoConfiguration
@EnableTransactionManagement
public class DaoConfiguration {

}
