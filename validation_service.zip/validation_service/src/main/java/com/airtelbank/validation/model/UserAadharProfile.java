package com.airtelbank.validation.model;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonRootName;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter@Setter
@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_EMPTY)
@XmlRootElement(name = "getUserAadhaarProfileRequest")
@JsonRootName("getUserAadhaarProfileRequest")
@JsonIgnoreProperties(ignoreUnknown = true)
@XmlAccessorType(XmlAccessType.FIELD)
public class UserAadharProfile {

    private String userIdentifier;
    private String userIdentifierType;
    private String residentConsent;
    private String printFormatRequest;
    private String localLangRequired;
    private String oneTimePassword;
    private String uniqueDeviceCode;
    private Status status;
    private ResidentIdentity residentIdentity;
    private String responseCode;
    private String responseTimeStamp;
    private String action;
    private String photo;
    @XmlElement(name = "eAadhaarPDF")
    @JsonProperty("eAadhaarPDF")
    private String eAadhaarPDF;
    private String uidToken;
    private String aadhaarNumber;
    
	@Override
	public String toString() {
		return "UserAadhaarProfile [residentConsent=" + residentConsent + ", printFormatRequest=" + printFormatRequest
				+ ", localLangRequired=" + localLangRequired + ", oneTimePassword=" + oneTimePassword
				+ ", uniqueDeviceCode=" + uniqueDeviceCode + ", status=" + status + ", residentIdentity="
				+ residentIdentity + ", responseCode=" + responseCode + ", responseTimeStamp=" + responseTimeStamp
				+ ", action=" + action + ", photo=" + photo + ", eAadhaarPDF=" + "[***Binary Data***]" + "]";
	}
}
