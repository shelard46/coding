package com.airtelbank.validation.util;

import java.math.BigDecimal;
import java.util.Arrays;
import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.airtelbank.validation.model.LoggerModel;

@Component
public class KibanaUtil {

	@Autowired
	LoggerModel loggerModel;

	public LoggerModel getLoggerModel() {
		return loggerModel;
	}

	public void setKibanaId(String... ids) {
		loggerModel.getIds().addAll(Arrays.asList(ids));
	}

	public void setKibanaNumber(BigDecimal... numbers) {
		loggerModel.setNumbers(Arrays.asList(numbers));
	}

	public void setKibanaDate(Date... dates) {
		loggerModel.setDates(Arrays.asList(dates));
	}

}