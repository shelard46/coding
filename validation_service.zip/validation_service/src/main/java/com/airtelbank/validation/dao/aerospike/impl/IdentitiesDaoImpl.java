package com.airtelbank.validation.dao.aerospike.impl;

import com.aerospike.client.policy.GenerationPolicy;
import com.aerospike.client.policy.WritePolicy;
import com.aerospike.client.query.IndexType;
import com.aerospike.helper.query.Qualifier;
import com.aerospike.helper.query.Qualifier.FilterOperation;
import com.airtelbank.validation.constants.Constants;
import com.airtelbank.validation.dao.aerospike.IdentitiesDao;
import com.airtelbank.validation.dao.aerospike.model.Identities;
import com.airtelbank.validation.exception.AeroSpikeException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.MessageSource;
import org.springframework.data.aerospike.core.AerospikeTemplate;
import org.springframework.data.aerospike.repository.query.AerospikeCriteria;
import org.springframework.data.aerospike.repository.query.Query;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Locale;

@Repository
public class IdentitiesDaoImpl implements IdentitiesDao {

    @Autowired
    AerospikeTemplate aerospikeTemplate;
    
    @Autowired
	private MessageSource messageSource;

    @Value("${config.aerospike.expiration}")
    public long expiration;

    @Value("${config.aerospike.expiration.no}")
    public long noExpiration;

    private static final Logger logger = LoggerFactory.getLogger(IdentitiesDaoImpl.class);

    @Override
    public Boolean addAndSaveIdentityInRepo(Identities identities) {
        Boolean savedSuccessfully = false;
        WritePolicy writePolicy = new WritePolicy();
        writePolicy.expiration = (int) Math.min(expiration, Integer.MAX_VALUE);
        writePolicy.generationPolicy = GenerationPolicy.EXPECT_GEN_EQUAL;
        writePolicy.generation = identities.getVersion();
        try {
            aerospikeTemplate.persist(identities, writePolicy);
            savedSuccessfully = true;
            return savedSuccessfully;
        } catch (Exception ex) {
            logger.info("Exception while adding Identity in Aerospike.");
            String message = messageSource.getMessage(Constants.DEDUPE_FAILURE_MSG,null, Locale.ENGLISH);
			String id = messageSource.getMessage("config.dedupe.aerospike.failure.code",null, Locale.ENGLISH);;
			throw new AeroSpikeException(message, ex, id);
        }
    }

    @Override
    public Identities getIdentityFromRepo(String id) {
    	try {
    		return aerospikeTemplate.findById(id, Identities.class);
    	}catch (Exception e) {
    		String message =messageSource.getMessage("verify.aadhaar.otp.aerospike.failure.msg",null, Locale.ENGLISH);
			String errorCode = messageSource.getMessage("verify.aadhaar.otp.aerospike.failure.code",null, Locale.ENGLISH);
			throw new AeroSpikeException(message, e, errorCode);
    	}
    }

    @Override
    public List<Identities> getIdentityFromRepoUnique(String mobileNumber, String docNumber) {
        Query query = null;
        List<Identities> list = null;
        try {
            Qualifier docNumQualifier = new Qualifier("docNumber", FilterOperation.EQ, com.aerospike.client.Value.get(docNumber));
            Qualifier mobileNumQualifier = new Qualifier("mobileNumber", FilterOperation.EQ, com.aerospike.client.Value.get(mobileNumber));
            AerospikeCriteria criteria = new AerospikeCriteria(FilterOperation.AND, docNumQualifier, mobileNumQualifier);
            query = new Query(criteria);
            if (!aerospikeTemplate.indexExists("mobIndex"))
                aerospikeTemplate.createIndex(Identities.class, "mobIndex", "mobileNumber", IndexType.STRING);
            if (!aerospikeTemplate.indexExists("docNumberIndex"))
                aerospikeTemplate.createIndex(Identities.class, "docNumberIndex", "docNumber", IndexType.STRING);
            list = (List<Identities>) aerospikeTemplate.find(query, Identities.class);
            return list;
        } catch (Exception ex) {
            logger.info("Exception while storing data in AeroSpike.");
            String message =messageSource.getMessage(Constants.DEDUPE_FAILURE_MSG,null, Locale.ENGLISH);
			String id = messageSource.getMessage("config.dedupe.aerospike.failure.code",null, Locale.ENGLISH);;
			throw new AeroSpikeException(message, ex, id);
        }
    }

    @Override
    public Boolean updateIdentityInRepo(Identities identities, boolean isSuccess) {
        Boolean savedSuccessfully = false;
        WritePolicy writePolicy = new WritePolicy();
        if(isSuccess) {
            writePolicy.expiration = (int) Math.min(noExpiration, Integer.MAX_VALUE);
        } else {
            writePolicy.expiration = (int) Math.min(expiration, Integer.MAX_VALUE);
        }
        writePolicy.generationPolicy = GenerationPolicy.EXPECT_GEN_EQUAL;
        writePolicy.generation = identities.getVersion();
        try {
            aerospikeTemplate.persist(identities, writePolicy);
            savedSuccessfully = true;
            return savedSuccessfully;
        } catch (Exception e) {
            logger.info("Exception while updating data in AeroSpike");
            String message =messageSource.getMessage(Constants.DEDUPE_FAILURE_MSG,null, Locale.ENGLISH);
			String id = messageSource.getMessage("config.dedupe.aerospike.failure.code",null, Locale.ENGLISH);;
			throw new AeroSpikeException(message, e, id);
        }
    }

}
