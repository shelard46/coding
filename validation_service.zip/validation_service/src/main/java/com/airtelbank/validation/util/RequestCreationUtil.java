package com.airtelbank.validation.util;

import java.util.Locale;
import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Component;

import com.airtelbank.validation.constants.Constants;
import com.airtelbank.validation.enums.CommunicationType;
import com.airtelbank.validation.model.BlacklistResponse;
import com.airtelbank.validation.model.blacklist.CustomerResponse;
import com.airtelbank.validation.model.communication.CommunicationData;
import com.airtelbank.validation.model.communication.CommunicationTemplate;
import com.airtelbank.validation.model.communication.SMSTemplate;
import com.airtelbank.validation.model.communication.SmsData;

@Component
public class RequestCreationUtil {
	
	@Autowired private MessageSource messageSource;
  
	@Value("${config.sms.sender}")
	private String smsSender;

	public BlacklistResponse transformResponseFromPosidex(CustomerResponse customerResponse) {
		BlacklistResponse blResponse = new BlacklistResponse();
		if (customerResponse.getStatus().equalsIgnoreCase("C")) {
			int rematchCount = Integer.parseInt(customerResponse.getRematchcount());
			blResponse.setStatusFromPosidex(customerResponse.getStatus());
			if (rematchCount != Constants.SUCCESS_STATUS) {
				blResponse.setStatus(Constants.SUCCESS_STATUS);
				blResponse.setErrorCode(messageSource.getMessage("config.blacklist.found.code", null, Locale.ENGLISH));
				blResponse.setMessage(messageSource.getMessage("config.blacklist.customerFound.msg", null, Locale.ENGLISH));
				blResponse.setCustomers(customerResponse.getResults().getREResults());
			} else {
				blResponse.setRequestId(customerResponse.getRequestId());
				blResponse.setStatusFromPosidex(customerResponse.getStatus());
				blResponse.setErrorCode(messageSource.getMessage("config.blacklist.notfound.code", null, Locale.ENGLISH));
				blResponse.setMessage(messageSource.getMessage("config.blacklist.customerNotFound.msg", null, Locale.ENGLISH));
				blResponse.setStatus(Constants.FAILURE_STATUS);
			}
		} else if (customerResponse.getStatus().equalsIgnoreCase("P") || customerResponse.getStatus().equalsIgnoreCase("F")) {
			blResponse.setStatusFromPosidex(customerResponse.getStatus());
			blResponse.setMessage("BLACKLIST_PENDING");
			blResponse.setStatus(Constants.FAILURE_STATUS);
			blResponse.setErrorCode(messageSource.getMessage("config.blacklist.failure.code", null, Locale.ENGLISH));
		}
		return blResponse;
	}
	
	public SmsData createSmsRequest(String recipient, CommunicationType communicationType, List<SMSTemplate> smsTemplates, String refNo) {
		return SmsData.builder()
				.communicationList(Arrays.asList(CommunicationData.builder()
						.templateCode(communicationType.toString())
						.type(Constants.Sms.TYPE)
						.mode(Constants.Sms.MODE)
						.langId(Constants.Sms.LANGUAGE_ID)
						.externalRefNo(refNo)
						.ucId(Constants.Sms.UCID)
						.subject(Constants.Sms.SUBJECT)
						.sender(smsSender)
						.index(Constants.Sms.INDEX)
						.category(Constants.Sms.CATEGORY)
						.priority(Constants.Sms.PRIORITY)
						.recipient(Arrays.asList(recipient))
						.tamplateDataModel(smsTemplates)
						.build()))
				.build();
	}
}
