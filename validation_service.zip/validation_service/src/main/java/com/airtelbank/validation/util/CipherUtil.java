package com.airtelbank.validation.util;

import java.nio.charset.StandardCharsets;
import java.security.spec.KeySpec;

import javax.crypto.Cipher;
import javax.crypto.Mac;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;
import javax.crypto.spec.SecretKeySpec;

import org.apache.commons.codec.binary.Hex;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.springframework.util.StringUtils;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public final class CipherUtil {

	
	private static final byte[] salt = { (byte) 0xA8, (byte) 0x9B, (byte) 0xC8, (byte) 0x32, (byte) 0x56, (byte) 0x34,
			(byte) 0xE3, (byte) 0x03 };

	public static  String decryptData(final String str, String passphrase) {
		if (StringUtils.isEmpty(str)) {
			return "";
		}

		int iterationCount = 20;

		try {
			KeySpec keySpec = new PBEKeySpec(passphrase.toCharArray(), salt, iterationCount, 128);
			SecretKeyFactory keyFactory = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA1");
			byte[] keyBytes = keyFactory.generateSecret(keySpec).getEncoded();
			SecretKey key = new SecretKeySpec(keyBytes, "AES");
			Cipher dcipher = Cipher.getInstance("AES/ECB/PKCS5Padding");
			dcipher.init(Cipher.DECRYPT_MODE, key);
			byte[] dec = new sun.misc.BASE64Decoder().decodeBuffer(str);
			byte[] utf8 = dcipher.doFinal(dec);
			return new String(utf8, StandardCharsets.UTF_8);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return str;

	}

	public static String encryptData(final String str, String passphrase) {
		if (StringUtils.isEmpty(str)) {
			return "";
		}

		int iterationCount = 20;
		try {
			KeySpec keySpec = new PBEKeySpec(passphrase.toCharArray(), salt, iterationCount, 128);
			SecretKeyFactory keyFactory = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA1");
			byte[] keyBytes = keyFactory.generateSecret(keySpec).getEncoded();
			SecretKey key = new SecretKeySpec(keyBytes, "AES");
			Cipher ecipher = Cipher.getInstance("AES/ECB/PKCS5Padding");
			ecipher.init(Cipher.ENCRYPT_MODE, key);
			byte[] utf8 = str.getBytes(StandardCharsets.UTF_8);
			byte[] enc = ecipher.doFinal(utf8);
			return new sun.misc.BASE64Encoder().encode(enc);
		} catch (Exception e) {
			log.error("exception in encryptData {}", ExceptionUtils.getStackTrace(e));
		}
		return str;
	}
	
	public static String getHashedValue(String plainText, String algorithmName, String secretKey) {
		try {
			Mac sha256_HMAC = Mac.getInstance(algorithmName);
			SecretKeySpec secret_key = new SecretKeySpec(secretKey.getBytes(StandardCharsets.UTF_8), algorithmName);
			sha256_HMAC.init(secret_key);
			return Hex.encodeHexString(sha256_HMAC.doFinal(plainText.getBytes(StandardCharsets.UTF_8)));
		} catch (Exception e) {
			log.error("exception in getHashedValue {}", ExceptionUtils.getStackTrace(e));
		}
		return "";

	}
	
}