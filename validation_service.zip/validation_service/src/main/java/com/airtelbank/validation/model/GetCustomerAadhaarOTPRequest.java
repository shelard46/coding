package com.airtelbank.validation.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.*;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@Setter
@Getter
@ToString
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_EMPTY)
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "getCustomerAadhaarOTPRequest")
public class GetCustomerAadhaarOTPRequest
{
	@XmlElement(name = "terminalId")
    private String terminalId;
	@XmlElement(name = "timestamp")
    private String timestamp;
	@XmlElement(name = "otpRequestType")
    private String otpRequestType;
	@XmlElement(name = "aadhaarNumber")
    private String aadhaarNumber;
	@XmlElement(name = "subAua")
    private String subAua;
	@XmlElement(name = "mobileNumber")
    private String mobileNumber;
}
