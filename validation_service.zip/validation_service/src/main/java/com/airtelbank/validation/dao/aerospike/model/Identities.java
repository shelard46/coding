package com.airtelbank.validation.dao.aerospike.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.*;
import org.springframework.data.aerospike.mapping.Field;
import org.springframework.data.annotation.Id;
import org.springframework.data.annotation.Version;

import java.io.Serializable;
import java.time.LocalDate;
import java.time.LocalDateTime;

@JsonInclude(JsonInclude.Include.NON_EMPTY)
@Setter
@Getter
@ToString
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Identities implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    private String id;
    private String aid;
    private String mobileNumber;
    private String docNumber;
    @Field(value = "documentType")
    private String docType;
    private LocalDate validFrom;
    private LocalDate validTo;
    private LocalDateTime createdDate;
    private LocalDateTime modifyDate;
    private Boolean isVerified;
    private int verifyCount;
    private int genCount;
    @Version
    private int version;
    private String channel;
    private String source;
    private String uidToken;
    @Field(value = "reqType")
    private String userIdentifierType;

}
