package com.airtelbank.validation.service.impl;

import java.util.Objects;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.airtelbank.validation.exception.NameMatchException;
import com.airtelbank.validation.model.NameMatchRequest;
import com.airtelbank.validation.model.NameMatchResponse;
import com.airtelbank.validation.service.INameMatchService;
import com.airtelbank.validation.service.impl.helper.NameMatchServiceHelper;
import com.airtelbank.validation.service.impl.helper.NameMatchServiceHelper.NameMatchValidation;

@Component
public class NameMatchService implements INameMatchService {

	@Autowired
	private NameMatchServiceHelper nameMatchServiceHelper;
	
	private static final Logger logger = LoggerFactory.getLogger(NameMatchService.class);

	@Override
	public NameMatchResponse checkNames(NameMatchRequest nameMatchRequest) {
		logger.info("Name match request : {}", nameMatchRequest);
		if (Objects.nonNull(nameMatchRequest)) {
			if (Objects.nonNull(nameMatchRequest.getSource()) && Objects.nonNull(nameMatchRequest.getTarget())) {
				String strSourceTrimmed = nameMatchRequest.getSource().trim().toUpperCase();
				String strTargetTrimmed = nameMatchRequest.getTarget().trim().toUpperCase();

				if( "".equals(strSourceTrimmed) )
					throw nameMatchServiceHelper.generateNameMatchValidationException(NameMatchValidation.EMPTY_SOURCE);
				if(  "".equals(strTargetTrimmed))
					throw nameMatchServiceHelper.generateNameMatchValidationException(NameMatchValidation.EMPTY_TARGET);
				if (strSourceTrimmed.equals(strTargetTrimmed)) {
					logger.info("names are identical, returning full match");
					return fullMatch(nameMatchRequest);
				} else {
					logger.info("requesting posidex to provide name matching");
					return nameMatchServiceHelper.matchNameWithPosidex(strSourceTrimmed, strTargetTrimmed,
							nameMatchRequest);
				}
			} else if (nameMatchRequest.getSource() == null && nameMatchRequest.getTarget() == null) {
				logger.info("both names are null, validation failed");
				throw nameMatchServiceHelper.generateNameMatchValidationException(NameMatchValidation.EMPTY);

			} else {
				logger.info("Either of name are null, returning no match");
				return noMatch(nameMatchRequest);
			}
		}
		NameMatchException ex = nameMatchServiceHelper.generateNameMatchValidationException(NameMatchValidation.EMPTY);
		throw ex;

	}

	static NameMatchResponse fullMatch(NameMatchRequest nameMatchRequest) {
		return NameMatchResponse.builder().source(nameMatchRequest.getSource()).target(nameMatchRequest.getTarget())
				.percentageMatch(100).message("YES").build();
	}

	static NameMatchResponse noMatch(NameMatchRequest nameMatchRequest) {
		return NameMatchResponse.builder().source(nameMatchRequest.getSource()).target(nameMatchRequest.getTarget())
				.percentageMatch(0).message("NO").build();
	}

}
