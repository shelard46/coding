package com.airtelbank.validation.dao.aerospike.impl;

import java.util.List;
import java.util.Locale;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.data.aerospike.core.AerospikeTemplate;
import org.springframework.data.aerospike.repository.query.AerospikeCriteria;
import org.springframework.data.aerospike.repository.query.Query;
import org.springframework.stereotype.Repository;

import com.aerospike.client.Value;
import com.aerospike.client.query.IndexType;
import com.aerospike.helper.query.Qualifier.FilterOperation;
import com.airtelbank.validation.dao.aerospike.PosidexRulesDao;
import com.airtelbank.validation.dao.aerospike.model.PosidexRules;
import com.airtelbank.validation.exception.AeroSpikeException;

@Repository
public class PosidexRulesDaoImpl implements PosidexRulesDao{
	
	@Autowired
    AerospikeTemplate aerospikeTemplate;
	
	@Autowired
	private MessageSource messageSource;

	@Override
	public List<PosidexRules> getAllRules() {
		return aerospikeTemplate.findAll(PosidexRules.class);
	}

	@Override
	public List<PosidexRules> getRulesByAccountTypes(String accountType) {
		try {
			if(accountType == null) return null;
			AerospikeCriteria criteria=new AerospikeCriteria("accountType", FilterOperation.EQ, true, Value.get(accountType));
			Query query = new Query(criteria);
			if(!aerospikeTemplate.indexExists("accountTypeIndex"))
				aerospikeTemplate.createIndex(PosidexRules.class, "accountTypeIndex", "accountType", IndexType.STRING);
			return (List<PosidexRules>) aerospikeTemplate.find(query, PosidexRules.class);
		}catch (Exception e) {
			String message =messageSource.getMessage("config.dedupe.aerospike.failure.msg",null, Locale.ENGLISH);
			String id = messageSource.getMessage("config.dedupe.aerospike.failure.code",null, Locale.ENGLISH);
			throw new AeroSpikeException(message, e, id);
		}
	}

}
