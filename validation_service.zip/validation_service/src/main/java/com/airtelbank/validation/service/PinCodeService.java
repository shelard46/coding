package com.airtelbank.validation.service;

import org.springframework.stereotype.Service;

import com.airtelbank.validation.dao.aerospike.model.PinCode;
import com.airtelbank.validation.model.ResponseDTO;

@Service
public interface PinCodeService {
	public ResponseDTO<PinCode> validatePinCode(String contentId, String userAgent, String pinCode);
	
	public void loadPincodeDataToAerospike();
}
