package com.airtelbank.validation.model.blacklist;

import com.univocity.parsers.annotations.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.NoArgsConstructor;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlElement;

/**
 * <p>Java class for anonymous complex type.
 *
 * <p>The following schema fragment specifies the expected content contained within this class.
 *
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="Id" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="Action" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="Blacklisted" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="Name" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="Pan" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="Charge" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="Country" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 *
 *
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
        "id",
        "action",
        "blacklisted",
        "name",
        "charge",
        "addressLine",
        "addressCity",
        "country",
        "pan",
        "address"
})
@Builder
@NoArgsConstructor
@AllArgsConstructor
@XmlRootElement(name = "BlacklistData")
public class BlacklistData {

    @Trim
    @Parsed(index = 0, defaultNullRead = "")
    @XmlElement(name = "Id" )
    protected String id;
    @Parsed(index = 1, defaultNullRead = "")
    @XmlElement(name = "Action")
    protected String action;
    @Trim
    @Parsed(index = 8, defaultNullRead = "")
    @XmlElement(name = "Name")
    protected String name;
    @Parsed(index = 12)
    @XmlElement(name = "Charge")
    protected String charge;
    @Trim
    @UpperCase
    @Parsed(index = 50, defaultNullRead = "")
    @XmlElement(name = "Pan")
    protected String pan = "";
    @Parsed(index = 38)
    @XmlElement(name = "AddressCity")
    protected String addressCity;
    @Parsed(index = 37)
    @XmlElement(name = "AddressLine")
    protected String addressLine;
    @Parsed(index = 48)
    @XmlElement(name = "Country")
    protected String country;
    @Parsed(index = 4)
    @BooleanString(falseStrings = {"Inactive"}, trueStrings = {"Active", "", "null"})
    @XmlElement(name = "Blacklisted")
    protected boolean blacklisted;
    @XmlElement(name = "Address")
    protected String address;
    /**
     * Gets the value of the name property.
     *
     * @return
     *     possible object is
     *     {@link String }
     *
     */
    public String getName() {
        return name;
    }

    /**
     * Sets the value of the name property.
     *
     * @param value
     *     allowed object is
     *     {@link String }
     *
     */
    public void setName(String value) {
        this.name = value;
    }

    /**
     * Gets the value of the pan property.
     *
     * @return
     *     possible object is
     *     {@link String }
     *
     */
    public String getPan() {
        return pan;
    }

    /**
     * Sets the value of the pan property.
     *
     * @param value
     *     allowed object is
     *     {@link String }
     *
     */
    public void setPan(String value) {
        this.pan = value;
    }

    /**
     * Gets the value of the id property.
     *
     * @return
     *     possible object is
     *     {@link String }
     *
     */
    public String getId() {
        return id != null ? id : "";
    }

    /**
     * Sets the value of the id property.
     *
     * @param value
     *     allowed object is
     *     {@link String }
     *
     */
    public void setId(String value) {
        this.id = value;
    }

    /**
     * Gets the value of the action property.
     *
     * @return
     *     possible object is
     *     {@link String }
     *
     */
    public String getAction() {
        return action;
    }

    /**
     * Sets the value of the action property.
     *
     * @param value
     *     allowed object is
     *     {@link String }
     *
     */
    public void setAction(String value) {
        this.action = value;
    }

    /**
     * Gets the value of the charge property.
     *
     * @return
     *     possible object is
     *     {@link String }
     *
     */
    public String getCharge() {
        return charge;
    }

    /**
     * Sets the value of the charge property.
     *
     * @param value
     *     allowed object is
     *     {@link String }
     *
     */
    public void setCharge(String value) {
        this.charge = value;
    }

    /**
     * Gets the value of the addressLine property.
     *
     * @return
     *     possible object is
     *     {@link String }
     *
     */
    public String getAddressLine() {
        return addressLine;
    }

    /**
     * Sets the value of the addressLine property.
     *
     * @param value
     *     allowed object is
     *     {@link String }
     *
     */
    public void setAddressLine(String value) {
        this.addressLine = value;
    }

    /**
     * Gets the value of the addressCity property.
     *
     * @return
     *     possible object is
     *     {@link String }
     *
     */
    public String getAddressCity() {
        return addressCity;
    }

    /**
     * Sets the value of the addressCity property.
     *
     * @param value
     *     allowed object is
     *     {@link String }
     *
     */
    public void setAddressCity(String value) {
        this.addressCity = value;
    }

    /**
     * Gets the value of the country property.
     *
     * @return
     *     possible object is
     *     {@link String }
     *
     */
    public String getCountry() {
        return country;
    }

    /**
     * Sets the value of the country property.
     *
     * @param value
     *     allowed object is
     *     {@link String }
     *
     */
    public void setCountry(String value) {
        this.country = value;
    }

    public boolean isBlacklisted() {
       return blacklisted;
    }

    public void setBlacklisted(boolean blacklisted) {
        this.blacklisted = blacklisted;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }
}
