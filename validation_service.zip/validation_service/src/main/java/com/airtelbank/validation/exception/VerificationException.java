package com.airtelbank.validation.exception;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.*;

@Setter
@Getter
@ToString
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class VerificationException extends Exception {
    private String id;

    public VerificationException(String message, String id) {
        super(message);
        this.id = id;
    }

    public VerificationException(String message, Throwable cause, String id) {
        super(message, cause);
        this.id = id;
    }

    public VerificationException(Throwable cause, String id) {
        super(cause);
        this.id = id;
    }
}
