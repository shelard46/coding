package com.airtelbank.validation.util;

import static org.elasticsearch.index.query.QueryBuilders.matchQuery;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;

import org.apache.commons.lang3.StringUtils;
import org.apache.http.HttpHost;
import org.elasticsearch.action.ActionListener;
import org.elasticsearch.action.bulk.BulkRequest;
import org.elasticsearch.action.bulk.BulkResponse;
import org.elasticsearch.action.delete.DeleteRequest;
import org.elasticsearch.action.index.IndexRequest;
import org.elasticsearch.action.search.SearchRequest;
import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.client.RequestOptions;
import org.elasticsearch.client.RestClient;
import org.elasticsearch.client.RestHighLevelClient;
import org.elasticsearch.common.unit.Fuzziness;
import org.elasticsearch.search.SearchHit;
import org.elasticsearch.search.builder.SearchSourceBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.MessageSource;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;

import com.airtelbank.validation.constants.Constants;
import com.airtelbank.validation.exception.ElasticSearchException;
import com.airtelbank.validation.model.BlacklistEntityResponse;
import com.airtelbank.validation.model.blacklist.BlacklistData;
import com.google.gson.Gson;


import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
public class BlackListEntityUtil {

    @Value("${elasticsearch.clustername}")
    private String esClusterName;

    @Value("${elasticsearch.matchPercentage}")
    private String matchPercentage;

    @Value("${elasticsearch.matchFactor}")
    private float matchFactor;

    @Value("#{'${elasticsearch.host}'.split(',')}")
    private List<String> hosts;

    @Autowired
    private RestHighLevelClient client;
    
    @Autowired
    private MessageSource messageSource;

    public BlacklistEntityResponse getFailureResponse() {
        BlacklistEntityResponse blacklistEntityResponse = new BlacklistEntityResponse();
        blacklistEntityResponse.setStatus(HttpStatus.OK.value());
        blacklistEntityResponse.setMessage(messageSource.getMessage("config.blacklist.entityNotFound.msg", null, Locale.ENGLISH));
        blacklistEntityResponse.setErrorCode(messageSource.getMessage("config.blacklist.entity.notFound.code", null, Locale.ENGLISH));
        return blacklistEntityResponse;
    }

    public BlacklistEntityResponse getErrorResponse() {
        BlacklistEntityResponse blacklistEntityResponse = new BlacklistEntityResponse();
        blacklistEntityResponse.setStatus(HttpStatus.INTERNAL_SERVER_ERROR.value());
        blacklistEntityResponse.setMessage(messageSource.getMessage("config.blacklist.entity.server.error.msg", null, Locale.ENGLISH));
        blacklistEntityResponse.setErrorCode(messageSource.getMessage("config.blacklist.entity.server.error.code", null, Locale.ENGLISH));
        return blacklistEntityResponse;
    }

    public BlacklistEntityResponse getValidationFailureResponse() {
        BlacklistEntityResponse blacklistEntityResponse = new BlacklistEntityResponse();
        blacklistEntityResponse.setStatus(HttpStatus.BAD_REQUEST.value());
        blacklistEntityResponse.setMessage(messageSource.getMessage("config.blacklist.entity.field.missing.msg", null, Locale.ENGLISH));
        blacklistEntityResponse.setErrorCode(messageSource.getMessage("config.blacklist.entity.validation.failure.code", null, Locale.ENGLISH));
        return blacklistEntityResponse;
    }

    public BlacklistEntityResponse getSuccessResponse(List<BlacklistData> entities, String name) {
        BlacklistEntityResponse blacklistEntityResponse = new BlacklistEntityResponse();
        blacklistEntityResponse.setStatus(HttpStatus.OK.value());
        blacklistEntityResponse.setMessage(String.format(messageSource.getMessage("config.blacklist.entityFound.msg", null, Locale.ENGLISH), name));
        blacklistEntityResponse.setErrorCode(messageSource.getMessage("config.blacklist.entity.found.code", null, Locale.ENGLISH));
        blacklistEntityResponse.setEntities(entities);
        return blacklistEntityResponse;
    }

    public List<BlacklistData> getEntities(SearchResponse searchResponse, int factor) {
        List<BlacklistData> list = new ArrayList<>();
        factor = factor + (int) Math.ceil(factor * matchFactor);      //logic to implement 75% match
        if (searchResponse == null || searchResponse.getHits() == null || searchResponse.getHits().getHits() == null) {
            return list;
        }

        SearchHit[] results = searchResponse.getHits().getHits();
        Gson gson = new Gson();
        for (SearchHit hit : results) {
            String sourceAsString = hit.getSourceAsString();
            BlacklistData blacklistData;
            if (sourceAsString != null) {
                blacklistData = gson.fromJson(sourceAsString, BlacklistData.class);
                if (blacklistData.isBlacklisted() && (factor == 0 || blacklistData.getName().split(Constants.SPACE_SEPARATOR).length < factor))
                	list.add(blacklistData);
            }
        }
        return list;
    }

    public SearchResponse getSearchResponse(String key, String value) throws IOException {
        SearchResponse searchResponse = null;
        SearchRequest searchRequest = new SearchRequest(esClusterName);
        SearchSourceBuilder searchSourceBuilder = new SearchSourceBuilder();
        searchSourceBuilder.from(0);
        searchSourceBuilder.size(5000);
        if (key.equalsIgnoreCase(Constants.PAN)) {
            searchSourceBuilder.query(matchQuery(key, value));
        } else {
            searchSourceBuilder.query(matchQuery(key, value)
                    .fuzziness(Fuzziness.AUTO)
                    .fuzzyTranspositions(false)
                    .minimumShouldMatch(matchPercentage));
        }
        searchRequest.source(searchSourceBuilder);
        ensureElasticConnectivity(client);
        searchResponse = client.search(searchRequest, RequestOptions.DEFAULT);
        return searchResponse;
    }

    public void addIndexes(BlacklistData blacklistData, BulkRequest bulkRequest) {
        Map<String, Object> indexRequestMap = new HashMap();
        indexRequestMap.put(Constants.NAME, blacklistData.getName());
        indexRequestMap.put(Constants.PAN.toLowerCase(), blacklistData.getPan());
        indexRequestMap.put(Constants.ID, blacklistData.getId());
        indexRequestMap.put(Constants.BLACKLISTED, blacklistData.isBlacklisted());
        indexRequestMap.put(Constants.CHARGE, blacklistData.getCharge());
        indexRequestMap.put(Constants.COUNTRY, blacklistData.getCountry());
        indexRequestMap.put(Constants.ADDRESS, getAddress(blacklistData));

        IndexRequest indexRequest = new IndexRequest(esClusterName, esClusterName, UUID.randomUUID().toString());
        indexRequest.source(indexRequestMap);
        bulkRequest.add(indexRequest);
    }

    private String getAddress(BlacklistData blacklistData) {
        StringBuilder stringBuilder = new StringBuilder();
        if (StringUtils.isNotEmpty(blacklistData.getAddressLine())) {
            stringBuilder.append(blacklistData.getAddressLine());
        }
        if (StringUtils.isNotEmpty(blacklistData.getAddressCity())) {
            stringBuilder.append(" ").append(blacklistData.getAddressCity());
        }
        return stringBuilder.toString();
    }

    public void deleteIndexes(BlacklistData blacklistData) throws IOException {
        DeleteRequest deleteRequest = new DeleteRequest(esClusterName, esClusterName, blacklistData.getId());
        ensureElasticConnectivity(client);
        client.delete(deleteRequest, RequestOptions.DEFAULT);
    }

    private void ensureElasticConnectivity(RestHighLevelClient client) {
        try {
            if(client.ping(RequestOptions.DEFAULT)) {
                return;
            }
        } catch (IOException e) {
            log.error("exception occurred resetting elastic");
        } finally {
            List<HttpHost> hostList = new ArrayList<>();
            for (String host : hosts) {
                String[] hostDetails  = host.split("\\:");
                hostList.add(new HttpHost(hostDetails[0], Integer.parseInt(hostDetails[1]), Constants.HTTP));
            }

            log.info("reconnecting to {} elastic clusters", hostList.size());
            client = new RestHighLevelClient(
                    RestClient.builder(
                            hostList.toArray(new HttpHost[hostList.size()])));
        }

    }

    public void putDataInElastic(BulkRequest bulkRequest) {
        ensureElasticConnectivity(client);
        client.bulkAsync(bulkRequest, RequestOptions.DEFAULT, new ActionListener<BulkResponse>() {

            @Override
            public void onResponse(BulkResponse bulkItemResponses) {
                if (!bulkItemResponses.hasFailures()) {
                    log.info("successfully loaded data in elastic and it took: {} ms", bulkItemResponses.getTook());
                }
            }

            @Override
            public void onFailure(Exception e) {
                log.error("error occurred while pushing data to elastic", e);
                throw new ElasticSearchException();
            }
        });
    }
}
