package com.airtelbank.validation.util;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.airtelbank.validation.constants.Constants;
import com.airtelbank.validation.dao.aerospike.model.AadhaarVerify;
import com.airtelbank.validation.dao.aerospike.model.Identities;
import com.airtelbank.validation.dao.jpa.model.DocumentAuditLog;
import com.airtelbank.validation.dao.jpa.model.DocumentAuditLog.TransactionStatus;
import com.airtelbank.validation.exception.AadhaarKUAVerifyException;
import com.airtelbank.validation.exception.AadharVerificationException;
import com.airtelbank.validation.exception.ObjectConversionException;
import com.airtelbank.validation.exception.UIDAIAadhaarVerifyException;
import com.airtelbank.validation.exception.UIDAIException;
import com.airtelbank.validation.model.AadhaarInfo;
import com.airtelbank.validation.model.CBSDedupeRequest;
import com.airtelbank.validation.model.DataArea;
import com.airtelbank.validation.model.Document;
import com.airtelbank.validation.model.EbmHeader;
import com.airtelbank.validation.model.GenerateAadhaarOTPResponse;
import com.airtelbank.validation.model.KUARequest;
import com.airtelbank.validation.model.ResidentIdentity;
import com.airtelbank.validation.model.Status;
import com.airtelbank.validation.model.UserAadharProfile;
import com.airtelbank.validation.model.UserAadharProfileResponse;
import com.airtelbank.validation.model.aadhar.generate.otp.GenerateAadhaarOTPData;
import com.airtelbank.validation.model.aadhar.generate.otp.GenerateAadharOTPDataResponse;
import com.airtelbank.validation.model.aadhar.validate.otp.ValidateAadharOTPData;
import com.airtelbank.validation.model.aadhar.validate.otp.ValidateAadharOTPDataResponse;
import com.airtelbank.validation.model.cbs.DedupeRequestForCBS;
import com.airtelbank.validation.model.cbs.SessionContext;

@Component
public class ValidationUtil {

    private static final Logger logger = LoggerFactory.getLogger(ValidationUtil.class);

    @Value("${config.uidai.lob}")
    private String uidaiLob;

    @Value("${config.uidai.consumername}")
    private String uidaiConsumerName;

    @Value("${config.uidai.programename}")
    private String uidaiProgrameName;

    @Value("${config.uidai.subaua}")
    private String uidaiSubAua;

    @Value("${config.uidai.terminalid}")
    private String uidaiTerminalId;

    public  GenerateAadhaarOTPData createAadhaarOTPRequest(Document request,String docNumber) {
        try {
            if (request != null) {
                GenerateAadhaarOTPData uidaiRequest = new GenerateAadhaarOTPData();
                EbmHeader ebmHeader = new EbmHeader();
                ebmHeader.setConsumerName(uidaiConsumerName);
                ebmHeader.setConsumerTransactionId(request.getId());
                ebmHeader.setLob(uidaiLob);
                ebmHeader.setProgrammeName(uidaiProgrameName);
                AadhaarInfo aadhaarRequestDetails = new AadhaarInfo();
                if (CommonUtil.isAadhaarRequest(request)) {
                    aadhaarRequestDetails.setUserIdentifier(docNumber);
                } else {
                    aadhaarRequestDetails.setUserIdentifier(request.getDocNumber());
                }
                aadhaarRequestDetails.setOtpRequestType(request.getUserIdentifierType().toUpperCase());
                aadhaarRequestDetails.setSubAua(uidaiSubAua);


                aadhaarRequestDetails.setTimestamp(LocalDateTime.now().withNano(0).format(DateTimeFormatter.ISO_DATE_TIME));

                DataArea dataArea = new DataArea();
                dataArea.setAadhaarInfo(aadhaarRequestDetails);

                uidaiRequest.setDataArea(dataArea);
                uidaiRequest.setEbmHeader(ebmHeader);
                return uidaiRequest;
            } else {
                logger.info("request null in createAadhaarOTPRequest");
                throw new ObjectConversionException();
            }
        } catch (Exception ex) {
            logger.info("Exception in createAadhaarOTPRequest.");
            throw new ObjectConversionException();
        }
    }

    public static Document validateGenerateAadhaarOTPResponse(GenerateAadharOTPDataResponse response) throws Exception {
        try {
            if (response == null || response.getDataArea() == null
                    || response.getDataArea().getGenerateAadhaarOTPResponse() == null
                    || response.getDataArea().getGenerateAadhaarOTPResponse().getStatus() == null) {
                logger.info("Exception while creating generate Aadhaar OTP response.");
                throw new ObjectConversionException();
            }
            if (response.getDataArea().getGenerateAadhaarOTPResponse().getStatus().getStatusCode()
                    .equals(Constants.GENERATE_AADHAAR_OTP_SUCCESS_STATUS_CODE)) {

                Document document = new Document();
                GenerateAadhaarOTPResponse generateAadhaarOTPResponse = response.getDataArea().getGenerateAadhaarOTPResponse();
                String maskedEmailId = null;
                String maskedMobileNumber = null;

                if (generateAadhaarOTPResponse.getEmail() != null) {
                    maskedEmailId = generateAadhaarOTPResponse.getEmail().trim();
                }
                if (generateAadhaarOTPResponse.getMobileNumber() != null) {
                    maskedMobileNumber = generateAadhaarOTPResponse.getMobileNumber().trim();
                }
                document.setId(response.getEbmHeader().getConsumerTransactionId());
                document.setMaskedEmailId(maskedEmailId);
                document.setMaskedMobileNumber(maskedMobileNumber);
                document.setUserIdentifierType(generateAadhaarOTPResponse.getUserIdentifierType());
                return document;
            } else {
                logger.info("UIDAI giving 400/500 response code.");
                throw new UIDAIException(response.getDataArea()
                        .getGenerateAadhaarOTPResponse().getStatus().getStatusCode());
            }
        } catch (Exception ex) {
            logger.info("Exception while creating generate Aadhaar OTP response.");
            throw ex;
        }
    }

    public static DocumentAuditLog createDocumentAuditLogForRequest(Document document,
                                                                    DocumentAuditLog documentAuditLog) {
        try {
            documentAuditLog.setAction(document.getAction());
            documentAuditLog.setChannel(document.getChannel());
            documentAuditLog.setTransactionId(document.getId());
            documentAuditLog.setRequestTimestamp(new Date());
            documentAuditLog.setSource(document.getSource());
            documentAuditLog.setMobile(document.getMobile());
            documentAuditLog.setDocType(document.getDocType());
            documentAuditLog.setDocNumber(Constants.NA);
            documentAuditLog.setTransactionStatus(TransactionStatus.GENERATION_AADHAAR_OTP_SUCCESS);
            documentAuditLog.setUserIdentifierType(document.getUserIdentifierType().toUpperCase());
            return documentAuditLog;
        } catch (Exception ex) {
            logger.info("Exception while creating request for DocumentAuditLog.");
            throw new ObjectConversionException();
        }
    }

    public static DocumentAuditLog updateDocumentAuditLog(GenerateAadharOTPDataResponse response,
                                                          DocumentAuditLog documentAuditLog) {
        try {
            documentAuditLog.setResponseTimestamp(response.getDataArea().getGenerateAadhaarOTPResponse().getResponseTimeStamp());
            if( response.getDataArea().getGenerateAadhaarOTPResponse().getStatus()  != null) {
            	documentAuditLog.setStatusCode(response.getDataArea().getGenerateAadhaarOTPResponse().getStatus().getStatusCode());
            	documentAuditLog.setStatusMessage(response.getDataArea().getGenerateAadhaarOTPResponse().getStatus().getStatusDescription());
            }
            documentAuditLog.setPartnerTransactionId((response.getDataArea().getGenerateAadhaarOTPResponse().getResponseCode()));
            documentAuditLog.setTransactionStatus(TransactionStatus.GENERATION_AADHAAR_OTP_SUCCESS);
            return documentAuditLog;
        } catch (Exception ex) {
            logger.info("Exception while updating request object of DocumentAuditLog");
            throw new ObjectConversionException();
        }
    }

    public static Identities createIdentityRequest(String id, String aid, int generationCount, Document document) {
        try {
            Identities identity = new Identities();
            identity.setIsVerified(false);
            identity.setGenCount(generationCount + 1);
            identity.setChannel(document.getChannel() != null ? document.getChannel() : null);
            identity.setAid(aid);
            identity.setCreatedDate(LocalDateTime.now());
            identity.setDocType(document.getDocType() != null ? document.getDocType() : null);
            identity.setId(id);
            identity.setMobileNumber(document.getMobile() != null ? document.getMobile() : null);
            identity.setSource(document.getSource() != null ? document.getSource() : null);
            if (CommonUtil.isAadhaarRequest(document)) {
                identity.setDocNumber(document.getDocReferenceNumber() != null ? document.getDocReferenceNumber() : null);
            } else {
                identity.setDocNumber(CommonUtil.encryptData(document.getDocNumber(), document.getMobile()));
            }
            identity.setUserIdentifierType(document.getUserIdentifierType() != null ? document.getUserIdentifierType() : null);
            return identity;
        } catch (Exception ex) {
            logger.info("Exception while creating request for Identity.");
            throw new ObjectConversionException();
        }
    }

    public static DocumentAuditLog updateVerifyDocumentAuditLog(ValidateAadharOTPDataResponse response,
                                                                DocumentAuditLog documentAuditLog, Boolean isSuccess) {

        documentAuditLog.setResponseTimestamp(CommonUtil.getDate(response.getDataArea().getAadharProfileResponse().getResponseTimeStamp()));
        if( response.getDataArea().getAadharProfileResponse().getStatus() != null) {
        	documentAuditLog.setStatusCode(response.getDataArea().getAadharProfileResponse().getStatus().getStatusCode());
        	documentAuditLog.setStatusMessage(response.getDataArea().getAadharProfileResponse().getStatus().getStatusDescription());
        }
        documentAuditLog.setPartnerTransactionId((response.getDataArea().getAadharProfileResponse().getResponseCode()));
        documentAuditLog.setUidToken((response.getDataArea().getAadharProfileResponse().getUidToken()));
        if(response.getDataArea().getAadharProfileResponse().getUserIdentifierType() != null){
        	documentAuditLog.setUserIdentifierType(response.getDataArea().getAadharProfileResponse().getUserIdentifierType());
        }
        if (isSuccess)
            documentAuditLog.setTransactionStatus(com.airtelbank.validation.dao.jpa.model.DocumentAuditLog.TransactionStatus.VALIDATE_AADHAAR_OTP_SUCCESS);
        else
            documentAuditLog.setTransactionStatus(com.airtelbank.validation.dao.jpa.model.DocumentAuditLog.TransactionStatus.VALIDATE_AADHAAR_OTP_FAILED);
        return documentAuditLog;
    }

    public static Boolean getAadhaarProfileStatus(ValidateAadharOTPDataResponse aadhaarProfile, String errorCode) throws UIDAIAadhaarVerifyException {
        DataArea dataArea = null;
        UserAadharProfileResponse userAadharProfileResponse = null;
        String statusCode = errorCode;
        String statusCodeComplete = null;
        if ((dataArea = aadhaarProfile.getDataArea()) != null) {
            userAadharProfileResponse = dataArea.getAadharProfileResponse();
        }
        if (userAadharProfileResponse != null) {
            Status responseStatus = userAadharProfileResponse.getStatus();
            statusCodeComplete = (responseStatus != null ? responseStatus.getStatusCode() : null);
            if (statusCodeComplete != null && !statusCodeComplete.isEmpty()) {
                String[] statusCodeSplit = statusCodeComplete.split(Constants.DEFAULT_STATUS_CODE_SPLITTER);
                statusCode = statusCodeSplit.length == 3 ? statusCodeSplit[1].trim() : errorCode;
            }
        }
        if (!Constants.AADHAAR_VERIFY_SUCCESS_STATUS_CODE.equals(statusCode)) {
            throw new UIDAIAadhaarVerifyException(CommonUtil.getValueByDefault(statusCodeComplete, errorCode));
        }
        return true;
    }

    public  ValidateAadharOTPData getAadhaarProfileRequest(Identities identity, String residentConsent, String printFormatRequest, String localLangRequired, String docOriginalNum, String oneTimePassword, String uniqueDeviceCode) {
    	ValidateAadharOTPData getUserAadhaarProfileReqMsg = new ValidateAadharOTPData();
        EbmHeader ebmHeader = new EbmHeader();
        ebmHeader.setLob(uidaiLob);
        ebmHeader.setConsumerName(uidaiConsumerName);
        ebmHeader.setProgrammeName(uidaiProgrameName);
        ebmHeader.setConsumerTransactionId(identity.getAid());
        getUserAadhaarProfileReqMsg.setEbmHeader(ebmHeader);
        DataArea dataArea = new DataArea();
        UserAadharProfile getUserAadhaarProfileRequest = new UserAadharProfile();
        getUserAadhaarProfileRequest.setUserIdentifier(docOriginalNum);
        getUserAadhaarProfileRequest.setUserIdentifierType(identity.getUserIdentifierType());
        getUserAadhaarProfileRequest.setResidentConsent(residentConsent);
        getUserAadhaarProfileRequest.setPrintFormatRequest(printFormatRequest);
        getUserAadhaarProfileRequest.setLocalLangRequired(localLangRequired);
        getUserAadhaarProfileRequest.setOneTimePassword(oneTimePassword);
        getUserAadhaarProfileRequest.setUniqueDeviceCode(uniqueDeviceCode);
        dataArea.setAadhaarProfileRequest(getUserAadhaarProfileRequest);
        getUserAadhaarProfileReqMsg.setDataArea(dataArea);

        return getUserAadhaarProfileReqMsg;

    }

    public static AadhaarVerify getAadhaarProfileResponse(ValidateAadharOTPDataResponse aadhaarProfileResponse) throws  UIDAIAadhaarVerifyException {
        AadhaarVerify aadharVerifyResponse = new AadhaarVerify();
        try {
            if (aadhaarProfileResponse == null || aadhaarProfileResponse.getDataArea() == null
                    || aadhaarProfileResponse.getDataArea().getAadharProfileResponse() == null
                    || aadhaarProfileResponse.getDataArea().getAadharProfileResponse().getStatus() == null
                    || aadhaarProfileResponse.getDataArea().getAadharProfileResponse().getStatus().getStatusCode() == null) {
                throw new AadharVerificationException();
            }
            String statusCodeTemp = aadhaarProfileResponse.getDataArea().getAadharProfileResponse().getStatus().getStatusCode();
            String statusCode = null;
            if (!StringUtils.isEmpty(statusCodeTemp)) {
                if (!statusCodeTemp.isEmpty()) {
                    String[] statusCodeSplit = statusCodeTemp.split(Constants.DEFAULT_STATUS_CODE_SPLITTER);
                    statusCode = statusCodeSplit[1].trim();
                }
                if (Constants.AADHAAR_VERIFY_SUCCESS_STATUS_CODE.equals(statusCode)) {
                    ResidentIdentity residentIdentity = null;
                    DataArea dataArea = aadhaarProfileResponse.getDataArea();
                    UserAadharProfileResponse userAadharProfileResponse = dataArea.getAadharProfileResponse();

                    residentIdentity = userAadharProfileResponse.getResidentIdentity();
                    aadharVerifyResponse.setPhoto(userAadharProfileResponse.getPhoto());
                    aadharVerifyResponse.setEAadhaarPdf(userAadharProfileResponse.getEAadhaarPDF());

                    if(StringUtils.isNotBlank(userAadharProfileResponse.getResponseCode())) {
                        aadharVerifyResponse.setResponseCode(userAadharProfileResponse.getResponseCode());
                    }

                    if(StringUtils.isNotBlank(userAadharProfileResponse.getResponseTimeStamp())) {
                        aadharVerifyResponse.setResponseTimeStamp(userAadharProfileResponse.getResponseTimeStamp());
                 	}

                    if (userAadharProfileResponse.getUserIdentifierType().equalsIgnoreCase(Constants.VID_IDENTIFIER)) {
                        //Vid response
                        aadharVerifyResponse.setAadhaarNumber(userAadharProfileResponse.getAadhaarNumber());
                        aadharVerifyResponse.setUidToken(userAadharProfileResponse.getUidToken());
                        aadharVerifyResponse.setUserIdentifierType(userAadharProfileResponse.getUserIdentifierType().toUpperCase());
                    } else {
                        //Aadhaar response
                        aadharVerifyResponse.setAadhaarNumber(userAadharProfileResponse.getAadhaarNumber());
                        aadharVerifyResponse.setUidToken(userAadharProfileResponse.getUidToken());
                        aadharVerifyResponse.setUserIdentifierType(userAadharProfileResponse.getUserIdentifierType().toUpperCase());
                    }

                    if (residentIdentity != null) {
                        aadharVerifyResponse.setAadhaarRegMobile(residentIdentity.getAadhaarRegMobile());
                        aadharVerifyResponse.setCareOf(residentIdentity.getCareOf());
                        aadharVerifyResponse.setCity(residentIdentity.getCity());
                        aadharVerifyResponse.setCountry(residentIdentity.getCountry());
                        aadharVerifyResponse.setDateOfBirth(CommonUtil.getDateDobAua(residentIdentity.getDateOfBirth()));
                        aadharVerifyResponse.setDistrict(residentIdentity.getDistrict());
                        aadharVerifyResponse.setEmail(residentIdentity.getEmail());
                        aadharVerifyResponse.setGender(residentIdentity.getGender());
                        aadharVerifyResponse.setHouse(residentIdentity.getHouse());
                        aadharVerifyResponse.setLandMark(residentIdentity.getLandMark());
                        aadharVerifyResponse.setLocality(residentIdentity.getLocality());
                        Map<String, String> nameParts = getNameByParts(residentIdentity.getName());
                        aadharVerifyResponse.setFirstName(nameParts.get(Constants.FIRST_NAME));
                        aadharVerifyResponse.setMiddleName(nameParts.get(Constants.MIDDLE_NAME));
                        aadharVerifyResponse.setLastName(nameParts.get(Constants.LAST_NAME));
                        aadharVerifyResponse.setPinCode(residentIdentity.getPinCode());
                        aadharVerifyResponse.setPostOfficeName(residentIdentity.getPostOfficeName());
                        aadharVerifyResponse.setState(residentIdentity.getState());
                        aadharVerifyResponse.setSubDistrict(residentIdentity.getSubDistrict());
                        aadharVerifyResponse.setStreet(residentIdentity.getStreet());
                    }
                    return aadharVerifyResponse;
                } else {
                    throw new UIDAIAadhaarVerifyException(statusCode);
                }
            } else {
                throw new UIDAIAadhaarVerifyException(statusCode);
            }
        } catch (UIDAIAadhaarVerifyException | AadharVerificationException ex) {
        	throw ex;
        } catch(Exception ex) {
        	logger.error(ex.getMessage(),ex);
        	throw new AadharVerificationException();
        }
    }

    public static Map<String, String> getNameByParts(String fullName) {
        Map<String, String> nameParts = new HashMap<>();
        String []namePart = fullName.trim().split("\\s+");

        if( namePart.length >= 1) {
        	nameParts.put(Constants.FIRST_NAME, namePart[0]);
        } else {
        	nameParts.put(Constants.FIRST_NAME, null);
        }

        if(namePart.length>=2) {
        	nameParts.put(Constants.LAST_NAME, namePart[namePart.length-1]);
        }

        int limit = namePart.length-1;
        StringBuilder nameBuilder = new StringBuilder();
        for( int i=1; i < limit; i++) {
        	nameBuilder.append(namePart[i]).append(" ");
        }

        if( nameBuilder.length()> 0) {
        	nameBuilder.delete(nameBuilder.length()-1, nameBuilder.length());
        	nameParts.put(Constants.MIDDLE_NAME, nameBuilder.toString());
        }
        return nameParts;
    }

    public static DedupeRequestForCBS getRequestForCBSDedupe(CBSDedupeRequest request, SessionContext session) {

        DedupeRequestForCBS dedupeRequestForCBS = new DedupeRequestForCBS();
        dedupeRequestForCBS.setSessionContext(session!=null?session:null);
        dedupeRequestForCBS.setAadharCardNo(request.getAadhaarNo()!=null? (request.getAadhaarNo()):null);
        dedupeRequestForCBS.setNationalIdentificationCode(request.getMobileNo()!=null? (request.getMobileNo()):null);
        dedupeRequestForCBS.setEmailId(request.getEmailId()!=null? (request.getEmailId()):null);
        dedupeRequestForCBS.setCustomerType(request.getCustomerType()!=null? (request.getCustomerType()):null);
        dedupeRequestForCBS.setPanNo(request.getPanNo()!=null? (request.getPanNo()):null);
        return dedupeRequestForCBS;
    }

    public static Boolean getAadhaarProfileStatusForKUA(ValidateAadharOTPDataResponse aadhaarProfile, String errorCode)  {
        DataArea dataArea = null;
        UserAadharProfileResponse userAadharProfileResponse = null;
        String statusCode = errorCode;
        String statusCodeComplete = null;
        if ((dataArea = aadhaarProfile.getDataArea()) != null) {
            userAadharProfileResponse = dataArea.getAadharProfileResponse();
        }
        if (userAadharProfileResponse != null) {
            Status responseStatus = userAadharProfileResponse.getStatus();
            statusCodeComplete = (responseStatus != null ? responseStatus.getStatusCode() : null);
            if (statusCodeComplete != null && !statusCodeComplete.isEmpty()) {
                String[] statusCodeSplit = statusCodeComplete.split(Constants.DEFAULT_STATUS_CODE_SPLITTER);
                statusCode = statusCodeSplit.length == 3 ? statusCodeSplit[1].trim() : errorCode;
            }

        }
        if (!Constants.AADHAAR_VERIFY_KUA_SUCCESS_STATUS_CODE.equals(statusCode)) {
            throw new AadhaarKUAVerifyException(CommonUtil.getValueByDefault(statusCodeComplete, errorCode));
        }
        return true;
    }

    public static DocumentAuditLog createDocumentAuditLogForRequestForKUA(KUARequest kuaRequest,
                                                                    DocumentAuditLog documentAuditLog) {
        try {
            documentAuditLog.setCustomColumn1(kuaRequest.getContentId());
            documentAuditLog.setAction(Constants.KUA);
            documentAuditLog.setRequestTimestamp(new Date());
            documentAuditLog.setSource(kuaRequest.getSource());
            documentAuditLog.setMobile(kuaRequest.getMobile());
            documentAuditLog.setChannel(kuaRequest.getChannel());
            documentAuditLog.setDocType(Constants.AADHAAR);
            documentAuditLog.setTransactionStatus(com.airtelbank.validation.dao.jpa.model.DocumentAuditLog.TransactionStatus.AADHAAR_KUA_SUCCESS);
            documentAuditLog.setUserIdentifierType(kuaRequest.getUserIdentifierType().toUpperCase());
            documentAuditLog.setDocNumber(Constants.NA);
            return documentAuditLog;
        } catch (Exception ex) {
            logger.info("Exception while creating request for DocumentAuditLog for KUA.");
            throw new ObjectConversionException();
        }
    }

    public static DocumentAuditLog updateVerifyDocumentAuditLogForKUA(ValidateAadharOTPDataResponse response,
                                                                      DocumentAuditLog documentAuditLog, Boolean isSuccess) {
        try {
            documentAuditLog.setResponseTimestamp(CommonUtil.getDate(response.getDataArea().getAadharProfileResponse().getResponseTimeStamp()));
            documentAuditLog.setStatusCode(response.getDataArea().getAadharProfileResponse().getStatus().getStatusCode());
            documentAuditLog.setStatusMessage(response.getDataArea().getAadharProfileResponse().getStatus().getStatusDescription());
            documentAuditLog.setPartnerTransactionId((response.getDataArea().getAadharProfileResponse().getResponseCode()));
            documentAuditLog.setUidToken((response.getDataArea().getAadharProfileResponse().getUidToken()));
            documentAuditLog.setTransactionId(response.getEbmHeader().getConsumerTransactionId());

            if (isSuccess)
                documentAuditLog.setTransactionStatus(com.airtelbank.validation.dao.jpa.model.DocumentAuditLog.TransactionStatus.AADHAAR_KUA_SUCCESS);
            else
                documentAuditLog.setTransactionStatus(com.airtelbank.validation.dao.jpa.model.DocumentAuditLog.TransactionStatus.AADHAAR_KUA_FAILURE);
            return documentAuditLog;
        } catch (Exception ex) {
            logger.info("Exception while updating request object of DocumentAuditLog for KUA.");
            throw new ObjectConversionException();
        }
    }
}