package com.airtelbank.validation.validator;

public interface AadhaarOtpGroup {

}
