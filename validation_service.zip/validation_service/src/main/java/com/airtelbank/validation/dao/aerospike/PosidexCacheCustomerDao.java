package com.airtelbank.validation.dao.aerospike;


import java.util.List;

import com.airtelbank.validation.dao.aerospike.model.PosidexCacheCustomerDetails;


public interface PosidexCacheCustomerDao {
	public PosidexCacheCustomerDetails getPosidexDataAero(String id);
	public List<PosidexCacheCustomerDetails> getPosidexDataFromAeroForPoiNumber(String poiNumber);
}
