package com.airtelbank.validation.exception;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Setter
@Getter
@ToString
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class ElasticSearchException extends RuntimeException {
    private String id;

    public ElasticSearchException(String message, String id) {
        super(message);
        this.id = id;
    }

    public ElasticSearchException(String message, Throwable cause, String id) {
        super(message, cause);
        this.id = id;
    }

    public ElasticSearchException(Throwable cause, String id) {
        super(cause);
        this.id = id;
    }
}