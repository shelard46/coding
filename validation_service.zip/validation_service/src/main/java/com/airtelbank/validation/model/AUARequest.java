package com.airtelbank.validation.model;

import javax.validation.Valid;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Pattern;

import lombok.Builder;


import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@Builder
@ToString
public class AUARequest {
	@NotBlank
	private String serviceCode;
	@NotBlank
	private String aadhaarTimestamp;
	@NotBlank
	private String biometricData;
	@NotBlank
	@Pattern(regexp = "[2-9][0-9]{11}|[0-9]{16}|.{72}", message = "invalid aadhaarId or VID or UID")
	private String userIdentifier;
	@NotBlank
	@Pattern(regexp = "[AVT]", message = "invalid identifier Type use (A/V/T)")
	private String userIdentifierType;
	@NotBlank
	private String certificateIdentifier;
	@NotBlank
	private String skey;
	@NotBlank
	private String hmac;
	@Valid
	private DeviceDetails deviceDetails;
	//@NotBlank
    //@Pattern(regexp = "[6789][0-9]{9}", message = "invalid customerId")
	private String customerId;
	private String channel;
	private String biometricType;
}
