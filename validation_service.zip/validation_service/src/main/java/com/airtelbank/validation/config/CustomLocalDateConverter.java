package com.airtelbank.validation.config;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

import org.springframework.core.convert.converter.Converter;
import org.springframework.data.convert.ReadingConverter;
import org.springframework.data.convert.WritingConverter;

public class CustomLocalDateConverter {
	
	private static DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");

	@WritingConverter
	  public enum Java8LocalDateToStringConverter implements Converter<java.time.LocalDate, String> {
	    INSTANCE;

	    @Override
	    public String convert(java.time.LocalDate source) {
	    	return source == null ? null : dateTimeFormatter.format(source);
	    }
	  }
	
	
	@ReadingConverter
	  public enum StringToJava8LocalDateConverter implements Converter<String, java.time.LocalDate> {
	    INSTANCE;

	    @Override
	    public java.time.LocalDate convert(String source) {
	      if (source == null) {
	        return null;
	      }

	      return LocalDate.parse(source,dateTimeFormatter);
	    }
	  }
}
