package com.airtelbank.validation.dao.aerospike.model;

import org.springframework.data.aerospike.mapping.Document;
import org.springframework.data.aerospike.mapping.Field;
import org.springframework.data.annotation.Id;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Setter
@Getter
@NoArgsConstructor
@AllArgsConstructor
@ToString
@Document(expiration=300)
public class Blackout {
	@Id
	@Field(value = "PK")
	private String id;
	@Field(value = "customerId")
	private String customerId;
	@Field(value = "type")
	private String type;
}
