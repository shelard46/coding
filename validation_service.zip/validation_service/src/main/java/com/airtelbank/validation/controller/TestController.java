package com.airtelbank.validation.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.airtelbank.validation.enums.CommunicationType;
import com.airtelbank.validation.service.CommunicationService;

@RestController
@RequestMapping(value = {"/api/test","/api/v2"})
public class TestController {
	
	@Autowired private CommunicationService communicationService;

	@PostMapping(path = "/send/sms")
	public ResponseEntity<String> test(@RequestHeader String customerId, @RequestHeader String type) {
		communicationService.sendCommunication(CommunicationType.valueOf(type), customerId, null, "content", "test");
		return ResponseEntity.ok().body(":)");
	}

}
