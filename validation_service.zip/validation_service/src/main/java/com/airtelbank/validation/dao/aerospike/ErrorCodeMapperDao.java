package com.airtelbank.validation.dao.aerospike;

import java.util.List;

import com.airtelbank.validation.dao.aerospike.model.ErrorCodeMapper;

public interface ErrorCodeMapperDao {
    Boolean addNewErrorCode(ErrorCodeMapper errorCodeMapper);
    ErrorCodeMapper getErrorCodeDataById(String id);
    ErrorCodeMapper getUniqueErrorCodeData(String errorCode, String apiName);
    public int saveAllErrorCode(List<ErrorCodeMapper> errorCodeMappers);
    public List<ErrorCodeMapper> getErrorCode(String originalErrorCode);
    public int deleteErrorCode(String originalErrorCode);
}
