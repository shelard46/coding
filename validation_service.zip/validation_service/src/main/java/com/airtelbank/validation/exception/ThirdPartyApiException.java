package com.airtelbank.validation.exception;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.*;

@Setter
@Getter
@ToString
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class ThirdPartyApiException extends RuntimeException {
    private String errorMessage;
    private String errorCode;
	public ThirdPartyApiException(String errorMessage, String errorCode, Throwable cause) {
		super(cause);
		this.errorMessage = errorMessage;
		this.errorCode = errorCode;
	}
    
    
}
