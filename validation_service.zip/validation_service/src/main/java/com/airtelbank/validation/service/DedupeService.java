package com.airtelbank.validation.service;

import com.airtelbank.validation.model.CBSDedupeRequest;
import com.airtelbank.validation.model.DedupeRequest;
import com.airtelbank.validation.model.DedupeResponse;
import com.airtelbank.validation.model.ResponseDTO;

public interface DedupeService {
	
	public ResponseDTO<DedupeResponse> fullKycDedupe(DedupeRequest request, String contentId);
	public ResponseDTO<?> checkCbsDedupe(CBSDedupeRequest cbsDedupeRequest, String channel);
}
