package com.airtelbank.validation.service.impl.helper;

import java.util.Date;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.Async;

import com.airtelbank.validation.dao.jpa.model.DocumentAuditLog;
import com.airtelbank.validation.dao.jpa.model.DocumentAuditLog.TransactionStatus;
import com.airtelbank.validation.dao.jpa.respository.DocumentAuditRepository;
import com.airtelbank.validation.exception.ObjectConversionException;
import com.airtelbank.validation.model.PANRequest;
import com.airtelbank.validation.model.PanEsbRequest;
import com.airtelbank.validation.model.PanEsbResponse;
import com.airtelbank.validation.util.CommonUtil;
import com.airtelbank.validation.util.LogMasker;

/**
 * Aspect class to log the audit of pan service.
 * @author B0206676
 *
 */
@Aspect
@Configuration
public class DocumentAuditor {

	@Autowired
	private DocumentAuditRepository documentAuditRepository;
	
	@Autowired
	private LogMasker logMasker;

	private static final Logger log = LoggerFactory.getLogger(DocumentAuditor.class);

	@Pointcut("execution(public com.airtelbank.validation.model.PanEsbResponse com.airtelbank.validation.service.impl.helper.PanServiceImplHelper.fetchResponseForXML(com.airtelbank.validation.model.PanEsbRequest, com.airtelbank.validation.model.PANRequest))")
	public void fetchResponseFromESBPan() {
		// left blank
	}

	@Around("execution(public com.airtelbank.validation.model.PanEsbResponse com.airtelbank.validation.service.impl.helper.PanServiceImplHelper.fetchResponseForXML(com.airtelbank.validation.model.PanEsbRequest, com.airtelbank.validation.model.PANRequest))")
	public PanEsbResponse doAuditLog(ProceedingJoinPoint thisJoinPoint) {
		PanEsbResponse  panEsbResponse= null;
		DocumentAuditLog documentAuditLog = null;
		try {
			if(log.isDebugEnabled())
				log.debug("data Request: {}", logMasker.patternReplace(CommonUtil.jsonObjectToString(thisJoinPoint.getArgs())));
			documentAuditLog = createDocumentAudit( (PanEsbRequest) thisJoinPoint.getArgs()[0], (PANRequest)thisJoinPoint.getArgs()[1]);
			panEsbResponse = (PanEsbResponse)thisJoinPoint.proceed();
			if(log.isDebugEnabled())
				log.debug("data Request: {}", logMasker.patternReplace(CommonUtil.jsonObjectToString(panEsbResponse)));
			documentAuditLog = updateDocumentAuditLog(panEsbResponse, documentAuditLog);
			
		} catch (Throwable e) {
			log.error(e.getMessage(), e);
		}finally {
			saveAuditData(documentAuditLog);
		}
		return panEsbResponse;
	}
	
	
	@Async
	public void saveAuditData(DocumentAuditLog documentAuditLog) {
		try {
			if( documentAuditLog != null) {
				documentAuditRepository.save(documentAuditLog);
			}
		}catch(Exception e) {
			log.error(e.getMessage(),e);
		}
	}

	DocumentAuditLog createDocumentAudit(PanEsbRequest panEsbRequest, PANRequest panRequest) {
		DocumentAuditLog documentAuditLog = new DocumentAuditLog();
		try {
			documentAuditLog.setAction("VERIFY_PAN_DETAILS");
			documentAuditLog.setChannel(panRequest.getChannel());
			documentAuditLog.setTransactionId(panEsbRequest.getPanHeader().getConsumerTransactionId());
			documentAuditLog.setRequestTimestamp(new Date());
			documentAuditLog.setSource("ONBOARDING");
			documentAuditLog.setMobile(panRequest.getMobile());
			documentAuditLog.setDocType("PAN");
			documentAuditLog.setDocNumber(panEsbRequest.getPanData().getPanRequestDetails().getPanNumber());
			documentAuditLog.setTransactionStatus(TransactionStatus.PAN_VERIFY_FAILED);
			documentAuditLog.setUserIdentifierType("P");
			return documentAuditLog;
		} catch (Exception ex) {
			log.info("Exception while creating request for DocumentAuditLog.");
			throw new ObjectConversionException();
		}
	}

	DocumentAuditLog updateDocumentAuditLog(PanEsbResponse panEsbResponse, DocumentAuditLog documentAuditLog) {
		documentAuditLog.setResponseTimestamp(new Date());

		boolean isSuccess = false;
		if (panEsbResponse != null && panEsbResponse.getPanData() != null
				&& panEsbResponse.getPanData().getPanRequestDetails() != null) {
			isSuccess = true;
			if (panEsbResponse.getPanData().getPanResponseDetails().getStatus() != null) {
				documentAuditLog
						.setStatusCode(panEsbResponse.getPanData().getPanResponseDetails().getStatus().getCode());
				documentAuditLog.setStatusMessage(
						panEsbResponse.getPanData().getPanResponseDetails().getStatus().getDescription());
			}
		}

		if (isSuccess)
			documentAuditLog.setTransactionStatus(
					com.airtelbank.validation.dao.jpa.model.DocumentAuditLog.TransactionStatus.PAN_VERIFY_SUCCESS);
		return documentAuditLog;

	}

}
