package com.airtelbank.validation.validator;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.lang3.StringUtils;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

import com.airtelbank.validation.constants.Constants;
import com.airtelbank.validation.model.Document;

public class DocumentRequestValidator implements Validator {
    private Pattern aadhaarPattern = Pattern.compile("[0-9]{12}");
    private Pattern vidPattern = Pattern.compile("[0-9]{16}");

    @Override
    public boolean supports(Class<?> classObj) {
        return Document.class.equals(classObj);
    }

    @Override
    public void validate(Object obj, Errors errors) {
        Document document = (Document) obj;
        if (StringUtils.isNotEmpty((document.getDocNumber()))) {
        	if (Constants.AADHAAR.equalsIgnoreCase(document.getDocType())) {
        		if (document.getUserIdentifierType().equalsIgnoreCase(Constants.AADHAAR_IDENTIFIER)
                        && !isValidDocNumber(document.getDocNumber(), aadhaarPattern)) {
                    errors.rejectValue(Constants.DOC_NUBMER, "", "Invalid Aadhaar id");
                } else if (document.getUserIdentifierType().equalsIgnoreCase(Constants.VID_IDENTIFIER)
                        && !isValidDocNumber(document.getDocNumber(), vidPattern)) {
                    errors.rejectValue(Constants.DOC_NUBMER, "", "Invalid Virtual id");
                }
        	} else {
        		 errors.rejectValue("document.docType", "", "Invalid docType");
        	}
        } else {
            errors.rejectValue(Constants.DOC_NUBMER, "", "Invalid doc number");
        }
    }

    public boolean isValidDocNumber(String docNumber, Pattern pattern) {
        Matcher matcher = pattern.matcher(docNumber);
        return matcher.find();
    }
}
