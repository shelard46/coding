package com.airtelbank.validation.dao.aerospike.model;

import org.springframework.data.aerospike.mapping.Document;
import org.springframework.data.aerospike.mapping.Field;
import org.springframework.data.annotation.Id;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Setter
@Getter
@NoArgsConstructor
@AllArgsConstructor
@ToString
@Builder
@Document(collection = "PINCODES_DETAILS")
public class PinCode{
    
	@Id
	@Field(value="PK")
	private String id;
	
	@Field(value = "pinCode")
	private String pinCode;
	
	@Field(value = "city")
	private String city;
	
	@Field(value = "state")
	private String state;
	
	@Field(value = "circle")
	private String circle;
	
	@Field(value = "source")
	private String source;
}
