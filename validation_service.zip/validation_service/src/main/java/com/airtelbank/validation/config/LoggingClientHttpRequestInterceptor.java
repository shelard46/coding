package com.airtelbank.validation.config;

import com.airtelbank.validation.util.CommonUtil;
import com.airtelbank.validation.util.LogMasker;
import org.apache.log4j.Level;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpRequest;
import org.springframework.http.MediaType;
import org.springframework.http.client.ClientHttpRequestExecution;
import org.springframework.http.client.ClientHttpRequestInterceptor;
import org.springframework.http.client.ClientHttpResponse;
import org.springframework.stereotype.Component;
import org.springframework.util.StreamUtils;

import com.airtelbank.validation.constants.Constants;

import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.nio.charset.UnsupportedCharsetException;

/**
 * Allows logging outgoing requests and the corresponding responses.
 * Requires the use of a {@link org.springframework.http.client.BufferingClientHttpRequestFactory} to log
 * the body of received responses.
 */
@Component
public class LoggingClientHttpRequestInterceptor implements ClientHttpRequestInterceptor {

	protected Logger logger = LoggerFactory.getLogger(getClass());

    private volatile boolean loggedMissingBuffering;
    
    @Autowired
    private LogMasker logMasker;
    @Value("${log.encryption.key}")
    private String key;
    @Override
    public ClientHttpResponse intercept(HttpRequest request, byte[] body, ClientHttpRequestExecution execution) throws IOException {
        logRequest(request, body);
        ClientHttpResponse response = execution.execute(request, body);
        logResponse(request, response);
        return response;
    }

    protected void logRequest(HttpRequest request, byte[] body) {
        if (logger.isDebugEnabled()) {
        	logger.debug("=============request begin============");
        	logger.debug("Request uri :{}",request.getMethod());
        	logger.debug("Request uri :{}",request.getURI());
        	logger.debug("Request headers :{}",request.getHeaders());
            if (body.length > 0 && hasTextBody(request.getHeaders())) {
                String bodyText = new String(body, determineCharset(request.getHeaders()));
                String log = logMasker.patternReplace(bodyText);
                CommonUtil.encryptAndPrint(Level.DEBUG, "Request body", log, key);
            }
            logger.debug("-------------request end--------------");
        }
    }

    protected void logResponse(HttpRequest request, ClientHttpResponse response) {
        if (logger.isDebugEnabled()) {
            try {
            	String bodyText=null;
            	StringBuilder inputStringBuilder = new StringBuilder();
        		logger.debug("==========response begin===========");
        		logger.debug("Status code  : {}", response.getStatusCode());
        		logger.debug("Status text  : {}", response.getStatusText());
        		logger.debug("Headers      : {}", response.getHeaders());
                HttpHeaders responseHeaders = response.getHeaders();
                long contentLength = responseHeaders.getContentLength();
                if (contentLength != 0) {
                    if (hasTextBody(responseHeaders) && isBuffered(response)) {
                        bodyText = StreamUtils.copyToString(response.getBody(), determineCharset(responseHeaders));
                        inputStringBuilder.append(bodyText);
                    } else {
                        if (contentLength == -1) {
                        	inputStringBuilder.append(" with content of unknown length");
                        } else {
                        	inputStringBuilder.append(" with content of length ").append(contentLength);
                        }
                        MediaType contentType = responseHeaders.getContentType();
                        if (contentType != null) {
                        	inputStringBuilder.append(" and content type ").append(contentType);
                        } else {
                        	inputStringBuilder.append(" and unknown context type");
                        }
                    }
                }
                String log = logMasker.patternReplace(inputStringBuilder.toString());
                CommonUtil.encryptAndPrint(Level.DEBUG, "Response body ", log, key);
        		logger.debug("----------response end-----------");
            } catch (IOException e) {
            	logger.warn("Failed to log response for {} request to {}", request.getMethod(), request.getURI(), e);
            }
        }
    }

    protected boolean hasTextBody(HttpHeaders headers) {
        MediaType contentType = headers.getContentType();
        if (contentType != null) {
            String subtype = contentType.getSubtype();
            return Constants.TEXT.equals(contentType.getType()) || Constants.XML.equals(subtype) || Constants.JSON.equals(subtype);
        }
        return false;
    }

    protected Charset determineCharset(HttpHeaders headers) {
        MediaType contentType = headers.getContentType();
        if (contentType != null) {
            try {
                Charset charSet = contentType.getCharset();
                if (charSet != null) {
                    return charSet;
                }
            } catch (UnsupportedCharsetException e) {
                // ignore
            }
        }
        return StandardCharsets.UTF_8;
    }

    protected boolean isBuffered(ClientHttpResponse response) {
        // class is non-public, so we check by name
        boolean buffered = "org.springframework.http.client.BufferingClientHttpResponseWrapper".equals(response.getClass().getName());
        if (!buffered && !loggedMissingBuffering) {
            logger.warn( "Can't log HTTP response bodies, as you haven't configured the RestTemplate with a BufferingClientHttpRequestFactory");
            loggedMissingBuffering = true;
        }
        return buffered;
    }

}