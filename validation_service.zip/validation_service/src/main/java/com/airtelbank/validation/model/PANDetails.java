package com.airtelbank.validation.model;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonRootName;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@ToString
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_EMPTY)
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "panDetails")
@JsonRootName("panDetails")
@JsonIgnoreProperties(ignoreUnknown = true)
public class PANDetails {
	
	@XmlElement(name = "panNumber")
	@JsonProperty("panNumber")
	private String panNumber;
	
	@XmlElement(name = "panStatus")
	@JsonProperty("panStatus")
	private String panStatus;
	
	@XmlElement(name = "lastName")
	@JsonProperty("lastName")
	private String lastName;
	
	@XmlElement(name = "firstName")
	@JsonProperty("firstName")
	private String firstName;
	
	@XmlElement(name = "middleName")
	@JsonProperty("middleName")
	private String middleName;
	
	@XmlElement(name = "panTitle")
	@JsonProperty("panTitle")
	private String panTitle;
	
	@XmlElement(name = "lastUpdatedDate")
	@JsonProperty("lastUpdatedDate")
	private String lastUpdatedDate;
	
	@XmlElement(name = "panName")
	@JsonProperty("panName")
	private String panName;
	
}
