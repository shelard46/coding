package com.airtelbank.validation.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonRootName;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

import javax.xml.bind.annotation.XmlRootElement;

@Setter
@Getter
@ToString
@NoArgsConstructor
@XmlRootElement(name = "getAadhaarProfileResponse")
@JsonRootName("getAadhaarProfileResponse")
@JsonIgnoreProperties(ignoreUnknown = true)
public class AadhaarProfileKUA {
    private EbmHeader ebmHeader;
    private DataArea dataArea;
}
