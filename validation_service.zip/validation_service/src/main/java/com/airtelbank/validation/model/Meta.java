package com.airtelbank.validation.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.*;

@Getter
@Setter
@Builder
@ToString
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class Meta {
    private String code;
    private String description;
    private int status;
    private Metrics metrics;

    public Meta(String code, String description) {
        this.code = code;
        this.description = description;
    }

    public Meta(String code, String description, int isSuccess) {
        this.code = code;
        this.description = description;
        this.status = isSuccess;
    }
}
