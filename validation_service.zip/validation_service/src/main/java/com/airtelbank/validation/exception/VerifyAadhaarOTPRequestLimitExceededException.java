package com.airtelbank.validation.exception;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.*;

@Setter
@Getter
@ToString
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class VerifyAadhaarOTPRequestLimitExceededException extends RuntimeException {
    private String id;

    public VerifyAadhaarOTPRequestLimitExceededException(String message, String id) {
        super(message);
        this.id = id;
    }

    public VerifyAadhaarOTPRequestLimitExceededException(String message, Throwable cause, String id) {
        super(message, cause);
        this.id = id;
    }

    public VerifyAadhaarOTPRequestLimitExceededException(Throwable cause, String id) {
        super(cause);
        this.id = id;
    }
}
