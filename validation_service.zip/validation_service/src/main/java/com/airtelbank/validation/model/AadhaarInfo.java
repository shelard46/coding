package com.airtelbank.validation.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonRootName;

import lombok.*;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@Setter
@Getter
@ToString
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_EMPTY)
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "getCustomerAadhaarOTPRequest")
@JsonRootName("getCustomerAadhaarOTPRequest")
@JsonIgnoreProperties(ignoreUnknown = true)
public class AadhaarInfo {
    @XmlElement(name = "timestamp")
    @JsonProperty("timestamp")
    private String timestamp;
    @XmlElement(name = "otpRequestType")
    @JsonProperty("otpRequestType")
    private String otpRequestType;
    @XmlElement(name = "subAua")
    @JsonProperty("subAua")
    private String subAua;
    @XmlElement(name = "userIdentifier")
    @JsonProperty("userIdentifier")
    private String userIdentifier;
    @XmlElement(name = "mobileNumber")
    @JsonProperty("mobileNumber")
    private String mobileNumber;
}
