package com.airtelbank.validation.model;

import lombok.Builder;
import javax.validation.constraints.NotBlank;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@Builder
public class DeviceDetails {
	@NotBlank
	private String registeredDeviceProviderCode;
	@NotBlank
	private String registeredDeviceServiceID;
	@NotBlank
	private String registeredDeviceServiceVersion;
	@NotBlank
	private String registeredDeviceCode;
	@NotBlank
	private String registeredDeviceModelID;
	@NotBlank
	private String registeredDevicePublicKeyCertificate;
	@NotBlank
	private String uniqueDeviceCode;
}
