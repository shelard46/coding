package com.airtelbank.validation.dao.aerospike;

import java.util.List;

import com.airtelbank.validation.dao.aerospike.model.Identities;

public interface IdentitiesDao {

	public Boolean addAndSaveIdentityInRepo(Identities identities);
	public Identities getIdentityFromRepo(String id);
	public List<Identities> getIdentityFromRepoUnique(String mobileNumber, String docNumber);
	public Boolean updateIdentityInRepo(Identities identities,boolean isSuccess);
}
