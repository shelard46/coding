package com.airtelbank.validation.service.impl;

import java.util.Locale;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Service;

import com.airtelbank.validation.constants.Constants;
import com.airtelbank.validation.dao.aerospike.model.Blackout;
import com.airtelbank.validation.dao.aerospike.repository.BlackoutRepository;
import com.airtelbank.validation.exception.GenericException;
import com.airtelbank.validation.model.BlackoutRequest;
import com.airtelbank.validation.model.BlackoutResponse;
import com.airtelbank.validation.model.Meta;
import com.airtelbank.validation.model.ResponseDTO;
import com.airtelbank.validation.service.BlackoutService;

@Service
public class BlackoutServiceImpl implements BlackoutService {

	@Autowired private BlackoutRepository blackoutRepository;
	@Autowired private MessageSource messageSource;

	@Override
	public ResponseDTO<BlackoutResponse> getBlackout(String customerId) {
		try {
			ResponseDTO<BlackoutResponse> responseDTO = new ResponseDTO<>();
			BlackoutResponse blackoutResponse = new BlackoutResponse();
			Meta meta = new Meta();
			Blackout blackout = blackoutRepository.findOne(customerId);
			if (null != blackout) {
				meta.setCode(messageSource.getMessage("blackout.success.response.code", null, Locale.ENGLISH));
		        meta.setDescription(messageSource.getMessage("blackout.success.response.message", null, Locale.ENGLISH));
		        meta.setStatus(Constants.SUCCESS_STATUS);
		        blackoutResponse.setExist(true);
			} else {
				meta.setCode(messageSource.getMessage("blackout.error.response.code", null, Locale.ENGLISH));
		        meta.setDescription(messageSource.getMessage("blackout.error.response.message", null, Locale.ENGLISH));
		        meta.setStatus(Constants.FAILURE_STATUS);
		        blackoutResponse.setExist(false);
			}
			responseDTO.setData(blackoutResponse);
			responseDTO.setMeta(meta);
			return responseDTO;
		}catch (Exception e) {
			throw new GenericException();
		}
	}

	@Override
	public ResponseDTO<BlackoutResponse> postBlackout(BlackoutRequest request) {
		try {
			ResponseDTO<BlackoutResponse> responseDTO = new ResponseDTO<>();
			BlackoutResponse blackoutResponse = new BlackoutResponse();
			Meta meta = new Meta();
			Blackout blackout = new Blackout();
			blackout.setId(request.getIdentifierValue());
			blackout.setCustomerId(request.getCustomerId());
			blackout.setType(request.getIdentifierType());
			blackoutRepository.save(blackout);
			blackoutResponse.setExist(true);
			responseDTO.setData(blackoutResponse);
			meta.setCode(messageSource.getMessage("blackout.saved.response.code", null, Locale.ENGLISH));
	        meta.setDescription(messageSource.getMessage("blackout.saved.response.message", null, Locale.ENGLISH));
	        meta.setStatus(Constants.SUCCESS_STATUS);
			responseDTO.setMeta(meta);
			return responseDTO;
		}catch (Exception e) {
			throw new GenericException();
		}
	}

}
