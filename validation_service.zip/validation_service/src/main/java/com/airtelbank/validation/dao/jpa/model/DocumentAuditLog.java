package com.airtelbank.validation.dao.jpa.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Parameter;

import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Setter
@Getter
@ToString
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_EMPTY)
@Entity
@Table(name = "DOCUMENT_AUDIT")
@GenericGenerator(
        name = "documentAuditSequence",
        strategy = "org.hibernate.id.enhanced.SequenceStyleGenerator",
        parameters = {
                @Parameter(name = "sequence_name", value = "DOCUMENT_AUDIT_SEQUENCE"),
                @Parameter(name = "initial_value", value = "1"),
                @Parameter(name = "increment_size", value = "50"),
                @Parameter(name = "allocation_size", value="50")
        }
)
public class DocumentAuditLog {
	public enum TransactionStatus{
		GENEATION_AADHAAR_OTP_FAILED,
        GENERATION_AADHAAR_OTP_SUCCESS,
        VALIDATE_AADHAAR_OTP_FAILED,
        VALIDATE_AADHAAR_OTP_SUCCESS,
        PAN_VERIFY_FAILED,
        PAN_VERIFY_SUCCESS,
        AADHAAR_KUA_SUCCESS,
        AADHAAR_KUA_FAILURE,
        ALERT_AUA_SUCCESS,
        ALERT_AUA_FAILED,
        ALERT_KUA_SUCCESS,
        ALERT_KUA_FAILED,
        ALERT_OTP_SUCCESS,
        ALERT_OTP_FAILED
	}
    @Id
    @GeneratedValue( generator = "documentAuditSequence") 
    @Column(name = "ID", updatable = false, nullable = false)
    private Long id;

    @NotNull
    @Column(name = "TRANSACTION_ID")
    private String transactionId;

    @NotNull
    @Size(min = 1, message = "Action can't be null")
    @Column(name = "ACTION")
    private String action;

    @Column(name = "USER_IDENTIFIER_TYPE")
    private String userIdentifierType;

    @NotNull
    @Size(min = 1, message = "Document type can't be null")
    @Column(name = "DOC_TYPE")
    private String docType;

    @NotNull
    @Size(min = 1, message = "Document reference number can't be null")
    @Column(name = "DOC_NUMBER")
    private String docNumber;

    @Column(name = "MOBILE")
    private String mobile;

    @Column(name = "STATUS_CODE")
    private String statusCode;

    @Column(name = "STATUS_MESSAGE")
    private String statusMessage;

    @Column(name = "UID_TOKEN")
    private String uidToken;

    //Success:0, Failed:1, Timeout:2
//    @NotNull
//    @Size(min = 1, message = "Transaction status can't be null")
    @NotNull
    @Column(name = "TRANSACTION_STATUS")
    @Enumerated(EnumType.ORDINAL)
    private TransactionStatus transactionStatus;

    //@JsonDeserialize(using = DateTimeDeserializer.class)
    //@JsonSerialize(using = DateTimeSerializer.class)
    //@Convert(converter = LocalDateTimeConverter.class)
    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "REQUEST_TIMESTAMP")
    private Date requestTimestamp;

    /*@JsonDeserialize(using = DateTimeDeserializer.class)
    @JsonSerialize(using = DateTimeSerializer.class)*/
    //@Convert(converter = LocalDateTimeConverter.class)
    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "RESPONSE_TIMESTAMP")
    private Date responseTimestamp;

    @Column(name = "PARTNER_TRANSACTION_ID")
    private String partnerTransactionId;

    @Column(name = "CHANNEL")
    private String channel;

    @Column(name = "SOURCE")
    private String source;

    @Column(name = "CUSTOM_COLUMN1")
    private String customColumn1;

    @Column(name = "CUSTOM_COLUMN2")
    private String customColumn2;

    @Column(name = "CUSTOM_COLUMN3")
    private String customColumn3;

    @Column(name = "CUSTOM_COLUMN4")
    private String customColumn4;

    @Column(name = "CUSTOM_COLUMN5")
    private String customColumn5;

    @Column(name = "CUSTOM_COLUMN6")
    private String customColumn6;

    @Column(name = "CUSTOM_COLUMN7")
    private String customColumn7;

    @Column(name = "CUSTOM_COLUMN8")
    private String customColumn8;

    @Column(name = "CUSTOM_COLUMN9")
    private String customColumn9;

    @Column(name = "CUSTOM_COLUMN10")
    private String customColumn10;
}
