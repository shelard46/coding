package com.airtelbank.validation.model.cbs;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonRootName;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@XmlAccessorType(XmlAccessType.FIELD)
@JsonInclude(JsonInclude.Include.NON_EMPTY)
@XmlRootElement(name = "Response")
@JsonRootName("Response")
@JsonIgnoreProperties(ignoreUnknown = true)
public class DedupeResponseFromCBS {

    @XmlElement(name = "TransactionStatus")
    @JsonProperty("TransactionStatus")
    TransactionStatus transactionStatusObject;

    @XmlElement(name = "DedupeStatus")
    @JsonProperty("DedupeStatus")
    private String dedupeStatus;

    @XmlElement(name = "DedupeErrorDesc")
    @JsonProperty("DedupeErrorDesc")
    private String dedupeErrorDesc;

    @XmlElement(name = "CustomerDedupeDetailsDTOArray")
    @JsonProperty("CustomerDedupeDetailsDTOArray")
    CustomerDedupeDetailsDTOArray customerDedupeDetailsDTOArray;
}
