package com.airtelbank.validation.dao.jpa.respository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.airtelbank.validation.dao.jpa.model.DocumentAuditLog;

@Repository
public interface DocumentAuditRepository extends JpaRepository<DocumentAuditLog, Long> {

}
