package com.airtelbank.validation.config;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.aerospike.convert.AerospikeTypeAliasAccessor;
import org.springframework.data.aerospike.convert.CustomConversions;
import org.springframework.data.aerospike.convert.MappingAerospikeConverter;
import org.springframework.data.aerospike.core.AerospikeTemplate;
import org.springframework.data.aerospike.core.DefaultAerospikeExceptionTranslator;
import org.springframework.data.aerospike.mapping.AerospikeMappingContext;
import org.springframework.data.aerospike.mapping.AerospikeSimpleTypes;
import org.springframework.data.aerospike.repository.config.EnableAerospikeRepositories;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import com.aerospike.client.AerospikeClient;
import com.aerospike.client.Host;
import com.aerospike.client.policy.ClientPolicy;
import com.aerospike.client.policy.QueryPolicy;
import com.aerospike.client.policy.WritePolicy;
import com.airtelbank.validation.config.CustomLocalDateConverter.Java8LocalDateToStringConverter;
import com.airtelbank.validation.config.CustomLocalDateConverter.StringToJava8LocalDateConverter;
import com.airtelbank.validation.util.CollectionUtil;

@Configuration
@EnableAerospikeRepositories(basePackages = {"com.airtelbank.validation.dao.aerospike"})
@EnableAutoConfiguration
@EnableTransactionManagement
public class AerospikeRepositoryConfiguration {

	private static final Logger LOGGER = LoggerFactory.getLogger(AerospikeRepositoryConfiguration.class);
    @Value("${config.aerospike.defaultNS}")
    public String defaultNS;
    @Value("${config.aerospike.host}")
    private String aerospikeHost;
    @Value("${config.aerospike.port}")
    private String aerospikePort;
    @Value("${config.aerospike.userName}")
    public String aerospikeUserName;
    @Value("${config.aerospike.password}")
    public String aerospikePassword;
    @Value("${config.aerospike.expiration}")
    public long expiration;
    @Value("${config.aerospike.expiration.no}")
    public long noExpiration;
    @Value("${config.aerospike.timeout}")
    public int connectionTimeout;

    public @Bean(destroyMethod = "close")
    AerospikeClient aerospikeClient() {
        ClientPolicy policy = new ClientPolicy();
        WritePolicy writePolicy = new WritePolicy();
        writePolicy.expiration = (int) Math.min(expiration, Integer.MAX_VALUE);
        policy.writePolicyDefault = writePolicy;
        policy.user = aerospikeUserName;
        policy.password = aerospikePassword;
        policy.failIfNotConnected = true;
        policy.timeout = connectionTimeout;
        policy.writePolicyDefault.sendKey = true;
        QueryPolicy queryPolicy = new QueryPolicy();
        queryPolicy.setTimeouts((int) Math.min(expiration, Integer.MAX_VALUE), (int) Math.min(expiration, Integer.MAX_VALUE));
        policy.queryPolicyDefault= queryPolicy;
        List<Host> hosts = CollectionUtil.toList(aerospikeHost)
                .stream()
                .filter(host -> StringUtils.isNotBlank(host))
                .map(host -> new Host(host, Integer.parseInt(aerospikePort)))
                .peek(host -> LOGGER.info("aerospike host added: {}", host))
                .collect(Collectors.toList());
        return new AerospikeClient(policy, hosts.toArray(new Host[hosts.size()]));
    }

    public @Bean
    AerospikeTemplate aerospikeTemplate() {
    	CustomConversions conversions = new CustomConversions(Arrays.asList(StringToJava8LocalDateConverter.INSTANCE,Java8LocalDateToStringConverter.INSTANCE), AerospikeSimpleTypes.HOLDER);
    	AerospikeMappingContext mappingContext = new AerospikeMappingContext();
    	mappingContext.setDefaultNameSpace(defaultNS);
        MappingAerospikeConverter converter = new MappingAerospikeConverter(mappingContext, conversions, new AerospikeTypeAliasAccessor("type"));
        converter.afterPropertiesSet();
        return new AerospikeTemplate(aerospikeClient(), defaultNS,converter,mappingContext,new DefaultAerospikeExceptionTranslator());
    }


    @Bean
    public WritePolicy writePolicy(){
        WritePolicy writePolicy = new WritePolicy();
        writePolicy.expiration = (int)noExpiration;
        writePolicy.sendKey = true;
        return writePolicy;
    }
}