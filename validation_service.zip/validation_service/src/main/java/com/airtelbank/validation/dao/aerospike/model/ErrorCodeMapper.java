package com.airtelbank.validation.dao.aerospike.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.*;

import org.springframework.data.annotation.Id;

import java.io.Serializable;
import java.time.LocalDateTime;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_EMPTY)
@ToString
@Builder
public class ErrorCodeMapper implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    private String errorId;
    private String errorCode;
    private String errorMsg;
    private String orgErrorCode;
    private String orgErrorMsg;
    private String apiName;
    private LocalDateTime createDate;
    private LocalDateTime modifyDate;
}