package com.airtelbank.validation.service.impl.helper;

import java.io.IOException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

import com.airtelbank.validation.constants.Constants;
import com.airtelbank.validation.dao.aerospike.AadharVerifyDao;
import com.airtelbank.validation.dao.aerospike.model.AadhaarVerify;
import com.airtelbank.validation.dao.aerospike.model.Identities;
import com.airtelbank.validation.dao.jpa.model.DocumentAuditLog;
import com.airtelbank.validation.exception.AadharVerificationException;
import com.airtelbank.validation.exception.VerifyAadhaarOTPRequestLimitExceededException;
import com.airtelbank.validation.model.Document;
import com.airtelbank.validation.service.AadhaarService;
import com.airtelbank.validation.util.CommonUtil;

@Component
public class AadhaarServiceImplHelper {

	public enum RequestEndPoint {
		GENERATE_AADHAAR_OTP, VALIDATE_AADHAAR_OTP, VALIDATE_PAN
	}

	@Value("${config.aadhaar.otp.verify}")
	private String strOtpVerifyUrl;

	@Value("${pan.esb.url}")
	private String strPanVerifyUrl;

	@Value("${config.aadhaar.otp.verify.maxcount}")
	private int intMaxAadhaarOtpVerifyCount;

	@Autowired private AadharVerifyDao aadharVerifyDao;
	@Autowired private AadhaarService aadhaarService;
	@Autowired private Environment environment;



	public void checkIndetiyContrainsForAadhaarOTPVerification(Identities identity) {
		if (identity == null) {
			throw new AadharVerificationException();
		}

		if (identity.getVerifyCount() >= intMaxAadhaarOtpVerifyCount) {
			throw new VerifyAadhaarOTPRequestLimitExceededException();
		}
	}

	public String getDocRefernceNumber(Document request, Identities identities) {
		String docReferenceNumber = identities.getDocNumber();
		request.setUserIdentifierType(identities.getUserIdentifierType());
		request.setDocNumber(docReferenceNumber);

		if (request.getMobile() == null || request.getMobile().isEmpty()) {
			request.setMobile(identities.getMobileNumber());
		}
		return docReferenceNumber;

	}

	public void processAadharVerifyData(Document request, Identities identity, AadhaarVerify aadhaarVerify,
			String docReferenceNumber, String docOriginalNum, DocumentAuditLog documentAuditLog) {
		aadhaarVerify.setTransactionId(request.getId());
		if (aadhaarVerify.getUserIdentifierType().equalsIgnoreCase(Constants.VID_IDENTIFIER)) {
			// VID response
			docReferenceNumber = CommonUtil.getAadhaarReferenceNumberFromAadhaar(aadhaarVerify.getAadhaarNumber(),
					aadhaarService, environment);
			docOriginalNum = aadhaarVerify.getAadhaarNumber();
			aadhaarVerify.setAadhaarNumber(docReferenceNumber);
			documentAuditLog.setDocNumber(Constants.NA);
		} else {
			// Aadhaar response
			aadhaarVerify.setAadhaarNumber(docReferenceNumber);
			documentAuditLog.setDocNumber(Constants.NA);
		}
		identity.setUidToken(aadhaarVerify.getUidToken());
		identity.setDocNumber(docReferenceNumber);
		aadharVerifyDao.saveAadhaarVerifyResponse(aadhaarVerify);
		aadhaarVerify.setAadhaarNumber(docOriginalNum);
	}

}
