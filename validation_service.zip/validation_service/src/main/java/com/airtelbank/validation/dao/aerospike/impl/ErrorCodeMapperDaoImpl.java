package com.airtelbank.validation.dao.aerospike.impl;

import com.aerospike.client.policy.GenerationPolicy;
import com.aerospike.client.policy.WritePolicy;
import com.aerospike.client.query.IndexType;
import com.aerospike.helper.query.Qualifier;
import com.aerospike.helper.query.Qualifier.FilterOperation;
import com.airtelbank.validation.constants.Constants;
import com.airtelbank.validation.dao.aerospike.ErrorCodeMapperDao;
import com.airtelbank.validation.dao.aerospike.model.ErrorCodeMapper;
import com.airtelbank.validation.exception.AeroSpikeException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.aerospike.core.AerospikeTemplate;
import org.springframework.data.aerospike.repository.query.AerospikeCriteria;
import org.springframework.data.aerospike.repository.query.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public class ErrorCodeMapperDaoImpl implements ErrorCodeMapperDao {
    @Autowired
    AerospikeTemplate aerospikeTemplate;

    @Value("${config.aerospike.expiration}")
    public long expiration;

    @Value("${config.aerospike.expiration.no}")
    public long noExpiration;

    private static final Logger logger = LoggerFactory.getLogger(ErrorCodeMapperDaoImpl.class);

    @Override
    public Boolean addNewErrorCode(ErrorCodeMapper errorCodeMapper) {
        Boolean savedSuccessfully = false;
        WritePolicy writePolicy = new WritePolicy();
        writePolicy.expiration = (int) Math.min(noExpiration, Integer.MAX_VALUE);
        writePolicy.generationPolicy = GenerationPolicy.EXPECT_GEN_EQUAL;
        try {
            aerospikeTemplate.persist(errorCodeMapper, writePolicy);
            savedSuccessfully = true;
            return savedSuccessfully;
        } catch (Exception ex) {
            logger.info("Exception while adding error code in ErrorCodeMapper in Aerospike.");
            throw new AeroSpikeException();
        }
    }

    @Override
    public ErrorCodeMapper getErrorCodeDataById(String id) {
        return aerospikeTemplate.findById(id, ErrorCodeMapper.class);
    }

    @Override
    public ErrorCodeMapper getUniqueErrorCodeData(String errorCode, String apiName) {
        Query query = null;
        List<ErrorCodeMapper> list = null;
        try {
            Qualifier apiNameQualifier = new Qualifier("apiName", FilterOperation.EQ, com.aerospike.client.Value.get(apiName));
            Qualifier errorCodeQualifier = new Qualifier(Constants.ORG_ERROR_CODE, FilterOperation.EQ, com.aerospike.client.Value.get(errorCode));
            AerospikeCriteria criteria = new AerospikeCriteria(FilterOperation.AND, apiNameQualifier, errorCodeQualifier);
            query = new Query(criteria);
            if (!aerospikeTemplate.indexExists("apiIndex"))
                aerospikeTemplate.createIndex(ErrorCodeMapper.class, "apiIndex", "apiName", IndexType.STRING);
            if (!aerospikeTemplate.indexExists(Constants.ORG_ERROR_CODE))
                aerospikeTemplate.createIndex(ErrorCodeMapper.class, Constants.ORG_ERROR_CODE, "orgErrorCode", IndexType.STRING);
            list = (List<ErrorCodeMapper>) aerospikeTemplate.find(query, ErrorCodeMapper.class);
            return (list != null && list.size() > 0) ? (ErrorCodeMapper) list.get(0) : null;
        } catch (Exception ex) {
            logger.info("Exception while getting data in Aerospike.");
            throw new AeroSpikeException();
        }
    }

    @Override
    public List<ErrorCodeMapper> getErrorCode(String originalErrorCode) {
        if(originalErrorCode == null) return null;
        AerospikeCriteria criteria=new AerospikeCriteria(Constants.ORG_ERROR_CODE, FilterOperation.EQ, true, com.aerospike.client.Value.get(originalErrorCode));
        Query query = new Query(criteria);
        if(!aerospikeTemplate.indexExists("orgErrorIndex"))
            aerospikeTemplate.createIndex(ErrorCodeMapper.class, "orgErrorIndex", Constants.ORG_ERROR_CODE, IndexType.STRING);
        return (List<ErrorCodeMapper>) aerospikeTemplate.find(query, ErrorCodeMapper.class);
    }

    @Override
    public int deleteErrorCode(String originalErrorCode) {
        List<ErrorCodeMapper> errorCodeMapperList=getErrorCode(originalErrorCode);
        int deletedRows=0;
        if(errorCodeMapperList!=null || !errorCodeMapperList.isEmpty()) {
            for (ErrorCodeMapper errorCodeMapper : errorCodeMapperList) {
                if(aerospikeTemplate.delete(errorCodeMapper)) deletedRows++;
            }
        }
        return deletedRows;
    }

    @Override
    public int saveAllErrorCode(List<ErrorCodeMapper> errorCodeMappers) {
        // TODO Auto-generated method stub
        int count =0;
        if(errorCodeMappers ==null || errorCodeMappers.size() == 0) return count;
        for (ErrorCodeMapper errorCodeMapper : errorCodeMappers) {
            if(addNewErrorCode(errorCodeMapper)) count++;
        }
        return count;
    }

}
