package com.airtelbank.validation.service;

public interface AuthService {

	/**
     * Validate Basic Authentication.
     * @param basicAuthHeaderValue the base 64 encoded header value
     * @return the boolean
     */
	boolean validateBasicAuthentication(String basicAuthHeaderValue);

}
