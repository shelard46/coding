package com.airtelbank.validation.model;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonRootName;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@ToString
@Getter
@Setter
@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_EMPTY)
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "verifyCustomerPanDetailsRequest")
@JsonRootName("verifyCustomerPanDetailsRequest")
@JsonIgnoreProperties(ignoreUnknown = true)
public class VerifyPANDetailsRequest {
	@XmlElement(name = "panNumber")
	@JsonProperty("panNumber")
	private String panNumber;
	
	  @XmlElement(name = "version")
		@JsonProperty("version")
		private String version;
	
}
