package com.airtelbank.validation.filter;

import java.io.IOException;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.MessageSource;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import com.airtelbank.validation.constants.Constants;
import com.airtelbank.validation.model.LoggerModel;
import com.airtelbank.validation.model.LoggerModel.LoggerError;
import com.airtelbank.validation.util.LogMasker;

@Component
@Order(1)
public class StatsFilter extends OncePerRequestFilter {

	@Value("${config.service.id}")
	private String serviceId;
	
	@Value("${config.kibana.separator}")
	private String separator;
	
	@Autowired
	LogMasker logMasker;
	
	@Autowired
	LoggerModel loggerModel;
	
	@Autowired
    MessageSource messageSource;

	@Override
	protected void doFilterInternal(HttpServletRequest req, HttpServletResponse res, FilterChain filterChain)
			throws ServletException, IOException {
		if (!req.getRequestURI().startsWith("/api")) {
			filterChain.doFilter(req, res);
			return;
		}

		long startTime = System.currentTimeMillis();

		MultipleReadHttpServletRequest multipleReadHttpServletRequest = new MultipleReadHttpServletRequest(req);
		if (res.getCharacterEncoding() == null) {
			res.setCharacterEncoding("UTF-8"); // Or whatever default. UTF-8 is good for World Domination.
		}
		HttpServletResponseCopier responseCopier = new HttpServletResponseCopier(res);
		try {
			filterChain.doFilter(multipleReadHttpServletRequest, responseCopier);

			byte[] copy = responseCopier.getCopy();
			try {
				responseCopier.flushBuffer();
			} finally {

			}
			StringBuilder builder = new StringBuilder();
			builder.append(serviceId).append(separator);
			builder.append(MDC.get(Constants.API_ID) != null ? MDC.get(Constants.API_ID) : "").append(separator);
			builder.append(MDC.get(Constants.CUSTOMER_ID) != null ? MDC.get(Constants.CUSTOMER_ID) : "")
					.append(separator);
			builder.append(MDC.get(Constants.CONTENT_ID) != null ? MDC.get(Constants.CONTENT_ID) : "")
					.append(separator);
			builder.append(MDC.get(Constants.TRANSACTION_ID) != null ? MDC.get(Constants.TRANSACTION_ID) : "")
					.append(separator);
			builder.append("0").append(separator);
			builder.append(multipleReadHttpServletRequest.getRemoteHost()).append(separator);
			builder.append(multipleReadHttpServletRequest.getLocalAddr()).append(separator);
			builder.append(multipleReadHttpServletRequest.getServerPort()).append(separator);
			
			// append String Ids
			loggerModel.getIds().forEach(id -> builder.append(id + separator));
			for (int i = 0; i < 7 - loggerModel.getIds().size(); i++) {
				builder.append(separator);
			}
			// append numbers
			loggerModel.getNumbers().forEach(id -> builder.append(id + separator));
			for (int i = 0; i < 3 - loggerModel.getNumbers().size(); i++) {
				builder.append(separator);
			}
			// append Dates
			loggerModel.getDates().forEach(id -> builder.append(id + separator));
			for (int i = 0; i < 2 - loggerModel.getDates().size(); i++) {
				builder.append(separator);
			}
			
			String request = multipleReadHttpServletRequest.getRequestBody();
			builder.append(request).append(separator);
			String responseString = new String(copy, res.getCharacterEncoding());
			builder.append(responseString).append(separator);
			if (MDC.get(Constants.ERRORS) != null) {
				LoggerError logError = (LoggerError) MDC.get(Constants.ERRORS);
				builder.append(logError.getStatus()).append(separator).append(logError.getErrorCode()).append(separator)
						.append(logError.getErrorDescription()).append(separator);
			}
			long endTime = System.currentTimeMillis();
			long time = endTime - startTime;
			builder.append(time);
			String result = logMasker.patternReplace(builder.toString());
			logger.info(result);
		} finally {
			MDC.clear();
		}
	}

}
