package com.airtelbank.validation.util;

import com.airtelbank.validation.model.ResponseDTO;
import com.airtelbank.validation.model.audit.AuditLogRequest;
import com.airtelbank.validation.model.audit.AuditLogResponse;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.Map;

import static com.airtelbank.validation.constants.Constants.ACCEPT;
import static com.airtelbank.validation.constants.Constants.APPLICATION_JSON;
import static com.airtelbank.validation.constants.Constants.CONTENT_TYPE;

/**
 * @author Hitesh Khatri
 * @date 18/06/21
 */
@Component
public class AuditUtil {

    private static final Logger logger = LoggerFactory.getLogger(AuditUtil.class);

    @Value("${audit.url}")
    private String auditUrl;

    @Autowired
    private HttpUtil httpUtil;

    public void doAudit(String appType, String customerId, String request, String action, String description, String txnStatus) {
        ObjectMapper objectMapper = new ObjectMapper();
        try {
            AuditLogRequest auditLogRequest = AuditLogRequest.builder()
                    .appType(appType)
                    .custId(customerId)
                    .request(request)
                    .action(action)
                    .desc(description)
                    .txnStatus(txnStatus)
                    .build();
            String auditLogRequestAsString = objectMapper.writeValueAsString(auditLogRequest);
            Map<String, String> headersMap = new HashMap<>();
            headersMap.put(CONTENT_TYPE, APPLICATION_JSON);
            headersMap.put(ACCEPT, APPLICATION_JSON);
            ResponseDTO<AuditLogResponse> response = (ResponseDTO) httpUtil.processHttpRequest(auditUrl,
                    auditLogRequestAsString, ResponseDTO.class, headersMap, HttpMethod.POST);
            logger.info("Response for AuditLog :: {} ", response);
        } catch (Exception e) {
            logger.error("Error while Audit the request. ErrorMessage : {} | Exception : {} | appType : {} | customerId : {} | request : {}", e.getMessage(), e, appType, customerId, request);
        }
    }
}
