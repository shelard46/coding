package com.airtelbank.validation.service;

import com.airtelbank.validation.dao.aerospike.model.PosidexCacheCustomerDetails;

public interface PosidexCacheCustomerService {

	PosidexCacheCustomerDetails getPosidexCacheCustomerDetails(String id);
	
	void save(PosidexCacheCustomerDetails posidexCacheCustomerDetails);
	
}
