package com.airtelbank.validation.model.cbs;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonRootName;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_EMPTY)
@XmlRootElement(name = "CustomerDedupeDetailsDTO")
@XmlAccessorType(XmlAccessType.FIELD)
@JsonRootName("CustomerDedupeDetailsDTO")
@JsonIgnoreProperties(ignoreUnknown = true)
public class CustomerDedupeDetailsDTO {

    @XmlElement(name = "CustomerId")
    @JsonProperty("CustomerId")
    private String customerId;

    @XmlElement(name = "NationalIdentificationCode")
    @JsonProperty("NationalIdentificationCode")
    private String nationalIdentificationCode;

    @XmlElement(name = "FirstName")
    @JsonProperty("FirstName")
    private String firstName;

    @XmlElement(name = "MidName")
    @JsonProperty("MidName")
    private String midName;

    @XmlElement(name = "LastName")
    @JsonProperty("LastName")
    private String lastName;

    @XmlElement(name = "OfficerID")
    @JsonProperty("OfficerID")
    private String officerID;

    @XmlElement(name = "CustomerAddressObject")
    @JsonProperty("CustomerAddressObject")
    CustomerAddress customerAddressObject;

    @XmlElement(name = "BirthDateText")
    @JsonProperty("BirthDateText")
    private String birthDateText;

    @XmlElement(name = "Category")
    @JsonProperty("Category")
    private String category;

    @XmlElement(name = "Sex")
    @JsonProperty("Sex")
    private String sex;

    @XmlElement(name = "IsImageAvailable")
    @JsonProperty("IsImageAvailable")
    private String isImageAvailable;

    @XmlElement(name = "IsSignatureAvailable")
    @JsonProperty("IsSignatureAvailable")
    private String isSignatureAvailable;

    @XmlElement(name = "AgeOfCustRel")
    @JsonProperty("AgeOfCustRel")
    private String ageOfCustRel;

    @XmlElement(name = "AadhrNo")
    @JsonProperty("AadhrNo")
    private String aadhrNo;

    @XmlElement(name = "AadhrNoUpdDate")
    @JsonProperty("AadhrNoUpdDate")
    private String aadhrNoUpdDate;

    @XmlElement(name = "HomeBranch")
    @JsonProperty("HomeBranch")
    private String homeBranch;

    @XmlElement(name = "MobileNumber")
    @JsonProperty("MobileNumber")
    private String mobileNumber;

    @XmlElement(name = "EmailAddress")
    @JsonProperty("EmailAddress")
    private String emailAddress;

    @XmlElement(name = "IcType")
    @JsonProperty("IcType")
    private String icType;

    @XmlElement(name = "IcTypeDesc")
    @JsonProperty("IcTypeDesc")
    private String icTypeDesc;

    @XmlElement(name = "XfaceAccountDTOArray")
    @JsonProperty("XfaceAccountDTOArray")
    XfaceAccountDTOArray xfaceAccountDTOArray;
}
