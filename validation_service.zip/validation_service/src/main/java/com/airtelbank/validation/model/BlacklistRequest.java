package com.airtelbank.validation.model;


import java.time.LocalDate;

import javax.validation.constraints.NotBlank;
import org.springframework.format.annotation.DateTimeFormat;

import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter@Setter@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_EMPTY)
@ToString
public class BlacklistRequest {

	@NotBlank(message="customer ID is mandatory")
	private String customerId;
	@NotBlank(message="profile ID is mandatory")
	private String profileId;
	private String firstName;
	private String middleName;
	private String lastName;
	@DateTimeFormat
	private LocalDate dateOfBirth;
	private String gender;
	private String motherName;
	private String fatherOrHusbandName;
	private String aadharNo;
	private String pan;
	private String poiType;
	private String poiNumber;
	private String poaType;
	private String poaNo;
	private String walletType;
	private String imei;
	private String locAdd1;
	private String locAdd2;
	private String locAdd3;
	private String locAdd4;
	private String locCity;
	private String locDist;
	private String locState;
	private String locPostalCode;
	private String permAdd1;
	private String permAdd2;
	private String permAdd3;
	private String permAdd4;
	private String permCity;
	private String permDist;
	private String permState;
	private String permPostalCode;
	private String emailId;
}
