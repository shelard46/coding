package com.airtelbank.validation.model;

import java.util.List;

import com.airtelbank.validation.model.blacklist.BlacklistData;
import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class BlacklistEntityResponse {

	private String requestId;
	private int status;
	private String message;
	private String errorCode;
	private List<BlacklistData> entities;
}
