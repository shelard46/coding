package com.airtelbank.validation.service.impl;

import com.airtelbank.validation.constants.Constants;
import com.airtelbank.validation.exception.ElasticSearchException;
import com.airtelbank.validation.model.blacklist.BlacklistData;
import com.airtelbank.validation.reader.AbstractReaderFactory;
import com.airtelbank.validation.service.IBlacklistDataUploadService;
import com.airtelbank.validation.util.BlackListEntityUtil;
import org.apache.commons.lang3.StringUtils;
import org.elasticsearch.action.bulk.BulkRequest;
import org.elasticsearch.core.TimeValue;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.util.LinkedList;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicReference;

@Service
public class BlacklistDataUploadServiceImpl implements IBlacklistDataUploadService {

    @Value("${elasticsearch.clustername}")
    private String esClusterName;

    @Value("${elasticsearch.timeout.minutes}")
    private long elasticTimeout;

    @Value("${elasticsearch.bulk.limit.records}")
    private long bulkLimit;

    @Autowired
    private BlackListEntityUtil blackListEntityUtil;

    private static final Logger LOG = LoggerFactory.getLogger(BlacklistDataUploadServiceImpl.class);

    @Override
    public void upload(String filePath) throws Exception {
        String fileType = getFileType(filePath);
        BlacklistData dummy = new BlacklistData();
        AtomicReference<BulkRequest> bulkRequest = new AtomicReference<>(new BulkRequest());
        bulkRequest.get().timeout(TimeValue.timeValueMinutes(elasticTimeout));
        List<BlacklistData> list = new LinkedList<>();
        list.addAll(new AbstractReaderFactory().getReader(fileType).readFile(filePath, BlacklistData.class));
        LOG.info("size of data being uploaded in elastic is: {}", list.size());
        AtomicInteger counter = new AtomicInteger();
        list.stream().forEachOrdered(blacklistData -> {
            try {
                counter.getAndIncrement();
                setData(dummy, blacklistData);
                switch (blacklistData.getAction()) {
                    case Constants.CHANGE :
                        blackListEntityUtil.deleteIndexes(blacklistData);
                        blackListEntityUtil.addIndexes(blacklistData, bulkRequest.get());
                        break;
                    case Constants.DELETE :
                        blackListEntityUtil.deleteIndexes(blacklistData);
                        break;
                    default:
                        blackListEntityUtil.addIndexes(blacklistData, bulkRequest.get());
                }

                if (counter.get() > bulkLimit) {
                    LOG.info("going to put data in elastic search in chunked manner with bulkLimit: {}", bulkLimit);
                    blackListEntityUtil.putDataInElastic(bulkRequest.get());
                    counter.set(0);
                    bulkRequest.set(new BulkRequest());
                    bulkRequest.get().timeout(TimeValue.timeValueMinutes(elasticTimeout));
                }
            } catch (Exception ex) {
                LOG.error("Exception occurred while publishing data to elastic search is: ", ex);
                throw new ElasticSearchException();
            }
        });
        LOG.info("going to put data in elastic search");
        blackListEntityUtil.putDataInElastic(bulkRequest.get());
    }

    private String getFileType(String filePath) {
        return filePath.split(Constants.DOT_SEPARATOR)[1];
    }

    private void setData(BlacklistData dummy, BlacklistData blacklistData) {
        if (StringUtils.isNotEmpty(blacklistData.getId())) {
            dummy.setPan(blacklistData.getPan());
            dummy.setBlacklisted(blacklistData.isBlacklisted());
            dummy.setCharge(blacklistData.getCharge());
            dummy.setCountry(blacklistData.getCountry());
            dummy.setId(blacklistData.getId());
            dummy.setAddressCity(blacklistData.getAddressCity());
            dummy.setAddressLine(blacklistData.getAddressLine());
        } else {
            blacklistData.setId(dummy.getId());
            blacklistData.setBlacklisted(dummy.isBlacklisted());
            blacklistData.setCountry(dummy.getCountry());
            blacklistData.setPan(StringUtils.isNotEmpty(blacklistData.getPan()) ? blacklistData.getPan() : dummy.getPan());
            blacklistData.setCharge(dummy.getCharge());
            blacklistData.setAddressLine(dummy.getAddressLine());
            blacklistData.setAddressCity(dummy.getAddressCity());
            }
        }
    }
