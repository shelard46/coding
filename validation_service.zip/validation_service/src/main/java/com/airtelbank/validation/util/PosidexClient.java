package com.airtelbank.validation.util;

import java.time.format.DateTimeFormatter;
import java.util.Locale;

import javax.xml.bind.JAXBElement;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.core.env.Environment;
import org.springframework.oxm.jaxb.Jaxb2Marshaller;
import org.springframework.stereotype.Component;
import org.springframework.web.client.ResourceAccessException;
import org.springframework.ws.client.core.support.WebServiceGatewaySupport;
import org.springframework.ws.soap.client.SoapFaultClientException;

import com.airtelbank.validation.exception.ThirdPartyApiException;
import com.airtelbank.validation.model.DedupeRequest;
import com.airtelbank.validation.model.posidex.customer.Address;
import com.airtelbank.validation.model.posidex.customer.CustomerRequest;
import com.airtelbank.validation.model.posidex.customer.CustomerResponse;
import com.airtelbank.validation.model.posidex.customer.Demographics;
import com.airtelbank.validation.model.posidex.customer.Email;
import com.airtelbank.validation.model.posidex.customer.ObjectFactory;


@Component
public class PosidexClient extends WebServiceGatewaySupport {

	private static DateTimeFormatter dateformatterDob = DateTimeFormatter.ofPattern("dd/MM/yyyy");
	private ObjectFactory objectFactory = new ObjectFactory();
	private static final Logger log = LoggerFactory.getLogger(PosidexClient.class);
	@Autowired
    Environment environment;

    @Autowired
    private MessageSource messageSource;

	public PosidexClient() {
		super();
		Jaxb2Marshaller marshaller = new Jaxb2Marshaller();
		marshaller.setContextPath("com.airtelbank.validation.model.posidex.customer");
		getWebServiceTemplate().setMarshaller(marshaller);
		getWebServiceTemplate().setUnmarshaller(marshaller);
	}

	public CustomerResponse findCustomers(DedupeRequest dedupeReq, String partner, String posidexUrl, int posidexProfileId, String contentId) {
		log.info("Calling dedupe...");
		CustomerResponse customerResponse = null;
		CustomerRequest customerRequest = new CustomerRequest();
		Demographics demographics = new Demographics();
		if(StringUtils.isNotBlank(contentId)) {
            demographics.setRequestid(contentId);
        } else {
            demographics.setRequestid(CommonUtil.generateUniqueId());
        }
		log.info("Dedupe request Id : {}, customerId : {} " , demographics.getRequestid(), dedupeReq.getCustomerId());
		demographics.setCustFname(dedupeReq.getFirstName());
		demographics.setCustLname(dedupeReq.getLastName());
		demographics.setCustDob(dedupeReq.getDateOfBirth().format(dateformatterDob));
		demographics.setCustMsisdn(dedupeReq.getCustomerId());
		demographics.setProfileId(posidexProfileId);
		demographics.setPoiType(dedupeReq.getDocType());//dedupeReq.getPoiType().equals("AADHAAR ID")?"AADHAARID":requestDTO.getPoiType()
		demographics.setPoiNumber(dedupeReq.getDocNumber());
		demographics.setSourceType(partner);

		customerRequest.setDemographics(demographics);
		Address address = new Address();
		address.setPermanentPostalCode(dedupeReq.getPincode());
		customerRequest.getAddress().add(address);
		customerRequest.getEmail().add(new Email());
		JAXBElement<?> requestObj = objectFactory.createFindCustomer(customerRequest);
		logger.info("sending request to posidex ...");
		if(log.isDebugEnabled()) {
			try {
				log.debug("dedupe request : {}", CommonUtil.jsonObjectToString(customerRequest));
			}catch(Exception e) {
				logger.error("errro : " + e.getMessage());
			}
		}
		try {
			JAXBElement<?> responseObject = (JAXBElement<CustomerResponse>)getWebServiceTemplate().marshalSendAndReceive(posidexUrl,requestObj);
			customerResponse = (CustomerResponse)responseObject.getValue();
			if(log.isDebugEnabled()) {
				log.debug("dedupe response : {}", CommonUtil.jsonObjectToString(customerResponse));
			}
		} catch (ResourceAccessException e) {
			log.error("Timeout during Posidex request.");
			String errorMessage = messageSource.getMessage("config.dedupe.posidex.timeout.error.msg",null,Locale.ENGLISH);
			String errorCode = environment.getProperty("config.dedupe.posidex.timeout.error.code");
			throw new ThirdPartyApiException(errorMessage , errorCode, e);
		} catch (SoapFaultClientException e) {
			log.error("ERROR while sending request to Posidex, error");
			String errorMessage = messageSource.getMessage("config.posidex.error.soap.msg",null,Locale.ENGLISH);
			String errorCode = environment.getProperty("config.posidex.error.soap.code");
			throw new ThirdPartyApiException(errorMessage , errorCode, e);
		}
		logger.info("Dedupe is done.");
		return customerResponse;
	}

}
