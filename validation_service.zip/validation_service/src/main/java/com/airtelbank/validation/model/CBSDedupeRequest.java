package com.airtelbank.validation.model;

import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString(exclude = "panNo")
public class CBSDedupeRequest {
    private String mobileNo;
    private String aadhaarNo;
    private String panNo;
    private String emailId;
    private String customerType;
}
