package com.airtelbank.validation.service.impl.helper;

import com.airtelbank.validation.dao.aerospike.AadharVerifyDao;
import com.airtelbank.validation.dao.aerospike.model.AadhaarVerify;
import com.airtelbank.validation.dao.aerospike.model.Identities;
import com.airtelbank.validation.dao.jpa.model.DocumentAuditLog;
import com.airtelbank.validation.exception.AadharVerificationException;
import com.airtelbank.validation.exception.VerifyAadhaarOTPRequestLimitExceededException;
import com.airtelbank.validation.model.AadhaarVaultRequest;
import com.airtelbank.validation.model.AadhaarVaultResponse;
import com.airtelbank.validation.model.Document;
import com.airtelbank.validation.service.AadhaarService;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.core.env.Environment;

import static com.airtelbank.validation.service.impl.helper.AadhaarServiceImplHelper.RequestEndPoint.GENERATE_AADHAAR_OTP;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class AadhaarServiceImplHelperTest {
	
	@Mock private AadharVerifyDao aadharVerify;
	@Mock private AadhaarService aadhaarService;
	@Mock private Environment environment;
	
	@InjectMocks AadhaarServiceImplHelper aadhaarServiceImplHelper;
	
	@Before
	public void init() {
		MockitoAnnotations.initMocks(this);


	}
	
	@Test(expected = Test.None.class)
	public void processAadharVerifyDataWhenAadhaarIdTest() {
		Document request = Document.builder().build();
		Identities identity = Identities.builder().build();
		AadhaarVerify aadhaarVerify = AadhaarVerify.builder().userIdentifierType("A").build();
		String docReferenceNumber = ""; String docOriginalNum = "";
		DocumentAuditLog documentAuditLog = DocumentAuditLog.builder().build();
		aadhaarServiceImplHelper.processAadharVerifyData(request, identity, aadhaarVerify, docReferenceNumber, docOriginalNum, documentAuditLog);
	}
	
	@Test(expected = Test.None.class)
	public void processAadharVerifyDataWhenVIDTest() {
		Document request = Document.builder().build();
		Identities identity = Identities.builder().build();
		AadhaarVerify aadhaarVerify = AadhaarVerify.builder().userIdentifierType("V").build();
		String docReferenceNumber = ""; String docOriginalNum = "";
		DocumentAuditLog documentAuditLog = DocumentAuditLog.builder().build();
		when(aadhaarService.getAadhaarReference(Mockito.any(AadhaarVaultRequest.class))).thenReturn(AadhaarVaultResponse.builder().referenceKey("ref").build());
		aadhaarServiceImplHelper.processAadharVerifyData(request, identity, aadhaarVerify, docReferenceNumber, docOriginalNum, documentAuditLog);
	}


	@Test(expected = VerifyAadhaarOTPRequestLimitExceededException.class)
	public void checkIndetiyContrainsForAadhaarOTPVerificationExceptionTest() {

			Identities identities = new Identities();
			identities.setDocType("test");
			aadhaarServiceImplHelper.checkIndetiyContrainsForAadhaarOTPVerification(identities);


	}

	@Test(expected = AadharVerificationException.class)
	public void checkIndetiyContrainsForAadhaarOTPVerificationsExceptionTest() {

			Identities identities = new Identities();
			identities.setDocType("test");
			aadhaarServiceImplHelper.checkIndetiyContrainsForAadhaarOTPVerification(null);


	}


	@Test
	public void getDocRefernceNumberTest() {
		Document document=new Document();
		document.setDocNumber("test");
		Identities identities = new Identities();
		identities.setDocType("test");
		String s=aadhaarServiceImplHelper.getDocRefernceNumber(document,identities);
		Assert.assertNull(s);
	}

	@Test
	public void shouldTest()
	{
		Assert.assertEquals(GENERATE_AADHAAR_OTP, GENERATE_AADHAAR_OTP);

	}
}