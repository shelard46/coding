package com.airtelbank.validation.controller;

import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import com.airtelbank.validation.exception.ThirdPartyApiException;
import com.airtelbank.validation.model.*;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.airtelbank.validation.constants.Constants;
import com.airtelbank.validation.model.blacklist.BlacklistEntity;
import com.airtelbank.validation.service.BlacklistService;
import com.fasterxml.jackson.databind.ObjectMapper;


@RunWith(MockitoJUnitRunner.class)
public class BlacklistControllerTest {

	@Mock private BlacklistService service;
	@InjectMocks private BlacklistController controller;

	private MockMvc mvc;

	@Before
	public void init() {
		MockitoAnnotations.initMocks(this);
		mvc = MockMvcBuilders.standaloneSetup(controller).build();
	}

	@Test(expected = Test.None.class)
	public void checkEntityBlacklistingTest() throws Exception {
		BlacklistEntity request = new BlacklistEntity();
		ResponseDTO<BlacklistEntityResponse> response = new ResponseDTO();
		response.setMeta(Meta.builder().status(Constants.SUCCESS_STATUS).build());
		when(service.getEntityBlacklistInfo(Mockito.any(BlacklistEntity.class), Mockito.anyString())).thenReturn(response);
		mvc.perform(MockMvcRequestBuilders
						.post("/api/v1/entity/blacklist")
						.content(new ObjectMapper().writeValueAsString(request))
						.contentType(MediaType.APPLICATION_JSON)
						.header("contentId", "sdfghj")
						.header("channel", "TEST")
						.accept(MediaType.APPLICATION_JSON))
				.andDo(print())
				.andExpect(status().isOk());
	}
	@Test(expected = ThirdPartyApiException.class)
	public void checkCustomerBlacklistingExceptiontest()
	{

			BlacklistRequest blacklistRequest = new BlacklistRequest();
			blacklistRequest.setCustomerId("test");
			ResponseDTO<BlacklistResponse> blacklistResponseResponseDTO = controller.checkCustomerBlacklisting("test", blacklistRequest, "test", "test");


	}

	@Test
	public void checkCustomerBlacklistingresponseisnullExceptiontest()
	{

			BlacklistRequest blacklistRequest = new BlacklistRequest();
			blacklistRequest.setCustomerId("test");
			ResponseDTO<BlacklistResponse> response = new ResponseDTO<>();
			Meta meta=new Meta();
			meta.setDescription("test");
			response.setMeta(meta);
			Mockito.when(service.getCustomerBlacklistInfo(Mockito.any(),Mockito.any())).thenReturn(response);
			ResponseDTO<BlacklistResponse> blacklistResponseResponseDTO = controller.checkCustomerBlacklisting("test", blacklistRequest, "test", "test");


	}

	@Test(expected = RuntimeException.class)
	public void checkEntityBlacklistingExcptionTest() throws Exception {

			BlacklistEntity request = new BlacklistEntity();
			ResponseDTO<BlacklistEntityResponse> response = new ResponseDTO();
			response.setMeta(Meta.builder().status(Constants.SUCCESS_STATUS).build());
			when(service.getEntityBlacklistInfo(Mockito.any(BlacklistEntity.class), Mockito.anyString())).thenThrow(new RuntimeException());
			ResponseDTO<BlacklistEntityResponse> blacklistEntityResponseResponseDTO = controller.checkEntityBlacklisting(request, "test", "test");




	}


}