package com.airtelbank.validation.service.impl.helper;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.io.IOException;
import java.util.UUID;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.MockitoJUnitRunner;

import com.airtelbank.validation.model.BlacklistEntityResponse;
import com.airtelbank.validation.model.blacklist.BlacklistEntity;
import com.airtelbank.validation.service.impl.BlacklistServiceImpl;
import com.airtelbank.validation.util.BlackListEntityUtil;


@RunWith(MockitoJUnitRunner.Silent.class)
public class BlacklistServiceImplTest {

	@InjectMocks
	BlacklistServiceImpl blacklistService;

	@Mock
	BlackListEntityUtil blackListEntityUtil;

	@Before
	public void init() {
		MockitoAnnotations.initMocks(this);
	}

	@Test
	public void testEntityBlacklistInfo() throws IOException {
		when(blackListEntityUtil.getFailureResponse()).thenReturn(new BlacklistEntityResponse());
		when(blackListEntityUtil.getSuccessResponse(any(), anyString())).thenReturn(new BlacklistEntityResponse());
		blacklistService.getEntityBlacklistInfo(getBlacklistEntity(), UUID.randomUUID().toString());
		verify(this.blackListEntityUtil, times(2)).getSearchResponse(anyString(), anyString());
	}

	private BlacklistEntity getBlacklistEntity() {
		BlacklistEntity blacklistEntity = new BlacklistEntity();
		blacklistEntity.setPan("123456789");
		blacklistEntity.setName("Bhusan Steel");
		return blacklistEntity;
	}
}

