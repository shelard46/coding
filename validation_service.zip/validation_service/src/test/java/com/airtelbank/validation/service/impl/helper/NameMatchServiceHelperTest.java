package com.airtelbank.validation.service.impl.helper;

import static org.junit.Assert.assertEquals;

import static org.mockito.Mockito.when;

import java.util.Locale;

import com.airtelbank.validation.exception.NameMatchException;
import com.airtelbank.validation.model.NameMatchRequest;
import com.airtelbank.validation.model.NameMatchResponse;
import com.airtelbank.validation.model.posidex.namematch.NameRequest;
import com.airtelbank.validation.model.posidex.namematch.NameResult;
import com.airtelbank.validation.util.NameMatchPosidexClient;
import lombok.extern.slf4j.Slf4j;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.context.MessageSource;

@RunWith(MockitoJUnitRunner.Silent.class)
@Slf4j
public class NameMatchServiceHelperTest {

    @Mock
    private MessageSource messageSource;

    @Mock
    private NameMatchPosidexClient nameMatchPosidexClient;

    @InjectMocks
    private NameMatchServiceHelper nameMatchServiceHelper;

    @Mock
    private NameResult nameResult;

    @Before
    public void init() {
        MockitoAnnotations.initMocks(this);
        when(messageSource.getMessage("config.posidex.namematch.error.empty.request.code", null, Locale.ENGLISH)).thenReturn("empty request code");
        when(messageSource.getMessage("config.posidex.namematch.error.empty.request.msg", null, Locale.ENGLISH)).thenReturn("empty request msg");
        when(messageSource.getMessage("config.posidex.namematch.error.empty.request.source.code", null, Locale.ENGLISH)).thenReturn("empty request source code");
        when(messageSource.getMessage("config.posidex.namematch.error.empty.request.source.msg", null, Locale.ENGLISH)).thenReturn("empty request source msg");
        when(messageSource.getMessage("config.posidex.namematch.error.empty.request.target.code", null, Locale.ENGLISH)).thenReturn("empty request target code");
        when(messageSource.getMessage("config.posidex.namematch.error.empty.request.target.msg", null, Locale.ENGLISH)).thenReturn("empty request target msg");
        when(messageSource.getMessage("config.posidex.namematch.error.generic.code", null, Locale.ENGLISH)).thenReturn("generic request code");
        when(messageSource.getMessage("config.posidex.namematch.error.generic.msg", null, Locale.ENGLISH)).thenReturn("generic request msg");

    }

    @Test
    public void generateNameMatchValidationExceptionEmptyRequestTest() {

        NameMatchException result = nameMatchServiceHelper.generateNameMatchValidationException(NameMatchServiceHelper.NameMatchValidation.EMPTY);
        assertEquals("empty request code", result.getErrorCode());
        assertEquals("empty request msg", result.getErrorMessage());
    }

    @Test
    public void generateNameMatchValidationExceptionEmptySourceTest() {

        NameMatchException result = nameMatchServiceHelper.generateNameMatchValidationException(NameMatchServiceHelper.NameMatchValidation.EMPTY_SOURCE);
        assertEquals("empty request source code", result.getErrorCode());
        assertEquals("empty request source msg", result.getErrorMessage());
    }

    @Test
    public void generateNameMatchValidationExceptionEmptyTargetTest() {

        NameMatchException result = nameMatchServiceHelper.generateNameMatchValidationException(NameMatchServiceHelper.NameMatchValidation.EMPTY_TARGET);
        assertEquals("empty request target code", result.getErrorCode());
        assertEquals("empty request target msg", result.getErrorMessage());
    }

    @Test
    public void generateNameMatchValidationExceptionGenericTest() {

        NameMatchException result = nameMatchServiceHelper.generateNameMatchValidationException(NameMatchServiceHelper.NameMatchValidation.SUCCESS);
        assertEquals("generic request code", result.getErrorCode());
        assertEquals("generic request msg", result.getErrorMessage());
    }

    @Test
    public void generateNameMatchValidationExceptionNullTest() {

        NameMatchException result = nameMatchServiceHelper.generateNameMatchValidationException(null);
        assertEquals("generic request code", result.getErrorCode());
        assertEquals("generic request msg", result.getErrorMessage());
    }

    @Test
    public void matchNameWithPosidexTest() {
        NameMatchRequest nameMatchRequest = new NameMatchRequest();
        nameMatchRequest.setSource("Source");
        nameMatchRequest.setTarget("Target");
        NameResult nameResult =new NameResult();
        nameResult.setMatchPercentage(0);
        nameResult.setMessage("Fail");
        NameRequest nameRequest = new NameRequest();
        nameRequest.setSourceName("Source");
        nameRequest.setTargetName("Target");
        when(nameMatchPosidexClient.nameMatch(Mockito.any(NameRequest.class), Mockito.any(),Mockito.anyInt())).thenReturn(nameResult);
        NameMatchResponse result = nameMatchServiceHelper.matchNameWithPosidex("Source","Target",nameMatchRequest);
        assertEquals("Source", result.getSource());
        assertEquals("Target", result.getTarget());
        assertEquals(0, result.getPercentageMatch());
    }
}
