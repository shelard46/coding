package com.airtelbank.validation.service.impl;

import com.airtelbank.validation.dao.aerospike.model.Blackout;
import com.airtelbank.validation.dao.aerospike.repository.BlackoutRepository;
import com.airtelbank.validation.model.*;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.MockitoJUnitRunner;

import static org.junit.Assert.*;
import static org.mockito.Mockito.when;
import org.mockito.Mockito;
import org.springframework.context.MessageSource;

@RunWith(MockitoJUnitRunner.Silent.class)
public class BlackoutServiceImplTest {

    
    @Mock
    private BlackoutRepository blackoutRepository;
    @Mock
    private MessageSource messageSource;
    @InjectMocks
    private BlackoutServiceImpl blackoutServiceImpl;

    @Before
    public void init() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void postBlackoutTest(){
        BlackoutRequest request = new BlackoutRequest();
        Blackout blackout = new Blackout();
        request.setCustomerId("1");
        request.setIdentifierType("C");
        request.setIdentifierValue("20");
        when(blackoutRepository.save(blackout)).thenReturn(blackout);
        when(messageSource.getMessage(Mockito.any(),Mockito.any())).thenReturn("ABC");
        ResponseDTO<BlackoutResponse> responseDTO = blackoutServiceImpl.postBlackout(request);
        assertTrue(responseDTO.getData().getExist());
    }

    @Test
    public void getBlackoutTest(){
        BlackoutRequest request = new BlackoutRequest();
        Blackout blackout = new Blackout();
        request.setCustomerId("1");
        request.setIdentifierType("C");
        request.setIdentifierValue("20");
        when(blackoutRepository.save(blackout)).thenReturn(blackout);
        when(messageSource.getMessage(Mockito.any(),Mockito.any())).thenReturn("ABC");
        ResponseDTO<BlackoutResponse> responseDTO = blackoutServiceImpl.getBlackout("1");
        assertFalse(responseDTO.getData().getExist());
    }

    @Test
    public void getBlackoutNegativeTest(){
        BlackoutRequest request = new BlackoutRequest();
        Blackout blackout = new Blackout();
        request.setCustomerId("1");
        request.setIdentifierType("C");
        request.setIdentifierValue("20");
        when(blackoutRepository.save(blackout)).thenReturn(blackout);
        when(messageSource.getMessage(Mockito.any(),Mockito.any())).thenReturn("ABC");
        ResponseDTO<BlackoutResponse> responseDTO = blackoutServiceImpl.getBlackout("");
        assertFalse(responseDTO.getData().getExist());
    }

    @Test
    public void getBlackoutNotNullTest(){
        BlackoutRequest request = new BlackoutRequest();
        Blackout blackout = new Blackout();
        blackout.setId("12");
        blackout.setCustomerId("Customer");
        blackout.setType("Dummy");
        request.setCustomerId("1");
        request.setIdentifierType("C");
        request.setIdentifierValue("20");
        when(blackoutRepository.findOne(Mockito.anyString())).thenReturn(blackout);
        when(messageSource.getMessage(Mockito.any(),Mockito.any())).thenReturn("ABC");
        ResponseDTO<BlackoutResponse> responseDTO = blackoutServiceImpl.getBlackout("");
        assertTrue(responseDTO.getData().getExist());
    }
}
