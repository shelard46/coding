package com.airtelbank.validation.service.impl;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.when;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.test.util.ReflectionTestUtils;

import com.airtelbank.validation.dao.jpa.respository.DocumentAuditRepository;
import com.airtelbank.validation.enums.CommunicationType;
import com.airtelbank.validation.model.communication.SMSResponse;
import com.airtelbank.validation.util.HttpUtil;
import com.airtelbank.validation.util.RequestCreationUtil;

public class SmsCommunicationServiceImplTest {
	
	@Mock private HttpUtil httpUtil;
	@Mock private RequestCreationUtil requestCreation;
	@Mock private DocumentAuditRepository documentAuditRepository;
	
	@InjectMocks private SmsCommunicationServiceImpl communicationService;
	
	@Before
	public void init() {
		MockitoAnnotations.initMocks(this);
		ReflectionTestUtils.setField(communicationService, "smsUrl", "http://sms.url");
		ReflectionTestUtils.setField(communicationService, "smsSuccessCode", "000");
	}
	
	@Test
	public void sendSmsWhenSuccess() throws Exception {
		SMSResponse smsResponse = SMSResponse.builder().responseCode("000").build();
		when(httpUtil.handleRequest(Mockito.anyString(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(smsResponse);
		boolean isSuccess = communicationService.sendCommunication(CommunicationType.ALERT_AUA_SUCCESS, "9876543210", null, "contentId", "TEST");
		assertTrue(isSuccess);
	}
	
	@Test
	public void sendSmsWhenFailure() throws Exception {
		SMSResponse smsResponse = SMSResponse.builder().responseCode("001").build();
		when(httpUtil.handleRequest(Mockito.anyString(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(smsResponse);
		boolean isSuccess = communicationService.sendCommunication(CommunicationType.ALERT_AUA_SUCCESS, "9876543210", null, "contentId", "TEST");
		assertFalse(isSuccess);
	}
	
	@Test
	public void sendSmsWhenNullResponse() throws Exception {
		SMSResponse smsResponse = null;
		when(httpUtil.handleRequest(Mockito.anyString(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(smsResponse);
		boolean isSuccess = communicationService.sendCommunication(CommunicationType.ALERT_AUA_SUCCESS, "9876543210", null, "contentId", "TEST");
		assertFalse(isSuccess);
	}
	
	@Test
	public void sendSmsWhenNullResponseCode() throws Exception {
		SMSResponse smsResponse = SMSResponse.builder().build();
		when(httpUtil.handleRequest(Mockito.anyString(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(smsResponse);
		boolean isSuccess = communicationService.sendCommunication(CommunicationType.ALERT_AUA_SUCCESS, "9876543210", null, "contentId", "TEST");
		assertFalse(isSuccess);
	}
	
	@Test
	public void sendSmsWhenException() throws Exception {
		when(httpUtil.handleRequest(Mockito.anyString(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any())).thenThrow(new RuntimeException());
		boolean isSuccess = communicationService.sendCommunication(CommunicationType.ALERT_AUA_SUCCESS, "9876543210", null, "contentId", "TEST");
		assertFalse(isSuccess);
	}
	
	@Test
	public void sendSmsWhenSuccessButExceptionDuringDbSave() throws Exception {
		SMSResponse smsResponse = SMSResponse.builder().responseCode("000").build();
		when(documentAuditRepository.save(Mockito.any())).thenThrow(new RuntimeException());
		when(httpUtil.handleRequest(Mockito.anyString(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(smsResponse);
		boolean isSuccess = communicationService.sendCommunication(CommunicationType.ALERT_AUA_SUCCESS, "9876543210", null, "contentId", "TEST");
		assertTrue(isSuccess);
	}

}
