package com.airtelbank.validation.util;

import java.io.IOException;

import org.junit.Assert;
import org.junit.Test;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonRootName;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

public class TestCommonUtil {
	
	@Test
	public void testEscapeSpecialCharacterInTextNodeOfXMLWithEmp() {
		String input = "<parent><child>Data 1 & data 2 &</child></parent>";
		String output = "<parent><child>Data 1 &amp; data 2 &amp;</child></parent>";
		String actualOutput = CommonUtil.escapeSpecialCharacterInTextNodeOfXML(input);
		System.out.println(actualOutput);
		Assert.assertEquals(output,actualOutput );
		
	}
	
	
	@Test
	public void testEscapeSpecialCharacterInTextNodeOfXMLWithEmpHtmlCode() {
		String input = "<parent><child>Data 1 &amp; data 2</child></parent>";
		String output = "<parent><child>Data 1 &amp; data 2</child></parent>";
		String actualOutput = CommonUtil.escapeSpecialCharacterInTextNodeOfXML(input);
		System.out.println(actualOutput);
		Assert.assertEquals(output,actualOutput);
	}
	
	
	
	//@Test
	public void testEscapeSpecialCharacterInTextNodeOfXMLWithGTLT() {
		String input = "<parent><child>Data 1 < data 2</child></parent>";
		String output = "<parent><child>Data 1 &lt; data 2</child></parent>";
		String actualOutput = CommonUtil.escapeSpecialCharacterInTextNodeOfXML(input);
		System.out.println(actualOutput);
		Assert.assertEquals(output,actualOutput);
		//Assert.assertEquals(output, CommonUtil.escapeSpecialCharacterInTextNodeOfXML(input));
		
	}
	
	
	//@Test
	public void testEscapeSpecialCharacterInTextNodeOfXMLWithGTLTHtml() {
		String input = "<parent><child>Data 1 &lt;data 2</child></parent>";
		String output = "<parent><child>Data 1 &lt; data 2</child></parent>";
		String actualOutput = CommonUtil.escapeSpecialCharacterInTextNodeOfXML(input);
		System.out.println(actualOutput);
		Assert.assertEquals(output,actualOutput);
	
		
	}
	
	
	@Test
	public void testEscapeSpecialCharacterInTextNodeOfXMLQuuotes() {
		
		String input = "<parent><child>Data 1 data 2' #</child></parent>";
		String output = "<parent><child>Data 1 data 2&apos; #</child></parent>";
		String actualOutput = CommonUtil.escapeSpecialCharacterInTextNodeOfXML(input);
		try {
			Parent parent = CommonUtil.convertToObjectFromXMLInJackson(actualOutput, Parent.class);
			System.out.println(parent);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
		System.out.println(actualOutput);
		Assert.assertEquals(output,actualOutput);
		
	}
	
	//@Test
	public void testXml() {
		String input = "<parent><child>Data 1 & data 2</child></parent>";
		Parent parent = null;
		try {
			parent = CommonUtil.convertToObjectFromXMLInJackson(input, Parent.class);
		
		} catch (JsonParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (JsonMappingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		Assert.assertEquals("Data 1 & data 2", parent.getChild());
	}

}

@AllArgsConstructor
@NoArgsConstructor
@Setter
@Getter
@ToString
@JsonRootName("parent")
class Parent{
	@JsonProperty("child")
	String child;
}

