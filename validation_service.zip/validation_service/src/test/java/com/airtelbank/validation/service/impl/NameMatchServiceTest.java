package com.airtelbank.validation.service.impl;

import com.airtelbank.validation.exception.NameMatchException;
import com.airtelbank.validation.model.NameMatchRequest;
import com.airtelbank.validation.model.NameMatchResponse;
import com.airtelbank.validation.service.impl.helper.NameMatchServiceHelper;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import static org.junit.Assert.*;

public class NameMatchServiceTest {

    @InjectMocks
    NameMatchService nameMatchService;

    @Mock
    NameMatchServiceHelper nameMatchServiceHelper;

    @Before
    public void init() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void checkNamesPositiveTest(){

        NameMatchRequest nameMatchRequest = new NameMatchRequest();
        nameMatchRequest.setSource("Source");
        nameMatchRequest.setTarget("Source");
        NameMatchResponse nameMatchResponse = nameMatchService.checkNames(nameMatchRequest);
        assertEquals(100,nameMatchResponse.getPercentageMatch());
    }

    @Test(expected = Exception.class)
    public void checkNamesEmptySourceException() throws NameMatchException {
        NameMatchRequest nameMatchRequest = new NameMatchRequest();
        nameMatchRequest.setSource("");
        nameMatchRequest.setTarget("Source");
        nameMatchService.checkNames(nameMatchRequest);
    }

    @Test(expected = Exception.class)
    public void checkNamesEmptyTargetException() throws NameMatchException {
        NameMatchRequest nameMatchRequest = new NameMatchRequest();
        nameMatchRequest.setSource("Source");
        nameMatchRequest.setTarget("");
        nameMatchService.checkNames(nameMatchRequest);
    }

    @Test(expected = Exception.class)
    public void checkNamesEmptyRequestException() throws NameMatchException {
        NameMatchRequest nameMatchRequest = null;
        nameMatchService.checkNames(nameMatchRequest);
    }
}
