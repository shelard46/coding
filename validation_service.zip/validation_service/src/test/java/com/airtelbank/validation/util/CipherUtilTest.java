package com.airtelbank.validation.util;

import static org.junit.Assert.assertEquals;

import org.junit.Before;
import org.junit.Test;
import org.mockito.MockitoAnnotations;

public class CipherUtilTest {

	@Before
	public void init() {
		MockitoAnnotations.initMocks(this);
	}

	@Test
	public void getHashedValueTest() {
		String hashedPassword = "b54fe225548cc8f7ae365ee74c09c4baaaa6753f3f0f4f9bbbb9f5d1afd99935";
		assertEquals(hashedPassword, CipherUtil.getHashedValue("12345", "HmacSHA256",
				"TEAKEYKEYNDSKLFNSKBJSFBLSFBLSIAHFOOOQQQEWFFWSFELFSALFLSDFBFLPPPLLLJALVN"));
	}

	@Test(expected = Test.None.class)
	public void getHashedValueTestWithException() {
		CipherUtil.getHashedValue(null, "HmacSHA256",
				"TEAKEYKEYNDSKLFNSKBJSFBLSFBLSIAHFOOOQQQEWFFWSFELFSALFLSDFBFLPPPLLLJALVN");
	}
}
