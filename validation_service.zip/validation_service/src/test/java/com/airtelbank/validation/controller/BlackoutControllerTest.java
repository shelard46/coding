package com.airtelbank.validation.controller;

import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.apache.logging.log4j.core.config.Configurator;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.airtelbank.validation.model.BlackoutRequest;
import com.airtelbank.validation.model.BlackoutResponse;
import com.airtelbank.validation.model.ResponseDTO;
import com.airtelbank.validation.service.BlackoutService;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.validation.BindingResult;

@SpringBootTest
@RunWith(MockitoJUnitRunner.class)
public class BlackoutControllerTest {

	@Mock private BindingResult bindingResult;
	@Mock private BlackoutService service;
	@InjectMocks private BlackoutController controller;
	
	private MockMvc mvc;

	@Before
	public void init() {
		MockitoAnnotations.initMocks(this);
		mvc = MockMvcBuilders.standaloneSetup(controller).build();
		ReflectionTestUtils.setField(controller, "privateKey", "MIIBVAIBADANBgkqhkiG9w0BAQEFAASCAT4wggE6AgEAAkEAmUIa1G/XYHsFG9LjYIyDnzUQnz+P7R7NrJqEEbDxx6zSTbfh79Ri9vlH4+OPC+0RR7V4PCXyCZ16U6XpnHTP+QIDAQABAkA94QfuMD4Y0XLtmgd+ax2VwZo1gjd9eQt4HmcmsXfds5Q8DBRHX199+IypL4kO7Xj5wv7N7vrDdRv4P663ahGVAiEA1ogj2b2bFBPryaXadqXkqsCpqeAqAybGoO1Axyz1ptMCIQC24emDhhiyQuEehjTNiCtdkQpPi45o5erBZM/RHBqGgwIhAMvKp8PACgEYq3PyyYTMMlzCiGmHOGGmBCn7Nv3+B51hAiBEeJauKJGshD+25vZ0EUxzLq+WkqCSA6r+F1l7aDNCMwIgIw7Hu7V3NO6lFI4o8oXNYkJZisFhAlYe4kkG3HdW9Qs=");
		Configurator.setAllLevels("", org.apache.logging.log4j.Level.ALL);
	}

	@Test
	public void getBlackoutTest() throws Exception {
		ResponseDTO<BlackoutResponse> response = new ResponseDTO();
		String customerId = "9876543210"; String contentId = "content"; String channel = "channel";
		when(service.getBlackout(Mockito.anyString())).thenReturn(response);
		mvc.perform(MockMvcRequestBuilders
						.get("/api/v1/blackout/" + customerId)
						.contentType(MediaType.APPLICATION_JSON)
						.header("contentId", contentId)
						.header("channel", channel)
						.accept(MediaType.APPLICATION_JSON))
				.andDo(print())
				.andExpect(status().isOk());
	}
	
	@Test
	public void getBlackoutTestV2() throws Exception {
		ResponseDTO<BlackoutResponse> response = new ResponseDTO();
		String customerId = "9876543210"; String contentId = "content"; String channel = "channel";
		when(service.getBlackout(Mockito.anyString())).thenReturn(response);
		mvc.perform(MockMvcRequestBuilders
						.get("/api/v2/blackout/")
						.contentType(MediaType.APPLICATION_JSON)
						.header("contentId", contentId)
						.header("channel", channel)
						.header("customerId", "SP9pwV9mnE+QLUM06lX3k82gZvS2PKXycwh/zDLvZ7iElS8PVoBVDPtNbmsiLedCKltpMpzJs+mq9GjUWrvxXQ==")
						.accept(MediaType.APPLICATION_JSON))
				.andDo(print())
				.andExpect(status().isOk());
	}

	@Test
	public void postBlackoutTest() throws Exception {
		ResponseDTO<BlackoutResponse> response = new ResponseDTO();
		BlackoutRequest request = new BlackoutRequest();
		request.setIdentifierType("something");
		String contentId = "content"; String channel = "channel";
		when(service.postBlackout(Mockito.any(BlackoutRequest.class))).thenReturn(response);
		mvc.perform(MockMvcRequestBuilders
						.post("/api/v1/blackout/")
						.content(new ObjectMapper().writeValueAsString(request))
						.contentType(MediaType.APPLICATION_JSON)
						.header("contentId", contentId)
						.header("channel", channel)
						.accept(MediaType.APPLICATION_JSON))
				.andDo(print())
				.andExpect(status().isOk());
	}
	
	@Test
	public void postBlackoutTestV2() throws Exception {
		ResponseDTO<BlackoutResponse> response = new ResponseDTO();
		BlackoutRequest request = new BlackoutRequest();
		request.setIdentifierType("something");
		String contentId = "content"; String channel = "channel";
		when(service.postBlackout(Mockito.any(BlackoutRequest.class))).thenReturn(response);
		mvc.perform(MockMvcRequestBuilders
						.post("/api/v2/blackout/")
						.content(new ObjectMapper().writeValueAsString(request))
						.contentType(MediaType.APPLICATION_JSON)
						.header("contentId", contentId)
						.header("channel", channel)
						.accept(MediaType.APPLICATION_JSON))
				.andDo(print())
				.andExpect(status().isOk());
	}

	@Test
	public void postBlackout1successTest() {
		ResponseDTO<BlackoutResponse> response = new ResponseDTO();
		BlackoutRequest request = new BlackoutRequest();
		request.setIdentifierType("MOBILE");
		request.setIdentifierValue("test");
		String contentId = "content"; String channel = "channel";
		when(service.postBlackout(Mockito.any(BlackoutRequest.class))).thenReturn(response);
		ResponseEntity<ResponseDTO<BlackoutResponse>> responseDTOResponseEntity=controller.postBlackout(request,"test","test",bindingResult);
		Assert.assertNotNull(responseDTOResponseEntity);
	}


}