package com.airtelbank.validation.service.impl;

import com.airtelbank.validation.dao.aerospike.PosidexCacheCustomerDao;
import com.airtelbank.validation.dao.aerospike.model.PosidexCacheCustomerDetails;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.MockitoJUnitRunner;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;

@RunWith(MockitoJUnitRunner.class)
public class PosidexCacheCustomerServiceImplTest {

    @InjectMocks
    private PosidexCacheCustomerServiceImpl getPosidexCacheCustomerDetails;

    @Mock
  private  PosidexCacheCustomerDao posidexCacheCustomerDAO;

    @Before
    public void setUp() throws Exception {
        MockitoAnnotations.initMocks(this);

    }

    @After
    public void tearDown() {
    }

    @Test
    public void testGetPosidexCacheCustomerDetails() {

        final PosidexCacheCustomerDetails result = getPosidexCacheCustomerDetails.getPosidexCacheCustomerDetails(
                "id");
        assertNull(result);

    }

    @Test
    public void testGetPosidexCacheCustomerDetailsNullTest() {

        Mockito.when(posidexCacheCustomerDAO.getPosidexDataAero(Mockito.any())).thenThrow(NullPointerException.class);
        final PosidexCacheCustomerDetails result = getPosidexCacheCustomerDetails.getPosidexCacheCustomerDetails(
                "id");
        assertNull(result);


    }


    @Test(expected = Test.None.class)
    public void testSave() {

        final PosidexCacheCustomerDetails posidexCacheCustomerDetails = PosidexCacheCustomerDetails.builder().build();
        getPosidexCacheCustomerDetails.save(posidexCacheCustomerDetails);

    }


}