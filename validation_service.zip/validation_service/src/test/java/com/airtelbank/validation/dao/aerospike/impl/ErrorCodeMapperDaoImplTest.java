package com.airtelbank.validation.dao.aerospike.impl;

import com.airtelbank.validation.dao.aerospike.model.ErrorCodeMapper;
import com.airtelbank.validation.exception.AeroSpikeException;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.data.aerospike.core.AerospikeTemplate;

import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.*;

@RunWith(MockitoJUnitRunner.class)
public class ErrorCodeMapperDaoImplTest {

    @Mock private AerospikeTemplate aerospikeTemplate;
    @InjectMocks private ErrorCodeMapperDaoImpl errorCodeMapperDaoImpl;

    @Before
    public void init() {
        MockitoAnnotations.initMocks(this);
    }
    @Test
    public void getUniqueErrorCodeData()  {
        ErrorCodeMapper result = errorCodeMapperDaoImpl.getUniqueErrorCodeData("ABC","XYZ");
        assertNull(result);

    }

    @Test(expected = AeroSpikeException.class)
    public void getUniqueErrorCodeDataExceptionTest()  {

            Mockito.when(aerospikeTemplate.find(Mockito.any(), Mockito.any())).thenThrow(new RuntimeException());
            ErrorCodeMapper result = errorCodeMapperDaoImpl.getUniqueErrorCodeData("ABC", "XYZ");



    }


    @Test
    public void addNewErrorCodeTest() {
        ErrorCodeMapper errorCodeMapper=new ErrorCodeMapper();
        errorCodeMapper.setErrorCode("test");
        Boolean aBoolean=errorCodeMapperDaoImpl.addNewErrorCode(errorCodeMapper);
        assertTrue(aBoolean);
    }



    @Test
    public void getErrorCodeDataByIdTest() {
        ErrorCodeMapper errorCodeMapper=new ErrorCodeMapper();
        errorCodeMapper.setErrorCode("test");
        Mockito.when(aerospikeTemplate.findById(Mockito.any(),Mockito.any())).thenReturn(errorCodeMapper);
        ErrorCodeMapper errorCodeMapper1=errorCodeMapperDaoImpl.getErrorCodeDataById("test");
        assertNotNull(errorCodeMapper1);

    }

    @Test
    public void getErrorCodeTest() {
        List<ErrorCodeMapper> errorCodeMappers=errorCodeMapperDaoImpl.getErrorCode("test");
        assertNotNull(errorCodeMappers);
    }

    @Test
    public void getErrorCodeoriginalerrorcodeisnullTest() {
        List<ErrorCodeMapper> errorCodeMappers=errorCodeMapperDaoImpl.getErrorCode(null);
        assertNull(errorCodeMappers);
    }


    @Test
    public void deleteErrorCodeTest() {
        ErrorCodeMapper errorCodeMapper=new ErrorCodeMapper();
        errorCodeMapper.setErrorCode("test");
        List<ErrorCodeMapper> errorCodeMappers=new ArrayList<>();
        errorCodeMappers.add(errorCodeMapper);
        Mockito.when(aerospikeTemplate.find(Mockito.any(),Mockito.any())).thenReturn(new ArrayList(errorCodeMappers));
        int ErrorCode= errorCodeMapperDaoImpl.deleteErrorCode("test");
        assertNotNull(ErrorCode);
    }

    @Test
    public void saveAllErrorCodeTest() {
        ErrorCodeMapper errorCodeMapper=new ErrorCodeMapper();
        errorCodeMapper.setErrorCode("test");
        List<ErrorCodeMapper> errorCodeMappers=new ArrayList<>();
        errorCodeMappers.add(errorCodeMapper);
        int ErrorCode= errorCodeMapperDaoImpl.saveAllErrorCode(errorCodeMappers);
        assertNotNull(ErrorCode);
    }


    @Test(expected = AeroSpikeException.class)
    public void addNewErrorCodeExceptionTest() {

            ErrorCodeMapper errorCodeMapper = new ErrorCodeMapper();
            errorCodeMapper.setErrorCode("test");
            Mockito.doThrow(new RuntimeException()).when(aerospikeTemplate).persist(Mockito.any(), Mockito.any());
            Boolean aBoolean = errorCodeMapperDaoImpl.addNewErrorCode(errorCodeMapper);


    }

}