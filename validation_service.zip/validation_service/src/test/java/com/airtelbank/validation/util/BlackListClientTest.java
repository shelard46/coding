package com.airtelbank.validation.util;

import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.mock;

import javax.xml.bind.JAXBElement;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.context.MessageSource;
import org.springframework.ws.client.core.WebServiceOperations;
import org.springframework.ws.client.core.WebServiceTemplate;
import org.springframework.ws.client.core.support.WebServiceGatewaySupport;

import com.airtelbank.validation.exception.ThirdPartyApiException;
import com.airtelbank.validation.model.BlacklistRequest;
import com.airtelbank.validation.model.blacklist.CustomerResponse;

public class BlackListClientTest extends WebServiceGatewaySupport {
	
	@Mock private MessageSource messageSource;
	@InjectMocks private BlackListClient blackListClient;
	
	@Before
	public void init() {
		MockitoAnnotations.initMocks(this);
	}
	
	@Test(expected= ThirdPartyApiException.class)
	public void findBlacklistCustomersWhenException() {
		BlacklistRequest blacklistRequest = new BlacklistRequest();
		blacklistRequest.setFirstName("first name");
		blacklistRequest.setLastName("last name");
		blacklistRequest.setCustomerId("9876543210");
		blacklistRequest.setPoiType("AADHAAR");
		blacklistRequest.setPoiNumber("987654321012");
		blacklistRequest.setPermPostalCode("497111");
		String posidexUrl = "http://localhost";
		int posidexProfileId = 0;
		String contentId = null;
		
		CustomerResponse customerResponse = new CustomerResponse();
		customerResponse.setCutomermatchcount("0");
		WebServiceOperations spy = Mockito.spy(WebServiceOperations.class);
		/*JAXBElement jaxbElement = mock(JAXBElement.class);
		Mockito.when(jaxbElement.getValue()).thenReturn(customerResponse);
		BlackListClient spy = Mockito.spy(blackListClient);
		doReturn(jaxbElement).when(spy).findBlacklistCustomers(Mockito.any(), Mockito.anyString(), Mockito.any(), Mockito.any());*/
		JAXBElement<CustomerResponse> jaxbResponse = mockWithValue(JAXBElement.class, customerResponse);
		//doReturn(spy).when(blackListClientSpy).getWebServiceTemplate();
		doReturn(jaxbResponse).when(spy).marshalSendAndReceive(Mockito.any(), (JAXBElement<?>)Mockito.any());
		blackListClient.findBlacklistCustomers(blacklistRequest, posidexUrl, posidexProfileId, contentId);
	}
	
	private <T> JAXBElement<T> mockWithValue(Class<JAXBElement> jaxbElementClass, T value) {
	    JAXBElement<T> mock = mock(jaxbElementClass);
	    Mockito.when(mock.getValue()).thenReturn(value);
	    return mock;
	}

}
