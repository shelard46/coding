package com.airtelbank.validation.controller;

import static org.junit.Assert.assertEquals;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.test.context.junit4.SpringRunner;

import com.airtelbank.validation.service.IBlacklistDataUploadService;


@RunWith(SpringRunner.class)
@AutoConfigureMockMvc
public class BlackListDataUploadControllerTest {
	
	@Mock private IBlacklistDataUploadService dataUploadService;
	@InjectMocks private BlacklistedDataUploadController blacklistedDataUploadController;
	
	@Before
	public void init() {
		MockitoAnnotations.initMocks(this);
	}

	@Test
	public void testPositiveScenario() throws Exception {
		blacklistedDataUploadController.uploadBlacklistedData("src/test/resources/files/test_sample.csv");
		verify(dataUploadService, times(1)).upload(anyString());
	}

	@Test
	public void testNegativeScenario() throws Exception {
		BlacklistedDataUploadController blacklistedDataUploadController = new BlacklistedDataUploadController();
		String result = blacklistedDataUploadController.uploadBlacklistedData("/test.csv").getBody();
		assertEquals("Something went wrong", result);
	}
	
}

