package com.airtelbank.validation.dao.aerospike.impl;

import com.airtelbank.validation.dao.aerospike.model.PosidexCacheCustomerDetails;
import com.airtelbank.validation.exception.AeroSpikeException;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.context.MessageSource;
import org.springframework.data.aerospike.core.AerospikeTemplate;

import java.util.List;

import static org.junit.Assert.*;
@RunWith(MockitoJUnitRunner.class)
public class PosidexCacheCustomerDaoImplTest {

    @InjectMocks
    private PosidexCacheCustomerDaoImpl posidexCacheCustomerDao;

    @Mock
    private AerospikeTemplate aerospikeTemplate;

    @Mock
    private MessageSource messageSource;

    @Before
    public void setUp() throws Exception {
        MockitoAnnotations.initMocks(this);
    }

    @After
    public void tearDown() throws Exception {
    }

    @Test
    public void getPosidexDataAeroTest() {
        PosidexCacheCustomerDetails posidexCacheCustomerDetails = PosidexCacheCustomerDetails.builder().customerId("test").build();
        Mockito.when(aerospikeTemplate.findById(Mockito.any(),Mockito.any())).thenReturn(posidexCacheCustomerDetails);
        PosidexCacheCustomerDetails posidexCacheCustomerDetails1=posidexCacheCustomerDao.getPosidexDataAero("test");
        assertNotNull(posidexCacheCustomerDetails1);
    }

    @Test(expected = AeroSpikeException.class)
    public void getPosidexDataAeroAeroSpikeException() {

            PosidexCacheCustomerDetails posidexCacheCustomerDetails = PosidexCacheCustomerDetails.builder().customerId("test").build();
            Mockito.when(aerospikeTemplate.findById(Mockito.any(), Mockito.any())).thenThrow(new RuntimeException());
            PosidexCacheCustomerDetails posidexCacheCustomerDetails1 = posidexCacheCustomerDao.getPosidexDataAero("test");


    }

    @Test
    public void getPosidexDataFromAeroForPoiNumbersuccessTest() {
        List<PosidexCacheCustomerDetails> posidexCacheCustomerDetails=posidexCacheCustomerDao.getPosidexDataFromAeroForPoiNumber("test");
        assertNotNull(posidexCacheCustomerDetails);
    }

    @Test
    public void getPosidexDataFromAeroForPoiNumberFailTest() {
        Mockito.when(aerospikeTemplate.find(Mockito.any(),Mockito.any())).thenThrow(new RuntimeException());
        List<PosidexCacheCustomerDetails> posidexCacheCustomerDetails=posidexCacheCustomerDao.getPosidexDataFromAeroForPoiNumber("test");
        assertNull(posidexCacheCustomerDetails);
    }

}