package com.airtelbank.validation.controller;

import com.airtelbank.validation.model.NameMatchRequest;
import com.airtelbank.validation.model.NameMatchResponse;
import com.airtelbank.validation.model.ResponseDTO;
import com.airtelbank.validation.service.INameMatchService;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.MessageSource;
import org.springframework.http.ResponseEntity;

import static org.junit.Assert.*;

@RunWith(MockitoJUnitRunner.class)
public class NameMatchControllerTest {

    @InjectMocks
    private NameMatchController nameMatchController;
    @Mock
    private INameMatchService nameMatchService;

    @Mock
    private MessageSource messageSource;

    @Before
    public void setUp() throws Exception {
        MockitoAnnotations.initMocks(this);
    }

    @After
    public void tearDown() throws Exception {
    }

    @Test
    public void nameMatchTest() {
        NameMatchRequest nameMatchRequest=new NameMatchRequest();
        nameMatchRequest.setSource("test");
        nameMatchRequest.setTarget("test");
        ResponseEntity<ResponseDTO<NameMatchResponse>> responseDTOResponseEntity=nameMatchController.nameMatch(nameMatchRequest,"test","test");
        Assert.assertNotNull(responseDTOResponseEntity);


    }
}



