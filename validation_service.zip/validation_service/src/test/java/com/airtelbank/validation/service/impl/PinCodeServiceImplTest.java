package com.airtelbank.validation.service.impl;

import static org.mockito.Mockito.when;

import java.util.Optional;

import com.airtelbank.validation.model.ResponseDTO;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.MockitoJUnitRunner;


import com.airtelbank.validation.dao.aerospike.model.PinCode;
import com.airtelbank.validation.dao.aerospike.repository.PinCodeValidationRepository;
import com.airtelbank.validation.exception.AeroSpikeException;
import com.airtelbank.validation.exception.GenericException;
import org.springframework.context.MessageSource;


import static org.junit.Assert.*;

@RunWith(MockitoJUnitRunner.Silent.class)
public class PinCodeServiceImplTest {

	@Mock
	PinCodeValidationRepository pinCodeRepository;

	@InjectMocks
	PinCodeServiceImpl pinCodeServiceImpl;

	@Mock
	MessageSource messageSource;

	@Before
	public void setup() throws Exception {
		MockitoAnnotations.initMocks(this);
	}

	@Test(expected = GenericException.class)
	public void getPinCodeWhenException() {
		when(pinCodeRepository.findById(Mockito.anyString())).thenThrow(AeroSpikeException.class);
		pinCodeServiceImpl.validatePinCode("contentId", "userAgent", "000000");
	}

	@Test
	public void validatePinCodePositiveTest(){
		String contentId = "123";
		String userAgent = "Airtel";
		String pincode = "55532";
		Optional<PinCode> pinCode = Optional.of(new PinCode());
		pinCode.get().setCircle("NCR");
		pinCode.get().setCity("Delhi");
		pinCode.get().setState("New Delhi");
		when(pinCodeRepository.findById(Mockito.anyString())).thenReturn(pinCode);
		when(messageSource.getMessage(Mockito.any(),Mockito.any())).thenReturn("ABC");
		ResponseDTO<PinCode> responseDTO = pinCodeServiceImpl.validatePinCode(contentId,userAgent,pincode);
		assertEquals(0,responseDTO.getMeta().getStatus());
	}

	@Test
	public void validatePinCodeNegativeTest() {
		String contentId = "123";
		String userAgent = "Airtel";
		String pincode = "55532";
		when(pinCodeRepository.findById(Mockito.anyString())).thenReturn(Optional.ofNullable(null));
		when(messageSource.getMessage(Mockito.any(), Mockito.any())).thenReturn("ABC");
		ResponseDTO<PinCode> responseDTO = pinCodeServiceImpl.validatePinCode(contentId, userAgent, pincode);
		assertEquals(1, responseDTO.getMeta().getStatus());
	}
}
