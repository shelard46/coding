package com.airtelbank.validation.util;

import com.airtelbank.validation.constants.Constants;
import com.airtelbank.validation.dao.aerospike.model.AadhaarVerify;
import com.airtelbank.validation.dao.aerospike.model.Identities;
import com.airtelbank.validation.exception.*;
import com.airtelbank.validation.model.*;
import com.airtelbank.validation.model.aadhar.generate.otp.GenerateAadhaarOTPData;
import com.airtelbank.validation.model.aadhar.generate.otp.GenerateAadharOTPDataResponse;
import com.airtelbank.validation.model.aadhar.validate.otp.ValidateAadharOTPData;
import com.airtelbank.validation.model.aadhar.validate.otp.ValidateAadharOTPDataResponse;
import com.airtelbank.validation.model.cbs.DedupeRequestForCBS;
import org.junit.Assert;
import org.apache.log4j.Level;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import static org.junit.Assert.*;
import static org.mockito.Mockito.when;

import com.airtelbank.validation.dao.jpa.model.DocumentAuditLog;
import org.springframework.test.util.ReflectionTestUtils;

import java.util.Date;

public class ValidationUtilTest {

	@InjectMocks
	ValidationUtil util;

	@Before
	public void init() {
		MockitoAnnotations.initMocks(this);
		ReflectionTestUtils.setField(util, "uidaiLob", "ENC(Dy3sS2zMHaAp9MpK8R4CdyI5r+mAFwl4)");
		ReflectionTestUtils.setField(util, "uidaiConsumerName", "ENC(5eQDf7hRPW6+vsCCRs8iEZZZfTGlYy3w)");
		ReflectionTestUtils.setField(util, "uidaiProgrameName", "Aadhaar OTP KYC");
		ReflectionTestUtils.setField(util, "uidaiSubAua", "public");
		ReflectionTestUtils.setField(util, "uidaiTerminalId", "ENC(rQrdTG/KnsyUepIkqr2GvA==)");
	}
	
	@Test(expected = Test.None.class)
	public void createDocumentAuditLogForRequest() {
		Document document = Document.builder().userIdentifierType("MOBILE").build();
		DocumentAuditLog documentAuditLog = new DocumentAuditLog();
		util.createDocumentAuditLogForRequest(document, documentAuditLog);
	}
	
	/*@Test
	public void test() {
		String key = "MFwwDQYJKoZIhvcNAQEBBQADSwAwSAJBAJlCGtRv12B7BRvS42CMg581EJ8/j+0ezayahBGw8ces0k234e/UYvb5R+PjjwvtEUe1eDwl8gmdelOl6Z";
		String keySIT = "MFwwDQYJKoZIhvcNAQEBBQADSwAwSAJBAJlCGtRv12B7BRvS42CMg581EJ8/j+0ezayahBGw8ces0k234e/UYvb5R+PjjwvtEUe1eDwl8gmdelOl6Zx0z/kCAwEAAQ==";
		String unEncResponse = "success";
		String encResponse = CommonUtil.encryptLogs(unEncResponse, key);
		String genRequest = "m8VPZOEyfLixriIa8BOpr+s3M1fiFWvq1a/Dx7EhNs7s7UOEiFE8AP8XQRK8h5AxOS2PO5NYOv+m\n" + 
				"im8BeeSG+1GGaMYPnE7BRUowOGJ029Q=";
		String request = "aMEzhgfYiuyFcXV3oz9ipxMl0ws8LkkfANhO4edHQ3UI4OiMH3aiyd2kNhEoY9zhOboPcE43IqkGs5T+rYNP4h3QfesjcEGjm2OrO9KitzpRlU9Ir7HbKgh34UhEr+od0muwRI8jueqO3qAnLYxB4be0/SBmyJmSvsXpjW3mUXx1/j3bQT7ldb2TXGoJ7xdFPJhKno7ySiAXXRrHAw56zX/arFEbGX2fC4pOp03mOxIlX8Puu/Vbb/MwZhvDCFtNtqOJhOGSLF+xvFD4LQq17zjnXVLECAYWtdpP85yYKH3eIVTZvDLRIRi9HtJUEzb0zLefDhi4ufu4/fIlWWXfUMLiVJSZwIkT+0d5u3SByftDCVuCFsDkcL7hKKOL2bDB2auQobTuPC4r1/drZg95byqET5Py02gJ+b0FZhU/h5L+my1PduG3PcoKi5hxltqtr8rk/pZ7NONlXbZwUjNbwGD1DWd9isnxnarNYHAxCXcmRUrCMnt0KvvuNHt2yJjSaAYPRkfv5Ow3xw2b90AcyR3wNEQdMkyPZYLZvqqxjuW6v8yJ1J/jJGn6pEGa1fTW9dhpd/mZmm1K4piBfKyaNITCMMGdobReT4bHvuttn1S5KoOroQ1UHocx/WxKKD+d0JXDMgDuLQ0sAmS+4hHSC2BHMozR4tVg+0ZuVLxODcF36Yx/fS5BeWe0VlMz6aGQZrRLEZIzlR6USILgwq9iZN8GLsoxRoy0SPjxwuBVJp21W7GNrtm9WRtAmFrMkWun8P8LKXCzvLWlDGl87mPz2R4MFPO4P+vyUsBVgRESqqPI/9jNYUlrfBAyHySfEP0dZCiYSXhnjF9FN04UKpZMZ4X1G5YqBe5Ixhgz9mworBDW+8o6Fm9GaY/2CLHw4RvAgv5rS3ZjBQLzG8XKgKM84INYRziEgj/f6bUX0BILeZOHzrAPPuTM56qlfCW3UKD1OcFjjulCbEfh75X5bfnonto2x+VBrjTaYfsdrUAlud7LIh/6yZ46l3DQNs+5u3QvkK6M/Jc5jO5CkFWdtIaS6TSXKzkHWbmV54b/6OlMrp9bchEfPqEuFdXUOmeUjJl4kZh7CimAcviwHfs3a+ct40uHE/1mJZ+0IUw1XtN37ibp9lIW7sWK4Zj1z3/pYEFXsEkfN6E6cevxcBTZ+7UyYEuHE/1mJZ+0IUw1XtN37iZ+pWjiTp+BC/0VEDe3LQuO";
		String response = "QGdMOj5fET4KAOnUVwpgclAxDrbwmjV5IlJTKP/CobXsuLHMWIymDgCoUEXUlo7U8YPIQXt/fDX9kH2QmzNFKRt8tL41V9b5BX2pZvVyXum53FORAyLsncPnkxgZbtdav/YnOqn588ahHPjdLWPEt5vCLUzYpsH3LeTyhaZbwledbt0JfvPehgRwzrSJWNNGhFNNtyWczGFWEb5tOrJwTPxtBT0bn0XsZpKN3ZeozKS5weHqCJrKJWBr7DtGlwMiw1SMRxKBVEIPfTG1vBj/zDPlsFotPcrgKOruxqlvKkM+MQM7oGriscMWjKCbBRsBUXDCH8atsL54Kfg1w/zi3a7rK4XXM1x58nTeTbdNroUYqFerjx4kiWCASDRwuSoCmLIhXY23Rn3Sv7SI2HfSqc0SKm2zh3MuXcHTiQIMtxp1ay3PBqj6RRs3RkiJHPICsXjzZTcnJsw0ayCIun1aVHucJPDSuhPmrLSW3SPi5OHqZOGstOcvmSB/yF6ObIDitEr5QO9dD3LFMA/9iZyemZ8kRbgfrFqTWAIuYqi/Ctku849kE6iEE6bCWqcIeaEH";
		System.out.println(CommonUtil.decryptLogs(genRequest, keySIT));
	}*/

	@Test(expected = Test.None.class)
	public void createAadhaarOTPRequestTest() {
		Document document = Document.builder().userIdentifierType("MOBILE").build();
		DocumentAuditLog documentAuditLog = new DocumentAuditLog();
		document.setDocNumber("123");
		String documentNbr = "123";
		GenerateAadhaarOTPData resultRequest = util.createAadhaarOTPRequest(document, documentNbr);
		assertEquals(documentNbr,resultRequest.getDataArea().getAadhaarInfo().getUserIdentifier());
	}

	@Test(expected = ObjectConversionException.class)
	public void createAadhaarOTPRequestTestWithException() {
		String documentNbr = "123";
		util.createAadhaarOTPRequest(null, documentNbr);
	}

	@Test(expected = ObjectConversionException.class)
	public void createAadhaarOTPRequestTestWithExceptionII() {
		Document document = Document.builder().build();
		DocumentAuditLog documentAuditLog = new DocumentAuditLog();
		document.setDocNumber("123");
		String documentNbr = "123";
		GenerateAadhaarOTPData resultRequest = util.createAadhaarOTPRequest(document, documentNbr);
		//assertEquals(documentNbr,resultRequest.getDataArea().getAadhaarInfo().getUserIdentifier());
	}

	@Test
	public void validateGenerateAadhaarOTPResponse() throws Exception {
		Document document = util.validateGenerateAadhaarOTPResponse(getStubGenerateAadharOTPDataResponse(Constants.GENERATE_AADHAAR_OTP_SUCCESS_STATUS_CODE, "test@gmail.com", "1234567890"));
		assertEquals("test@gmail.com", document.getMaskedEmailId());
		assertEquals("1234567890", document.getMaskedMobileNumber());
	}

	@Test
	public void validateGenerateAadhaarOTPResponseWithEmailAndMobileNull() throws Exception {
		Document document = util.validateGenerateAadhaarOTPResponse(getStubGenerateAadharOTPDataResponse(Constants.GENERATE_AADHAAR_OTP_SUCCESS_STATUS_CODE, null, null));
		assertEquals(null, document.getMaskedEmailId());
		assertEquals(null, document.getMaskedMobileNumber());
	}


	@Test(expected = ObjectConversionException.class)
	public void validateGenerateAadhaarOTPResponseWithDataAreaNull() throws Exception {
		util.validateGenerateAadhaarOTPResponse(GenerateAadharOTPDataResponse.builder().build());
	}

	@Test(expected = ObjectConversionException.class)
	public void validateGenerateAadhaarOTPResponseWithDataAreaGenerateAadhaarOTPResponseNull() throws Exception {
		util.validateGenerateAadhaarOTPResponse(GenerateAadharOTPDataResponse.builder().dataArea(DataArea.builder().build()).build());
	}

	@Test(expected = ObjectConversionException.class)
	public void validateGenerateAadhaarOTPResponseWithDataAreaGenerateAadhaarOTPRNull() throws Exception {
		util.validateGenerateAadhaarOTPResponse(GenerateAadharOTPDataResponse.builder().dataArea(DataArea.builder().generateAadhaarOTPResponse(GenerateAadhaarOTPResponse.builder().build()).build()).build());
	}

	@Test(expected = ObjectConversionException.class)
	public void validateGenerateAadhaarOTPResponseWithException() throws Exception {
		util.validateGenerateAadhaarOTPResponse(null);
	}

	@Test(expected = UIDAIException.class)
	public void validateGenerateAadhaarOTPResponseWithUIDAIException() throws Exception {
		Document document = util.validateGenerateAadhaarOTPResponse(getStubGenerateAadharOTPDataResponse("", "test@gmail.com", "1234567890"));
	}

	@Test
	public void createDocumentAuditLogForRequestWithSuccess() {
		DocumentAuditLog documentAuditLog = util.createDocumentAuditLogForRequest(Document.builder().channel("test").userIdentifierType("test").build(), DocumentAuditLog.builder().build());
		assertEquals("test", documentAuditLog.getChannel());
	}

	@Test(expected = ObjectConversionException.class)
	public void createDocumentAuditLogForRequestWithException(){
		DocumentAuditLog documentAuditLog = util.createDocumentAuditLogForRequest(null, DocumentAuditLog.builder().build());
		assertEquals("test", documentAuditLog.getTransactionId());
	}

	@Test
	public void updateDocumentAuditLogSuccess(){
		DocumentAuditLog documentAuditLog = util.updateDocumentAuditLog(getStubGenerateAadharOTPDataResponse("", "test@gmail.com", "1234567890"), DocumentAuditLog.builder().build());
		assertNotNull(documentAuditLog.getResponseTimestamp());
	}

	@Test
	public void updateDocumentAuditLogSuccessAsStatusNull(){
		DocumentAuditLog documentAuditLog = util.updateDocumentAuditLog(getStubGenerateAadharOTPDataResponse(null, "test@gmail.com", "1234567890"), DocumentAuditLog.builder().build());
		assertNotNull(documentAuditLog.getResponseTimestamp());
	}

	@Test(expected = ObjectConversionException.class)
	public void updateDocumentAuditLogWithException(){
		util.updateDocumentAuditLog(null, DocumentAuditLog.builder().build());
	}

	@Test
	public void createIdentityRequestSuccess() {
		Identities identities = util.createIdentityRequest("test", "test", 1, com.airtelbank.validation.model.Document.builder().userIdentifierType(Constants.AADHAAR_IDENTIFIER).docNumber("123456789012").mobile("1234567890").build());
		assertEquals("test", identities.getId());
	}

	@Test
	public void createIdentityRequestValidSuccess() {
		Identities identities = util.createIdentityRequest("test", "test", 1, com.airtelbank.validation.model.Document.builder().userIdentifierType(Constants.AADHAAR_IDENTIFIER).docReferenceNumber("123456789012").channel("test").docType("AADHAAR").source("test").build());
		assertEquals("test", identities.getId());
	}

	@Test
	public void createIdentityRequestSuccessOne() {
		Identities identities = util.createIdentityRequest("test", "test", 1, com.airtelbank.validation.model.Document.builder().userIdentifierType(Constants.AADHAAR_IDENTIFIER).docNumber("1234567890121234").mobile("1234567890").build());
		assertEquals("test", identities.getId());
	}

	@Test(expected = ObjectConversionException.class)
	public void createIdentityRequestWithException() {
		util.createIdentityRequest("test", "test", 1, com.airtelbank.validation.model.Document.builder().docNumber("test").mobile("1234567890").build());
	}

	@Test
	public void updateVerifyDocumentAuditLogSuccess(){
		ValidateAadharOTPDataResponse validateAadharOTPDataResponse = ValidateAadharOTPDataResponse.builder().dataArea(DataArea.builder().aadharProfileResponse(UserAadharProfileResponse.builder().responseCode("test").userIdentifierType("test").uidToken("test").status(Status.builder().statusCode("test").statusDescription("test").build()).responseTimeStamp("2021-04-10'T'11:11:11").build()).build()).build();
		DocumentAuditLog documentAuditLog = util.updateVerifyDocumentAuditLog(validateAadharOTPDataResponse, DocumentAuditLog.builder().build(), true);
		assertNotNull(documentAuditLog);
	}

	@Test
	public void updateVerifyDocumentAuditLogFlagSuccess(){
		DocumentAuditLog documentAuditLog = util.updateVerifyDocumentAuditLog(getStubValidateAadharOTPDataResponse(), DocumentAuditLog.builder().build(), false);
		assertNotNull(documentAuditLog);
	}

	@Test
	public void getAadhaarProfileStatusSuccess() throws Exception {
		boolean flag = util.getAadhaarProfileStatus(getStubValidateAadharOTPDataResponse(), "0001");
		assertEquals(true, flag);
	}

	@Test(expected = UIDAIAadhaarVerifyException.class)
	public void getAadhaarProfileStatusException() throws Exception {
		util.getAadhaarProfileStatus(ValidateAadharOTPDataResponse.builder().dataArea(DataArea.builder().aadharProfileResponse(UserAadharProfileResponse.builder().residentIdentity(null).responseCode("test").userIdentifierType("test").uidToken("test").status(Status.builder().statusCode("test-0002-001").statusDescription("test").build()).responseTimeStamp("2021-04-10'T'11:11:11").build()).build()).build(), "123");
	}

	@Test
	public void getAadhaarProfileRequestSuccess() {
		ValidateAadharOTPData validateAadharOTPData = util.getAadhaarProfileRequest(Identities.builder().id("test").userIdentifierType("test").build(), "test", "test", "test", "test", "test", "test");
		assertNotNull(validateAadharOTPData);
	}

	@Test
	public void getAadhaarProfileResponseSuccess() throws UIDAIAadhaarVerifyException {
		AadhaarVerify aadharVerifyResponse = util.getAadhaarProfileResponse(getStubValidateAadharOTPDataResponse());
		assertNotNull(aadharVerifyResponse);
	}

	@Test
	public void getAadhaarProfileResponseSuccessWithValidIdentifier() throws UIDAIAadhaarVerifyException {
		AadhaarVerify aadharVerifyResponse = util.getAadhaarProfileResponse(ValidateAadharOTPDataResponse.builder().dataArea(DataArea.builder().aadharProfileResponse(UserAadharProfileResponse.builder().responseCode("test").userIdentifierType("V").uidToken("test").status(Status.builder().statusCode("test-0001").statusDescription("test").build()).responseTimeStamp("2021-04-10'T'11:11:11").build()).build()).build());
		assertNotNull(aadharVerifyResponse);
	}

	@Test(expected = AadharVerificationException.class)
	public void getAadhaarProfileResponseException() throws UIDAIAadhaarVerifyException {
		AadhaarVerify aadharVerifyResponse = util.getAadhaarProfileResponse(null);
	}

	@Test(expected = AadharVerificationException.class)
	public void getAadhaarProfileResponseExceptionWithInvalidData() throws UIDAIAadhaarVerifyException {
		util.getAadhaarProfileResponse(ValidateAadharOTPDataResponse.builder().build());
	}

	@Test(expected = AadharVerificationException.class)
	public void getAadhaarProfileResponseExceptionWithDataareaNull() throws UIDAIAadhaarVerifyException {
		util.getAadhaarProfileResponse(ValidateAadharOTPDataResponse.builder().dataArea(null).build());
	}

	@Test(expected = AadharVerificationException.class)
	public void getAadhaarProfileResponseExceptionWithDataArea() throws UIDAIAadhaarVerifyException {
		util.getAadhaarProfileResponse(ValidateAadharOTPDataResponse.builder().dataArea(DataArea.builder().build()).build());
	}

	@Test(expected = AadharVerificationException.class)
	public void getAadhaarProfileResponseExceptionWithAadharProfileResponseNull() throws UIDAIAadhaarVerifyException {
		util.getAadhaarProfileResponse(ValidateAadharOTPDataResponse.builder().dataArea(DataArea.builder().aadharProfileResponse(UserAadharProfileResponse.builder().build()).build()).build());
	}

	@Test(expected = AadharVerificationException.class)
	public void getAadhaarProfileResponseExceptionWithAadharProfileResponseStatusNull() throws UIDAIAadhaarVerifyException {
		util.getAadhaarProfileResponse(ValidateAadharOTPDataResponse.builder().dataArea(DataArea.builder().aadharProfileResponse(UserAadharProfileResponse.builder().status(Status.builder().build()).build()).build()).build());
	}

	@Test(expected = UIDAIAadhaarVerifyException.class)
	public void getAadhaarProfileResponseExceptionTwo() throws UIDAIAadhaarVerifyException {
		util.getAadhaarProfileResponse(ValidateAadharOTPDataResponse.builder().dataArea(DataArea.builder().aadharProfileResponse(UserAadharProfileResponse.builder().responseCode("test").userIdentifierType("V").uidToken("test").status(Status.builder().statusCode("").statusDescription("test").build()).responseTimeStamp("2021-04-10'T'11:11:11").build()).build()).build());
	}

	@Test(expected = UIDAIAadhaarVerifyException.class)
	public void getAadhaarProfileResponseExceptionThree() throws UIDAIAadhaarVerifyException {
		util.getAadhaarProfileResponse(ValidateAadharOTPDataResponse.builder().dataArea(DataArea.builder().aadharProfileResponse(UserAadharProfileResponse.builder().responseCode("test").userIdentifierType("V").uidToken("test").status(Status.builder().statusCode("test-test").statusDescription("test").build()).responseTimeStamp("2021-04-10'T'11:11:11").build()).build()).build());
	}

	@Test
	public void getRequestForCBSDedupeSuccess(){
		DedupeRequestForCBS dedupeRequestForCBS = util.getRequestForCBSDedupe(new CBSDedupeRequest(), null);
		assertNotNull(dedupeRequestForCBS);
	}

	@Test
	public void getAadhaarProfileStatusForKUASuccess() throws Exception {
		boolean flag = util.getAadhaarProfileStatusForKUA(getStubValidateAadharOTPDataResponse(), "");
		assertEquals(true, flag);
	}

	@Test(expected = AadhaarKUAVerifyException.class)
	public void getAadhaarProfileStatusForKUAException() throws Exception {
		util.getAadhaarProfileStatusForKUA(ValidateAadharOTPDataResponse.builder().dataArea(DataArea.builder().aadharProfileResponse(UserAadharProfileResponse.builder().residentIdentity(null).responseCode("test").userIdentifierType("test").uidToken("test").status(Status.builder().statusCode("test-0002-001").statusDescription("test").build()).responseTimeStamp("2021-04-10'T'11:11:11").build()).build()).build(), "");
	}

	@Test
	public void createDocumentAuditLogForRequestForKUASuccess(){
		DocumentAuditLog documentAuditLog = util.createDocumentAuditLogForRequestForKUA(KUARequest.builder().userIdentifierType("t").build(), DocumentAuditLog.builder().build());
		assertNotNull(documentAuditLog);
	}

	@Test(expected = ObjectConversionException.class)
	public void createDocumentAuditLogForRequestForKUAException(){
		util.createDocumentAuditLogForRequestForKUA(null, DocumentAuditLog.builder().build());
	}

	@Test
	public void updateVerifyDocumentAuditLogForKUASuccess(){
		DocumentAuditLog documentAuditLog = util.updateVerifyDocumentAuditLogForKUA(getStubValidateAadharOTPDataResponse(), DocumentAuditLog.builder().build(), true);
		assertNotNull(documentAuditLog);
	}

	@Test
	public void updateVerifyDocumentAuditLogForKUASuccessOne(){
		DocumentAuditLog documentAuditLog = util.updateVerifyDocumentAuditLogForKUA(getStubValidateAadharOTPDataResponse(), DocumentAuditLog.builder().build(), false);
		assertNotNull(documentAuditLog);
	}

	@Test(expected = ObjectConversionException.class)
	public void updateVerifyDocumentAuditLogForKUAException(){
		util.updateVerifyDocumentAuditLogForKUA(null, DocumentAuditLog.builder().build(), false);
	}

	private GenerateAadharOTPDataResponse getStubGenerateAadharOTPDataResponse(String statusCode, String email, String mobile) {
		GenerateAadhaarOTPData generateAadhaarOTPData = new GenerateAadhaarOTPData();
		Status status = Status.builder().statusCode(statusCode).build();
		GenerateAadhaarOTPResponse generateAadhaarOTPResponse = GenerateAadhaarOTPResponse.builder()
				.status(status)
				.email(email)
				.mobileNumber(mobile)
				.userIdentifierType(Constants.AADHAAR_IDENTIFIER)
				.responseTimeStamp(new Date())
				.build();
		DataArea dataArea = DataArea.builder().generateAadhaarOTPResponse(generateAadhaarOTPResponse).build();
		EbmHeader ebmHeader = new EbmHeader();
		ebmHeader.setConsumerTransactionId("test");
		return GenerateAadharOTPDataResponse.builder()
				.dataArea(dataArea)
				.ebmHeader(ebmHeader)

				.build();
	}

	private ValidateAadharOTPDataResponse getStubValidateAadharOTPDataResponse() {
		ResidentIdentity residentIdentity = new ResidentIdentity();
		residentIdentity.setName("test test");
		EbmHeader ebmHeader = new EbmHeader();
		ebmHeader.setConsumerTransactionId("test");
		return ValidateAadharOTPDataResponse.builder().ebmHeader(ebmHeader).dataArea(DataArea.builder().aadharProfileResponse(UserAadharProfileResponse.builder().residentIdentity(residentIdentity).responseCode("test").userIdentifierType("test").uidToken("test").status(Status.builder().statusCode("test-0001-001").statusDescription("test").build()).responseTimeStamp("2021-04-10'T'11:11:11").build()).build()).build();
	}
}
