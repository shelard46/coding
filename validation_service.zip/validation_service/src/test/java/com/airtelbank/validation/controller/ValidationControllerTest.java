package com.airtelbank.validation.controller;

import com.airtelbank.validation.constants.Constants;
import com.airtelbank.validation.dao.aerospike.model.AadhaarVerify;
import com.airtelbank.validation.dao.aerospike.model.ErrorCodeMapper;
import com.airtelbank.validation.dao.aerospike.model.PinCode;
import com.airtelbank.validation.exception.ClientSideException;
import com.airtelbank.validation.exception.GenericException;
import com.airtelbank.validation.model.*;
import com.airtelbank.validation.service.AadhaarService;
import com.airtelbank.validation.service.ErrorCodeMapperService;
import com.airtelbank.validation.service.PinCodeService;
import com.airtelbank.validation.util.CommonUtil;
import com.airtelbank.validation.util.LogMasker;
import com.airtelbank.validation.util.ValidationUtils;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.logging.log4j.core.config.Configurator;
import org.junit.*;
import org.junit.runner.RunWith;
import org.mockito.*;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.context.MessageSource;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.validation.BindingResult;

import java.util.Locale;

import static org.junit.Assert.assertNotNull;
//import static org.mockito.Mockito.mockStatic;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@RunWith(MockitoJUnitRunner.class)
public class ValidationControllerTest {

	@Mock private PinCodeService pinCodeService;
	@Mock private ValidationUtils<Document> validationUtils;
	@Mock private MessageSource messageSource;
	@Mock private AadhaarService aadhaarService;
	@Mock private ErrorCodeMapperService errorCodeService;
	@Mock private LogMasker logMasker;
	@Mock private BindingResult bindingResult;

	@InjectMocks private ValidationController validationController;

	private MockMvc mockMvc;


	//private static MockedStatic<CommonUtil> mockedSettings;

	@BeforeClass
	public static void init() {

		//mockedSettings = mockStatic(CommonUtil.class);
	}

	@AfterClass
	public static void close() {
		//mockedSettings.close();

	}

	@Before
	public void setup() {
		MockitoAnnotations.initMocks(this);
		mockMvc = MockMvcBuilders.standaloneSetup(validationController).build();
		ReflectionTestUtils.setField(validationController, "key", "key");
		ReflectionTestUtils.setField(validationController, "enableDeleteApi", true);
		when(messageSource.getMessage("vault.success.code", null, Locale.ENGLISH)).thenReturn("code");
		when(messageSource.getMessage("vault.success.msg", null, Locale.ENGLISH)).thenReturn("msg");
		when(messageSource.getMessage("config.kua.success.code", null, Locale.ENGLISH)).thenReturn("2400");
		when(messageSource.getMessage("config.aua.success.code", null, Locale.ENGLISH)).thenReturn("2100");

		Configurator.setAllLevels("", org.apache.logging.log4j.Level.ALL);
	}

	@Test
	public void validatePinCodeExitsTest() throws Exception {
		ResponseDTO<PinCode> response = new ResponseDTO<>();
		response.setMeta(Meta.builder().status(Constants.SUCCESS_STATUS).build());
		String contentId = "content"; String userAgent = "agent"; String pinCode = "110062";
		Mockito.when(pinCodeService.validatePinCode(Mockito.eq(contentId), Mockito.eq(userAgent) ,Mockito.eq(pinCode))).thenReturn(response);
		LoggerModel.LoggerError loggerError=new LoggerModel.LoggerError();
		loggerError.setErrorCode("test");
		loggerError.setStatus("test");
		loggerError.setErrorDescription("test");
		/*mockedSettings.when(() -> CommonUtil.setLoggerError(Mockito.any()))
				.thenReturn(loggerError);*/
		mockMvc.perform(MockMvcRequestBuilders
						.get("/api/v1/validate/" + pinCode)
						.header("contentId", contentId)
						.header("User-Agent", userAgent)
						.contentType(MediaType.APPLICATION_JSON)
						.accept(MediaType.APPLICATION_JSON))
				.andDo(print())
				.andExpect(status().isOk());

	}

	@Test
	public void validatePinCodeNotExitsTest() throws Exception {
		ResponseDTO<PinCode> response = new ResponseDTO<>();
		response.setMeta(Meta.builder().status(Constants.FAILURE_STATUS).build());
		String contentId = "content"; String userAgent = "agent"; String pinCode = "pinCode";
		Mockito.when(pinCodeService.validatePinCode(Mockito.eq(contentId), Mockito.eq(userAgent) ,Mockito.eq(pinCode))).thenReturn(response);
		LoggerModel.LoggerError loggerError=new LoggerModel.LoggerError();
		loggerError.setErrorCode("test");
		loggerError.setStatus("test");
		loggerError.setErrorDescription("test");
		/*mockedSettings.when(() -> CommonUtil.setLoggerError(Mockito.any()))
				.thenReturn(loggerError);*/
		mockMvc.perform(MockMvcRequestBuilders
						.get("/api/v1/validate/"+pinCode)
						.header("contentId", contentId)
						.header("User-Agent", userAgent)
						.contentType(MediaType.APPLICATION_JSON)
						.accept(MediaType.APPLICATION_JSON))
				.andDo(print())
				.andExpect(status().isOk());

	}

	@Test
	public void loadPincodeDataTest() throws Exception {
		String contentId = "content"; String userAgent = "agent"; String channel = "TEST";
		mockMvc.perform(MockMvcRequestBuilders
						.get("/api/v1//loadPincodeDetailsSet")
						.header("contentId", contentId)
						.header("User-Agent", userAgent)
						.header("channel", channel)
						.contentType(MediaType.APPLICATION_JSON)
						.accept(MediaType.APPLICATION_JSON))
				.andDo(print())
				.andExpect(status().isOk());

	}

	@Test(expected = Exception.class)
	public void validateDocumentTest() throws Exception {
		Document request = Document.builder().docType("type").action("action").build();
		String contentId = "content"; String userAgent = "agent"; String channel = "TEST";
		mockMvc.perform(MockMvcRequestBuilders
						.post("/api/v1/validateDocument")
						.header("contentId", contentId)
						.header("User-Agent", userAgent)
						.header("channel", channel)
						.contentType(MediaType.APPLICATION_JSON)
						.content(new ObjectMapper().writeValueAsString(request))
						.accept(MediaType.APPLICATION_JSON))
				.andDo(print());
	}

	@Test
	public void getAadhaarReferenceTest() throws Exception {
		AadhaarVaultRequest request = AadhaarVaultRequest.builder().build();
		String contentId = "content"; String userAgent = "agent"; String channel = "TEST";
		LoggerModel.LoggerError loggerError=new LoggerModel.LoggerError();
		loggerError.setErrorCode("test");
		loggerError.setStatus("test");
		loggerError.setErrorDescription("test");
		/*mockedSettings.when(() -> CommonUtil.setLoggerError(Mockito.any()))
				.thenReturn(loggerError);*/
		mockMvc.perform(MockMvcRequestBuilders
						.post("/api/v1/getAadhaarReference")
						.header("contentId", contentId)
						.header("User-Agent", userAgent)
						.header("channel", channel)
						.contentType(MediaType.APPLICATION_JSON)
						.content(new ObjectMapper().writeValueAsString(request))
						.accept(MediaType.APPLICATION_JSON))
				.andDo(print())
				.andExpect(status().isOk());;
	}

	@Test
	public void getAadhaarNumberTest() throws Exception {
		AadhaarVaultRequest request = AadhaarVaultRequest.builder().build();
		String contentId = "content"; String userAgent = "agent"; String channel = "TEST";
		LoggerModel.LoggerError loggerError=new LoggerModel.LoggerError();
		loggerError.setErrorCode("test");
		loggerError.setStatus("test");
		loggerError.setErrorDescription("test");
		/*mockedSettings.when(() -> CommonUtil.setLoggerError(Mockito.any()))
				.thenReturn(loggerError);*/
		mockMvc.perform(MockMvcRequestBuilders
						.post("/api/v1/getAadhaarNumber")
						.header("contentId", contentId)
						.header("User-Agent", userAgent)
						.header("channel", channel)
						.contentType(MediaType.APPLICATION_JSON)
						.content(new ObjectMapper().writeValueAsString(request))
						.accept(MediaType.APPLICATION_JSON))
				.andDo(print())
				.andExpect(status().isOk());
	}

	@Test
	public void removeAadhaarTest() throws Exception {
		Mockito.when(aadhaarService.removeAadhaar(Mockito.any(AadhaarVaultRequest.class), Mockito.anyString(), Mockito.anyString())).thenReturn(ResponseDTO.builder().meta(Meta.builder().code("test").description("test").status(1).build()).build());
		String contentId = "content";
		String userAgent = "agent";
		String channel = "TEST";
		LoggerModel.LoggerError loggerError=new LoggerModel.LoggerError();
		loggerError.setErrorCode("test");
		loggerError.setStatus("test");
		loggerError.setErrorDescription("test");
		/*mockedSettings.when(() -> CommonUtil.setLoggerError(Mockito.any()))
				.thenReturn(loggerError);*/
		mockMvc.perform(MockMvcRequestBuilders
						.delete("/api/v1/deleteAadhaar")
						.header("contentId", contentId)
						.header("User-Agent", userAgent)
						.header("channel", channel)
						.header("appType", "test")
						.header("customerId", "1234567890")
						.contentType(MediaType.APPLICATION_JSON)
						.content(new ObjectMapper().writeValueAsString(AadhaarVaultRequest.builder().build()))
						.accept(MediaType.APPLICATION_JSON))
				.andDo(print())
				.andExpect(status().isOk());
	}

	@Test(expected = ClientSideException.class)
	public void testValidateDocumentException() throws Exception {

			Document document = new Document();
			document.setDocType("test");
			document.setAction("test");
			document.setDocNumber("test");
			ResponseEntity<?> response = validationController.validateDocument(document, "test", "test", "test", "test", bindingResult);



	}
	@Test(expected = ClientSideException.class)
	public void testValidateDocumentisAadhaarOrVidFalseException() throws Exception {

			Document document = new Document();
			document.setDocType("test");
			document.setAction("test");
			document.setDocNumber("test");

			/*mockedSettings.when(() -> CommonUtil.setOtpRequestType(Mockito.any()))
					.thenReturn(true);*/
			ResponseEntity<?> response = validationController.validateDocument(document, "test", "test", "test", "test", bindingResult);
			assertNotNull(response);


	}

	/*@Test
	public void testValidateDocumentdoctypePAN() throws Exception {

			Document document = new Document();
			document.setDocType("PAN");
			document.setAction("test");
			document.setDocNumber("test");

			mockedSettings.when(() -> CommonUtil.setOtpRequestType(Mockito.any())).thenReturn(true);
			ResponseEntity<?> response = validationController.validateDocument(document, "test", "test", "test", "test", bindingResult);
			assertNotNull(response);


	}*/
	@Test(expected = ClientSideException.class)
	public void testValidateDocumentdoctypeAADHAARException() throws Exception {

			Document document = new Document();
			document.setDocType("AADHAAR");
			document.setAction("test");
			document.setDocNumber("test");

			/*mockedSettings.when(() -> CommonUtil.setOtpRequestType(Mockito.any()))
					.thenReturn(true);*/
			ResponseEntity<?> response = validationController.validateDocument(document, "test", "test", "test", "test", bindingResult);



	}
	/*@Test
	public void testValidateDocumentACTIONGENERATE_AADHAAR_OTP() throws Exception {

			ResponseDTO<Document> documentResponseDTO=new ResponseDTO<>();
			Meta meta=new Meta();
			meta.setStatus(1);
			meta.setCode("test");
			meta.setDescription("test");
			Metrics metrics=new Metrics();
			metrics.setLimit(1);
			meta.setMetrics(metrics);
			documentResponseDTO.setMeta(meta);
			Document document = new Document();
			document.setDocType("AADHAAR");
			document.setAction("GENERATE_AADHAAR_OTP");
			document.setDocNumber("test");
			LoggerModel.LoggerError loggerError=new LoggerModel.LoggerError();
			loggerError.setErrorCode("test");
			loggerError.setStatus("test");
			loggerError.setErrorDescription("test");
			//mockedSettings.when(() -> CommonUtil.setLoggerError(Mockito.any())).thenReturn(loggerError);
			when(aadhaarService.generateAadhaarOTP(Mockito.any())).thenReturn(documentResponseDTO);
			//mockedSettings.when(() -> CommonUtil.setOtpRequestType(Mockito.any())).thenReturn(true);
			ResponseEntity<?> response = validationController.validateDocument(document, "test", "test", "test", "test", bindingResult);
			assertNotNull(response);


	}*/

	@Test(expected = Test.None.class)
	public void getAadhaarDetailsTest() {
		KUARequest kuaRequest=new KUARequest();
		kuaRequest.setChannel("test");
		ErrorCodeMapper errorCodeMapper1=new ErrorCodeMapper();
		errorCodeMapper1.setErrorCode("test");
		errorCodeMapper1.setErrorId("test");
		ResponseDTO<AadhaarVerify> aadhaarVerifyResponseDTO=new ResponseDTO<>();
		Meta meta=new Meta();
		meta.setCode("test");
		aadhaarVerifyResponseDTO.setMeta(meta);
		Mockito.when(aadhaarService.getAadhaarDetailsKUA(Mockito.any(),Mockito.any())).thenReturn(aadhaarVerifyResponseDTO);
		Mockito.when(errorCodeService.getErrorCodeByApiNameAndOrgErrorCode(Mockito.any(),Mockito.any())).thenReturn(errorCodeMapper1);
		LoggerModel.LoggerError loggerError=new LoggerModel.LoggerError();
		loggerError.setErrorCode("test");
		loggerError.setStatus("test");
		loggerError.setErrorDescription("test");
		/*mockedSettings.when(() -> CommonUtil.setLoggerError(Mockito.any()))
				.thenReturn(loggerError);*/
		ResponseEntity<ResponseDTO<AadhaarVerify>> responseDTOResponseEntity=validationController.getAadhaarDetails(kuaRequest,"test","test","test");

	}

	@Test(expected = Test.None.class)
	public void getAadhaarDetailserrorCodeMapperisnullTest() {
		KUARequest kuaRequest=new KUARequest();
		kuaRequest.setChannel("test");
		ErrorCodeMapper errorCodeMapper1=new ErrorCodeMapper();
		errorCodeMapper1.setErrorCode("2400");
		errorCodeMapper1.setErrorId("test");
		ResponseDTO<AadhaarVerify> aadhaarVerifyResponseDTO=new ResponseDTO<>();
		Meta meta=new Meta();
		meta.setCode("2400");
		aadhaarVerifyResponseDTO.setMeta(meta);
		Mockito.when(aadhaarService.getAadhaarDetailsKUA(Mockito.any(),Mockito.any())).thenReturn(aadhaarVerifyResponseDTO);
		Mockito.when(errorCodeService.getErrorCodeByApiNameAndOrgErrorCode(Mockito.any(),Mockito.any())).thenReturn(errorCodeMapper1);
		LoggerModel.LoggerError loggerError=new LoggerModel.LoggerError();
		loggerError.setErrorCode("test");
		loggerError.setStatus("test");
		loggerError.setErrorDescription("test");
		/*mockedSettings.when(() -> CommonUtil.setLoggerError(Mockito.any()))
				.thenReturn(loggerError);*/
		ResponseEntity<ResponseDTO<AadhaarVerify>> responseDTOResponseEntity=validationController.getAadhaarDetails(kuaRequest,"test","test","test");
		
	}

	@Test(expected = GenericException.class)
	public void getAadhaarDetailsGenericExceptionTest() {

			KUARequest kuaRequest = new KUARequest();
			kuaRequest.setChannel("test");
			ErrorCodeMapper errorCodeMapper1 = new ErrorCodeMapper();
			errorCodeMapper1.setErrorCode("2400");
			errorCodeMapper1.setErrorId("test");
			ResponseDTO<AadhaarVerify> aadhaarVerifyResponseDTO = new ResponseDTO<>();
			Meta meta = new Meta();
			meta.setCode("2400");
			aadhaarVerifyResponseDTO.setMeta(meta);
			Mockito.when(aadhaarService.getAadhaarDetailsKUA(Mockito.any(), Mockito.any())).thenReturn(aadhaarVerifyResponseDTO);
			Mockito.when(errorCodeService.getErrorCodeByApiNameAndOrgErrorCode(Mockito.any(), Mockito.any())).thenReturn(null);
			LoggerModel.LoggerError loggerError = new LoggerModel.LoggerError();
			loggerError.setErrorCode("test");
			loggerError.setStatus("test");
			loggerError.setErrorDescription("test");
			/*mockedSettings.when(() -> CommonUtil.setLoggerError(Mockito.any()))
					.thenReturn(loggerError);*/
			ResponseEntity<ResponseDTO<AadhaarVerify>> responseDTOResponseEntity = validationController.getAadhaarDetails(kuaRequest, "test", "test", "test");


	}


	@Test(expected = ClientSideException.class)
	public void testverifyDocumentClientSideException() throws Exception {

			Document document = new Document();
			document.setDocType("test");
			document.setAction("test");
			document.setDocNumber("test");
			ResponseEntity<?> response = validationController.verifyDocument(document, "test", "test", "test",  bindingResult);



	}
	@Test(expected = ClientSideException.class)
	public void testverifyDocumentExcecptionTest() throws Exception {

			Document document = new Document();
			document.setDocType("test");
			document.setAction("test");
			document.setDocNumber("test");

			/*mockedSettings.when(() -> CommonUtil.setOtpRequestType(Mockito.any()))
					.thenReturn(true);*/
			ResponseEntity<?> response = validationController.verifyDocument(document, "test", "test", "test", bindingResult);



	}

	@Test(expected = Test.None.class)
	public void testverifyDocumentsuccessTest() throws Exception {

			Document document = new Document();
			document.setDocType("PAN");
			document.setAction("test");
			document.setDocNumber("test");

			/*mockedSettings.when(() -> CommonUtil.setOtpRequestType(Mockito.any()))
					.thenReturn(true);*/
			ResponseEntity<?> response = validationController.verifyDocument(document, "test", "test", "test", bindingResult);
		


	}
	@Test(expected = ClientSideException.class)
	public void testverifyDocumentAADHAARTest() throws Exception {

			Document document = new Document();
			document.setDocType("AADHAAR");
			document.setAction("test");
			document.setDocNumber("test");

			/*mockedSettings.when(() -> CommonUtil.setOtpRequestType(Mockito.any()))
					.thenReturn(true);*/
			ResponseEntity<?> response = validationController.verifyDocument(document, "test", "test", "test",  bindingResult);

	}
	@Test(expected = Test.None.class)
	public void testverifyDocumentVERIFY_AADHAAR_OTPTest() throws Exception {

			ResponseDTO<AadhaarVerify> documentResponseDTO=new ResponseDTO<>();
			Meta meta=new Meta();
			meta.setStatus(1);
			meta.setCode("test");
			meta.setDescription("test");
			Metrics metrics=new Metrics();
			metrics.setLimit(1);
			meta.setMetrics(metrics);
			documentResponseDTO.setMeta(meta);
			Document document = new Document();
			document.setDocType("AADHAAR");
			document.setAction("VERIFY_AADHAAR_OTP");
			document.setDocNumber("test");
			LoggerModel.LoggerError loggerError=new LoggerModel.LoggerError();
			loggerError.setErrorCode("test");
			loggerError.setStatus("test");
			loggerError.setErrorDescription("test");
			/*mockedSettings.when(() -> CommonUtil.setLoggerError(Mockito.any()))
					.thenReturn(loggerError);*/
			when(aadhaarService.verifyAadhaarIdentity(Mockito.any())).thenReturn(documentResponseDTO);
			/*mockedSettings.when(() -> CommonUtil.setOtpRequestType(Mockito.any()))
					.thenReturn(true);*/
			ResponseEntity<?> response = validationController.verifyDocument(document, "test", "test", "test", bindingResult);
			


	}


	@Test(expected = Test.None.class)
	public void validateAUAFailTest() {
		AUARequest kuaRequest=AUARequest.builder().channel("test").build();
		ErrorCodeMapper errorCodeMapper1=new ErrorCodeMapper();
		errorCodeMapper1.setErrorCode("test");
		errorCodeMapper1.setErrorId("test");
		ResponseDTO<AUAResponse> aadhaarVerifyResponseDTO=new ResponseDTO<>();
		Meta meta=new Meta();
		meta.setCode("test");
		aadhaarVerifyResponseDTO.setMeta(meta);
		AUAResponse auaResponse=new AUAResponse();
		auaResponse.setResponseCode("test");
		Mockito.when(aadhaarService.validateAUA(Mockito.any(),Mockito.any())).thenReturn(auaResponse);
		Mockito.when(errorCodeService.getErrorCodeByApiNameAndOrgErrorCode(Mockito.any(),Mockito.any())).thenReturn(errorCodeMapper1);
		LoggerModel.LoggerError loggerError=new LoggerModel.LoggerError();
		loggerError.setErrorCode("test");
		loggerError.setStatus("test");
		loggerError.setErrorDescription("test");
		/*mockedSettings.when(() -> CommonUtil.setLoggerError(Mockito.any()))
				.thenReturn(loggerError);*/
		ResponseEntity<?> responseDTOResponseEntity=validationController.validateAUA(kuaRequest,"test","test","test");
		
	}

	@Test(expected = Test.None.class)
	public void validateAUAsuccessTest() {
		AUARequest kuaRequest=AUARequest.builder().channel("test").build();
		ErrorCodeMapper errorCodeMapper1=new ErrorCodeMapper();
		errorCodeMapper1.setErrorCode("2400");
		errorCodeMapper1.setErrorId("test");
		ResponseDTO<AadhaarVerify> aadhaarVerifyResponseDTO=new ResponseDTO<>();
		Meta meta=new Meta();
		meta.setCode("2100");
		aadhaarVerifyResponseDTO.setMeta(meta);
		AUAResponse auaResponse=new AUAResponse();
		auaResponse.setResponseCode("test");
		Mockito.when(aadhaarService.validateAUA(Mockito.any(),Mockito.any())).thenReturn(auaResponse);
		Mockito.when(errorCodeService.getErrorCodeByApiNameAndOrgErrorCode(Mockito.any(),Mockito.any())).thenReturn(errorCodeMapper1);
		LoggerModel.LoggerError loggerError=new LoggerModel.LoggerError();
		loggerError.setErrorCode("test");
		loggerError.setStatus("test");
		loggerError.setErrorDescription("test");
		/*mockedSettings.when(() -> CommonUtil.setLoggerError(Mockito.any()))
				.thenReturn(loggerError);*/
		ResponseEntity<?> responseDTOResponseEntity=validationController.validateAUA(kuaRequest,"test","test","test");
		
	}

	@Test(expected = GenericException.class)
	public void validateAUAGenericExceptionTest()  {

			AUARequest kuaRequest=AUARequest.builder().channel("test").build();
			ErrorCodeMapper errorCodeMapper1 = new ErrorCodeMapper();
			errorCodeMapper1.setErrorCode("2400");
			errorCodeMapper1.setErrorId("test");
			ResponseDTO<AadhaarVerify> aadhaarVerifyResponseDTO = new ResponseDTO<>();
			Meta meta = new Meta();
			meta.setCode("2100");
			aadhaarVerifyResponseDTO.setMeta(meta);
			AUAResponse auaResponse=new AUAResponse();
			auaResponse.setResponseCode("test");
			Mockito.when(aadhaarService.validateAUA(Mockito.any(), Mockito.any())).thenReturn(auaResponse);
			Mockito.when(errorCodeService.getErrorCodeByApiNameAndOrgErrorCode(Mockito.any(), Mockito.any())).thenReturn(null);
			LoggerModel.LoggerError loggerError = new LoggerModel.LoggerError();
			loggerError.setErrorCode("test");
			loggerError.setStatus("test");
			loggerError.setErrorDescription("test");
			/*mockedSettings.when(() -> CommonUtil.setLoggerError(Mockito.any()))
					.thenReturn(loggerError);*/
			ResponseEntity<?> responseDTOResponseEntity = validationController.validateAUA(kuaRequest, "test", "test", "test");


	}


}