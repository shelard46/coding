package com.airtelbank.validation.dao.aerospike.impl;

import com.airtelbank.validation.dao.aerospike.model.Identities;
import com.airtelbank.validation.exception.AeroSpikeException;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.context.MessageSource;
import org.springframework.data.aerospike.core.AerospikeTemplate;
import org.springframework.test.util.ReflectionTestUtils;

import static org.junit.Assert.*;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class IdentitiesDaoImplTest {

    @Mock
    private AerospikeTemplate aerospikeTemplate;
    @Mock private MessageSource messageSource;

    @InjectMocks
    private IdentitiesDaoImpl identitiesDaoImpl;

    @Before
    public void init() {
        MockitoAnnotations.initMocks(this);
        ReflectionTestUtils.setField(identitiesDaoImpl, "expiration", 10);
    }

    @Test(expected = AeroSpikeException.class)
    public void addAndSaveIdentityInRepoWhenExceptionTest() {
        Identities identities = Identities.builder().build();
        doThrow(new RuntimeException()).when(aerospikeTemplate).persist(Mockito.any(), Mockito.any());
        identitiesDaoImpl.addAndSaveIdentityInRepo(identities);
    }

    @Test(expected = AeroSpikeException.class)
    public void getIdentityFromRepoWhenExceptionTest() {
        when(aerospikeTemplate.findById(Mockito.any(), Mockito.any())).thenThrow(new RuntimeException());
        identitiesDaoImpl.getIdentityFromRepo("id");
    }

    @Test(expected = AeroSpikeException.class)
    public void getIdentityFromRepoUniqueWhenExceptionTest() {
        when(aerospikeTemplate.find(Mockito.any(), Mockito.any())).thenThrow(new RuntimeException());
        identitiesDaoImpl.getIdentityFromRepoUnique("9876543210", "9876543210");
    }

    @Test(expected = AeroSpikeException.class)
    public void updateIdentityInRepoWhenExceptionTest() {
        Identities identities = Identities.builder().build();
        doThrow(new RuntimeException()).when(aerospikeTemplate).persist(Mockito.any(), Mockito.any());
        identitiesDaoImpl.updateIdentityInRepo(identities, false);
    }



}