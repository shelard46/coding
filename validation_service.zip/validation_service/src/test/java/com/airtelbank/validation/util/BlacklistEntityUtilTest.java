package com.airtelbank.validation.util;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import org.elasticsearch.action.bulk.BulkRequest;
import org.elasticsearch.client.RestHighLevelClient;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.MessageSource;
import org.springframework.context.NoSuchMessageException;
import org.springframework.http.HttpStatus;
import org.springframework.test.util.ReflectionTestUtils;

import com.airtelbank.validation.model.BlacklistEntityResponse;
import com.airtelbank.validation.model.blacklist.BlacklistData;

import lombok.extern.slf4j.Slf4j;

@RunWith(MockitoJUnitRunner.class)
@Slf4j
public class BlacklistEntityUtilTest {

	@InjectMocks
	private BlackListEntityUtil blackListEntityUtil;

	@Mock
	private MessageSource messageSource;



	@MockBean
	private RestHighLevelClient restHighLevelClient;

	@Before
	public void init() {
		MockitoAnnotations.initMocks(this);
		when(messageSource.getMessage("config.blacklist.entityFound.msg", null, Locale.ENGLISH)).thenReturn("ABC");

	}

	BulkRequest bulkRequest = new BulkRequest();

	@Test
	public void testFailureResponse() throws NoSuchMessageException {
		when(messageSource.getMessage(Mockito.any(),Mockito.any(),Mockito.any())).thenReturn("test");
		BlacklistEntityResponse blacklistResponse = blackListEntityUtil.getFailureResponse();
		assertNotNull(blacklistResponse);
		assertEquals(HttpStatus.OK.value(), blacklistResponse.getStatus());
	}

	@Test
	public void testErrorResponse() throws NoSuchMessageException {
		when(messageSource.getMessage(Mockito.any(),Mockito.any(),Mockito.any())).thenReturn("test");
		BlacklistEntityResponse blacklistResponse = blackListEntityUtil.getErrorResponse();
		assertNotNull(blacklistResponse);
		assertEquals(HttpStatus.INTERNAL_SERVER_ERROR.value(), blacklistResponse.getStatus());
	}

	@Test
	public void testAddIndexes() {
		ReflectionTestUtils.setField(blackListEntityUtil, "esClusterName", "elasticsearch");
		ReflectionTestUtils.setField(blackListEntityUtil, "matchPercentage", "100%");
		blackListEntityUtil.addIndexes(getBlackListdata(), bulkRequest);
		assertNotNull(bulkRequest);
	}

	private BlacklistData getBlackListdata () {
		return BlacklistData.builder()
				.id("12345")
				.action("add")
				.blacklisted(true)
				.pan("AAAAA")
				.country("India")
				.charge("(SIE)")
				.name("Dummy")
				.build();
	}

	@Test
	public void getValidationFailureResponseTest() throws Exception {
		ReflectionTestUtils.setField(blackListEntityUtil, "esClusterName", "elasticsearch");
		ReflectionTestUtils.setField(blackListEntityUtil, "matchPercentage", "100%");
		BlacklistEntityResponse blacklistResponse = blackListEntityUtil.getValidationFailureResponse();
		assertNotNull(blacklistResponse);
	}

	@Test
	public void getSuccessResponseTest() throws Exception {
		List<BlacklistData> entities = new ArrayList<BlacklistData>();
		BlacklistEntityResponse blacklistResponse = blackListEntityUtil.getSuccessResponse(entities,"ABC");
		assertNotNull(blacklistResponse);
	}

}
