package com.airtelbank.validation.controller;

import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.context.MessageSource;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.airtelbank.validation.dao.aerospike.model.ErrorCodeMapper;
import com.airtelbank.validation.service.ErrorCodeMapperService;
import com.fasterxml.jackson.databind.ObjectMapper;

@RunWith(MockitoJUnitRunner.class)
public class ErrorCodeMapperControllerTest {
	
	@Mock private MessageSource messageSource;
	@Mock private ErrorCodeMapperService service;
	
	@InjectMocks private ErrorCodeMapperController controller;
	
	private MockMvc mvc;
	
	@Before
	public void init() {
		MockitoAnnotations.initMocks(this);
		mvc = MockMvcBuilders.standaloneSetup(controller).build();
	}
	
	@Test
	public void getErrorCodeEntryTest() throws Exception {
		ErrorCodeMapper mapper = new ErrorCodeMapper();
		when(service.getErrorCodeByApiNameAndOrgErrorCode(Mockito.anyString(), Mockito.anyString())).thenReturn(mapper);
		mvc.perform(MockMvcRequestBuilders
				.get("/api/v1/errorCodeMapper/API/1234")
				.accept(MediaType.APPLICATION_JSON))
				.andDo(print())
				.andExpect(status().isOk());
	}
	
	@Test
	public void createNewErrorCodeWhenSuccessTest() throws Exception {
		ErrorCodeMapper mapper = new ErrorCodeMapper();
		boolean isSuccess = true;
		when(service.addNewErrorCode(Mockito.any(ErrorCodeMapper.class))).thenReturn(isSuccess);
		mvc.perform(MockMvcRequestBuilders
				.post("/api/v1/errorCodeMapper")
				.content(new ObjectMapper().writeValueAsString(mapper))
				.contentType(MediaType.APPLICATION_JSON)
				.accept(MediaType.APPLICATION_JSON))
				.andDo(print())
				.andExpect(status().isCreated());
	}
	
	@Test
	public void createNewErrorCodeWhenFailTest() throws Exception {
		ErrorCodeMapper mapper = new ErrorCodeMapper();
		boolean isSuccess = false;
		when(service.addNewErrorCode(Mockito.any(ErrorCodeMapper.class))).thenReturn(isSuccess);
		mvc.perform(MockMvcRequestBuilders
				.post("/api/v1/errorCodeMapper")
				.content(new ObjectMapper().writeValueAsString(mapper))
				.contentType(MediaType.APPLICATION_JSON)
				.accept(MediaType.APPLICATION_JSON))
				.andDo(print())
				.andExpect(status().isCreated());
	}

}