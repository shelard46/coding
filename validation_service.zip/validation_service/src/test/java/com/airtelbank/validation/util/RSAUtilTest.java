package com.airtelbank.validation.util;

import static org.junit.Assert.assertEquals;

import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;

import org.junit.Test;

import com.airtelbank.validation.exception.ObjectConversionException;

public class RSAUtilTest {
	
	@Test
	public void encryptAndDecrypt() throws InvalidKeyException, NoSuchAlgorithmException, NoSuchPaddingException, IllegalBlockSizeException, BadPaddingException {
		String strToEncrypt = "hello world";
		String encryptedString = RSAUtil.encrypt(strToEncrypt, "MFwwDQYJKoZIhvcNAQEBBQADSwAwSAJBAJlCGtRv12B7BRvS42CMg581EJ8/j+0ezayahBGw8ces0k234e/UYvb5R+PjjwvtEUe1eDwl8gmdelOl6Zx0z/kCAwEAAQ==");
		String decryptedString = RSAUtil.decrypt(encryptedString, RSAUtil.getPrivateKey("MIIBVAIBADANBgkqhkiG9w0BAQEFAASCAT4wggE6AgEAAkEAmUIa1G/XYHsFG9LjYIyDnzUQnz+P7R7NrJqEEbDxx6zSTbfh79Ri9vlH4+OPC+0RR7V4PCXyCZ16U6XpnHTP+QIDAQABAkA94QfuMD4Y0XLtmgd+ax2VwZo1gjd9eQt4HmcmsXfds5Q8DBRHX199+IypL4kO7Xj5wv7N7vrDdRv4P663ahGVAiEA1ogj2b2bFBPryaXadqXkqsCpqeAqAybGoO1Axyz1ptMCIQC24emDhhiyQuEehjTNiCtdkQpPi45o5erBZM/RHBqGgwIhAMvKp8PACgEYq3PyyYTMMlzCiGmHOGGmBCn7Nv3+B51hAiBEeJauKJGshD+25vZ0EUxzLq+WkqCSA6r+F1l7aDNCMwIgIw7Hu7V3NO6lFI4o8oXNYkJZisFhAlYe4kkG3HdW9Qs="));
		assertEquals(strToEncrypt, decryptedString);
	}
	
	@Test(expected = ObjectConversionException.class)
	public void encryptWhenException() throws InvalidKeyException, NoSuchAlgorithmException, NoSuchPaddingException, IllegalBlockSizeException, BadPaddingException {
		String strToEncrypt = "hello world";
		RSAUtil.encrypt(strToEncrypt, "MFwwDQYJKoZIhvcNAQEBBQADSwAwSAJBAJlCGtRv12B7BRvS42CMg581EJ8/j+0ezayahBGw8ces0k234e/UYvb5R+PjjwvtEUe1eDwl8gmdelOl6Zx0z/kCAwEAA");
	}
	
	@Test(expected = ObjectConversionException.class)
	public void decryptWhenException() throws InvalidKeyException, NoSuchAlgorithmException, NoSuchPaddingException, IllegalBlockSizeException, BadPaddingException {
		String strToDecrypt = "hello world";
		RSAUtil.decrypt(strToDecrypt, RSAUtil.getPrivateKey("MIIBVAIBADANBgkqhkiG9w0BAQEFAASCAT4wggE6AgEAAkEAmUIa1G/XYHsFG9LjYIyDnzUQnz+P7R7NrJqEEbDxx6zSTbfh79Ri9vlH4+OPC+0RR7V4PCXyCZ16U6XpnHTP+QIDAQABAkA94QfuMD4Y0XLtmgd+ax2VwZo1gjd9eQt4HmcmsXfds5Q8DBRHX199+IypL4kO7Xj5wv7N7vrDdRv4P663ahGVAiEA1ogj2b2bFBPryaXadqXkqsCpqeAqAybGoO1Axyz1ptMCIQC24emDhhiyQuEehjTNiCtdkQpPi45o5erBZM/RHBqGgwIhAMvKp8PACgEYq3PyyYTMMlzCiGmHOGGmBCn7Nv3+B51hAiBEeJauKJGshD+25vZ0EUxzLq+WkqCSA6r+F1l7aDNCMwIgIw7Hu7V3NO6lFI4o8oXNYkJZisFhAlYe4kkG3HdW9Qs="));
	}
	
	@Test(expected = Test.None.class)
	public void getPrivateKeyWhenException() throws InvalidKeyException, NoSuchAlgorithmException, NoSuchPaddingException, IllegalBlockSizeException, BadPaddingException {
		RSAUtil.getPrivateKey("MIIBVAIBADANBgkqhkiG9w0BAQEFAASCAT4wggE6AgEAAkEAmUIa1G/XYHsFG9LjYIyDnzUQnz+P7R7NrJqEEbDxx6zSTbfh79Ri9vlH4+OPC+0RR7V4PCXyCZ16U6XpnHTP+QIDAQABAkA94QfuMD4Y0XLtmgd+ax2VwZo1gjd9eQt4HmcmsXfds5Q8DBRHX199+IypL4kO7Xj5wv7N7vrDdRv4P663ahGVAiEA1ogj2b2bFBPryaXadqXkqsCpqeAqAybGoO1Axyz1ptMCIQC24emDhhiyQuEehjTNiCtdkQpPi45o5erBZM/RHBqGgwIhAMvKp8PACgEYq3PyyYTMMlzCiGmHOGGmBCn7Nv3+B51hAiBEeJauKJGshD+25vZ0EUxzLq+WkqCSA6r+F1l7aDNCMwIgIw7Hu7V3NO6lFI4o8oXNYkJZisFh");
	}
	
	@Test(expected = Test.None.class)
	public void getPubicKeyWhenException() throws InvalidKeyException, NoSuchAlgorithmException, NoSuchPaddingException, IllegalBlockSizeException, BadPaddingException {
		RSAUtil.getPublicKey("wrong public key");
	}



}
