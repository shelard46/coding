package com.airtelbank.validation.dao.aerospike.impl;

import com.airtelbank.validation.dao.aerospike.model.AadhaarVerify;
import com.airtelbank.validation.exception.AeroSpikeException;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.context.MessageSource;
import org.springframework.data.aerospike.core.AerospikeTemplate;
import org.springframework.test.util.ReflectionTestUtils;

import static org.junit.Assert.*;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.when;
@RunWith(MockitoJUnitRunner.class)
public class AadharVerifyDaoImplTest {

    @Mock
    private AerospikeTemplate aerospikeTemplate;
    @Mock private MessageSource messageSource;

    @InjectMocks
    private AadharVerifyDaoImpl aadharVerifyDaoImpl;

    @Before
    public void init() {
        MockitoAnnotations.initMocks(this);
        ReflectionTestUtils.setField(aadharVerifyDaoImpl, "noExpiration", 1000);
    }

    @Test(expected = AeroSpikeException.class)
    public void saveAadhaarVerifyResponseWhenExceptionTest() {
        AadhaarVerify aadhaarVerify = AadhaarVerify.builder().build();
        doThrow(new RuntimeException()).when(aerospikeTemplate).persist(Mockito.any(), Mockito.any());
        aadharVerifyDaoImpl.saveAadhaarVerifyResponse(aadhaarVerify);
    }

    @Test(expected = AeroSpikeException.class)
    public void getAadhaarVerifyResponseWhenExceptionTest() {
        AadhaarVerify aadhaarVerify = AadhaarVerify.builder().build();
        when(aerospikeTemplate.findById(Mockito.any(), Mockito.any())).thenThrow(new RuntimeException());
        aadharVerifyDaoImpl.getAadhaarVerifyResponse("id");
    }



    @Test
    public void saveAadhaarVerifyResponseTest() {
        AadhaarVerify aadhaarVerify = AadhaarVerify.builder().build();
       Mockito.doNothing().when(aerospikeTemplate).persist(Mockito.any(), Mockito.any());
        boolean VerifyResponse=aadharVerifyDaoImpl.saveAadhaarVerifyResponse(aadhaarVerify);
        assertTrue(VerifyResponse);

    }
}