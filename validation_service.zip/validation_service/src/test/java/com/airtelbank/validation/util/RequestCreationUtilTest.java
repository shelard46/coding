package com.airtelbank.validation.util;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import com.airtelbank.validation.model.blacklist.RECustomerResults;
import com.airtelbank.validation.model.blacklist.REResult;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.context.MessageSource;

import com.airtelbank.validation.constants.Constants;
import com.airtelbank.validation.enums.CommunicationType;
import com.airtelbank.validation.model.BlacklistResponse;
import com.airtelbank.validation.model.blacklist.CustomerResponse;
import static org.mockito.Mockito.when;
import com.airtelbank.validation.model.communication.SmsData;

public class RequestCreationUtilTest {
	
	@Mock private MessageSource messagesource;
	@InjectMocks private RequestCreationUtil util;
	
	@Before
	public void init () {
		MockitoAnnotations.initMocks(this);
	}
	
	@Test
	public void transformResponseFromPosidexWhenStatusP() {
		CustomerResponse customerResponse = new CustomerResponse();
		customerResponse.setStatus("P");
		BlacklistResponse response = util.transformResponseFromPosidex(customerResponse);
		assertEquals(Constants.FAILURE_STATUS, response.getStatus());
	}
	
	@Test
	public void transformResponseFromPosidexWhenStatusF() {
		CustomerResponse customerResponse = new CustomerResponse();
		customerResponse.setStatus("F");
		BlacklistResponse response = util.transformResponseFromPosidex(customerResponse);
		assertEquals(Constants.FAILURE_STATUS, response.getStatus());

	}
	
	@Test
	public void createSmsRequest() {
		SmsData smsData = util.createSmsRequest("9876543210", CommunicationType.ALERT_AUA_SUCCESS, null, "SMSref");
		assertNotNull(smsData);
	}

	@Test
	public void transformResponseFromPosidexTest() {
		CustomerResponse customerResponse = new CustomerResponse();
		customerResponse.setStatus("C");
		customerResponse.setRematchcount("1");
		RECustomerResults reCustomerResults = new RECustomerResults();
		customerResponse.setResults(reCustomerResults);
		REResult reResult = new REResult();
		customerResponse.getResults().setREResults(reResult);
		when(messagesource.getMessage(Mockito.any(),Mockito.any())).thenReturn("ABC");
		BlacklistResponse response = util.transformResponseFromPosidex(customerResponse);
		assertEquals(Constants.SUCCESS_STATUS, response.getStatus());

	}

	@Test
	public void transformResponseFromPosidexInvalidTest() {
		CustomerResponse customerResponse = new CustomerResponse();
		customerResponse.setStatus("C");
		customerResponse.setRematchcount("0");
		RECustomerResults reCustomerResults = new RECustomerResults();
		customerResponse.setResults(reCustomerResults);
		REResult reResult = new REResult();
		customerResponse.getResults().setREResults(reResult);
		when(messagesource.getMessage(Mockito.any(),Mockito.any())).thenReturn("ABC");
		BlacklistResponse response = util.transformResponseFromPosidex(customerResponse);
		assertEquals(Constants.FAILURE_STATUS, response.getStatus());

	}

}
