package com.airtelbank.validation.dao.aerospike;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.invocation.InvocationOnMock;
import org.springframework.context.MessageSource;
import org.springframework.data.aerospike.core.AerospikeTemplate;
import org.springframework.test.util.ReflectionTestUtils;

import com.airtelbank.validation.dao.aerospike.impl.AadharVerifyDaoImpl;
import com.airtelbank.validation.dao.aerospike.model.AadhaarVerify;
import com.airtelbank.validation.exception.AeroSpikeException;

import static org.mockito.Mockito.*;

public class AadharVerifyDaoImplTest {
	
	@Mock private AerospikeTemplate aerospikeTemplate;
	@Mock private MessageSource messageSource;
	
	@InjectMocks private AadharVerifyDaoImpl aadharVerifyDaoImpl;
	
	@Before
	public void init() {
		MockitoAnnotations.initMocks(this);
		ReflectionTestUtils.setField(aadharVerifyDaoImpl, "noExpiration", 1000);
	}
	
	@Test(expected = AeroSpikeException.class)
	public void saveAadhaarVerifyResponseWhenException() {
		AadhaarVerify aadhaarVerify = AadhaarVerify.builder().build();
		doAnswer(InvocationOnMock ->{throw new Exception();}).when(aerospikeTemplate).persist(Mockito.any(), Mockito.any());
		aadharVerifyDaoImpl.saveAadhaarVerifyResponse(aadhaarVerify);
	}
	
	@Test(expected = AeroSpikeException.class)
	public void getAadhaarVerifyResponseWhenException() {
		AadhaarVerify aadhaarVerify = AadhaarVerify.builder().build();
		when(aerospikeTemplate.findById(Mockito.any(), Mockito.any())).thenThrow(new RuntimeException());
		aadharVerifyDaoImpl.getAadhaarVerifyResponse("id");
	}

}
