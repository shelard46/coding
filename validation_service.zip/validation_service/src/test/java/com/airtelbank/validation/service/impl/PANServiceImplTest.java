package com.airtelbank.validation.service.impl;

import com.airtelbank.validation.model.PANDetails;
import com.airtelbank.validation.model.PANRequest;
import com.airtelbank.validation.service.impl.helper.PanServiceImplHelper;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.MockitoJUnitRunner;

import static org.junit.Assert.*;

@RunWith(MockitoJUnitRunner.class)
public class PANServiceImplTest {
    @InjectMocks
    private PANServiceImpl panService;

    @Mock
    private PanServiceImplHelper panServiceImplHelper;

    @Before
    public void setUp() throws Exception {
        MockitoAnnotations.initMocks(this);
    }

    @After
    public void tearDown() throws Exception {
    }

    @Test
    public void getPanDetailsTest() {
        PANRequest panRequest=new PANRequest();
        panRequest.setPanNumber("test");
        panRequest.setChannel("test");
        panRequest.setContentId("test");
        panRequest.setMobile("test");
        panRequest.setRefNumber("test");
        PANDetails panDetails =new PANDetails();
        panDetails.setPanNumber("test");
        Mockito.when( panServiceImplHelper.getPanDetails(Mockito.any())).thenReturn(panDetails);
        PANDetails panDetails1=panService.getPanDetails(panRequest);
        assertNotNull(panDetails1);
    }
}