package com.airtelbank.validation.exception;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.when;

import java.util.HashSet;
import java.util.Locale;
import java.util.Set;

import javax.jws.WebResult;
import javax.validation.ConstraintViolation;
import javax.validation.ConstraintViolationException;

import com.airtelbank.validation.model.BlacklistRequest;
import lombok.extern.slf4j.Slf4j;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.Request;
import org.junit.runner.RunWith;
import org.junit.runner.Runner;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.context.MessageSource;
import org.springframework.core.MethodParameter;
import org.springframework.core.env.Environment;

import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.ServletRequestBindingException;
import org.springframework.web.client.ResourceAccessException;
import org.springframework.web.context.request.ServletWebRequest;
import org.springframework.web.context.request.WebRequest;
import org.springframework.ws.client.WebServiceIOException;

import com.airtelbank.validation.constants.Constants;
import com.airtelbank.validation.dao.aerospike.model.ErrorCodeMapper;
import com.airtelbank.validation.model.LoggerModel;
import com.airtelbank.validation.model.Meta;
import com.airtelbank.validation.model.ResponseDTO;
import com.airtelbank.validation.service.ErrorCodeMapperService;


@RunWith(MockitoJUnitRunner.Silent.class)
@Slf4j
public class GlobalExceptionHandlerTest {

	@Mock
	private Environment environment;
	@Mock
	private LoggerModel loggerModel;
	@Mock
	private MessageSource messageSource;
	@Mock
	private ErrorCodeMapperService errorCodeMapperService;

	@InjectMocks
	private GlobalExceptionHandler globalExceptionHandler;

	@Before
	public void init() {
		MockitoAnnotations.initMocks(this);
		when(messageSource.getMessage("generate.aadhaar.otp.aerospike.error.code", null, Locale.ENGLISH)).thenReturn("aerospike code");
		when(messageSource.getMessage("generate.aadhaar.otp.aerospike.error.msg", null, Locale.ENGLISH)).thenReturn("aerospike msg");
		when(messageSource.getMessage("generate.aadhaar.otp.db.error.code", null, Locale.ENGLISH)).thenReturn("db code");
		when(messageSource.getMessage("generate.aadhaar.otp.db.error.msg", null, Locale.ENGLISH)).thenReturn("db msg");
		when(messageSource.getMessage("generate.aadhaar.otp.object.conversion.error.code", null, Locale.ENGLISH)).thenReturn("object code");
		when(messageSource.getMessage("generate.aadhaar.otp.object.conversion.error.msg", null, Locale.ENGLISH)).thenReturn("object msg");
		when(messageSource.getMessage("generate.aadhaar.otp.timeout.error.code", null, Locale.ENGLISH)).thenReturn("timeout code");
		when(messageSource.getMessage("generate.aadhaar.otp.timeout.error.msg", null, Locale.ENGLISH)).thenReturn("timeout msg");
		when(messageSource.getMessage("generate.aadhaar.otp.third.party.error.code", null, Locale.ENGLISH)).thenReturn("thirdparty code");
		when(messageSource.getMessage("generate.aadhaar.otp.third.party.error.msg", null, Locale.ENGLISH)).thenReturn("thirdparty msg");
		when(messageSource.getMessage("config.posidex.namematch.error.generic.code", null, Locale.ENGLISH)).thenReturn("namematch code");
		when(messageSource.getMessage("config.posidex.namematch.error.generic.msg", null, Locale.ENGLISH)).thenReturn("namematch msg");
		when(messageSource.getMessage("generate.aadhaar.otp.validation.error.code", null, Locale.ENGLISH)).thenReturn("validation code");
		when(messageSource.getMessage("generate.aadhaar.otp.validation.error.msg", null, Locale.ENGLISH)).thenReturn("validation msg");
		when(messageSource.getMessage("generate.aadhaar.otp.max.retry.count.reached.code", null, Locale.ENGLISH)).thenReturn("genmaxretry code");
		when(messageSource.getMessage("generate.aadhaar.otp.max.retry.count.reached.msg", null, Locale.ENGLISH)).thenReturn("genmaxretry msg");
		when(messageSource.getMessage("verify.aadhaar.otp.max.retry.count.fail.code", null, Locale.ENGLISH)).thenReturn("vermaxretry code");
		when(messageSource.getMessage("verify.aadhaar.otp.max.retry.count.fail.msg", null, Locale.ENGLISH)).thenReturn("vermaxretry msg");
		when(messageSource.getMessage("verify.aadhaar.otp.failed.response.code", null, Locale.ENGLISH)).thenReturn("adhrotp code");
		when(messageSource.getMessage("verify.aadhaar.otp.failed.response.msg", null, Locale.ENGLISH)).thenReturn("adhrotp msg");
		when(messageSource.getMessage("vault.error.code", null, Locale.ENGLISH)).thenReturn("vault code");
		when(messageSource.getMessage("vault.error.msg", null, Locale.ENGLISH)).thenReturn("vault msg");
		when(messageSource.getMessage("pan.verification.error.code", null, Locale.ENGLISH)).thenReturn("pan code");
		when(messageSource.getMessage("pan.verification.error.msg", null, Locale.ENGLISH)).thenReturn("pan msg");
		when(messageSource.getMessage("pan.verification.invalid.error.msg", null, Locale.ENGLISH)).thenReturn("pan msg");
		when(environment.getProperty("config.pan.esb.error.code.mapper.api.name")).thenReturn("ESB");
		when(messageSource.getMessage("ESB", null, null)).thenReturn("esb msg");
		when(messageSource.getMessage("pan.generic.error.code", null, Locale.ENGLISH)).thenReturn("pan code");
		when(messageSource.getMessage("pan.generic.error.msg", null, Locale.ENGLISH)).thenReturn("pan msg");
		when(messageSource.getMessage("identity.verification.error.code", null, Locale.ENGLISH)).thenReturn("identity code");
		when(messageSource.getMessage("identity.verification.error.msg", null, Locale.ENGLISH)).thenReturn("identity msg");
		when(messageSource.getMessage(Constants.GENERIC_ERROR_MSG, null, Locale.ENGLISH)).thenReturn("generic error code");
		when(messageSource.getMessage("config.generic.errorMessage", null, Locale.ENGLISH)).thenReturn("generic error msg");
		when(messageSource.getMessage("config.cbs.dedupe.customer.not.found.msg", null, Locale.ENGLISH)).thenReturn("dedupe customer msg");
		when(messageSource.getMessage("config.cbs.dedupe.customer.not.found.code", null, Locale.ENGLISH)).thenReturn("dedupe customer code");
		when(messageSource.getMessage("aadhaar.kua.failure.code", null, Locale.ENGLISH)).thenReturn("aadhar kua failure code");
		when(messageSource.getMessage("aadhaar.kua.failure.msg", null, Locale.ENGLISH)).thenReturn("aadhar kua failure msg");
		when(messageSource.getMessage("verify.aadhaar.otp.uidai.failure.code", null, Locale.ENGLISH)).thenReturn("aadhar uidai failure code");
		when(messageSource.getMessage("verify.aadhaar.otp.uidai.failure.msg", null, Locale.ENGLISH)).thenReturn("aadhar uidai failure msg");
		when(messageSource.getMessage("generate.aadhaar.otp.uidai.failure.code", null, Locale.ENGLISH)).thenReturn("generate aadhar uidai failure code");
		when(messageSource.getMessage("generate.aadhaar.otp.uidai.failure.msg", null, Locale.ENGLISH)).thenReturn("generate aadhar uidai failure msg");
		when(messageSource.getMessage("config.headersMissing.errorCode", null, Locale.ENGLISH)).thenReturn("config headersMissing errorCode");
		when(messageSource.getMessage("config.headersMissing.errorMessage", null, Locale.ENGLISH)).thenReturn("config headersMissing errorMessage");
		when(messageSource.getMessage("config.generic.errorMessage", null, Locale.ENGLISH)).thenReturn("constant generic error msg");

	}

	@Test
	public void aeroSpikeExcetionTestWhenCodeAndMsgIsNull() {
		AeroSpikeException exception = new AeroSpikeException();
		exception.setId("");
		ResponseEntity<Object> response = globalExceptionHandler.aeroSpikeExcetion(exception);
		assertNotNull(response);
		assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, response.getStatusCode());
		ResponseDTO<?> responseDto = (ResponseDTO) response.getBody();
		assertEquals("aerospike code", responseDto.getMeta().getCode());
		assertEquals("aerospike msg", responseDto.getMeta().getDescription());
		assertEquals(Constants.FAILURE_STATUS, responseDto.getMeta().getStatus());
	}

	@Test
	public void aeroSpikeExcetionTestWhenCodeAndMsgIsNotNull() {
		AeroSpikeException exception = new AeroSpikeException("custom msg", "custom code");
		ResponseEntity<Object> response = globalExceptionHandler.aeroSpikeExcetion(exception);
		assertNotNull(response);
		assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, response.getStatusCode());
		ResponseDTO<?> responseDto = (ResponseDTO) response.getBody();
		assertEquals("custom code", responseDto.getMeta().getCode());
		assertEquals("custom msg", responseDto.getMeta().getDescription());
		assertEquals(Constants.FAILURE_STATUS, responseDto.getMeta().getStatus());
	}

	@Test
	public void aeroSpikeExcetionTestWhenCodeNull() {
		AeroSpikeException exception = new AeroSpikeException();
		exception.setId("custom code");
		ResponseEntity<Object> response = globalExceptionHandler.aeroSpikeExcetion(exception);
		assertNotNull(response);
		assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, response.getStatusCode());
		ResponseDTO<?> responseDto = (ResponseDTO) response.getBody();
		assertEquals("aerospike code", responseDto.getMeta().getCode());
		assertEquals("aerospike msg", responseDto.getMeta().getDescription());
		assertEquals(Constants.FAILURE_STATUS, responseDto.getMeta().getStatus());
	}


	@Test
	public void dbExceptionTest() {
		ResponseEntity<Object> response = globalExceptionHandler.dbException();
		assertNotNull(response);
		assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, response.getStatusCode());
		ResponseDTO<?> responseDto = (ResponseDTO) response.getBody();
		assertEquals("db code", responseDto.getMeta().getCode());
		assertEquals("db msg", responseDto.getMeta().getDescription());
		assertEquals(Constants.FAILURE_STATUS, responseDto.getMeta().getStatus());
	}

	@Test
	public void objectConversionTest() {
		ResponseEntity<Object> response = globalExceptionHandler.objectConversion();
		assertNotNull(response);
		assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, response.getStatusCode());
		ResponseDTO<?> responseDto = (ResponseDTO) response.getBody();
		assertEquals("object code", responseDto.getMeta().getCode());
		assertEquals("object msg", responseDto.getMeta().getDescription());
		assertEquals(Constants.FAILURE_STATUS, responseDto.getMeta().getStatus());
	}

	@Test
	public void handleTimeoutsTest() {
		ThirdPartyApiException exception = new ThirdPartyApiException("custom msg", "custom code");
		ResponseEntity<Object> response = globalExceptionHandler.handleTimeouts(exception);
		assertNotNull(response);
		assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, response.getStatusCode());
		ResponseDTO<?> responseDto = (ResponseDTO) response.getBody();
		assertEquals("custom code", responseDto.getMeta().getCode());
		assertEquals("custom msg", responseDto.getMeta().getDescription());
		assertEquals(Constants.FAILURE_STATUS, responseDto.getMeta().getStatus());
	}

	@Test
	public void handleTimeoutsWhenInstanceOfResourceAccessExceptionTest() {
		ThirdPartyApiException exception = new ThirdPartyApiException("", "", new ResourceAccessException("ex"));
		ResponseEntity<Object> response = globalExceptionHandler.handleTimeouts(exception);
		assertNotNull(response);
		assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, response.getStatusCode());
		ResponseDTO<?> responseDto = (ResponseDTO) response.getBody();
		assertEquals("timeout code", responseDto.getMeta().getCode());
		assertEquals("timeout msg", responseDto.getMeta().getDescription());
		assertEquals(Constants.FAILURE_STATUS, responseDto.getMeta().getStatus());
	}

	@Test
	public void handleTimeoutsWhenInstanceOfWebServiceIOExceptionTest() {
		ThirdPartyApiException exception = new ThirdPartyApiException("", "code", new WebServiceIOException("ex"));
		ResponseEntity<Object> response = globalExceptionHandler.handleTimeouts(exception);
		assertNotNull(response);
		assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, response.getStatusCode());
		ResponseDTO<?> responseDto = (ResponseDTO) response.getBody();
		assertEquals("timeout code", responseDto.getMeta().getCode());
		assertEquals("timeout msg", responseDto.getMeta().getDescription());
		assertEquals(Constants.FAILURE_STATUS, responseDto.getMeta().getStatus());
	}

	@Test
	public void handleTimeoutsWhenInstanceOfThirdPartyApiExceptionTest() {
		ThirdPartyApiException exception = new ThirdPartyApiException("msg", "", new ThirdPartyApiException());
		ResponseEntity<Object> response = globalExceptionHandler.handleTimeouts(exception);
		assertNotNull(response);
		assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, response.getStatusCode());
		ResponseDTO<?> responseDto = (ResponseDTO) response.getBody();
		assertEquals("timeout code", responseDto.getMeta().getCode());
		assertEquals("timeout msg", responseDto.getMeta().getDescription());
		assertEquals(Constants.FAILURE_STATUS, responseDto.getMeta().getStatus());
	}

	@Test
	public void handleTimeoutsWhenInstanceOfNotHandledExceptionTest() {
		ThirdPartyApiException exception = new ThirdPartyApiException("msg", "", new AeroSpikeException());
		ResponseEntity<Object> response = globalExceptionHandler.handleTimeouts(exception);
		assertNotNull(response);
		assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, response.getStatusCode());
		ResponseDTO<?> responseDto = (ResponseDTO) response.getBody();
		assertEquals("thirdparty code", responseDto.getMeta().getCode());
		assertEquals("thirdparty msg", responseDto.getMeta().getDescription());
		assertEquals(Constants.FAILURE_STATUS, responseDto.getMeta().getStatus());
	}

	@Test
	public void handleTimeoutsWhenNullExceptionTest() {
		ThirdPartyApiException exception = new ThirdPartyApiException();
		ResponseEntity<Object> response = globalExceptionHandler.handleTimeouts(exception);
		assertNotNull(response);
		assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, response.getStatusCode());
		ResponseDTO<?> responseDto = (ResponseDTO) response.getBody();
		assertEquals("thirdparty code", responseDto.getMeta().getCode());
		assertEquals("thirdparty msg", responseDto.getMeta().getDescription());
		assertEquals(Constants.FAILURE_STATUS, responseDto.getMeta().getStatus());
	}


	@Test
	public void handleNameMatchExceptionTest() {
		NameMatchException exception = new NameMatchException("custom code", "custom msg");
		ResponseEntity<Object> response = globalExceptionHandler.handleNameMatchException(exception);
		assertNotNull(response);
		assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
		ResponseDTO<?> responseDto = (ResponseDTO) response.getBody();
		assertEquals("custom code", responseDto.getMeta().getCode());
		assertEquals("custom msg", responseDto.getMeta().getDescription());
		assertEquals(Constants.FAILURE_STATUS, responseDto.getMeta().getStatus());
	}

	@Test
	public void handleNameMatchExceptionWhenBlankMsgTest() {
		NameMatchException exception = new NameMatchException("code", "");
		ResponseEntity<Object> response = globalExceptionHandler.handleNameMatchException(exception);
		assertNotNull(response);
		assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
		ResponseDTO<?> responseDto = (ResponseDTO) response.getBody();
		assertEquals("namematch code", responseDto.getMeta().getCode());
		assertEquals("namematch msg", responseDto.getMeta().getDescription());
		assertEquals(Constants.FAILURE_STATUS, responseDto.getMeta().getStatus());
	}

	@Test
	public void handleNameMatchExceptionWhenBlankCodeTest() {
		NameMatchException exception = new NameMatchException("", "msg");
		ResponseEntity<Object> response = globalExceptionHandler.handleNameMatchException(exception);
		assertNotNull(response);
		assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
		ResponseDTO<?> responseDto = (ResponseDTO) response.getBody();
		assertEquals("namematch code", responseDto.getMeta().getCode());
		assertEquals("namematch msg", responseDto.getMeta().getDescription());
		assertEquals(Constants.FAILURE_STATUS, responseDto.getMeta().getStatus());
	}

	@Test
	public void badRequestException() {
		ClientSideException exception = new ClientSideException();
		ResponseEntity<Object> response = globalExceptionHandler.badRequestException(exception);
		assertNotNull(response);
		assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
		ResponseDTO<?> responseDto = (ResponseDTO) response.getBody();
		assertEquals("validation code", responseDto.getMeta().getCode());
		assertEquals("validation msg", responseDto.getMeta().getDescription());
		assertEquals(Constants.FAILURE_STATUS, responseDto.getMeta().getStatus());
	}

	@Test
	public void badRequestExceptionWithSomeId() {
		ClientSideException exception = new ClientSideException("custom msg", "generate.aadhaar.otp.validation.error.msg");
		ResponseEntity<Object> response = globalExceptionHandler.badRequestException(exception);
		assertNotNull(response);
		assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
		ResponseDTO<?> responseDto = (ResponseDTO) response.getBody();
		assertEquals("validation code", responseDto.getMeta().getCode());
		assertEquals("validation msg", responseDto.getMeta().getDescription());
		assertEquals(Constants.FAILURE_STATUS, responseDto.getMeta().getStatus());
	}

	@Test
	public void generateAadhaarOTPMaxCountExceededTest() {
		ResponseEntity<Object> response = globalExceptionHandler.generateAadhaarOTPMaxCountExceeded();
		assertNotNull(response);
		assertEquals(HttpStatus.OK, response.getStatusCode());
		ResponseDTO<?> responseDto = (ResponseDTO) response.getBody();
		assertEquals("genmaxretry code", responseDto.getMeta().getCode());
		assertEquals("genmaxretry msg", responseDto.getMeta().getDescription());
		assertEquals(Constants.FAILURE_STATUS, responseDto.getMeta().getStatus());
	}

	@Test
	public void verifyAadhaarOTPMaxCountExceededTest() {
		ResponseEntity<Object> response = globalExceptionHandler.verifyAadhaarOTPMaxCountExceeded();
		assertNotNull(response);
		assertEquals(HttpStatus.OK, response.getStatusCode());
		ResponseDTO<?> responseDto = (ResponseDTO) response.getBody();
		assertEquals("vermaxretry code", responseDto.getMeta().getCode());
		assertEquals("vermaxretry msg", responseDto.getMeta().getDescription());
		assertEquals(Constants.FAILURE_STATUS, responseDto.getMeta().getStatus());
	}

	@Test
	public void handleAadhaarVerificationExceptionTest() {
		AadharVerificationException exception = new AadharVerificationException();
		ResponseEntity<Object> response = globalExceptionHandler.handleAadhaarVerificationException(exception);
		assertNotNull(response);
		assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
		ResponseDTO<?> responseDto = (ResponseDTO) response.getBody();
		assertEquals("adhrotp code", responseDto.getMeta().getCode());
		assertEquals("adhrotp msg", responseDto.getMeta().getDescription());
		assertEquals(Constants.FAILURE_STATUS, responseDto.getMeta().getStatus());
	}

	@Test
	public void handleAadhaarVaultExceptionTest() {
		VaultException exception = new VaultException();
		ResponseEntity<Object> response = globalExceptionHandler.handleAadhaarVaultException(exception);
		assertNotNull(response);
		assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, response.getStatusCode());
		ResponseDTO<?> responseDto = (ResponseDTO) response.getBody();
		assertEquals("vault code", responseDto.getMeta().getCode());
		assertEquals("vault msg", responseDto.getMeta().getDescription());
		assertEquals(Constants.FAILURE_STATUS, responseDto.getMeta().getStatus());
	}

	@Test
	public void handleAadhaarVaultExceptionWhenMetaIsNotNullTest() {
		VaultException exception = new VaultException(Meta.builder().code("custom code").description("custom msg").status(Constants.FAILURE_STATUS).build());
		ResponseEntity<Object> response = globalExceptionHandler.handleAadhaarVaultException(exception);
		assertNotNull(response);
		assertEquals(HttpStatus.OK, response.getStatusCode());
		ResponseDTO<?> responseDto = (ResponseDTO) response.getBody();
		assertEquals("custom code", responseDto.getMeta().getCode());
		assertEquals("custom msg", responseDto.getMeta().getDescription());
		assertEquals(Constants.FAILURE_STATUS, responseDto.getMeta().getStatus());
	}

	@Test
	public void handleInvalidPanNumberTest() {
		ResponseEntity<Object> response = globalExceptionHandler.handleInvalidPanNumber();
		assertNotNull(response);
		assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
		ResponseDTO<?> responseDto = (ResponseDTO) response.getBody();
		assertEquals("pan code", responseDto.getMeta().getCode());
		assertEquals("pan msg", responseDto.getMeta().getDescription());
		assertEquals(Constants.FAILURE_STATUS, responseDto.getMeta().getStatus());
	}

	@Test
	public void handlePanNumberTest() {
		ResponseEntity<Object> response = globalExceptionHandler.handlePanNumber();
		assertNotNull(response);
		assertEquals(HttpStatus.OK, response.getStatusCode());
		ResponseDTO<?> responseDto = (ResponseDTO) response.getBody();
		assertEquals("pan code", responseDto.getMeta().getCode());
		assertEquals("pan msg", responseDto.getMeta().getDescription());
		assertEquals(Constants.FAILURE_STATUS, responseDto.getMeta().getStatus());
	}

	@Test
	public void handlePanVerificationExceptionTest() {
		ESBPanVerificationException exception = new ESBPanVerificationException(Meta.builder().code("custom code").description("custom msg").status(Constants.FAILURE_STATUS).build());
		ErrorCodeMapper mapper = new ErrorCodeMapper();
		mapper.setErrorCode("ESB");
		when(errorCodeMapperService.getErrorCodeByApiNameAndOrgErrorCode(Mockito.any(), Mockito.any())).thenReturn(mapper);
		ResponseEntity<Object> response = globalExceptionHandler.handlePanVerificationException(exception);
		assertNotNull(response);
		assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, response.getStatusCode());
		ResponseDTO<?> responseDto = (ResponseDTO) response.getBody();
		assertEquals("ESB", responseDto.getMeta().getCode());
		assertEquals("esb msg", responseDto.getMeta().getDescription());
		assertEquals(Constants.FAILURE_STATUS, responseDto.getMeta().getStatus());
	}

	@Test
	public void handlePanVerificationExceptionWhenMetaIsNullTest() {
		ESBPanVerificationException exception = new ESBPanVerificationException();
		ErrorCodeMapper mapper = new ErrorCodeMapper();
		mapper.setErrorCode("ESB");
		when(errorCodeMapperService.getErrorCodeByApiNameAndOrgErrorCode(Mockito.any(), Mockito.any())).thenReturn(mapper);
		ResponseEntity<Object> response = globalExceptionHandler.handlePanVerificationException(exception);
		assertNotNull(response);
		assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, response.getStatusCode());
		ResponseDTO<?> responseDto = (ResponseDTO) response.getBody();
		assertEquals("pan code", responseDto.getMeta().getCode());
		assertEquals("pan msg", responseDto.getMeta().getDescription());
		assertEquals(Constants.FAILURE_STATUS, responseDto.getMeta().getStatus());
	}

	@Test
	public void handlePanVerificationExceptionWhenMetaCodeIsNullTest() {
		ESBPanVerificationException exception = new ESBPanVerificationException(Meta.builder().build());
		ErrorCodeMapper mapper = new ErrorCodeMapper();
		mapper.setErrorCode("ESB");
		when(errorCodeMapperService.getErrorCodeByApiNameAndOrgErrorCode(Mockito.any(), Mockito.any())).thenReturn(mapper);
		ResponseEntity<Object> response = globalExceptionHandler.handlePanVerificationException(exception);
		assertNotNull(response);
		assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, response.getStatusCode());
		ResponseDTO<?> responseDto = (ResponseDTO) response.getBody();
		assertEquals("pan code", responseDto.getMeta().getCode());
		assertEquals("pan msg", responseDto.getMeta().getDescription());
		assertEquals(Constants.FAILURE_STATUS, responseDto.getMeta().getStatus());
	}

	@Test
	public void handlePanVerificationExceptionWhenErrorCodeMapperIsNullTest() {
		ESBPanVerificationException exception = new ESBPanVerificationException(Meta.builder().code("custom code").description("custom msg").status(Constants.FAILURE_STATUS).build());
		ErrorCodeMapper mapper = null;
		when(errorCodeMapperService.getErrorCodeByApiNameAndOrgErrorCode(Mockito.any(), Mockito.any())).thenReturn(mapper);
		ResponseEntity<Object> response = globalExceptionHandler.handlePanVerificationException(exception);
		assertNotNull(response);
		assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, response.getStatusCode());
		ResponseDTO<?> responseDto = (ResponseDTO) response.getBody();
		assertEquals("pan code", responseDto.getMeta().getCode());
		assertEquals("pan msg", responseDto.getMeta().getDescription());
		assertEquals(Constants.FAILURE_STATUS, responseDto.getMeta().getStatus());
	}

	@Test
	public void handleConstraintViolationExceptionTest() {
		Set<ConstraintViolation<?>> set = new HashSet<>();
		ConstraintViolationException exception = new ConstraintViolationException(set);
		ResponseEntity<ResponseDTO<?>> response = globalExceptionHandler.handleConstraintViolationException(exception);
		assertNotNull(response);
		assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
		ResponseDTO<?> responseDto = (ResponseDTO) response.getBody();
		assertEquals("validation code", responseDto.getMeta().getCode());
		assertEquals("validation msg", responseDto.getMeta().getDescription());
		assertEquals(Constants.FAILURE_STATUS, responseDto.getMeta().getStatus());
	}

	@Test
	public void handleVerificationExceptionTest() {
		ResponseEntity<Object> response = globalExceptionHandler.handleVerificationException();
		assertNotNull(response);
		assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
		ResponseDTO<?> responseDto = (ResponseDTO) response.getBody();
		assertEquals("identity code", responseDto.getMeta().getCode());
		assertEquals("identity msg", responseDto.getMeta().getDescription());
		assertEquals(Constants.FAILURE_STATUS, responseDto.getMeta().getStatus());
	}

	@Test
	public void handleGenericExceptionTest() {
		GenericException exception = new GenericException();
		ResponseEntity<Object> response = globalExceptionHandler.handleGenericException(exception);
		assertNotNull(response);
		assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, response.getStatusCode());
		ResponseDTO<?> responseDto = (ResponseDTO) response.getBody();
		assertEquals("generic error code", responseDto.getMeta().getCode());
		assertEquals(Constants.FAILURE_STATUS, responseDto.getMeta().getStatus());
	}

	@Test
	public void handleCBSErrorNegativeTest() {
		CBSException exception = new CBSException();
		ResponseEntity<Object> response = globalExceptionHandler.handleCBSError(exception);
		assertNotNull(response);
		assertEquals(HttpStatus.OK, response.getStatusCode());
		ResponseDTO<?> responseDto = (ResponseDTO) response.getBody();
		assertEquals("generic error code", responseDto.getMeta().getCode());
		assertEquals(Constants.FAILURE_STATUS, responseDto.getMeta().getStatus());
	}

	@Test
	public void handleCBSErrorPositiveTest() {
		CBSException exception = new CBSException();
		Meta meta = new Meta();
		exception.setId("12");
		exception.setMeta(meta);
		ResponseEntity<Object> response = globalExceptionHandler.handleCBSError(exception);
		assertNotNull(response);
		assertEquals(HttpStatus.OK, response.getStatusCode());
		ResponseDTO<?> responseDto = (ResponseDTO) response.getBody();
		assertEquals(Constants.SUCCESS_STATUS, responseDto.getMeta().getStatus());
	}

	@Test
	public void customerNotFoundInCBSTest() {
		CustomerNotFoundInCBS exception = new CustomerNotFoundInCBS();
		ResponseEntity<Object> response = globalExceptionHandler.customerNotFoundInCBS(exception);
		assertNotNull(response);
		assertEquals(HttpStatus.OK, response.getStatusCode());
		ResponseDTO<?> responseDto = (ResponseDTO) response.getBody();
		assertEquals("dedupe customer code", responseDto.getMeta().getCode());
		assertEquals("dedupe customer msg", responseDto.getMeta().getDescription());
		assertEquals(Constants.FAILURE_STATUS, responseDto.getMeta().getStatus());
	}

	@Test
	public void handleVerifyAadhaarKUAErrorPositiveTest() {
		AadhaarKUAVerifyException exception = new AadhaarKUAVerifyException();
		Meta meta = new Meta();
		exception.setId("12");
		exception.setMeta(meta);
		ErrorCodeMapper mapper = null;
		when(errorCodeMapperService.getErrorCodeByApiNameAndOrgErrorCode(Mockito.any(), Mockito.any())).thenReturn(mapper);
		ResponseEntity<Object> response = globalExceptionHandler.handleVerifyAadhaarKUAError(exception);
		assertNotNull(response);
		assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, response.getStatusCode());
		ResponseDTO<?> responseDto = (ResponseDTO) response.getBody();
		assertEquals(Constants.FAILURE_STATUS, responseDto.getMeta().getStatus());
	}

	@Test
	public void handleVerifyAadhaarKUAErrorNegativeTest() {
		AadhaarKUAVerifyException exception = new AadhaarKUAVerifyException();
		exception.setId("12");
		ErrorCodeMapper mapper = new ErrorCodeMapper();
		mapper.setErrorCode("ABC");
		mapper.setErrorMsg("Error");
		when(errorCodeMapperService.getErrorCodeByApiNameAndOrgErrorCode(Mockito.any(), Mockito.any())).thenReturn(mapper);
		ResponseEntity<Object> response = globalExceptionHandler.handleVerifyAadhaarKUAError(exception);
		assertNotNull(response);
		assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, response.getStatusCode());
		ResponseDTO<?> responseDto = (ResponseDTO) response.getBody();
		assertEquals("ABC", responseDto.getMeta().getCode());
		assertEquals("Error", responseDto.getMeta().getDescription());
		assertEquals(Constants.FAILURE_STATUS, responseDto.getMeta().getStatus());
	}

	@Test
	public void handleVerifyAadhaarKUAErrorTest() {
		AadhaarKUAVerifyException exception = new AadhaarKUAVerifyException();
		exception.setId("12");
		ErrorCodeMapper mapper = null;
		when(errorCodeMapperService.getErrorCodeByApiNameAndOrgErrorCode(Mockito.any(), Mockito.any())).thenReturn(mapper);
		ResponseEntity<Object> response = globalExceptionHandler.handleVerifyAadhaarKUAError(exception);
		assertNotNull(response);
		assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, response.getStatusCode());
		ResponseDTO<?> responseDto = (ResponseDTO) response.getBody();
		assertEquals("aadhar kua failure code", responseDto.getMeta().getCode());
		assertEquals("aadhar kua failure msg", responseDto.getMeta().getDescription());
		assertEquals(Constants.FAILURE_STATUS, responseDto.getMeta().getStatus());
	}

	@Test
	public void handleVerifyAadhaarKUAErrorEmptyIdTest() {
		AadhaarKUAVerifyException exception = new AadhaarKUAVerifyException();
		ErrorCodeMapper mapper = null;
		when(errorCodeMapperService.getErrorCodeByApiNameAndOrgErrorCode(Mockito.any(), Mockito.any())).thenReturn(mapper);
		ResponseEntity<Object> response = globalExceptionHandler.handleVerifyAadhaarKUAError(exception);
		assertNotNull(response);
		assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, response.getStatusCode());
		ResponseDTO<?> responseDto = (ResponseDTO) response.getBody();
		assertEquals("aadhar kua failure code", responseDto.getMeta().getCode());
		assertEquals("aadhar kua failure msg", responseDto.getMeta().getDescription());
		assertEquals(Constants.FAILURE_STATUS, responseDto.getMeta().getStatus());
	}

	@Test
	public void handleCBSErrorTest() {
		CBSException exception = new CBSException();
		exception.setId("12");
		ResponseEntity<Object> response = globalExceptionHandler.handleCBSError(exception);
		assertNotNull(response);
		assertEquals(HttpStatus.OK, response.getStatusCode());
		ResponseDTO<?> responseDto = (ResponseDTO) response.getBody();
		assertEquals(Constants.FAILURE_STATUS, responseDto.getMeta().getStatus());
	}

	@Test
	public void handleVerifyAadhaarOTPUIDAIErrorPositiveTest() {
		UIDAIAadhaarVerifyException exception = new UIDAIAadhaarVerifyException();
		Meta meta = new Meta();
		exception.setId("12");
		exception.setMeta(meta);
		ErrorCodeMapper mapper = null;
		when(errorCodeMapperService.getErrorCodeByApiNameAndOrgErrorCode(Mockito.any(), Mockito.any())).thenReturn(mapper);
		ResponseEntity<Object> response = globalExceptionHandler.handleVerifyAadhaarOTPUIDAIError(exception);
		assertNotNull(response);
		assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, response.getStatusCode());
		ResponseDTO<?> responseDto = (ResponseDTO) response.getBody();
		assertEquals(Constants.FAILURE_STATUS, responseDto.getMeta().getStatus());
	}

	@Test
	public void handleVerifyAadhaarOTPUIDAIErrorNegativeTest() {
		UIDAIAadhaarVerifyException exception = new UIDAIAadhaarVerifyException();
		exception.setId("12");
		ErrorCodeMapper mapper = new ErrorCodeMapper();
		mapper.setErrorCode("ABC");
		when(errorCodeMapperService.getErrorCodeByApiNameAndOrgErrorCode(Mockito.any(), Mockito.any())).thenReturn(mapper);
		ResponseEntity<Object> response = globalExceptionHandler.handleVerifyAadhaarOTPUIDAIError(exception);
		assertNotNull(response);
		assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, response.getStatusCode());
		ResponseDTO<?> responseDto = (ResponseDTO) response.getBody();
		assertEquals("ABC", responseDto.getMeta().getCode());
		assertEquals(Constants.FAILURE_STATUS, responseDto.getMeta().getStatus());
	}

	@Test
	public void handleVerifyAadhaarOTPUIDAIErrorTest() {
		UIDAIAadhaarVerifyException exception = new UIDAIAadhaarVerifyException();
		exception.setId("12");
		ErrorCodeMapper mapper = null;
		when(errorCodeMapperService.getErrorCodeByApiNameAndOrgErrorCode(Mockito.any(), Mockito.any())).thenReturn(mapper);
		ResponseEntity<Object> response = globalExceptionHandler.handleVerifyAadhaarOTPUIDAIError(exception);
		assertNotNull(response);
		assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, response.getStatusCode());
		ResponseDTO<?> responseDto = (ResponseDTO) response.getBody();
		assertEquals("aadhar uidai failure code", responseDto.getMeta().getCode());
		assertEquals("aadhar uidai failure msg", responseDto.getMeta().getDescription());
		assertEquals(Constants.FAILURE_STATUS, responseDto.getMeta().getStatus());
	}

	@Test
	public void handleVerifyAadhaarOTPUIDAIErrorEmptyIdTest() {
		UIDAIAadhaarVerifyException exception = new UIDAIAadhaarVerifyException();
		ErrorCodeMapper mapper = null;
		when(errorCodeMapperService.getErrorCodeByApiNameAndOrgErrorCode(Mockito.any(), Mockito.any())).thenReturn(mapper);
		ResponseEntity<Object> response = globalExceptionHandler.handleVerifyAadhaarOTPUIDAIError(exception);
		assertNotNull(response);
		assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, response.getStatusCode());
		ResponseDTO<?> responseDto = (ResponseDTO) response.getBody();
		assertEquals("aadhar uidai failure code", responseDto.getMeta().getCode());
		assertEquals("aadhar uidai failure msg", responseDto.getMeta().getDescription());
		assertEquals(Constants.FAILURE_STATUS, responseDto.getMeta().getStatus());
	}

	@Test
	public void handleGenerateAadhaarOTPUIDAIErrorPositiveTest() {
		UIDAIException exception = new UIDAIException();
		Meta meta = new Meta();
		exception.setId("12");
		exception.setMeta(meta);
		ErrorCodeMapper mapper = null;
		when(errorCodeMapperService.getErrorCodeByApiNameAndOrgErrorCode(Mockito.any(), Mockito.any())).thenReturn(mapper);
		ResponseEntity<Object> response = globalExceptionHandler.handleGenerateAadhaarOTPUIDAIError(exception);
		assertNotNull(response);
		assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, response.getStatusCode());
		ResponseDTO<?> responseDto = (ResponseDTO) response.getBody();
		assertEquals(Constants.FAILURE_STATUS, responseDto.getMeta().getStatus());
	}

	@Test
	public void handleGenerateAadhaarOTPUIDAIErrorNegativeTest() {
		UIDAIException exception = new UIDAIException();
		exception.setId("12");
		ErrorCodeMapper mapper = new ErrorCodeMapper();
		mapper.setErrorCode("ABC");
		when(errorCodeMapperService.getErrorCodeByApiNameAndOrgErrorCode(Mockito.any(), Mockito.any())).thenReturn(mapper);
		ResponseEntity<Object> response = globalExceptionHandler.handleGenerateAadhaarOTPUIDAIError(exception);
		assertNotNull(response);
		assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, response.getStatusCode());
		ResponseDTO<?> responseDto = (ResponseDTO) response.getBody();
		assertEquals("ABC", responseDto.getMeta().getCode());
		assertEquals(Constants.FAILURE_STATUS, responseDto.getMeta().getStatus());
	}

	@Test
	public void handleGenerateAadhaarOTPUIDAIErrorTest() {
		UIDAIException exception = new UIDAIException();
		exception.setId("12");
		ErrorCodeMapper mapper = null;
		when(errorCodeMapperService.getErrorCodeByApiNameAndOrgErrorCode(Mockito.any(), Mockito.any())).thenReturn(mapper);
		ResponseEntity<Object> response = globalExceptionHandler.handleGenerateAadhaarOTPUIDAIError(exception);
		assertNotNull(response);
		assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, response.getStatusCode());
		ResponseDTO<?> responseDto = (ResponseDTO) response.getBody();
		assertEquals("generate aadhar uidai failure code", responseDto.getMeta().getCode());
		assertEquals("generate aadhar uidai failure msg", responseDto.getMeta().getDescription());
		assertEquals(Constants.FAILURE_STATUS, responseDto.getMeta().getStatus());
	}

	@Test
	public void handleGenerateAadhaarOTPUIDAIErrorEmptyIdTest() {
		UIDAIException exception = new UIDAIException();
		ErrorCodeMapper mapper = null;
		when(errorCodeMapperService.getErrorCodeByApiNameAndOrgErrorCode(Mockito.any(), Mockito.any())).thenReturn(mapper);
		ResponseEntity<Object> response = globalExceptionHandler.handleGenerateAadhaarOTPUIDAIError(exception);
		assertNotNull(response);
		assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, response.getStatusCode());
		ResponseDTO<?> responseDto = (ResponseDTO) response.getBody();
		assertEquals("generate aadhar uidai failure code", responseDto.getMeta().getCode());
		assertEquals("generate aadhar uidai failure msg", responseDto.getMeta().getDescription());
		assertEquals(Constants.FAILURE_STATUS, responseDto.getMeta().getStatus());
	}

	@Test
	public void handleMethodExceptionInternalTest() {

		Object body = new Object();
		HttpHeaders headers = new HttpHeaders();
		MethodArgumentNotValidException m = new MethodArgumentNotValidException(Mockito.mock(MethodParameter.class),Mockito.mock(BindingResult.class));
		ResponseEntity<Object> response = globalExceptionHandler.handleExceptionInternal(m,body,headers,HttpStatus.OK,Mockito.mock(WebRequest.class));
		assertNotNull(response);
		assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
		ResponseDTO<?> responseDto = (ResponseDTO) response.getBody();
		assertEquals("validation code", responseDto.getMeta().getCode());
		assertEquals("validation msg", responseDto.getMeta().getDescription());
	}

	@Test
	public void handleExceptionInternalTest() {

		Object body = new Object();
		HttpHeaders headers = new HttpHeaders();
		Exception exception = new Exception();
		ResponseEntity<Object> response = globalExceptionHandler.handleExceptionInternal(exception,body,headers,HttpStatus.OK,Mockito.mock(WebRequest.class));
		assertNotNull(response);
		assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, response.getStatusCode());
		ResponseDTO<?> responseDto = (ResponseDTO) response.getBody();
		assertEquals("generic error code", responseDto.getMeta().getCode());
		assertEquals("constant generic error msg", responseDto.getMeta().getDescription());
		assertEquals(Constants.FAILURE_STATUS, responseDto.getMeta().getStatus());
	}

	@Test
	public void handleServletExceptionInternalTest() {

		Object body = new Object();
		HttpHeaders headers = new HttpHeaders();
		Exception exception = new Exception();
		ResponseEntity<Object> response = globalExceptionHandler.handleExceptionInternal(Mockito.mock(ServletRequestBindingException.class),body,headers,HttpStatus.OK,Mockito.mock(WebRequest.class));
		assertNotNull(response);
		assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
		ResponseDTO<?> responseDto = (ResponseDTO) response.getBody();
		assertEquals("config headersMissing errorCode", responseDto.getMeta().getCode());
		assertEquals("config headersMissing errorMessage", responseDto.getMeta().getDescription());
		assertEquals(Constants.FAILURE_STATUS, responseDto.getMeta().getStatus());
	}
}