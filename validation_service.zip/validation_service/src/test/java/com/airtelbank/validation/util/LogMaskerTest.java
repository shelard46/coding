package com.airtelbank.validation.util;

import static org.mockito.Mockito.when;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.airtelbank.validation.config.LogMaskingConfiguration;

public class LogMaskerTest {
	
	@Mock private LogMaskingConfiguration logMaskingConfiguration;
	@InjectMocks private LogMasker logMasker;
	
	@Before
	public void init() {
		MockitoAnnotations.initMocks(this);
	}

	@Test(expected = Test.None.class)
	public void setPatterns() {
		when(logMaskingConfiguration.getPattern()).thenReturn("");
		when(logMaskingConfiguration.getRegex()).thenReturn("");
		logMasker.setPatterns();
	}
}
