package com.airtelbank.validation.util;

import com.aerospike.client.Log;
import com.airtelbank.validation.constants.Constants;
import com.airtelbank.validation.dao.aerospike.model.ErrorCodeMapper;
import com.airtelbank.validation.exception.VaultException;
import com.airtelbank.validation.model.AUARequest;
import com.airtelbank.validation.model.AadhaarVaultResponse;
import com.airtelbank.validation.model.Document;
import com.airtelbank.validation.model.Meta;
import com.airtelbank.validation.model.aadhar.generate.otp.GenerateAadhaarOTPData;
import com.airtelbank.validation.model.cbs.ExtendedReply;
import com.airtelbank.validation.model.cbs.Messages;
import com.airtelbank.validation.model.cbs.MessagesArray;
import com.airtelbank.validation.model.cbs.SessionContext;
import com.airtelbank.validation.model.cbs.TransactionStatus;
import com.airtelbank.validation.model.cbs.ValidationErrors;
import com.airtelbank.validation.service.AadhaarService;
import com.airtelbank.validation.service.ErrorCodeMapperService;
import org.apache.log4j.Level;
import org.json.JSONObject;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.context.MessageSource;
import org.springframework.core.env.Environment;
import org.springframework.web.bind.ServletRequestBindingException;

import javax.xml.bind.JAXBException;
import javax.xml.stream.XMLStreamException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import static org.junit.Assert.*;
import static org.mockito.Mockito.when;

/**
 * @author Chetan Raj
 * @implNote
 * @since : 2020-08-27
 */
public class CommonUtilTest {

    @Mock
    private AadhaarService aadhaarService;

    @Mock
    private Environment environment;

    @InjectMocks
    private CommonUtil commonUtil;

    @Before
    public void init() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void setOtpRequestTypeForAadhaarSuccessTest() {
        Document document = new Document();
        document.setDocNumber("999999999999");
        assertTrue(CommonUtil.setOtpRequestType(document));
    }

    @Test
    public void setOtpRequestTypeForVidSuccessTest() {
        Document document = new Document();
        document.setDocNumber("9999999999999999");
        assertTrue(CommonUtil.setOtpRequestType(document));
    }

    @Test
    public void setOtpRequestTypeForVidOneSuccessTest() {
        Document document = new Document();
        document.setDocNumber("99999999999999999");
        assertFalse(CommonUtil.setOtpRequestType(document));
    }

    @Test
    public void setOtpRequestTypeForVidExceptionTest() {
        assertFalse(CommonUtil.setOtpRequestType(null));
    }

    @Test
    public void setOtpRequestTypeFailedTest() {
        Document document = new Document();
        document.setDocNumber("999999999999999978787");
        assertFalse(CommonUtil.isAadhaarRequest(document));
    }

    @Test
    public void setOtpRequestTypeExceptionTest() {
        assertFalse(CommonUtil.isAadhaarRequest(new Document()));
    }


    @Test
    public void isAadhaarRequestDocumentSuccessTest() {
        Document document = new Document();
        document.setUserIdentifierType(Constants.AADHAAR_IDENTIFIER);
        assertTrue(CommonUtil.isAadhaarRequest(document));
    }

    @Test
    public void isAadhaarRequestDocumentFailedTest() {
        Document document = new Document();
        document.setUserIdentifierType(Constants.VID_IDENTIFIER);
        assertFalse(CommonUtil.isAadhaarRequest(document));
    }

    @Test
    public void isAadhaarRequestDocumentExceptionTest() {
        assertFalse(CommonUtil.isAadhaarRequest(new Document()));
    }

    @Test
    public void isVidRequestDocumentSuccessTest() {
        Document document = new Document();
        document.setUserIdentifierType(Constants.VID_IDENTIFIER);
        assertTrue(CommonUtil.isVidRequest(document));
    }

    @Test
    public void isVidRequestDocumentFailedTest() {
        Document document = new Document();
        document.setUserIdentifierType(Constants.AADHAAR_IDENTIFIER);
        assertFalse(CommonUtil.isVidRequest(document));
    }

    @Test
    public void isVidRequestDocumentExceptionTest() {
        assertFalse(CommonUtil.isVidRequest(new Document()));
    }

    @Test
    public void isAadhaarRequestSuccessTest() {
        assertTrue(CommonUtil.isAadhaarRequest(Constants.AADHAAR_IDENTIFIER));
    }

    @Test
    public void isAadhaarRequestFailedTest() {
        assertFalse(CommonUtil.isAadhaarRequest(Constants.VID_IDENTIFIER));
    }

    @Test
    public void isAadhaarRequestExceptionTest() {
        assertFalse(CommonUtil.isAadhaarRequest(new String()));
    }

    @Test
    public void isAadhaarRequestFailedIITest() {
        assertFalse(CommonUtil.isAadhaarRequest((String) null));
    }

    @Test
    public void isVidRequestSuccessTest() {
        assertTrue(CommonUtil.isVidRequest(Constants.VID_IDENTIFIER));
    }

    @Test
    public void isVidRequestFailedTest() {
        assertFalse(CommonUtil.isVidRequest(Constants.AADHAAR_IDENTIFIER));
    }

    @Test
    public void isVidRequestExceptionTest() {
        assertFalse(CommonUtil.isVidRequest(new String()));
    }

    @Test
    public void isVidRequestExceptionOneTest() {
        assertFalse(CommonUtil.isVidRequest((String) null));
    }

    @Test
    public void createSessionContextSuccessTest() {
        String bankCode = "APB";
        String serviceCode = "A014";
        String transactionBranch = "TEST";
        String channel = "ANDROID";
        SessionContext finalSessionContext = CommonUtil.createSessionContext(bankCode, serviceCode, transactionBranch, channel);
        SessionContext expectedSessionContext = new SessionContext(serviceCode, bankCode, transactionBranch, channel, "8737474747474", "jlakdjf084758498758");
        assertEquals(expectedSessionContext.getServiceCode(), finalSessionContext.getServiceCode());
    }

    @Test
    public void createSessionContextFailureTest() {
        String bankCode = "APB";
        String serviceCode = "A014";
        String transactionBranch = "TEST";
        String channel = "ANDROID";
        SessionContext finalSessionContext = CommonUtil.createSessionContext(bankCode, serviceCode, transactionBranch, channel);
        SessionContext expectedSessionContext = new SessionContext("A012", bankCode, transactionBranch, channel, "8737474747474", "jlakdjf084758498758");
        assertNotEquals(expectedSessionContext.getServiceCode(), finalSessionContext.getServiceCode());
    }

    @Test
    public void getCBSReferenceNotNullTest() {
        assertNotNull(CommonUtil.getCBSReference());
    }

    @Test
    public void getChannelWebSuccessTest() throws ServletRequestBindingException {
        String expectedChannel = "WEB";
        String finalChannel = CommonUtil.getChannel(null);
        assertEquals(expectedChannel, finalChannel);
    }
    
    @Test
    public void getChannelWhenNotBlankTest() throws ServletRequestBindingException {
        String expectedChannel = "IOS";
        String finalChannel = CommonUtil.getChannel("AppName/version,IOS/OS_version, deviceName/Model, density");
        assertEquals(expectedChannel, finalChannel);
    }

    @Test
    public void infoPrefixSuffixSuccessTest() {
        String message = "message";
        String expectedMessage = Constants.INFO_MSG_PREFIX + message + Constants.INFO_MSG_SUFFIX;
        String finalMessage = CommonUtil.infoPrefixSuffix(message);
        assertEquals(expectedMessage, finalMessage);
    }
    
    @Test
    public void infoPrefixSuffixNullTest() {
        String message = null;
        String expectedMessage = null;
        String finalMessage = CommonUtil.infoPrefixSuffix(message);
        assertEquals(expectedMessage, finalMessage);
    }

    @Test
    public void infoPrefixSuffixFailureTest() {
        String message = "message";
        String expectedMessage = Constants.INFO_MSG_PREFIX + message;
        String finalMessage = CommonUtil.infoPrefixSuffix(message);
        assertNotEquals(expectedMessage, finalMessage);
    }
    
    @Test(expected = Test.None.class)
    public void setMDCMapWhenNotNull() {
    	String contentId = "contentId";
    	String channel = "RAPP";
    	String customerId = "9876543210";
    	String apiId = "KUA";
    	CommonUtil.setMDCMap(contentId, channel, customerId, apiId);
    }
    
    @Test(expected = Test.None.class)
    public void setMDCMapWhenNull() {
    	String contentId = null;
    	String channel = null;
    	String customerId = null;
    	String apiId = null;
    	CommonUtil.setMDCMap(contentId, channel, customerId, apiId);
    }

    @Test
    public void trimCustomerIdSuccessTest() {
        String customerId = "9898989898";
        String result = CommonUtil.trimCustomerId(customerId);
        assertEquals(customerId, result);
    }

    @Test
    public void trimCustomerIdWithDLTest() {
        String customerId = "9898989898DL";
        String result = CommonUtil.trimCustomerId(customerId);
        assertEquals(customerId, result);
    }

    @Test
    public void trimCustomerIdWithLength11SuccessTest() {
        String customerId = "09898989898";
        String result = CommonUtil.trimCustomerId(customerId);
        assertEquals("9898989898", result);
    }

    @Test
    public void trimCustomerIdWithLength12SuccessTest() {
        String customerId = "919898989898";
        String result = CommonUtil.trimCustomerId(customerId);
        assertEquals("9898989898", result);
    }

    // This test is showing that written function is wrong.
    // Have to change the existing function.
    @Test
    public void trimCustomerIdWithLengthGreaterThan12SuccessTest() {
        String customerId = "000000919898989898";
        String result = CommonUtil.trimCustomerId(customerId);
        assertEquals(customerId, result);
    }

    @Test
    public void maskedMobileNumberTest() {
        String customerId = "******3456";
        String mobileNumber = "3456";
        String result = CommonUtil.maskedMobileNumber(mobileNumber);
        assertEquals(customerId, result);
    }

    @Test
    public void getDOBTest() {
        Date dateValue = null;
        String inputparam = "";
        Date result = CommonUtil.getDateDOB(inputparam);
        assertEquals(dateValue, result);
    }

    @Test
    public void getDOBSuccessTest() {
        String inputparam = "2021-05-04";
        Date result = CommonUtil.getDateDOB(inputparam);
        assertNotNull(result);
    }

    @Test
    public void getDOBExceptionTest() {
        String inputparam = "202105-04";
        Date result = CommonUtil.getDateDOB(inputparam);
        assertNotNull(result);
    }

    @Test
    public void getDOBTestNotEqual() {
        Date d = new java.util.Date(1992, 12, 11);
        String inputparam = "19921211";
        Date result = CommonUtil.getDateDOB(inputparam);
        assertNotEquals(d, result);
    }

    @Test
    public void dateToStringTest() {
        Date d = new Date();
        String format = ("yyyy-MM-dd");
        String str = CommonUtil.dateToString(d, format);
        assertNotNull(str);
    }

    @Test
    public void isEmptyTest() {
        String string = "";
        Boolean status = CommonUtil.isEmpty(string);
        assertTrue(status);
    }
    
    @Test
    public void isEmptyTest2() {
        String string = null;
        Boolean status = CommonUtil.isEmpty(string);
        assertTrue(status);
    }

    @Test
    public void isNotEmptyTest() {
        String string = "ABC";
        Boolean status = CommonUtil.isEmpty(string);
        assertFalse(status);
    }

    @Test
    public void getValueByDefaultPositiveTest() {
        String value = "Test";
        String defaultval = "Default";
        String result = CommonUtil.getValueByDefault(value, defaultval);
        assertEquals(result, value);
    }

    @Test
    public void getValueByDefaultNegativeTest() {
        String value = "";
        String defaultval = "Default";
        String result = CommonUtil.getValueByDefault(value, defaultval);
        assertEquals(result, defaultval);
    }

    @Test
    public void getDateTimeEmptyTest() {
        String value = "";
        LocalDateTime l = CommonUtil.getDateTime(value);
        assertNull(l);
    }

    @Test
    public void getDateTimeNotNullTest() {
        String value = "2012-02-22T02:06:58";
        LocalDateTime l = CommonUtil.getDateTime(value);
        assertNotNull(l);
    }

    @Test
    public void getDateTimeNullTest() {
        String value = null;
        LocalDateTime l = CommonUtil.getDateTime(value);
        assertNull(l);
    }


    @Test
    public void getDateDobEmptyTest() {
        String value = "";
        LocalDate l = CommonUtil.getLocalDateDob(value);
        assertNull(l);
    }

    @Test
    public void getDateDobNotNullTest() {
        String value = "2012-02-22";
        LocalDate l = CommonUtil.getLocalDateDob(value);
        assertNotNull(l);
    }

    @Test
    public void getDateDobNullTest() {
        String value = null;
        LocalDate l = CommonUtil.getLocalDateDob(value);
        assertNull(l);
    }

    @Test
    public void getDateDobAuaEmptyTest() {
        String value = "";
        LocalDate l = CommonUtil.getDateDobAua(value);
        assertNull(l);
    }
    
    @Test
    public void getDateDobAuaNullTest() {
        String value = null;
        LocalDate l = CommonUtil.getDateDobAua(value);
        assertNull(l);
    }

    @Test
    public void getDateDobAuaNotNullTest() {
        String value = "22-02-2202";
        LocalDate l = CommonUtil.getDateDobAua(value);
        assertNotNull(l);
    }

    @Test
    public void getDateTimeNullCheckTest() {
        LocalDateTime localDateTime = null;
        Date l = CommonUtil.getDateTime(localDateTime);
        assertNull(l);
    }

    @Test
    public void getDateTimeNotNullCheckTest() {
        LocalDateTime localDateTime = LocalDateTime.now();
        Date l = CommonUtil.getDateTime(localDateTime);
        assertNotNull(l);
    }

    @Test
    public void getDateNullCheckTest() {
        String value = "";
        Date l = CommonUtil.getDate(value);
        assertNull(l);
    }

    @Test
    public void getDateNotNullCheckTest() {
        String value = "22-02-2202";
        Date l = CommonUtil.getDate(value);
        assertNotNull(l);
    }

    @Test
    public void createMetaTest() {
        String errorCode = "Fatal";
        String description = "Error";
        int status = 0;
        Meta l = CommonUtil.createMeta(errorCode, description, status);
        Meta m = new Meta();
        m.setCode(errorCode);
        m.setDescription(description);
        m.setStatus(status);
        assertEquals(m.getCode(), l.getCode());
        assertEquals(m.getDescription(), l.getDescription());
        assertEquals(m.getStatus(), l.getStatus());
    }

    @Test
    public void isUpgradeWalletActionNegativeTest() {
        assertFalse(CommonUtil.isUpgradeWalletAction(""));
    }

    @Test
    public void isUpgradeWalletActionPositiveTest() {
        assertTrue(CommonUtil.isUpgradeWalletAction(Constants.UPGRADE_ACTION));
    }

    @Test
    public void isUpgradeWalletActionNegativeIITest() {
        assertFalse(CommonUtil.isUpgradeWalletAction("test"));
    }

    @Test
    public void generateDataToEncryptTest() {
        String vid = "AirtelMoneyWallet";
        String mobile = "98979694";
        String expected = "AirtelMo98979694neyWalle";
        String result = CommonUtil.generateDataToEncrypt(vid, mobile);
        assertEquals(expected, result);
    }

    @Test
    public void convertToObjectFromXMLInJAXBTest() throws JAXBException, XMLStreamException {
        String xml = "<getCustomerAadhaarOTPResMsg><ebmHeader><lob>Mobility</lob><consumerTransactionId>20160613151405</consumerTransactionId><consumerName>APBL</consumerName><programmeName>AadhaarOTPKYC</programmeName></ebmHeader><dataArea><getCustomerAadhaarOTPResponse><status><statusCode>GetCustomerAadhaarOTP-0001-S</statusCode><statusDescription>AadhaarProfiledetailsfound</statusDescription></status><responseCode>09d189368f364b7a972ac39ebaae2559</responseCode><responseTimeStamp>2016-05-23T15:15:10</responseTimeStamp><mobileNumber>1234567890</mobileNumber><email>test@gmail.com</email><userIdentifierType>V</userIdentifierType></getCustomerAadhaarOTPResponse></dataArea></getCustomerAadhaarOTPResMsg>";
        GenerateAadhaarOTPData result = CommonUtil.convertToObjectFromXMLInJAXB(xml, GenerateAadhaarOTPData.class);
        String expected = "20160613151405";
        assertEquals(expected, result.getEbmHeader().getConsumerTransactionId());
    }

    @Test
    public void generateDataAfterDecryptTest() {
        String vid = "AirtelMoneyWalletMobileApplication";
        String expected = "AirtelMoobileApp";
        String result = CommonUtil.generateDataAfterDecrypt(vid);
        assertEquals(expected, result);

    }

    @Test
    public void encryptDataTest() throws Exception {
        String vid = "AirtelMoneyWalletMobileApplicati";
        String mobile = "9897969412341234";
        String expected = "3t1Pb2N274lZZWe9dmwnYMppPkc6lL076oWDx6FtH7Fia6F6BeH7tAUPmSdhgWZQ";
        String result = CommonUtil.encryptData(vid, mobile);
        assertEquals(expected, result);
    }

    @Test
    public void isEmptyTestSuccess() {
        boolean result = CommonUtil.isEmpty("test");
        assertFalse(result);
    }

    @Test
    public void formatTimestampPatternTest() {
        String ds = CommonUtil.formatTimestampPattern(new Date());
        assertNotNull(ds);
    }

    @Test
    public void jsonObjectToString() {
        String result = CommonUtil.jsonObjectToString(new JSONObject());
        assertNotNull(result);
    }
    
    @Test
    public void jsonObjectToStringWhenEx() {
        String result = CommonUtil.jsonObjectToString(new Throwable());
        assertNotNull(result);
    }

    @Test(expected = VaultException.class)
    public void getAadhaarNumberFromReferenceNumberException() {
        CommonUtil.getAadhaarNumberFromReferenceNumber(null, aadhaarService, environment);
    }

    @Test(expected = VaultException.class)
    public void getAadhaarNumberFromReferenceNumberExceptionII() {
        Mockito.when(environment.getProperty("aadhaarVault.apikey")).thenReturn("test");
        Mockito.when(aadhaarService.getAadhaarNumber(Mockito.any())).thenReturn(AadhaarVaultResponse.builder().build());
        CommonUtil.getAadhaarNumberFromReferenceNumber(Document.builder().docNumber("123456789012").build(), aadhaarService, environment);
    }

    @Test(expected = VaultException.class)
    public void getAadhaarNumberFromReferenceNumberExceptionIII() {
        Mockito.when(environment.getProperty("aadhaarVault.apikey")).thenReturn("test");
        Mockito.when(aadhaarService.getAadhaarNumber(Mockito.any())).thenReturn(null);
        CommonUtil.getAadhaarNumberFromReferenceNumber(Document.builder().docNumber("123456789012").build(), aadhaarService, environment);
    }

    @Test(expected = VaultException.class)
    public void getAadhaarReferenceNumberFromAadhaarException() {
        Mockito.when(environment.getProperty("aadhaarVault.apikey")).thenReturn("test");
        Mockito.when(aadhaarService.getAadhaarNumber(Mockito.any())).thenThrow(new RuntimeException());
        CommonUtil.getAadhaarReferenceNumberFromAadhaar("123456789012", aadhaarService, environment);

    }

    @Test
    public void setErrorCodeSuccessTest() {
        MessageSource messageSource = Mockito.mock(MessageSource.class);
        ErrorCodeMapperService errorCodeMapperService = Mockito.mock(ErrorCodeMapperService.class);
        Mockito.when(messageSource.getMessage(Mockito.any(), Mockito.any(), Mockito.any())).thenReturn("test");
        Mockito.when(errorCodeMapperService.getErrorCodeByApiNameAndOrgErrorCode(Mockito.any(),
                Mockito.any())).thenReturn(ErrorCodeMapper.builder().errorCode("test").build());
        Meta result = CommonUtil.setErrorCode(Meta.builder().build(), "test", errorCodeMapperService, messageSource);
        assertNotNull(result);
    }
    
    @Test
    public void setErrorCodeMetaNullTest() {
        MessageSource messageSource = Mockito.mock(MessageSource.class);
        ErrorCodeMapperService errorCodeMapperService = Mockito.mock(ErrorCodeMapperService.class);
        Mockito.when(messageSource.getMessage(Mockito.any(), Mockito.any(), Mockito.any())).thenReturn("test");
        Mockito.when(errorCodeMapperService.getErrorCodeByApiNameAndOrgErrorCode(Mockito.any(),
                Mockito.any())).thenReturn(ErrorCodeMapper.builder().errorCode("test").build());
        Meta result = CommonUtil.setErrorCode(null, "test", errorCodeMapperService, messageSource);
        assertNull(result);
    }

    @Test
    public void setErrorCodeSuccessIITest() {
        MessageSource messageSource = Mockito.mock(MessageSource.class);
        ErrorCodeMapperService errorCodeMapperService = Mockito.mock(ErrorCodeMapperService.class);
        Mockito.when(messageSource.getMessage(Mockito.any(), Mockito.any(), Mockito.any())).thenReturn("test");
        Mockito.when(errorCodeMapperService.getErrorCodeByApiNameAndOrgErrorCode(Mockito.any(),
                Mockito.any())).thenReturn(null);
        Meta result = CommonUtil.setErrorCode(Meta.builder().build(), "test", errorCodeMapperService, messageSource);
        assertNotNull(result);
    }

    @Test(expected = Test.None.class)
    public void encryptAndPrintInfoTest() {
        CommonUtil.encryptAndPrint(Level.INFO, "test", "test", "test");
    }
    
    @Test(expected = Test.None.class)
    public void encryptAndPrintInfoWhenEmptyObjectTest() {
    	AUARequest auaRequest = null;
        CommonUtil.encryptAndPrint(Level.INFO, "test", auaRequest, "test");
    }
    
    @Test(expected = Test.None.class)
    public void encryptAndPrintInfoWhenInfoTrace() {
    	AUARequest auaRequest = AUARequest.builder().build();
        CommonUtil.encryptAndPrint(Level.INFO, "test", auaRequest, "test");
    }
    
    @Test(expected = Test.None.class)
    public void encryptAndPrintInfoWhenDebugTest() {
    	AUARequest auaRequest = AUARequest.builder().build();
        CommonUtil.encryptAndPrint(Level.DEBUG, "test", auaRequest, "test");
    }
    
    @Test(expected = Test.None.class)
    public void encryptAndPrintInfoWhenWarnTest() {
    	AUARequest auaRequest = AUARequest.builder().build();
        CommonUtil.encryptAndPrint(Level.WARN, "test", auaRequest, "test");
    }

    @Test(expected = Test.None.class)
    public void encryptAndPrintSDebugTest() {
        CommonUtil.encryptAndPrint(Level.DEBUG, "test", "test", "test");
    }

    @Test(expected = Test.None.class)
    public void encryptAndPrintSWarnTest() {
        CommonUtil.encryptAndPrint(Level.WARN, "test", "test", "test");
    }

    @Test(expected = Test.None.class)
    public void decryptAndPrintInfoTest() {
        CommonUtil.decryptAndPrint(Level.INFO, "test", "test", "test");
    }

    @Test(expected = Test.None.class)
    public void decryptAndPrintSDebugTest() {
        CommonUtil.decryptAndPrint(Level.DEBUG, "test", "test", "test");
    }

    @Test(expected = Test.None.class)
    public void decryptAndPrintSWarnTest() {
        CommonUtil.decryptAndPrint(Level.WARN, "test", "test", "test");
    }
    
    @Test(expected = Test.None.class)
    public void decryptAndPrintSWarnTestWhenNull() {
    	AUARequest auaRequest = null;
        CommonUtil.decryptAndPrint(Level.WARN, "test", auaRequest, "test");
    }

    @Test
    public void decryptLogsTest() {
        String result = CommonUtil.decryptLogs("AirtelMoneyWalletMobileApplicati", "9897969412341234");
        assertNull(result);
    }
    
    @Test
    public void decryptLogsSit() {
    	String str = "5TUkhwwJ2sgdwdASK525Sng6TjqHWYJV7V8733juymdd9bcw7W1Q42m8UvkXQOqfws6wQ32kqXPlASZcvTt4LDpAuEY+9Ge9RcS1lk1Q5Kl9y4T6iwE9kYRpGjt+zxl0w2xKmqv7WXz46Pa/AGLiZfsBkTl4VcPILSC8t6YKVY2dbkKTnimmj/aYC94UBhfX7ejIoREascCbJsBBMEFhkNvf18C3zu5yBmp0+SMh2lA=";
    	String passphrase = "MFwwDQYJKoZIhvcNAQEBBQADSwAwSAJBAJlCGtRv12B7BRvS42CMg581EJ8/j+0ezayahBGw8ces0k234e/UYvb5R+PjjwvtEUe1eDwl8gmdelOl6Zx0z/kCAwEAAQ==";
        String result = CommonUtil.decryptLogs(str, passphrase);
        System.out.println(result);
        assertNotNull(result);
    }

    @Test
    public void encryptLogsTest() {
        String result = CommonUtil.encryptLogs("AirtelMoneyWalletMobileApplicati", "9897969412341234");
        assertEquals("ZQVgjRHTtDDNxD1MCaLZ5gkeAwhDuiuZibfXvO6Nhr/iZW4pVlNLtlj/td7uMvU8", result);
    }

    @Test
    public void encryptLogsExceptionTest() {
        String result = CommonUtil.encryptLogs(null, null);
        assertNull(result);
    }
    
    @Test
    public void maskAadhaar() {
        String result = CommonUtil.maskedAadhaarNumber("123456789012");
        assertNotNull(result);
        assertEquals("aadhaar XXXXXXXX9012", result);
    }
    
    @Test
    public void maskVid() {
        String result = CommonUtil.maskedAadhaarNumber("1234567890123456");
        assertNotNull(result);
        assertEquals("vid XXXXXXXXXXXX3456", result);
    }
    
    @Test
    public void maskUidToken() {
        String result = CommonUtil.maskedAadhaarNumber("asdf1234sgfsgh56789dfs0123hrey456");
        assertNotNull(result);
        assertEquals("aadhaar ", result);
    }

    
    @Test (expected = Test.None.class)
    public void retrieveCBSErrorDetailsWhenListNotNull() {
    	TransactionStatus txnStatus = new TransactionStatus();
    	List<ValidationErrors> validationErrors = new ArrayList<>();
    	ValidationErrors validationError = new ValidationErrors();
    	validationError.setErrorCode("code");
    	validationError.setErrorMessage("msg");
    	validationErrors.add(validationError);
    	txnStatus.setValidationErrorsList(validationErrors);
    	CommonUtil.retrieveCBSErrorDetails(txnStatus);
    }
    
    @Test (expected = Test.None.class)
    public void retrieveCBSErrorDetailsWhenListNull() {
    	TransactionStatus txnStatus = new TransactionStatus();
    	List<ValidationErrors> validationErrors = null;
    	txnStatus.setValidationErrorsList(validationErrors);
    	CommonUtil.retrieveCBSErrorDetails(txnStatus);
    }
    
    @Test (expected = Test.None.class)
    public void retrieveCBSErrorDetailsWhenListEmpty() {
    	TransactionStatus txnStatus = new TransactionStatus();
    	List<ValidationErrors> validationErrors = new ArrayList<>();
    	txnStatus.setValidationErrorsList(validationErrors);
    	CommonUtil.retrieveCBSErrorDetails(txnStatus);
    }
    
    @Test (expected = Test.None.class)
    public void retrieveCBSErrorDetailsWhenMessageListNotEmpty() {
    	TransactionStatus txnStatus = new TransactionStatus();
    	Messages message = new Messages();
    	message.setCode("code");
    	message.setMessage("msg");
    	List<Messages> messages = new ArrayList<>();
    	messages.add(message);
    	MessagesArray messagesArray = new MessagesArray();
    	messagesArray.setMessagesList(messages);
    	ExtendedReply extendedReply = new ExtendedReply();
    	extendedReply.setMessagesArray(messagesArray);
    	txnStatus.setExtendedReply(extendedReply);
    	CommonUtil.retrieveCBSErrorDetails(txnStatus);
    }
    
    @Test (expected = Test.None.class)
    public void retrieveCBSErrorDetailsWhenMessageListEmpty() {
    	TransactionStatus txnStatus = new TransactionStatus();
    	List<Messages> messages = new ArrayList<>();
    	MessagesArray messagesArray = new MessagesArray();
    	messagesArray.setMessagesList(messages);
    	ExtendedReply extendedReply = new ExtendedReply();
    	extendedReply.setMessagesArray(messagesArray);
    	txnStatus.setExtendedReply(extendedReply);
    	CommonUtil.retrieveCBSErrorDetails(txnStatus);
    }
    
    @Test (expected = Test.None.class)
    public void retrieveCBSErrorDetailsWhenMessageListIsNull() {
    	TransactionStatus txnStatus = new TransactionStatus();
    	MessagesArray messagesArray = new MessagesArray();
    	ExtendedReply extendedReply = new ExtendedReply();
    	extendedReply.setMessagesArray(messagesArray);
    	txnStatus.setExtendedReply(extendedReply);
    	CommonUtil.retrieveCBSErrorDetails(txnStatus);
    }
    
    @Test (expected = Test.None.class)
    public void retrieveCBSErrorDetailsWhenMessageArrayIsNull() {
    	TransactionStatus txnStatus = new TransactionStatus();
    	MessagesArray messagesArray = null;
    	ExtendedReply extendedReply = new ExtendedReply();
    	extendedReply.setMessagesArray(messagesArray);
    	txnStatus.setExtendedReply(extendedReply);
    	CommonUtil.retrieveCBSErrorDetails(txnStatus);
    }
    
    @Test (expected = Test.None.class)
    public void retrieveCBSErrorDetailsWhenExtendedReplyIsNull() {
    	TransactionStatus txnStatus = new TransactionStatus();
    	ExtendedReply extendedReply = null;
    	txnStatus.setExtendedReply(extendedReply);
    	CommonUtil.retrieveCBSErrorDetails(txnStatus);
    }
    
}

