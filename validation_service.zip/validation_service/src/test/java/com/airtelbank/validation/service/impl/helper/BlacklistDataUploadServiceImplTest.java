package com.airtelbank.validation.service.impl.helper;

import com.airtelbank.validation.service.impl.BlacklistDataUploadServiceImpl;
import com.airtelbank.validation.util.BlackListEntityUtil;
import lombok.extern.slf4j.Slf4j;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.util.ReflectionTestUtils;


import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.times;


@RunWith(SpringRunner.class)
@Slf4j
public class BlacklistDataUploadServiceImplTest {

	@InjectMocks
	BlacklistDataUploadServiceImpl blacklistDataUploadService;

	@Mock
	BlackListEntityUtil blackListEntityUtil;

	@Before
	public void init() {
		MockitoAnnotations.initMocks(this);
	}

	@Test
	public void testUpload() throws Exception {
		String filePath = "src/test/resources/files/test_sample.csv";
		ReflectionTestUtils.setField(blackListEntityUtil, "esClusterName", "elasticsearch");
		ReflectionTestUtils.setField(blackListEntityUtil, "matchPercentage", "100%");
		doNothing().when(blackListEntityUtil).addIndexes(Mockito.any(),Mockito.any());
		blacklistDataUploadService.upload(filePath);
		verify(this.blackListEntityUtil, times(1)).addIndexes(Mockito.any(),Mockito.any());
	}
}
