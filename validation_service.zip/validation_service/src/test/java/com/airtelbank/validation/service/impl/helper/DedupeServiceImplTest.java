package com.airtelbank.validation.service.impl.helper;

import com.airtelbank.validation.constants.Constants;
import com.airtelbank.validation.exception.ThirdPartyApiException;
import com.airtelbank.validation.model.CBSDedupeRequest;
import com.airtelbank.validation.model.DedupeRequest;
import com.airtelbank.validation.model.DedupeResponse;
import com.airtelbank.validation.model.ResponseDTO;
import com.airtelbank.validation.model.cbs.DedupeResponseFromCBS;
import com.airtelbank.validation.model.posidex.customer.CustomerResponse;
import com.airtelbank.validation.service.ErrorCodeMapperService;
import com.airtelbank.validation.service.impl.DedupeServiceImpl;
import com.airtelbank.validation.util.HttpUtil;
import com.airtelbank.validation.util.LogMasker;
import com.airtelbank.validation.util.PosidexClient;
import com.airtelbank.validation.util.RuleExecutor;
import lombok.extern.slf4j.Slf4j;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.context.MessageSource;
import org.springframework.core.env.Environment;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.util.ReflectionTestUtils;

import java.io.IOException;

@RunWith(SpringRunner.class)
@Slf4j
public class DedupeServiceImplTest {

    @Mock
    HttpUtil httpUtil;

    @Mock
    Environment environment;

    @Mock
    private PosidexClient posidexClient;

    @Mock
    private RuleExecutor ruleEngine;

    @Mock
    private MessageSource messageSource;

    @Mock
    private ErrorCodeMapperService errorCodeMapperService;

    @Mock
    private LogMasker logMasker;

    @InjectMocks
    private DedupeServiceImpl dedupeServiceImpl;

    @Before
    public void init(){
        MockitoAnnotations.initMocks(this);
        ReflectionTestUtils.setField(dedupeServiceImpl, "defaultPartnerId", "PAYMENTSBANK");
        ReflectionTestUtils.setField(dedupeServiceImpl, "posidexUrl", "http://10.56.110.156:8090/CustomerWS/PosidexService");
        ReflectionTestUtils.setField(dedupeServiceImpl, "posidexProfileId", 8);
        ReflectionTestUtils.setField(dedupeServiceImpl, "cbsUrl", "http://10.56.110.186:8022/NBWebClient/fcrjappinterface");
        ReflectionTestUtils.setField(dedupeServiceImpl, "bankCode", "753");
        ReflectionTestUtils.setField(dedupeServiceImpl, "transactionBranch", "9999");
        ReflectionTestUtils.setField(dedupeServiceImpl, "cbsDedupeServiceCode", "A022");
    }

    @Test
    public void fullKycDedupeTest(){
        Mockito.when(posidexClient.findCustomers(Mockito.any(DedupeRequest.class), Mockito.anyString() , Mockito.anyString(), Mockito.anyInt(), Mockito.anyString())).thenReturn(getStubCustomerResponse());
        Mockito.when(ruleEngine.applyRules(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(DedupeResponse.builder().errorCode("test").message("test").status(123).build());
        ResponseDTO<DedupeResponse> response = dedupeServiceImpl.fullKycDedupe(getStubDedupeRequest(Constants.UPGRADE_ACTION), "test");
        Assert.assertEquals(123,response.getMeta().getStatus());
    }

    @Test
    public void fullKycDedupeTestII(){
        Mockito.when(posidexClient.findCustomers(Mockito.any(DedupeRequest.class), Mockito.anyString() , Mockito.anyString(), Mockito.anyInt(), Mockito.anyString())).thenReturn(getStubCustomerResponse());
        Mockito.when(ruleEngine.applyRules(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(DedupeResponse.builder().errorCode("test").message("test").status(123).build());
        ResponseDTO<DedupeResponse> response = dedupeServiceImpl.fullKycDedupe(getStubDedupeRequest("test"), "test");
        Assert.assertEquals(123,response.getMeta().getStatus());
    }

    @Test(expected = ThirdPartyApiException.class)
    public void fullKycDedupeTestException(){
        Mockito.when(posidexClient.findCustomers(Mockito.any(DedupeRequest.class), Mockito.anyString() , Mockito.anyString(), Mockito.anyInt(), Mockito.anyString())).thenReturn(null);
        Mockito.when(ruleEngine.applyRules(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(DedupeResponse.builder().errorCode("test").message("test").status(123).build());
        dedupeServiceImpl.fullKycDedupe(getStubDedupeRequest("test"), "test");
    }

    @Test
    public void checkCbsDedupeTest() throws IOException {
        Mockito.when(httpUtil.sendRequest(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any())).thenReturn("<Response><TransactionStatus><ErrorCode>test</ErrorCode><ExternalReferenceNo>test</ExternalReferenceNo><IsOverriden>false</IsOverriden><IsServiceChargeApplied>false</IsServiceChargeApplied><ReplyCode>1</ReplyCode><ReplyText>test</ReplyText></TransactionStatus><DedupeStatus>0</DedupeStatus><dedupeErrorDesc>test</dedupeErrorDesc><CustomerDedupeDetailsDTOArray><CustomerDedupeDetailsDTO><CustomerId>test</CustomerId><NationalIdentificationCode>test</NationalIdentificationCode><FirstName>test</FirstName><LastName>test</LastName><OfficerID>test</OfficerID><Sex>Male</Sex><AadhrNo>123456789012</AadhrNo><MobileNumber>1234567890</MobileNumber><EmailAddress>test@gmail.com</EmailAddress></CustomerDedupeDetailsDTO></CustomerDedupeDetailsDTOArray></Response>");
        ResponseDTO<DedupeResponseFromCBS> response = (ResponseDTO<DedupeResponseFromCBS>) dedupeServiceImpl.checkCbsDedupe(getStubCBSDedupeRequest(), "test");
        Assert.assertNotNull(response);
    }

    @Test
    public void checkCbsDedupeTestII() throws IOException {
        Mockito.when(httpUtil.sendRequest(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any())).thenReturn("<Response><TransactionStatus><ErrorCode>test</ErrorCode><ExternalReferenceNo>test</ExternalReferenceNo><IsOverriden>false</IsOverriden><IsServiceChargeApplied>false</IsServiceChargeApplied><ReplyCode>1</ReplyCode><ReplyText>test</ReplyText></TransactionStatus><DedupeStatus>0</DedupeStatus><dedupeErrorDesc>test</dedupeErrorDesc><CustomerDedupeDetailsDTOArray></CustomerDedupeDetailsDTOArray></Response>");
        ResponseDTO<DedupeResponseFromCBS> response = (ResponseDTO<DedupeResponseFromCBS>) dedupeServiceImpl.checkCbsDedupe(getStubCBSDedupeRequest(), "test");
        Assert.assertNotNull(response);
    }

    private CustomerResponse getStubCustomerResponse() {
        CustomerResponse customerResponse = new CustomerResponse();
        customerResponse.setStatus("test");
        customerResponse.setCutomermatchcount("2");
        return customerResponse;
    }

    private DedupeRequest getStubDedupeRequest(String action){
        DedupeRequest dedupeRequest = new DedupeRequest();
        dedupeRequest.setPartnerId("test");
        dedupeRequest.setAction(action);
        dedupeRequest.setDocType("A");
        dedupeRequest.setDocNumber("123456789012");
        dedupeRequest.setCustomerId("1234567890");
        dedupeRequest.setAccountType("wallet");
        return dedupeRequest;
    }

    private CBSDedupeRequest getStubCBSDedupeRequest(){
        CBSDedupeRequest request = new CBSDedupeRequest();
        request.setAadhaarNo("123456789012");
        request.setMobileNo("1234567890");
        request.setEmailId("test@gmail.com");
        request.setPanNo("ABCDE1234D");
        return request;
    }

}
