package com.airtelbank.validation.service.impl;

import com.airtelbank.validation.dao.aerospike.ErrorCodeMapperDao;
import com.airtelbank.validation.dao.aerospike.ErrorCodeMapperRepository;
import com.airtelbank.validation.dao.aerospike.model.Blackout;
import com.airtelbank.validation.dao.aerospike.model.ErrorCodeMapper;
import com.airtelbank.validation.dao.aerospike.repository.BlackoutRepository;
import com.airtelbank.validation.model.*;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import static org.junit.Assert.*;
import static org.mockito.Mockito.when;
import org.mockito.Mockito;
import org.springframework.context.MessageSource;

public class ErrorCodeMapperServiceImplTest {

    @InjectMocks
    ErrorCodeMapperServiceImpl errorCodeMapperServiceImpl;

    @Mock
    ErrorCodeMapperDao errorCodeMapperDao;

    @Mock
    ErrorCodeMapperRepository errorCodeMapperRepository;

    @Before
    public void init() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void addNewErrorCodeTest(){
        ErrorCodeMapper errorCodeMapper = new ErrorCodeMapper();
        when(errorCodeMapperDao.addNewErrorCode(errorCodeMapper)).thenReturn(true);
        assertTrue(errorCodeMapperServiceImpl.addNewErrorCode(errorCodeMapper));
    }
}
