package com.airtelbank.validation.reader;

import com.airtelbank.validation.constants.Constants;
import com.airtelbank.validation.model.blacklist.BlacklistData;
import lombok.extern.slf4j.Slf4j;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;


@RunWith(SpringRunner.class)
@Slf4j
public class CsvReaderTest {

	@Test
	public void testCSVParsing() throws Exception {
		String filePath = "src/test/resources/files/test_sample.csv";
		String fileType = filePath.split(Constants.DOT_SEPARATOR)[1];
		List<BlacklistData> list = new AbstractReaderFactory().getReader(fileType).readFile(filePath, BlacklistData.class);
		assertNotNull(list);
		assertEquals(1, list.size());
		assertEquals("American Air Ways Charters, Inc.", list.get(0).getName());
	}
}

