package com.airtelbank.validation.mapper;

import com.airtelbank.validation.dao.aerospike.model.PincodeMasterCBS;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.MockitoJUnitRunner;

import java.sql.ResultSet;
import java.sql.SQLException;

import static org.junit.Assert.*;

@RunWith(MockitoJUnitRunner.class)
public class PincodeMasterMapperTest {

    @InjectMocks
    private PincodeMasterMapper pincodeMasterMapper;
    @Mock
   private ResultSet resultSet;

    @Before
    public void setUp() throws Exception {
        MockitoAnnotations.initMocks(this);
    }

    @After
    public void tearDown() throws Exception {
    }

    @Test
    public void mapRowTest() throws SQLException {

        PincodeMasterCBS pincodeMasterCBS=pincodeMasterMapper.mapRow(resultSet,1);
        assertNotNull(pincodeMasterCBS);
    }
}