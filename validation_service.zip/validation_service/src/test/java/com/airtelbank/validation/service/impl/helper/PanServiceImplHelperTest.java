package com.airtelbank.validation.service.impl.helper;

import com.airtelbank.validation.exception.ESBPanVerificationException;
import com.airtelbank.validation.exception.InvalidPanException;
import com.airtelbank.validation.exception.InvalidPanNumberException;
import com.airtelbank.validation.model.*;
import com.airtelbank.validation.util.CommonUtil;
import com.airtelbank.validation.util.HttpUtil;
import com.airtelbank.validation.util.LogMasker;
import org.junit.*;
import org.junit.runner.RunWith;
import org.mockito.*;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.util.ReflectionTestUtils;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.*;
//import static org.mockito.Mockito.mockStatic;

@RunWith(MockitoJUnitRunner.class)
public class PanServiceImplHelperTest {

    //private static MockedStatic<CommonUtil> mockedSettings;
    @InjectMocks
    private PanServiceImplHelper panServiceImplHelper;
    @Mock
    private HttpUtil httpUtil;

    @Mock
    private LogMasker logMasker;

    @BeforeClass
    public static void setUp() {

       // mockedSettings = mockStatic(CommonUtil.class);

    }

    @AfterClass
    public static void close() {

        //mockedSettings.close();

    }

    @Before
    public void init() {
        MockitoAnnotations.initMocks(this);
        ReflectionTestUtils.setField(panServiceImplHelper, "strEsbPanUrl", "strEsbPanUrl");

    }

    @Test
    public void validatePanRequestTest() {
        PANRequest request = new PANRequest();
        request.setPanNumber("ABCDE1234N");
        assertTrue(panServiceImplHelper.validatePanRequest(request));
    }

    @Test
    public void validatePanRequestsTest() {

            PANRequest request = new PANRequest();
            request.setPanNumber("ABCDE1234N");
       assertTrue(panServiceImplHelper.validatePanRequest(request));



    }


    @Test
    public void createPANEsbRequestTest() {
        PANRequest request = new PANRequest();
        request.setPanNumber("ABCDE1234N");
        request.setChannel("XYZZ");
        request.setContentId("PANDETAILS");
        request.setMobile("99992222");
        request.setRefNumber("12345");
        PanEsbRequest panEsbReq = panServiceImplHelper.createPANEsbRequest(request);
        assertEquals("ABCDE1234N", panEsbReq.getPanData().getPanRequestDetails().getPanNumber());
    }

    @Test
    public void createPANEsbRequest1Test() {
        PANRequest request = new PANRequest();
        request.setPanNumber("ABCDE1234N");
        request.setChannel("XYZZ");
        request.setContentId("");
        request.setMobile("99992222");
        request.setRefNumber("12345");
        PanEsbRequest panEsbReq = panServiceImplHelper.createPANEsbRequest(request);
        assertEquals("ABCDE1234N", panEsbReq.getPanData().getPanRequestDetails().getPanNumber());
    }


    /*@Test
    public void fetchResponseForXML() throws IOException {

        PanEsbRequest panRequest = new PanEsbRequest();
        panRequest.setNamespace("test");
        PanEsbResponse panEsbResponses = new PanEsbResponse();
        DataArea dataArea = new DataArea();
        AadhaarInfo aadhaarInfo = new AadhaarInfo();
        aadhaarInfo.setUserIdentifier("test");
        dataArea.setAadhaarInfo(aadhaarInfo);
        panEsbResponses.setPanData(dataArea);
        //mockedSettings.when(() -> CommonUtil.jsonObjectToString(Mockito.any())).thenReturn("test");
        //mockedSettings.when(() -> CommonUtil.convertToObjectFromXMLInJackson(Mockito.any(), Mockito.any())).thenReturn(panEsbResponses);
        PanEsbResponse panEsbResponse = panServiceImplHelper.fetchResponseForXML(panRequest);
        assertNotNull(panEsbResponse);

    }*/

    /*@Test(expected = ESBPanVerificationException.class)
    public void fetchResponseForXMLESBPanVerificationExceptionTest() throws IOException {

            PanEsbResponse panEsbResponses = new PanEsbResponse();
            DataArea dataArea = new DataArea();
            AadhaarInfo aadhaarInfo = new AadhaarInfo();
            aadhaarInfo.setUserIdentifier("test");
            dataArea.setAadhaarInfo(aadhaarInfo);
            panEsbResponses.setPanData(dataArea);
            PanEsbRequest panRequest = new PanEsbRequest();
            panRequest.setNamespace("test");
            panRequest.setPanData(dataArea);
            EbmHeader ebmHeader=new EbmHeader();
            ebmHeader.setConsumerTransactionId("test");
            panRequest.setPanHeader(ebmHeader);

            //mockedSettings.when(() -> CommonUtil.jsonObjectToString(panRequest)).thenReturn("test");
            //mockedSettings.when(() -> CommonUtil.convertToObjectFromXMLInJackson(Mockito.any(), Mockito.any())).thenReturn(null);
            PanEsbResponse panEsbResponse = panServiceImplHelper.fetchResponseForXML(panRequest);
            assertNotNull(panEsbResponse);


    }*/

    @Test(expected = ESBPanVerificationException.class)
    public void getPanDetailsESBPanVerificationException() {

            PanEsbResponse panEsbResponse = new PanEsbResponse();
            PANDetails panDetails = panServiceImplHelper.getPanDetails(panEsbResponse);
            assertNotNull(panDetails);

    }

    @Test(expected = ESBPanVerificationException.class)
    public void TestgetPanDetailsExESBPanVerificationException() {

            PanEsbResponse panEsbResponse = new PanEsbResponse();
            PANDetails panDetails = panServiceImplHelper.getPanDetails(null);
            assertNotNull(panDetails);

    }

    @Test
    public void getPanDetailsTest() {

            PanEsbResponse panEsbResponse = new PanEsbResponse();
            DataArea dataArea = new DataArea();
            VerifyPANDetailsResponse verifyPANDetailsResponse = new VerifyPANDetailsResponse();
            PANStatus panStatus = new PANStatus();
            panStatus.setCode("VerifyCustomerPanDetails-0001-S");
            verifyPANDetailsResponse.setStatus(panStatus);
            PANDetails panDetails = new PANDetails();
            panDetails.setPanStatus("E");
            List<PANDetails> panDetailsList = new ArrayList<>();
            panDetailsList.add(panDetails);
            verifyPANDetailsResponse.setPanDetails(panDetailsList);
            dataArea.setPanResponseDetails(verifyPANDetailsResponse);
            panEsbResponse.setPanData(dataArea);

            PANDetails panDetails1 = panServiceImplHelper.getPanDetails(panEsbResponse);
            assertNotNull(panDetails1);

    }


    @Test(expected = InvalidPanNumberException.class)
    public void getPanDetailsInvalidPanNumberExceptionTest() {

            PanEsbResponse panEsbResponse=new PanEsbResponse();
            DataArea dataArea=new DataArea();
            VerifyPANDetailsResponse verifyPANDetailsResponse=new VerifyPANDetailsResponse();
            PANStatus panStatus=new PANStatus();
            panStatus.setCode("VerifyCustomerPanDetails-0001-S");
            verifyPANDetailsResponse.setStatus(panStatus);
            PANDetails panDetails=new PANDetails();
            panDetails.setPanStatus("A");
            List<PANDetails> panDetailsList=new ArrayList<>();
            panDetailsList.add(panDetails);
            verifyPANDetailsResponse.setPanDetails(panDetailsList);
            dataArea.setPanResponseDetails(verifyPANDetailsResponse);
            panEsbResponse.setPanData(dataArea);

            PANDetails panDetails1= panServiceImplHelper.getPanDetails(panEsbResponse);


    }

    @Test(expected = InvalidPanException.class)
    public void getPanDetailsInvalidPanExceptionTest() {

            PanEsbResponse panEsbResponse=new PanEsbResponse();
            DataArea dataArea=new DataArea();
            VerifyPANDetailsResponse verifyPANDetailsResponse=new VerifyPANDetailsResponse();
            PANStatus panStatus=new PANStatus();
            panStatus.setCode("VerifyCustomerPanDetails-0002-S");
            verifyPANDetailsResponse.setStatus(panStatus);
            PANDetails panDetails=new PANDetails();
            panDetails.setPanStatus("A");
            List<PANDetails> panDetailsList=new ArrayList<>();
            panDetailsList.add(panDetails);
            verifyPANDetailsResponse.setPanDetails(panDetailsList);
            dataArea.setPanResponseDetails(verifyPANDetailsResponse);
            panEsbResponse.setPanData(dataArea);

            PANDetails panDetails1= panServiceImplHelper.getPanDetails(panEsbResponse);


    }

    @Test(expected = InvalidPanNumberException.class)
    public void TestgetPanDetailsInvalidPanNumberException() {

            PanEsbResponse panEsbResponse=new PanEsbResponse();
            DataArea dataArea=new DataArea();
            VerifyPANDetailsResponse verifyPANDetailsResponse=new VerifyPANDetailsResponse();
            PANStatus panStatus=new PANStatus();
            panStatus.setCode("VerifyCustomerPanDetails-4501-V");
            verifyPANDetailsResponse.setStatus(panStatus);
            PANDetails panDetails=new PANDetails();
            panDetails.setPanStatus("A");
            List<PANDetails> panDetailsList=new ArrayList<>();
            panDetailsList.add(panDetails);
            verifyPANDetailsResponse.setPanDetails(panDetailsList);
            dataArea.setPanResponseDetails(verifyPANDetailsResponse);
            panEsbResponse.setPanData(dataArea);

            PANDetails panDetails1= panServiceImplHelper.getPanDetails(panEsbResponse);


    }

    @Test(expected = ESBPanVerificationException.class)
    public void getPanDetails4() {

            PanEsbResponse panEsbResponse=new PanEsbResponse();
            DataArea dataArea=new DataArea();
            VerifyPANDetailsResponse verifyPANDetailsResponse=new VerifyPANDetailsResponse();
            PANStatus panStatus=new PANStatus();
            panStatus.setCode("VerifyCustomerPanDetails-4502-S");
            verifyPANDetailsResponse.setStatus(panStatus);
            PANDetails panDetails=new PANDetails();
            panDetails.setPanStatus("A");
            List<PANDetails> panDetailsList=new ArrayList<>();
            panDetailsList.add(panDetails);
            verifyPANDetailsResponse.setPanDetails(panDetailsList);
            dataArea.setPanResponseDetails(verifyPANDetailsResponse);
            panEsbResponse.setPanData(dataArea);

            PANDetails panDetails1= panServiceImplHelper.getPanDetails(panEsbResponse);


    }

    @Test(expected = ESBPanVerificationException.class)
    public void getPanDetailsESBPanVerificationExceptionTest() {

            PanEsbResponse panEsbResponse=new PanEsbResponse();
            DataArea dataArea=new DataArea();
            VerifyPANDetailsResponse verifyPANDetailsResponse=new VerifyPANDetailsResponse();
            PANStatus panStatus=new PANStatus();
            panStatus.setCode("");
            verifyPANDetailsResponse.setStatus(panStatus);
            PANDetails panDetails=new PANDetails();
            panDetails.setPanStatus("A");
            List<PANDetails> panDetailsList=new ArrayList<>();
            panDetailsList.add(panDetails);
            verifyPANDetailsResponse.setPanDetails(panDetailsList);
            dataArea.setPanResponseDetails(verifyPANDetailsResponse);
            panEsbResponse.setPanData(dataArea);

            PANDetails panDetails1= panServiceImplHelper.getPanDetails(panEsbResponse);


    }



}