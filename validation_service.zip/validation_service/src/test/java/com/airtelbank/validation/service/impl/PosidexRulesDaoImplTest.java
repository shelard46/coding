package com.airtelbank.validation.service.impl;

import com.airtelbank.validation.dao.aerospike.impl.PosidexRulesDaoImpl;
import com.airtelbank.validation.exception.AeroSpikeException;
import lombok.extern.slf4j.Slf4j;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.context.MessageSource;
import org.springframework.data.aerospike.core.AerospikeTemplate;
import org.springframework.data.aerospike.repository.query.Query;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.Locale;

@RunWith(SpringRunner.class)
@Slf4j
public class PosidexRulesDaoImplTest {

    @Mock
    private AerospikeTemplate aerospikeTemplate;

    @Mock
    private MessageSource messageSource;

    @InjectMocks
    private PosidexRulesDaoImpl posidexRulesDaoImpl;

    @Before
    public void init() {
        MockitoAnnotations.initMocks(this);
    }

    @Test(expected = AeroSpikeException.class)
    public void getRulesByAccountTypesTest() {
        Mockito.when(aerospikeTemplate.find(Mockito.any(Query.class), Mockito.any())).thenThrow(new RuntimeException());
        Mockito.when(messageSource.getMessage("config.dedupe.aerospike.failure.msg", null, Locale.ENGLISH)).thenReturn("test");
        Mockito.when(messageSource.getMessage("config.dedupe.aerospike.failure.code", null, Locale.ENGLISH)).thenReturn("test");
        posidexRulesDaoImpl.getRulesByAccountTypes("test");
    }

}
