package com.airtelbank.validation.service.impl.helper;

import com.airtelbank.validation.dao.jpa.model.DocumentAuditLog;
import com.airtelbank.validation.dao.jpa.respository.DocumentAuditRepository;
import com.airtelbank.validation.model.*;
import com.airtelbank.validation.util.LogMasker;
import org.aspectj.lang.ProceedingJoinPoint;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;

import java.util.Calendar;
import java.util.GregorianCalendar;

import static org.junit.Assert.assertNotNull;

@RunWith(MockitoJUnitRunner.class)
public class DocumentAuditorTest {

    @InjectMocks
    private DocumentAuditor documentAuditor;
    @Mock
    private DocumentAuditRepository documentAuditRepository;

    @Mock
    private LogMasker logMasker;


    @Test(expected = Test.None.class)
    public void testFetchResponseFromESBPan() {
        documentAuditor.fetchResponseFromESBPan();

    }


    @Test
    public void testDoAuditLogNullPointerExceptionTest() {

            final ProceedingJoinPoint thisJoinPoint = null;

            final DocumentAuditLog documentAuditLog = new DocumentAuditLog(0L, "transactionId", "action",
                    "userIdentifierType", "docType", "docNumber", "mobile", "code", "description", "uidToken",
                    DocumentAuditLog.TransactionStatus.GENEATION_AADHAAR_OTP_FAILED,
                    new GregorianCalendar(2020, Calendar.JANUARY, 1).getTime(),
                    new GregorianCalendar(2020, Calendar.JANUARY, 1).getTime(), "partnerTransactionId", "channel", "source",
                    "customColumn1", "customColumn2", "customColumn3", "customColumn4", "customColumn5", "customColumn6",
                    "customColumn7", "customColumn8", "customColumn9", "customColumn10");

            final PanEsbResponse result = documentAuditor.doAuditLog(thisJoinPoint);


    }


    @Test(expected = Test.None.class)
    public void saveAuditDataExceptionTest() {
        DocumentAuditLog documentAuditLogs=new DocumentAuditLog();
        documentAuditLogs.setChannel("test");
        documentAuditLogs.setDocNumber("test");
       Mockito.doThrow(new RuntimeException()).when(documentAuditRepository).save(documentAuditLogs);
        documentAuditor.saveAuditData(documentAuditLogs);
    }

    @Test(expected = Test.None.class)
    public void saveAuditDataTest() {
        DocumentAuditLog documentAuditLogs=new DocumentAuditLog();
        documentAuditLogs.setChannel("test");
        documentAuditLogs.setDocNumber("test");
        documentAuditor.saveAuditData(documentAuditLogs);
    }

    @Test
    public void createDocumentAuditTest() {
        PanEsbResponse panEsbResponses = new PanEsbResponse();
        DataArea dataArea = new DataArea();
        AadhaarInfo aadhaarInfo = new AadhaarInfo();
        aadhaarInfo.setUserIdentifier("test");
        dataArea.setAadhaarInfo(aadhaarInfo);
        VerifyPANDetailsRequest verifyPANDetailsRequest=new VerifyPANDetailsRequest();
        verifyPANDetailsRequest.setPanNumber("test");
        VerifyPANDetailsResponse verifyPANDetailsResponse=new VerifyPANDetailsResponse();
        PANStatus panStatus=new PANStatus();
        panStatus.setCode("test");
        verifyPANDetailsResponse.setStatus(panStatus);
        dataArea.setPanRequestDetails(verifyPANDetailsRequest);
        dataArea.setPanResponseDetails(verifyPANDetailsResponse);
        panEsbResponses.setPanData(dataArea);
        PanEsbRequest panRequest = new PanEsbRequest();
        panRequest.setNamespace("test");
        panRequest.setPanData(dataArea);
        EbmHeader ebmHeader=new EbmHeader();
        ebmHeader.setConsumerTransactionId("test");
        panRequest.setPanHeader(ebmHeader);
        DocumentAuditLog documentAuditLogs=new DocumentAuditLog();
        documentAuditLogs.setChannel("test");
        documentAuditLogs.setDocNumber("test");
        PANRequest request = new PANRequest();
        request.setPanNumber("ABCDE1234N");
        request.setChannel("XYZZ");
        request.setContentId("PANDETAILS");
        request.setMobile("99992222");
        request.setRefNumber("12345");
        DocumentAuditLog documentAuditLog=documentAuditor.createDocumentAudit(panRequest,request);
        assertNotNull(documentAuditLog);
    }

    @Test
    public void updateDocumentAuditLogTest() {
        PanEsbResponse panEsbResponses = new PanEsbResponse();
        DataArea dataArea = new DataArea();
        AadhaarInfo aadhaarInfo = new AadhaarInfo();
        aadhaarInfo.setUserIdentifier("test");
        dataArea.setAadhaarInfo(aadhaarInfo);
        VerifyPANDetailsRequest verifyPANDetailsRequest=new VerifyPANDetailsRequest();
        verifyPANDetailsRequest.setPanNumber("test");
        VerifyPANDetailsResponse verifyPANDetailsResponse=new VerifyPANDetailsResponse();
        PANStatus panStatus=new PANStatus();
        panStatus.setCode("test");
        verifyPANDetailsResponse.setStatus(panStatus);
        dataArea.setPanRequestDetails(verifyPANDetailsRequest);
        dataArea.setPanResponseDetails(verifyPANDetailsResponse);
        panEsbResponses.setPanData(dataArea);
        PanEsbRequest panRequest = new PanEsbRequest();
        panRequest.setNamespace("test");
        panRequest.setPanData(dataArea);
        EbmHeader ebmHeader=new EbmHeader();
        ebmHeader.setConsumerTransactionId("test");
        panRequest.setPanHeader(ebmHeader);
        DocumentAuditLog documentAuditLogs=new DocumentAuditLog();
        documentAuditLogs.setChannel("test");
        documentAuditLogs.setDocNumber("test");
        DocumentAuditLog documentAuditLog =documentAuditor.updateDocumentAuditLog(panEsbResponses,documentAuditLogs);
        assertNotNull(documentAuditLog);
    }
}