package com.airtelbank.validation.util;

import org.springframework.test.util.ReflectionTestUtils;

import com.airtelbank.validation.constants.Constants;
import com.airtelbank.validation.dao.aerospike.PosidexCacheCustomerDao;
import com.airtelbank.validation.dao.aerospike.PosidexRulesDao;
import com.airtelbank.validation.dao.aerospike.model.PosidexCacheCustomerDetails;
import com.airtelbank.validation.dao.aerospike.model.PosidexRules;
import com.airtelbank.validation.model.DedupeResponse;
import com.airtelbank.validation.model.posidex.customer.*;
import com.airtelbank.validation.service.PosidexCacheCustomerService;
import com.airtelbank.validation.service.impl.PosidexCacheCustomerServiceImpl;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.context.MessageSource;
import org.springframework.core.env.Environment;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;

public class RuleExecutorTest {

    @Mock
    Environment environment;

    @Mock
    PosidexCacheCustomerService posidexCacheCustomerService;

    @Mock
    PosidexCacheCustomerDao posidexCacheCustomerDao;

    @Mock
    PosidexRulesDao posidexRulesDao;

    @Mock
    PosidexCacheCustomerServiceImpl posidexCacheCustomerServiceImpl;

    @Mock
    MessageSource messageSource;

    @InjectMocks
    RuleExecutor ruleExecutor;

    @Before
    public void init() {
        MockitoAnnotations.initMocks(this);
        ReflectionTestUtils.setField(ruleExecutor, "apbPartnerID", "PAYMENTSBANK");
        ReflectionTestUtils.setField(ruleExecutor, "hikePartnerID", "HIKE");
        ReflectionTestUtils.setField(ruleExecutor, "createCode", "1800");
        ReflectionTestUtils.setField(ruleExecutor, "failureCode", "1850");
        ReflectionTestUtils.setField(ruleExecutor, "rejectCode", "1830");
        ReflectionTestUtils.setField(ruleExecutor, "createWithActionCode", "1805");
        ReflectionTestUtils.setField(ruleExecutor, "createMsg", "Create Customer.");
        ReflectionTestUtils.setField(ruleExecutor, "rejectMsg", "Customer rejected.");
        ReflectionTestUtils.setField(ruleExecutor, "createWithActionMsg", "Customer is APB customer, club it.");
        ReflectionTestUtils.setField(ruleExecutor, "failureMsg", "Dedupe api failed");
    }

    @Test
    public void applyRulesWithSuccessFKY() {
        when(posidexCacheCustomerDao.getPosidexDataFromAeroForPoiNumber(Mockito.anyString())).thenReturn(getStubPosidexCacheCustomerDetailsWithWalletFKY());
        when(messageSource.getMessage("config.dedupe.reject.msg", null, null)).thenReturn("Customer rejected.");
        DedupeResponse dataAfterApplyRules = ruleExecutor.applyRules("test", getStubCustomerResponse(), "test", "123456789012", "test", "1234567890");
        assertEquals("1830", dataAfterApplyRules.getErrorCode());
    }

    @Test
    public void applyRulesWithSuccessMKYA() {
        when(posidexCacheCustomerDao.getPosidexDataFromAeroForPoiNumber(Mockito.anyString())).thenReturn(getStubPosidexCacheCustomerDetailsWithWalletMKYA());
        when(messageSource.getMessage("config.dedupe.reject.msg", null, null)).thenReturn("Customer rejected.");
        DedupeResponse dataAfterApplyRules = ruleExecutor.applyRules("test", getStubCustomerResponse(), "test", "123456789012", "test", "1234567890");
        assertEquals("1830", dataAfterApplyRules.getErrorCode());
    }

    @Test
    public void applyRulesWithSuccessMKYAII() {
        when(posidexCacheCustomerDao.getPosidexDataFromAeroForPoiNumber(Mockito.anyString())).thenReturn(getStubPosidexCacheCustomerDetailsWithWalletMKYAWithWrongSNo());
        when(messageSource.getMessage("config.dedupe.reject.msg", null, null)).thenReturn("Customer rejected.");
        DedupeResponse dataAfterApplyRules = ruleExecutor.applyRules("test", getStubCustomerResponseWithCustomerSourceType(false, Constants.POI_NUMBER_POI_TYPE, Constants.WALLET_FKY
                , "0"), "test", "123456789012", "test", "1234567890");
        assertEquals("1800", dataAfterApplyRules.getErrorCode());
    }

    @Test
    public void applyRulesWithSuccessLKY() {
        when(posidexCacheCustomerDao.getPosidexDataFromAeroForPoiNumber(Mockito.anyString())).thenReturn(getStubPosidexCacheCustomerDetailsWithWalletLKY());
        when(messageSource.getMessage("config.dedupe.reject.msg", null, null)).thenReturn("Customer rejected.");
        DedupeResponse dataAfterApplyRules = ruleExecutor.applyRules("test", getStubCustomerResponse(), "test", "123456789012", "test", "1234567890");
        assertEquals("1805", dataAfterApplyRules.getErrorCode());
    }

    @Test
    public void applyRulesWithCustomerMatchCountAsSuccess() {
        when(posidexCacheCustomerDao.getPosidexDataFromAeroForPoiNumber(Mockito.anyString())).thenReturn(null);
        when(messageSource.getMessage("config.dedupe.create.msg", null, null)).thenReturn("Create Customer.");
        DedupeResponse dataAfterApplyRules = ruleExecutor.applyRules("test", getStubCustomerResponse(), "test", "123456789012", "test", "1234567890");
        assertEquals("1800", dataAfterApplyRules.getErrorCode());
    }

    @Test(expected = Exception.class)
    public void applyRulesWithException() {
        when(posidexCacheCustomerDao.getPosidexDataFromAeroForPoiNumber(Mockito.anyString())).thenThrow(new Exception());
        when(messageSource.getMessage("config.dedupe.reject.msg", null, null)).thenReturn("Customer rejected.");
        ruleExecutor.applyRules("test", getStubCustomerResponse(), "test", "123456789012", "test", "1234567890");
    }

    @Test
    public void applyRulesWithDemographicsResultPOITypeSuccess() {
        when(posidexCacheCustomerDao.getPosidexDataFromAeroForPoiNumber(Mockito.anyString())).thenReturn(null);
        when(posidexRulesDao.getRulesByAccountTypes(Mockito.anyString())).thenReturn(getStubPosidexRules(Constants.NAME_DOB_PINCODE));
        when(messageSource.getMessage("config.dedupe.create.msg", null, null)).thenReturn("Create Customer.");
        CustomerResponse customerResponse = getStubCustomerResponse();
        customerResponse.setCutomermatchcount("1");
        DedupeResponse dedupeResponse = ruleExecutor.applyRules("test", customerResponse, "test", "123456789012", "test", "1234567890");
        assertEquals("1800", dedupeResponse.getErrorCode());
    }

    @Test
    public void applyRulesWithDemographicsResultAPBPartnerIDSuccess() {
        when(posidexCacheCustomerDao.getPosidexDataFromAeroForPoiNumber(Mockito.anyString())).thenReturn(null);
        when(posidexRulesDao.getRulesByAccountTypes(Mockito.anyString())).thenReturn(getStubPosidexRules(Constants.NAME_DOB_PINCODE));
        when(messageSource.getMessage("config.dedupe.create.msg", null, null)).thenReturn("Create Customer.");
        DedupeResponse dedupeResponse = ruleExecutor.applyRules("test", getStubCustomerResponseWithCustomerSourceType(false, Constants.NAME_DOB_PINCODE, Constants.WALLET_FKY
                ,"1"), "test", "123456789012", "test", "1234567890");
        assertEquals("1830", dedupeResponse.getErrorCode());
    }

    @Test
    public void applyRulesWithDemographicsResultSuccess() {
        when(posidexCacheCustomerDao.getPosidexDataFromAeroForPoiNumber(Mockito.anyString())).thenReturn(null);
        when(posidexRulesDao.getRulesByAccountTypes(Mockito.anyString())).thenReturn(getStubPosidexRules(Constants.NAME_DOB_PINCODE));
        when(messageSource.getMessage("config.dedupe.create.msg", null, null)).thenReturn("Create Customer.");
        DedupeResponse dedupeResponse = ruleExecutor.applyRules("test", getStubCustomerResponseWithCustomerSourceType(true, Constants.NAME_DOB_PINCODE, Constants.WALLET_FKY
                ,"1"), "test", "123456789012", "test", "1234567890");
        assertEquals("1800", dedupeResponse.getErrorCode());
    }

    @Test
    public void applyRulesWithDemographicsResultPOITypeCheckSuccess() {
        when(posidexCacheCustomerDao.getPosidexDataFromAeroForPoiNumber(Mockito.anyString())).thenReturn(null);
        when(posidexRulesDao.getRulesByAccountTypes(Mockito.anyString())).thenReturn(getStubPosidexRules(Constants.POI_NUMBER_POI_TYPE));
        when(messageSource.getMessage("config.dedupe.create.msg", null, null)).thenReturn("Create Customer.");
        when(posidexCacheCustomerDao.getPosidexDataAero(Mockito.anyString())).thenReturn(PosidexCacheCustomerDetails.builder().walletType(Constants.WALLET_FKY).build());
        DedupeResponse dedupeResponse = ruleExecutor.applyRules("test", getStubCustomerResponseWithCustomerSourceType(false, Constants.POI_NUMBER_POI_TYPE, Constants.WALLET_FKY
        ,"1"), "test", "123456789012", "test", "1234567890");
        assertEquals("1830", dedupeResponse.getErrorCode());
    }

    @Test
    public void applyRulesWithDemographicsResultPOITypeAPBPartnerIDCheckSuccess() {
        when(posidexCacheCustomerDao.getPosidexDataFromAeroForPoiNumber(Mockito.anyString())).thenReturn(null);
        when(posidexRulesDao.getRulesByAccountTypes(Mockito.anyString())).thenReturn(getStubPosidexRules(Constants.POI_NUMBER_POI_TYPE));
        when(messageSource.getMessage("config.dedupe.create.msg", null, null)).thenReturn("Create Customer.");
        when(posidexCacheCustomerDao.getPosidexDataAero(Mockito.anyString())).thenReturn(PosidexCacheCustomerDetails.builder().walletType(Constants.WALLET_LKY).build());
        DedupeResponse dedupeResponse = ruleExecutor.applyRules("test", getStubCustomerResponseWithCustomerSourceType(false, Constants.POI_NUMBER_POI_TYPE, Constants.WALLET_FKY
                ,"1"), "test", "123456789012", "test", "1234567890");
        assertEquals("1830", dedupeResponse.getErrorCode());
    }

    @Test
    public void applyRulesWithDemographicsResultPOITypeAPBPartnerIDCheckSuccessII() {
        when(posidexCacheCustomerDao.getPosidexDataFromAeroForPoiNumber(Mockito.anyString())).thenReturn(null);
        when(posidexRulesDao.getRulesByAccountTypes(Mockito.anyString())).thenReturn(getStubPosidexRules(Constants.POI_NUMBER_POI_TYPE));
        when(messageSource.getMessage("config.dedupe.create.msg", null, null)).thenReturn("Create Customer.");
        when(posidexCacheCustomerDao.getPosidexDataAero(Mockito.anyString())).thenReturn(PosidexCacheCustomerDetails.builder().walletType(Constants.WALLET_LKY).build());
        DedupeResponse dedupeResponse = ruleExecutor.applyRules("test", getStubCustomerResponseWithCustomerSourceType(true, Constants.POI_NUMBER_POI_TYPE, Constants.WALLET_FKY
                ,"1"), "test", "123456789012", "test", "1234567890");
        assertEquals("1800", dedupeResponse.getErrorCode());
    }

    @Test
    public void applyRulesWithDemographicsResultPOITypeAPBPartnerIDCheckSuccessIII() {
        when(posidexCacheCustomerDao.getPosidexDataFromAeroForPoiNumber(Mockito.anyString())).thenReturn(null);
        when(posidexRulesDao.getRulesByAccountTypes(Mockito.anyString())).thenReturn(getStubPosidexRules(Constants.POI_NUMBER_POI_TYPE));
        when(messageSource.getMessage("config.dedupe.create.msg", null, null)).thenReturn("Create Customer.");
        when(posidexCacheCustomerDao.getPosidexDataAero(Mockito.anyString())).thenReturn(PosidexCacheCustomerDetails.builder().walletType(Constants.WALLET_LKY).build());
        DedupeResponse dedupeResponse = ruleExecutor.applyRules(Constants.UPGRADE_ACTION, getStubCustomerResponseWithCustomerSourceType(true, Constants.POI_NUMBER_POI_TYPE, Constants.WALLET_FKY
                , "1"), "test", "123456789012", "test", "1234567890");
        assertEquals("1800", dedupeResponse.getErrorCode());
    }

    @Test
    public void applyRulesWithDemographicsResultPOITypeAPBPartnerIDCheckSuccessIV() {
        when(posidexCacheCustomerDao.getPosidexDataFromAeroForPoiNumber(Mockito.anyString())).thenReturn(null);
        when(posidexRulesDao.getRulesByAccountTypes(Mockito.anyString())).thenReturn(getStubPosidexRules("test"));
        when(messageSource.getMessage("config.dedupe.create.msg", null, null)).thenReturn("Create Customer.");
        when(posidexCacheCustomerDao.getPosidexDataAero(Mockito.anyString())).thenReturn(PosidexCacheCustomerDetails.builder().walletType(Constants.WALLET_LKY).build());
        DedupeResponse dedupeResponse = ruleExecutor.applyRules(Constants.UPGRADE_ACTION, getStubCustomerResponseWithCustomerSourceType(true, Constants.POI_NUMBER_POI_TYPE, Constants.WALLET_FKY
                , "1"), "test", "123456789012", "test", "1234567890");
        assertEquals("1800", dedupeResponse.getErrorCode());
    }

    @Test
    public void setRuleDecisionSuccess(){
        Map<String, Object> map = ruleExecutor.setRuleDecision(null, "test", "test", "test", "test", "test", "test" );
        assertEquals(7, map.size());
    }

    private List<PosidexCacheCustomerDetails> getStubPosidexCacheCustomerDetailsWithWalletFKY() {
        List<PosidexCacheCustomerDetails> list = new ArrayList<>();
        list.add(PosidexCacheCustomerDetails.builder().sourceType("PAYMENTSBANK").walletType(Constants.WALLET_FKY).sno("1234PAYMENTSBANK").build());
        return list;
    }

    private List<PosidexCacheCustomerDetails> getStubPosidexCacheCustomerDetailsWithWalletMKYA() {
        List<PosidexCacheCustomerDetails> list = new ArrayList<>();
        list.add(PosidexCacheCustomerDetails.builder().sourceType("PAYMENTSBANK").walletType(Constants.WALLET_MKYA).sno("1234PAYMENTSBANK").build());
        return list;
    }

    private List<PosidexCacheCustomerDetails> getStubPosidexCacheCustomerDetailsWithWalletMKYAWithWrongSNo() {
        List<PosidexCacheCustomerDetails> list = new ArrayList<>();
        list.add(PosidexCacheCustomerDetails.builder().sourceType("PAYMENTSBANK").walletType(Constants.WALLET_MKYA).sno("1234567890").build());
        return list;
    }

    private List<PosidexCacheCustomerDetails> getStubPosidexCacheCustomerDetailsWithWalletLKY() {
        List<PosidexCacheCustomerDetails> list = new ArrayList<>();
        list.add(PosidexCacheCustomerDetails.builder().sourceType("PAYMENTSBANK").walletType(Constants.WALLET_LKY).sno("1234PAYMENTSBANK").build());
        return list;
    }

    private CustomerResponse getStubCustomerResponse() {
        List<Customer> customers = new ArrayList<>();
        DemographicsResult demographicsResult = new DemographicsResult();
        demographicsResult.setPoiType("test");
        demographicsResult.setSourceType("PAYMENTSBANK");
        demographicsResult.setWalletType(Constants.WALLET_FKY);
        Customer customer = new Customer();
        customer.setMatchRule(Constants.NAME_DOB_PINCODE);
        customers.add(customer);
        List<Contact> contacts = new ArrayList<>();
        Contact contact = new Contact();
        contact.setCustMsisdn("1");
        contacts.add(contact);
        customer.getContact().addAll(contacts);
        customer.setDemographics(demographicsResult);
        CustomerResult customerResult = new CustomerResult();
        customerResult.getCustomer().addAll(customers);
        RECustomerResults reCustomerResults = new RECustomerResults();
        reCustomerResults.setCustomerResults(customerResult);

        CustomerResponse customerResponse = new CustomerResponse();
        customerResponse.setCutomermatchcount("0");
        customerResponse.setResults(reCustomerResults);

        return customerResponse;
    }

    private CustomerResponse getStubCustomerResponseWithCustomerSourceType(boolean flag, String matchRule, String walletType, String customerMatchCount) {
        List<Customer> customers = new ArrayList<>();
        DemographicsResult demographicsResult = new DemographicsResult();
        if (flag) {
            demographicsResult.setPoiType("test1");
            demographicsResult.setSourceType("PAYMENTSBANK1");
        } else {
            demographicsResult.setPoiType("test1");
            demographicsResult.setSourceType("PAYMENTSBANK");
        }

        demographicsResult.setWalletType(walletType);
        Customer customer = new Customer();
        customer.setMatchRule(matchRule);
        customers.add(customer);
        List<Contact> contacts = new ArrayList<>();
        Contact contact = new Contact();
        contact.setCustMsisdn("1");
        contacts.add(contact);
        customer.getContact().addAll(contacts);
        customer.setDemographics(demographicsResult);
        CustomerResult customerResult = new CustomerResult();
        customerResult.getCustomer().addAll(customers);
        RECustomerResults reCustomerResults = new RECustomerResults();
        reCustomerResults.setCustomerResults(customerResult);

        CustomerResponse customerResponse = new CustomerResponse();
        customerResponse.setCutomermatchcount(customerMatchCount);
        customerResponse.setResults(reCustomerResults);

        return customerResponse;
    }

    private List<PosidexRules> getStubPosidexRules(String matchRule) {
        PosidexRules rule = new PosidexRules();
        rule.setRuleName(matchRule);
        rule.setAction("test");
        rule.setRulePriority(1);
        List<PosidexRules> rules = new ArrayList<>();
        rules.add(rule);
        return rules;
    }

}
