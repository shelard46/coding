package com.airtelbank.validation.util;

import com.airtelbank.validation.model.AadhaarVaultRequest;
import lombok.extern.slf4j.Slf4j;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.*;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;
import org.testcontainers.shaded.com.fasterxml.jackson.core.JsonProcessingException;
import org.testcontainers.shaded.com.fasterxml.jackson.databind.ObjectMapper;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

@RunWith(SpringRunner.class)
@Slf4j
public class HttpUtilTest {

    @Mock
    private RestTemplate restTemplate;

    @Mock
    private ObjectMapper objectMapper;

    @Mock
    private RestTemplate restTemplateAadhaarVault;

    @InjectMocks
    private HttpUtil httpUtil;

    @Before
    public void init(){
        MockitoAnnotations.initMocks(this);
        ReflectionTestUtils.setField(httpUtil, "publicKey", "MFwwDQYJKoZIhvcNAQEBBQADSwAwSAJBAJlCGtRv12B7BRvS42CMg581EJ8/j+0ezayahBGw8ces0k234e/UYvb5R+PjjwvtEUe1eDwl8gmdelOl6Zx0z/kCAwEAAQ==");
    }

	/*
	 * @Test public void postXmlRequestTest() { RestTemplate restTemplateForXml =
	 * Mockito.mock(RestTemplate.class);
	 * Mockito.when(restTemplateForXml.postForObject(Mockito.anyString(),
	 * Mockito.any(HttpEntity.class), Mockito.any())).thenReturn("test");
	 * httpUtil.postXmlRequest(
	 * "<Response><TransactionStatus><ErrorCode>test</ErrorCode><ExternalReferenceNo>test</ExternalReferenceNo><IsOverriden>false</IsOverriden><IsServiceChargeApplied>false</IsServiceChargeApplied><ReplyCode>1</ReplyCode><ReplyText>test</ReplyText></TransactionStatus><DedupeStatus>0</DedupeStatus><dedupeErrorDesc>test</dedupeErrorDesc><CustomerDedupeDetailsDTOArray><CustomerDedupeDetailsDTO><CustomerId>test</CustomerId><NationalIdentificationCode>test</NationalIdentificationCode><FirstName>test</FirstName><LastName>test</LastName><OfficerID>test</OfficerID><Sex>Male</Sex><AadhrNo>123456789012</AadhrNo><MobileNumber>1234567890</MobileNumber><EmailAddress>test@gmail.com</EmailAddress></CustomerDedupeDetailsDTO></CustomerDedupeDetailsDTOArray></Response>",
	 * "http://10.56.110.186:8022/NBWebClient/fcrjappinterface"); }
	 */

    @Test
    public void processHttpRequest() throws IOException {
        AadhaarVaultRequest request = AadhaarVaultRequest.builder().requestId("123456").apiKey("qwertyuio").referenceKey("qwertyuiop").build();
        String aadhaarVaultRequestString = objectMapper.writeValueAsString(request);
        Map<String, String> headersMap = new HashMap<>();
        headersMap.put("Content-Type", "application/json");
        headersMap.put("Accept", "application/json");
        headersMap.put("Message_Signature", "test");
        Mockito.when(restTemplateAadhaarVault.exchange(
                ArgumentMatchers.anyString(),
                ArgumentMatchers.any(HttpMethod.class),
                ArgumentMatchers.any(),
                ArgumentMatchers.<Class<String>>any())).thenReturn(ResponseEntity.ok().body("test"));
        String response = (String) httpUtil.processHttpRequest("http://10.56.110.189:9071/api/v1/aadhaarReference",
                aadhaarVaultRequestString, String.class, headersMap, HttpMethod.DELETE);
        Assert.assertNotNull(response);
    }

}
