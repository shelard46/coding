package com.airtelbank.validation.dao.aerospike.impl;

import com.airtelbank.validation.dao.aerospike.model.PosidexRules;
import com.airtelbank.validation.exception.AeroSpikeException;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.data.aerospike.core.AerospikeTemplate;

import java.util.List;

import static org.junit.Assert.*;

@RunWith(MockitoJUnitRunner.class)
public class PosidexRulesDaoImplTest {
    @InjectMocks
    private PosidexRulesDaoImpl posidexRulesDao;

    @Mock
    private AerospikeTemplate aerospikeTemplate;

    @Mock
    private MessageSource messageSource;


    @Before
    public void setUp() throws Exception {
        MockitoAnnotations.initMocks(this);
    }

    @After
    public void tearDown() throws Exception {
    }

    @Test
    public void getAllRulesTest() {
        List<PosidexRules> posidexRules=posidexRulesDao.getAllRules();
        assertNotNull(posidexRules);

    }

    @Test
    public void getRulesByAccountTypesTest() {
        List<PosidexRules> posidexRules=posidexRulesDao.getRulesByAccountTypes("test");
        assertNotNull(posidexRules);
    }

    @Test(expected = AeroSpikeException.class)
    public void getRulesByAccountTypeAeroSpikeExceptionTest() {

            Mockito.when(aerospikeTemplate.find(Mockito.any(), Mockito.any())).thenThrow(new RuntimeException());
            List<PosidexRules> posidexRules = posidexRulesDao.getRulesByAccountTypes("test");


    }
}