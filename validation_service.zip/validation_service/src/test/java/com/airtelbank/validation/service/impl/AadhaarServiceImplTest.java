package com.airtelbank.validation.service.impl;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.when;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.xml.bind.JAXBException;

import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.context.MessageSource;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.client.ResourceAccessException;
import org.springframework.web.client.RestClientException;

import com.airtelbank.validation.constants.Constants;
import com.airtelbank.validation.dao.aerospike.AadharVerifyDao;
import com.airtelbank.validation.dao.aerospike.IdentitiesDao;
import com.airtelbank.validation.dao.aerospike.IdentitiesRepository;
import com.airtelbank.validation.dao.aerospike.model.AadhaarVerify;
import com.airtelbank.validation.dao.aerospike.model.Identities;
import com.airtelbank.validation.dao.jpa.model.DocumentAuditLog;
import com.airtelbank.validation.dao.jpa.respository.DocumentAuditRepository;
import com.airtelbank.validation.exception.AadhaarKUAVerifyException;
import com.airtelbank.validation.exception.AadharVerificationException;
import com.airtelbank.validation.exception.ClientSideException;
import com.airtelbank.validation.exception.ClientSideValidationException;
import com.airtelbank.validation.exception.GenericException;
import com.airtelbank.validation.exception.ThirdPartyApiException;
import com.airtelbank.validation.exception.UIDAIAadhaarVerifyException;
import com.airtelbank.validation.exception.VaultException;
import com.airtelbank.validation.exception.VerificationException;
import com.airtelbank.validation.model.AUARequest;
import com.airtelbank.validation.model.AUAResponse;
import com.airtelbank.validation.model.AUAUidaiResponse;
import com.airtelbank.validation.model.AadhaarVaultRequest;
import com.airtelbank.validation.model.AadhaarVaultResponse;
import com.airtelbank.validation.model.AadhaarVaultResponseResult;
import com.airtelbank.validation.model.DataArea;
import com.airtelbank.validation.model.DataAreaAUA;
import com.airtelbank.validation.model.DeviceDetails;
import com.airtelbank.validation.model.Document;
import com.airtelbank.validation.model.EbmHeader;
import com.airtelbank.validation.model.GenerateAadhaarOTPResponse;
import com.airtelbank.validation.model.KUARequest;
import com.airtelbank.validation.model.ResponseDTO;
import com.airtelbank.validation.model.Status;
import com.airtelbank.validation.model.VerifyCustomerAadhaarDetailsResponse;
import com.airtelbank.validation.model.aadhar.generate.otp.GenerateAadhaarOTPData;
import com.airtelbank.validation.model.aadhar.generate.otp.GenerateAadharOTPDataResponse;
import com.airtelbank.validation.model.aadhar.validate.otp.ValidateAadharOTPData;
import com.airtelbank.validation.service.AadhaarService;
import com.airtelbank.validation.service.CommunicationService;
import com.airtelbank.validation.util.AuditUtil;
import com.airtelbank.validation.util.HttpUtil;
import com.airtelbank.validation.util.KibanaUtil;
import com.airtelbank.validation.util.LogMasker;
import com.airtelbank.validation.util.ValidationUtil;

public class AadhaarServiceImplTest {

    @Mock
    HttpUtil httpUtil;
    @Mock
    Environment environment;
    @Mock
    MessageSource messageSource;
    @Mock
    AadhaarService aadhaarService;
    @Mock
    ValidationUtil validationUtil;
    @Mock
    AadharVerifyDao aadharVerifyDao;
    @Mock
    IdentitiesRepository identitiesRepository;
    @Mock
    DocumentAuditRepository documentAuditRepository;
    @Mock
    private IdentitiesDao identitiesDao;
    @Mock 
    private CommunicationService communicationService;
    @Mock
    private LogMasker logMasker;
    @Mock
    private AuditUtil auditUtil;
    
    @Mock
    private KibanaUtil kibanaUtil;

    @InjectMocks
    AadhaarServiceImpl aadhaarServiceImpl;

    private final static String AUAResponse = "<verifyCustomerAadhaarDetailsResMsg><ebmHeader><lob>Mobility</lob><consumerTransactionId>20160613151405</consumerTransactionId><consumerName>e-CAF</consumerName><programmeName>Aadhaar</programmeName></ebmHeader><dataArea><verifyCustomerAadhaarDetailsResponse><status><statusCode>VerifyCustomerAadhaarDetails-0001-S</statusCode><statusDescription>CustomerAadhaarDetailsverified</statusDescription></status><responseCode>09d189368f364b7a972ac39ebaae2559</responseCode><uidToken>01001088A1hAAtDjztQ0+aD7qUJKucxvmVjJkFIYIOdzyJYkMpNx9d/imY7nAvN7DpsIQg7W</uidToken><userIdentifierType>V</userIdentifierType><responseTimeStamp>2016-05-23T15:15:10</responseTimeStamp></verifyCustomerAadhaarDetailsResponse></dataArea></verifyCustomerAadhaarDetailsResMsg>";
    private final static String KUAResponse = "<getAadhaarProfileResponse><ebmHeader><lob>Mobility</lob><consumerTransactionId>20160613151405</consumerTransactionId><consumerName>e-CAF</consumerName><programmeName>Aadhaar</programmeName></ebmHeader><dataArea><getUserAadharProfileResponse><status><statusCode>GetUserAadhaarProfile-0001-S</statusCode><statusDescription>AadhaarProfiledetailsfound</statusDescription></status><responseCode>09d189368f364b7a972ac39ebaae2559</responseCode><responseTimeStamp>2016-05-23T15:15:10</responseTimeStamp><uidToken>01001088A1hAAtDjztQ0+aD7qUJKucxvmVjJkFIYIOdzyJYkMpNx9d/imY7nAvN7DpsIQg7W</uidToken><userIdentifierType>A</userIdentifierType><aadhaarNumber>216669404206</aadhaarNumber><action>DummyAction</action><residentIdentity><name>ashoksharma</name><dob>25-02-1972</dob><gender>M</gender><phone>2810806979</phone><email>crbiitr@dummyemail.com</email><careOf>Singh</careOf><house>676</house><street>12MaulanaAzadMarg</street><landMark>NearChurch</landMark><locality>Sharsvatiroad</locality><vtc>Bangalore</vtc><subDistrict>Bangalore</subDistrict><district>Bangalore</district><state>Karnataka</state><country>India</country><pincode>560008</pincode><postOfficeName></postOfficeName></residentIdentity><photo>iVBORw0KGgoAAAANSUhEUgAAAOsAAADWCAMAAAAHMIWUAAAAkFBMVEX/////AAD/8vL/rq7/aGj/2dn/fHz/9fX/iYn/+/v/3t7/zMz/7Oz/xMT/5ub/sbH/lJT/ubn/U1P/j4//b2//xcX/T0//0tL/n5//2tr/HBz/mpr/XV3/hob/7u7/YWH/pKT/cnL/RUX/Pz//KCj/vb3/OTn/o6P/EBD/RET/JSX/Li7/S0v/WFj/eHj/gYGIaB0IAAAKz0lEQVR4nO2d61riMBCGKQeBgkWUFQTBgoLHde//7hYVyDfJpIeQtqlPvn/S2uZt02QymUwaDS8vLy8vLy8vLy+n1J9ux+Px9s80HFZdlAIVjZcfLwFq3p5Nqy6VfUWtdqBR+7LqwtnUYDnXgf7oZlV1Ee0o6iVzHl5uVHU5z9fldRbSL02qLuqZil/SGU+a1/jV9q9ygH5rVHWRTZWbdK/Pqgtton7LgHSvv1UXPL/+mJHWEDa6NUYNgnXVpc+l9Rmke8VVlz+7tnm6GVZ3VSNk1HBzLmkQvFQNkU2Gra+km6oxMqj/1wpqELg/EphaIq1BW2xiJ+nktsei/2ERNfhXNU6SQpuke/WrBtJraxk1GFdNpJWdrgbl7MDdPmoQVM2kURGoQbNqKlbjIlADJ93Gg0JQnXTHNItBDRZVgzGyakKALqoGU2XTMCRyzyS2bS4JtatGU/R+Ds7T/fpistMcdM7HFhtzPraOTv4u3z3fVwqmqmtKOumQ63Czla59r/+MQOdxV77QRD3LsXbY6LW+bblLqd+9Y/3rjQGqxhxS3TduDer6+UmftRdTTJKwRJJ05R7eXCQ4G5QBRHkcWZRz0uY18U3JRsmuLIpsyoea8v3JQ4hlOQwZdZeHNLXoMqtbTVOOIfpTekMjs7rlIM7eNGWZnpFY3wovfi7N7L3UhsLq1uea1e7POOe2ov/lmLcpUx1+z2oS0JZuXmjJ8ytL+Ed2o5ZebVZguU200vAJPeaIQ1uQ/3TOOazzKBzVynMxErXo2ji90bhMJG0rg9Qk0eHhoKgim+tBT/qUsyElDZ1rLdO3dLX4PbfT/gn/3UWXf6PxyJE+5O8cyTyJk691r6VC+mkSBEyGh6yTxgVFn1DKzcLM3umQD8ByCa2qM77q9Xo3LXO77hVZ/1gsmnsiwRbXVZemWJHv3a2Bq22RJS2uWcJ2RbxqjrnUbIuYEXVdtdIcLdeTyWeKl4xMHuQaLrijlZh8SzIOyOSGe/PLWdQnDY5+1Q2ZJ3HaitBK9uJrnU5k2OrcCD2LRoEsTaA3efsd/hy3xXhT+UaHPBNnTf4kcY7jHnciGcnF5RbSjtQKHPBx3uSjviq9nBbEhyfG6okRHq/DKhVFmvBEtYld1R61wS+7UmMHyDOpZQXmP9bgQTmPoMalF9OKWNRH5TSC6ta0cmaxUUCq6TfEww46vrOIDe56UqJfSGfjVmxPdnFJM+YKKvZKb7W0gb/EoSrTOjhH7VzgbGYxi6/elbd6AUdZy7EeUkNjVVSMxatpA/wtBfVNRh3CWvaXuvqWvqTE/ivfKlZy1b6ok5RgERl1/Uvqb0ONEpd8EdjVfNS2qzlIWpgvuVSw/a2/c58OcSgPxlbMa+lYoiIziySg8A4P1XMAJ4nUYRh9R/fw++3vmIcj8QQnx2FIomVq6SxkRAKKD5buJVmzsHY4u0A+0RHdRRS1/pGsiJu65O/JooTYrv0w9nfFQSQsEJ3X3E5SpUY7/VbShmZB9/WvSs0qpAxhnxZ1N3312mL4w3Vc5zFqBt2NZou9ZiPH1id4eXl5eXl5eXl5eXl5eXl5eXl5eXl5eSVqsQuC3bKuEcB5dIq4q3G4aEZBHLCzyfgtiUyi1zRmP6vIas7bqktTrOiUcmXBPKXcmLLma4uHg7jXnp/ZfvfD7eKhnNS9lDVz6NI0Xr8bPR9U83LWPoROlbLRDmXNGmWILZo5K0Rll5J+mrJm/a+ObdZSNtskUaWZ01RObbOW0rWTbAmZ88gNbLOWk5ICPr3sES81ZW1Eh2xrmxxBTH9ss5a29CWcrSdXuaL368uaX8hqHk4MrO6lyDwJ13OYL+eoH6t5DJ911nC0fNhsrtvLeGAcKtqcjmeL3nK5eD6AIWtSsqZuNB0MBh2NOWaVNVzQ5P3vsfbU1WBxy9fGzpKk3Hr8OkvK9/qy+/h7q+TFCa/Ecsrdkrm4PdbmbB6oUpcQdUY3Dz9nMglI+8/KRUYq67ekLmsgZ0ndKSsFbLF27gNe8npVuKFaG7ltsBoaVtr3cHvp/JVGqXZYw2vmVkfRxiSBlc1M/Kw7gpW0yVUp5XnYYWUTz/J3hBvG9CLcqzm4LjhWeIRD5vCPSKWyw5qytyna+HBDsiYy4l/Nz0CTS6guHHNJ+/r1+Vuf870ms+KV4YboCNFt2hxlYH1ijh71yd/6HBvx5PV9v1i0xuPxgn7AIXMmYZV36Xj7nI3G43gZN7Sspz5HWhj9Rv+EWmzLHv6+wmssevEhfsOwu9gzxyrVwoVsDCDr5HLa2euESpJXtfdf8ZAkwge/rC3WfW9xJZUQP0DxK6RVE30vYZW7ColVdqBjDTqsHR3iuxVtGLCelXmkqy4mxwZLdBDw0HlWzsWXwIquKLFM9oW7HrDa9sKju0V0pams3NIy9EtItj+ssgQnEhglImd6gaxYicWnCaxiwTaycmuY9az4nxH/8+nTKpIVBgLCYwhPnGfl3iv2SNSohwb8CX+HXfpOD69IVjCRRTdnmRWqMJnPXYvfT58KsFpPLw5Gn/iULLPCAbJaFtKanfoX26zNcDrY7jUatWbQGAofJRTCjPVOd4A00NC1nXJW2GTtjyeAR8SyikpnzAqWSdDqd08a4iJ4+6zDpK1Oz2TFTpTUYUwXo9XRxLLGmnzXolj5caCk439YYk3bbDoHK5dkAbfwIqx8blBJxw/ZDmtHfyOZFRIEik7XmDXTJtfHBtoKq94vkMgqLNU0Vqw2xG7S+F6ojj48K6zpT5dlFZPbxbIejXEbdhPdOC34GDe7/b3wbZfBOn972+12m9vb2/v2XpO91hdfYr5XU1ZpU2LRpUOqqTNZcTyuY02vlhZYyQ6RO/CjQTqQHKxcMFukOw6D8vTiA+tHfsxvEYcp+hTAYyB8HnZZwdlfBivJv0SyXsM4p6j3CqEmZbCSvpVMzZXAOhG/p2/LAZm6N3kpf4S+ILqvLtjfRbFiRurUkp7Pii402haCsVoUK948NQgOfBiveSnV21G3qxkrN2+OXTVhxcYiNdkesKp51zMJx5b0k7fHijsY0PcObX1qLBq8FcMNsrB+vZAj9lj1dRx3BkgLCoaWxXQzMLgbnQNMa5t4259jxapKWdFoS0sDijUwN+WPcLxMdsiAzk/ULyNWfJ7SJhxrOMS0TiswOTvJp2YR2SIFXywYVIIVegkzVqmY+CkrW8mvrnDyF081XTBDZgHF9CM2njlY2egYtEOlzOno/Hkiz2G6/voNZmCxnIYpUums+sFMXJF9js5lpfOzLUSiw6xe+P0k+qvBzdGnKU4m3qn2wGiBQ1JkyOHCZ7KqE/e3p5Ly2wwJieZembzf5V/jwG6ogYLAH/D78/4mPrYyVq4pngkXKYQS708JTFpz90pWim8NhyCGrKrHENqwdfLtRcyYspG9Aas2tONbMZ4JrLzPVBcfLMelYXs9CRKE3a5cTqO4/+Ebe5+9PmkIZur8qzYWWsrdS75rdgeeH1J6ewnWMG6C/2r+yZHuqfES+rhv2hjTC3f4cLKe0tauSKJY0zin7pU8c7Vm5itS42CSYtwvobLKi0CmSsPT5vvQAVSQM9ZfhfHn5n3f7L4/tq/GurULzWEYhlEUYVBsN/rScNXspnV6q7vtqNUacWlPu5c3x6n83TpOih+/G7cWN3u16p2JvB+FoWbLTS8vLy8vLy8vL68z9B/6aYoEi16yjQAAAABJRU5ErkJggg==</photo><eAadhaarPDF>MQDFAPqlSgCvAP8lRQB8AQuhPABwAQ</eAadhaarPDF></getUserAadharProfileResponse></dataArea></getAadhaarProfileResponse>";

    private final static String AUAResponse1 = "<verifyCustomerAadhaarDetailsResMsg><ebmHeader><lob>Mobility</lob><consumerTransactionId></consumerTransactionId><consumerName>e-CAF</consumerName><programmeName>Aadhaar</programmeName></ebmHeader><dataArea><verifyCustomerAadhaarDetailsResponse><status><statusCode>VerifyCustomerAadhaarDetails-0001-S</statusCode><statusDescription>CustomerAadhaarDetailsverified</statusDescription></status><responseCode>09d189368f364b7a972ac39ebaae2559</responseCode><uidToken>01001088A1hAAtDjztQ0+aD7qUJKucxvmVjJkFIYIOdzyJYkMpNx9d/imY7nAvN7DpsIQg7W</uidToken><userIdentifierType>V</userIdentifierType><responseTimeStamp>2016-05-23T15:15:10</responseTimeStamp></verifyCustomerAadhaarDetailsResponse></dataArea></verifyCustomerAadhaarDetailsResMsg>";
    @Before
    public void init() {
        MockitoAnnotations.initMocks(this);
        ReflectionTestUtils.setField(aadhaarServiceImpl, "maxVerifyCount", 3);
        ReflectionTestUtils.setField(aadhaarServiceImpl, "defaultDeviceCode", "code");
        ReflectionTestUtils.setField(aadhaarServiceImpl, "residentConsent", "code");
        ReflectionTestUtils.setField(aadhaarServiceImpl, "printFormatRequest", "code");
        ReflectionTestUtils.setField(aadhaarServiceImpl, "localLangRequired", "code");
        ReflectionTestUtils.setField(aadhaarServiceImpl, "otpVerifyUrl", "otpurl");
        ReflectionTestUtils.setField(aadhaarServiceImpl, "maxGenerateAadhaarOTPCount", 3);
        ReflectionTestUtils.setField(aadhaarServiceImpl, "maxGenerateAadhaarOTPSuccessMessage", "Aadhaar OTP generated successfully.");
        ReflectionTestUtils.setField(aadhaarServiceImpl, "userWaitingTime", 10);
        ReflectionTestUtils.setField(aadhaarServiceImpl, "generateAadhaarOTPUrl", "testurl");
        ReflectionTestUtils.setField(aadhaarServiceImpl, "aadhaarVaultPassphrase", "TbueAgc3azFf");
        ReflectionTestUtils.setField(aadhaarServiceImpl, "aadhaarVaultBaseUrl", "http://10.56.110.191:15153/getAadhaarVaultAadhaarId/");
        ReflectionTestUtils.setField(aadhaarServiceImpl, "vaultRefContext", "referenceKey");
        ReflectionTestUtils.setField(aadhaarServiceImpl, "residentConsent", "Y");
        ReflectionTestUtils.setField(aadhaarServiceImpl, "printFormatRequest", "Y");
        ReflectionTestUtils.setField(aadhaarServiceImpl, "localLangRequired", "N");
        ReflectionTestUtils.setField(aadhaarServiceImpl, "vaultAadhaarContext", "aadhaar");
        ReflectionTestUtils.setField(aadhaarServiceImpl, "vaultRemoveAadhaarContext", "aadhaarReference");
        ReflectionTestUtils.setField(aadhaarServiceImpl, "key", "MFwwDQYJKoZIhvcNAQEBBQADSwAwSAJBAJlCGtRv12B7BRvS42CMg581EJ8/j+0ezayahBGw8ces0k234e/UYvb5R+PjjwvtEUe1eDwl8gmdelOl6Zx0z/kCAwEAAQ==");
        ReflectionTestUtils.setField(aadhaarServiceImpl,"defaultBiometricType","FMR");
        List<String> bType = Arrays.asList("FMR","FIR","FMR,FIR");
        ReflectionTestUtils.setField(aadhaarServiceImpl,"validBiomerticTypes",bType);
    }

    @Test(expected = AadharVerificationException.class)
    public void verifyAadhaarIdentityWhenNullIdentity() throws Exception {
        when(identitiesRepository.findOne(Mockito.anyString())).thenReturn(null);
        aadhaarServiceImpl.verifyAadhaarIdentity(Document.builder().build());
    }

    @Test(expected = AadharVerificationException.class)
    public void verifyAadhaarIdentityWhenMaxCountExceeds() throws Exception {
        Document request = Document.builder().id("id").build();
        Identities identity = Identities.builder().verifyCount(3).build();
        when(identitiesRepository.findOne(Mockito.anyString())).thenReturn(identity);
        aadhaarServiceImpl.verifyAadhaarIdentity(request);
    }

    @Test
    public void verifyAadhaarIdentityWhenSuccess() throws Exception {
        Document request = Document.builder().id("id").userIdentifierType("type").verificationToken("token").build();
        Identities identity = Identities.builder().verifyCount(2).docNumber("doc").mobileNumber("9876543210").userIdentifierType("A").build();
        AadhaarVaultResponse vaultResponse = AadhaarVaultResponse.builder().referenceKey("refKey").uid("123456781234").build();
        when(identitiesRepository.findOne(Mockito.anyString())).thenReturn(identity);
        when(aadhaarService.getAadhaarNumber(Mockito.any(AadhaarVaultRequest.class))).thenReturn(vaultResponse);
        ValidateAadharOTPData otpData = new ValidateAadharOTPData();
        when(validationUtil.getAadhaarProfileRequest(Mockito.any(Identities.class), Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyString())).thenReturn(otpData);
        String httpRes = "<?xml version=\"1.0\" encoding=\"UTF-8\"?> <root> <dataArea> <getUserAadharProfileResponse> <responseCode> 12345609876 </responseCode><status> <statusCode>code-0001-S</statusCode> <statusDescription> success </statusDescription></status> <userIdentifierType>A</userIdentifierType> </getUserAadharProfileResponse> </dataArea> </root>";
        when(httpUtil.sendRequest(Mockito.anyString(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(httpRes);
        ResponseDTO<AadhaarVerify> response = aadhaarServiceImpl.verifyAadhaarIdentity(request);
        assertEquals(Constants.SUCCESS_STATUS, response.getMeta().getStatus());
    }

    @Test(expected = UIDAIAadhaarVerifyException.class)
    public void verifyAadhaarIdentityWhenFailure() throws Exception {
        Document request = Document.builder().id("id").userIdentifierType("type").verificationToken("token").build();
        Identities identity = Identities.builder().verifyCount(2).docNumber("doc").mobileNumber("9876543210").userIdentifierType("A").build();
        AadhaarVaultResponse vaultResponse = AadhaarVaultResponse.builder().referenceKey("refKey").uid("123456781234").build();
        when(identitiesRepository.findOne(Mockito.anyString())).thenReturn(identity);
        when(aadhaarService.getAadhaarNumber(Mockito.any(AadhaarVaultRequest.class))).thenReturn(vaultResponse);
        ValidateAadharOTPData otpData = new ValidateAadharOTPData();
        when(validationUtil.getAadhaarProfileRequest(Mockito.any(Identities.class), Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyString())).thenReturn(otpData);
        String httpRes = "<?xml version=\"1.0\" encoding=\"UTF-8\"?> <root> <dataArea> <getUserAadharProfileResponse> <status> <statusCode>code-0002-P</statusCode> </status> <userIdentifierType>A</userIdentifierType> </getUserAadharProfileResponse> </dataArea> </root>";
        when(httpUtil.sendRequest(Mockito.anyString(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(httpRes);
        ResponseDTO<AadhaarVerify> response = aadhaarServiceImpl.verifyAadhaarIdentity(request);
    }

    @Test(expected = ClientSideException.class)
    public void generateAadhaarOTPWhenException() throws Exception {
        aadhaarServiceImpl.generateAadhaarOTP(null);
    }

    @Test
    public void generateAadhaarOTPWhenSuccess() throws Exception {
        Document request = getStubDocument();
        AadhaarVaultResponse aadhaarVaultResponse = getStubAadhaarVault();
        List<Identities> identities = getStubIdentitiesWithGenCount();

        when(environment.getProperty("aadhaarVault.apikey")).thenReturn("apikey");
        when(aadhaarService.getAadhaarNumber(Mockito.any(AadhaarVaultRequest.class))).thenReturn(aadhaarVaultResponse);
        when(identitiesRepository.findByMobileNumberAndDocNumber(Mockito.anyString(), Mockito.anyString())).thenReturn(identities);
        when(identitiesDao.updateIdentityInRepo(Mockito.mock(Identities.class), false)).thenReturn(true);
        when(identitiesDao.addAndSaveIdentityInRepo(Mockito.mock(Identities.class))).thenReturn(true);
        when(validationUtil.createAadhaarOTPRequest(Mockito.any(Document.class), Mockito.anyString())).thenReturn(getStubGenerateAadhaarOTPData());
        when(documentAuditRepository.save(Mockito.mock(DocumentAuditLog.class))).thenReturn(new DocumentAuditLog());
        String res = "<getCustomerAadhaarOTPResMsg><ebmHeader><lob>Mobility</lob><consumerTransactionId>20160613151405</consumerTransactionId><consumerName>APBL</consumerName><programmeName>AadhaarOTPKYC</programmeName></ebmHeader><dataArea><getCustomerAadhaarOTPResponse><status><statusCode>GetCustomerAadhaarOTP-0001-S</statusCode><statusDescription>AadhaarProfiledetailsfound</statusDescription></status><responseCode>09d189368f364b7a972ac39ebaae2559</responseCode><responseTimeStamp>2016-05-23T15:15:10</responseTimeStamp><mobileNumber>1234567890</mobileNumber><email>test@gmail.com</email><userIdentifierType>V</userIdentifierType></getCustomerAadhaarOTPResponse></dataArea></getCustomerAadhaarOTPResMsg>";
        when(httpUtil.sendRequest(Mockito.anyString(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(res);

        ResponseDTO<Document> responseDTO = (ResponseDTO<Document>) aadhaarServiceImpl.generateAadhaarOTP(request);

        assertEquals(0, responseDTO.getMeta().getStatus());
        assertEquals("test@gmail.com", responseDTO.getData().getMaskedEmailId());
        assertEquals("1234567890", responseDTO.getData().getMaskedMobileNumber());
    }

    @Test
    public void generateAadhaarOTPWhenSuccessWithGenCountInIdentities() throws Exception {
        Document request = getStubDocument();
        AadhaarVaultResponse aadhaarVaultResponse = getStubAadhaarVault();
        List<Identities> identities = getStubIdentitiesWithGenCount();

        when(environment.getProperty("aadhaarVault.apikey")).thenReturn("apikey");
        when(aadhaarService.getAadhaarNumber(Mockito.any(AadhaarVaultRequest.class))).thenReturn(aadhaarVaultResponse);
        when(identitiesRepository.findByMobileNumberAndDocNumber(Mockito.anyString(), Mockito.anyString())).thenReturn(identities);
        when(identitiesDao.updateIdentityInRepo(Mockito.mock(Identities.class), false)).thenReturn(true);
        when(identitiesDao.addAndSaveIdentityInRepo(Mockito.mock(Identities.class))).thenReturn(true);
        when(validationUtil.createAadhaarOTPRequest(Mockito.any(Document.class), Mockito.anyString())).thenReturn(getStubGenerateAadhaarOTPData());
        when(documentAuditRepository.save(Mockito.mock(DocumentAuditLog.class))).thenReturn(new DocumentAuditLog());
        String res = "<getCustomerAadhaarOTPResMsg><ebmHeader><lob>Mobility</lob><consumerTransactionId>20160613151405</consumerTransactionId><consumerName>APBL</consumerName><programmeName>AadhaarOTPKYC</programmeName></ebmHeader><dataArea><getCustomerAadhaarOTPResponse><status><statusCode>GetCustomerAadhaarOTP-0001-S</statusCode><statusDescription>AadhaarProfiledetailsfound</statusDescription></status><responseCode>09d189368f364b7a972ac39ebaae2559</responseCode><responseTimeStamp>2016-05-23T15:15:10</responseTimeStamp><mobileNumber>1234567890</mobileNumber><email>test@gmail.com</email><userIdentifierType>V</userIdentifierType></getCustomerAadhaarOTPResponse></dataArea></getCustomerAadhaarOTPResMsg>";
        when(httpUtil.sendRequest(Mockito.anyString(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(res);

        ResponseDTO<Document> responseDTO = (ResponseDTO<Document>) aadhaarServiceImpl.generateAadhaarOTP(request);

        assertEquals(0, responseDTO.getMeta().getStatus());
        assertEquals("test@gmail.com", responseDTO.getData().getMaskedEmailId());
        assertEquals("1234567890", responseDTO.getData().getMaskedMobileNumber());
    }

    @Test
    public void getAadhaarReferenceSuccess() throws IOException {
        AadhaarVaultResponse aadhaarVaultResponse = getStubAadhaarVaultResponse();
        when(httpUtil.handleRequest(Mockito.anyString(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(getStubAadhaarVaultResponse());
        AadhaarVaultResponse response = aadhaarServiceImpl.getAadhaarReference(getStubAadhaarVaultRequest());
        assertEquals(aadhaarVaultResponse.getUid(), response.getUid());
        assertEquals(aadhaarVaultResponse.getResult().getStatusCode(), response.getResult().getStatusCode());
    }

    @Test(expected = VaultException.class)
    public void getAadhaarReferenceSuccessWithException() throws IOException {
        AadhaarVaultResponse aadhaarVaultResponse = getStubAadhaarVaultResponseWithFailedStatus();
        when(httpUtil.handleRequest(Mockito.anyString(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(aadhaarVaultResponse);
        aadhaarServiceImpl.getAadhaarReference(getStubAadhaarVaultRequest());
    }

    @Test(expected = GenericException.class)
    public void getAadhaarReferenceSuccessWithGenericException() throws IOException {
        AadhaarVaultResponse aadhaarVaultResponse = getStubAadhaarVaultResponseWithFailedStatus();
        when(httpUtil.handleRequest(Mockito.anyString(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(null);
        aadhaarServiceImpl.getAadhaarReference(getStubAadhaarVaultRequest());
    }

    @Test
    public void verifyIdentityWithSuccess() throws IOException, UIDAIAadhaarVerifyException, JAXBException, VerificationException {
        when(identitiesRepository.findOne(Mockito.anyString())).thenReturn(getStubIdentities().get(0));
        when(validationUtil.getAadhaarProfileRequest(Mockito.any(), Mockito.any(),
                Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(getStubValidateAadharOTPData());
        when(httpUtil.sendRequest(Mockito.anyString(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any())).thenReturn("<getAadhaarProfileResponse><ebmHeader><lob>Mobility</lob><consumerTransactionId>20160613151405</consumerTransactionId><consumerName>APBL</consumerName><programmeName>AadhaarOTPKYC</programmeName></ebmHeader><dataArea><getUserAadharProfileResponse><status><statusCode>GetUserAadhaarProfile-0001-S</statusCode><statusDescription>AadhaarProfiledetailsfound</statusDescription></status><responseCode>09d189368f364b7a972ac39ebaae2559</responseCode><responseTimeStamp>2016-05-23T15:15:10</responseTimeStamp><action>DummyAction</action><uidToken>01001088A1hAAtDjztQ0+aD7qUJKucxvmVjJkFIYIOdzyJYkMpNx9d/imY7nAvN7DpsIQg7W</uidToken><userIdentifierType>V</userIdentifierType><aadhaarNumber>930282337711</aadhaarNumber><residentIdentity><name>MartineBokassa</name><dob>02-02-1999</dob><gender>F</gender><phone>9168141231</phone><email>test@gmail.com</email><careOf>careof</careOf><house>SanskritiSociety</house><street>Sector-3</street><landMark>MainMarket</landMark><locality></locality><vtc>Dwarka</vtc><subDistrict>Dwarka</subDistrict><district>DELHI</district><state>DELHI</state><country>India</country><pincode>110030</pincode><postOfficeName>HDS</postOfficeName></residentIdentity><photo>ABC</photo><eAadhaarPDF>MQDFAPqlSgCvAP8lRQB8AQuhPABwAQ</eAadhaarPDF></getUserAadharProfileResponse></dataArea></getAadhaarProfileResponse>");
        AadhaarVerify response = aadhaarServiceImpl.verifyIdentity("test", "test", "test", "123");
        assertEquals("930282337711", response.getAadhaarNumber());
    }

    @Test(expected = VerificationException.class)
    public void verifyIdentityWithDocTypeNullAndVerificationException() throws IOException, UIDAIAadhaarVerifyException, JAXBException, VerificationException {
        Identities identities = getStubIdentities().get(0);
        identities.setDocType(null);
        when(identitiesRepository.findOne(Mockito.anyString())).thenReturn(identities);
        aadhaarServiceImpl.verifyIdentity("test", "test", "test", "123");
    }

    @Test(expected = VerificationException.class)
    public void verifyIdentityWithVerificationException() throws IOException, UIDAIAadhaarVerifyException, JAXBException, VerificationException {
        when(identitiesRepository.findOne(Mockito.anyString())).thenReturn(null);
        aadhaarServiceImpl.verifyIdentity("test", "test", "test", "123");
    }

    @Test
    public void getAadhaarNumberSuccess() throws IOException {
        when(httpUtil.handleRequest(Mockito.anyString(),
                Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(getStubAadhaarVaultResponse());
        AadhaarVaultResponse response = aadhaarServiceImpl.getAadhaarNumber(getStubAadhaarVaultRequest());
        assertEquals("uid-00", response.getResult().getStatusCode());
    }

    @Test(expected = VaultException.class)
    public void getAadhaarNumberSuccessWithVaultException() throws IOException {
        when(httpUtil.handleRequest(Mockito.anyString(),
                Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(getStubAadhaarVaultResponseWithFailedStatus());
        aadhaarServiceImpl.getAadhaarNumber(getStubAadhaarVaultRequest());
    }

    @Test(expected = GenericException.class)
    public void getAadhaarNumberSuccessWithGenericException() throws IOException {
        when(httpUtil.handleRequest(Mockito.anyString(),
                Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(null);
        aadhaarServiceImpl.getAadhaarNumber(getStubAadhaarVaultRequest());
    }

    @Test(expected = GenericException.class)
    public void getAadhaarNumberSuccessWithRestClientException() throws IOException {
        when(httpUtil.handleRequest(Mockito.anyString(),
                Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any())).thenThrow(new RestClientException(""));
        aadhaarServiceImpl.getAadhaarNumber(getStubAadhaarVaultRequest());
    }

    @Test(expected = ThirdPartyApiException.class)
    public void getAadhaarNumberSuccessWithResourceAccessException() throws IOException {
        when(httpUtil.handleRequest(Mockito.anyString(),
                Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any())).thenThrow(new ResourceAccessException(""));
        aadhaarServiceImpl.getAadhaarNumber(getStubAadhaarVaultRequest());
    }

    @Test(expected = GenericException.class)
    public void getAadhaarNumberSuccessWithException() throws IOException {
        when(httpUtil.handleRequest(Mockito.anyString(),
                Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any())).thenThrow(new RuntimeException());
        aadhaarServiceImpl.getAadhaarNumber(getStubAadhaarVaultRequest());
    }

    @Test
    public void validateAUAWithSuccess() {
        when(environment.getProperty("config.aua.url.new")).thenReturn("http://10.56.110.191:15153/aadhaarABAUA");
        when(httpUtil.postXmlRequest(Mockito.anyString(), Mockito.anyString())).thenReturn(AUAResponse);
        AUAResponse auaResponse = aadhaarServiceImpl.validateAUA(getStubAUARequest(), "test");
        assertEquals("VerifyCustomerAadhaarDetails-0001-S", auaResponse.getStatusCode());
    }

    @Test
    public void validateAUAWithBiometricTypeFIRSuccess() {
        when(environment.getProperty("config.aua.url.new")).thenReturn("http://10.56.110.191:15153/aadhaarABAUA");
        when(httpUtil.postXmlRequest(Mockito.anyString(), Mockito.anyString())).thenReturn(AUAResponse);
        AUARequest request = getStubAUARequest();
        request.setBiometricType("FIR");
        AUAResponse auaResponse = aadhaarServiceImpl.validateAUA(request, "test");
        assertEquals("VerifyCustomerAadhaarDetails-0001-S", auaResponse.getStatusCode());
    }

    @Test(expected = GenericException.class)
    public void validateAUAWithInvalidBiometricType() {
        when(environment.getProperty("config.aua.url.new")).thenReturn("http://10.56.110.191:15153/aadhaarABAUA");
        when(httpUtil.postXmlRequest(Mockito.anyString(), Mockito.anyString())).thenReturn(AUAResponse);
        AUARequest request = getStubAUARequest();
        request.setBiometricType("TEST");
        AUAResponse auaResponse = aadhaarServiceImpl.validateAUA(request, "test");
        assertEquals("1792", auaResponse.getResponseCode());
    }
    @Test(expected = ThirdPartyApiException.class)
    public void validateAUAWithSuccessWithResourceAccessException() {
        when(environment.getProperty("config.aua.url.new")).thenReturn("http://10.56.110.191:15153/aadhaarABAUA");
        when(httpUtil.postXmlRequest(Mockito.anyString(), Mockito.anyString())).thenThrow(new ResourceAccessException(""));
        aadhaarServiceImpl.validateAUA(getStubAUARequest(), "test");
    }

    @Test
    public void validateAUAWithSuccessWithHttpClientErrorExceptionWithResponseBody() {
        when(environment.getProperty("config.aua.url.new")).thenReturn("http://10.56.110.191:15153/aadhaarABAUA");
        when(httpUtil.postXmlRequest(Mockito.anyString(), Mockito.anyString())).thenThrow(new HttpClientErrorException(HttpStatus.BAD_REQUEST, "400", AUAResponse.getBytes(StandardCharsets.UTF_8), StandardCharsets.UTF_8));
        AUAResponse auaResponse = aadhaarServiceImpl.validateAUA(getStubAUARequest(), "test");
        assertEquals("VerifyCustomerAadhaarDetails-0001-S", auaResponse.getStatusCode());
    }

    @Test(expected = GenericException.class)
    public void validateAUAWithSuccessWithHttpClientErrorExceptionWithEmptyResponseBody() {
        when(environment.getProperty("config.aua.url.new")).thenReturn("http://10.56.110.191:15153/aadhaarABAUA");
        when(httpUtil.postXmlRequest(Mockito.anyString(), Mockito.anyString())).thenThrow(new HttpClientErrorException(HttpStatus.BAD_REQUEST));
        aadhaarServiceImpl.validateAUA(getStubAUARequest(), "test");
    }

    @Test
    @Ignore
    public void validateAUAWithSuccessWithHttpServerErrorExceptionWithResponseBody() {
        when(environment.getProperty("config.aua.url.new")).thenReturn("http://10.56.110.191:15153/aadhaarABAUA");
        when(httpUtil.postXmlRequest(Mockito.anyString(), Mockito.anyString())).thenThrow(new HttpServerErrorException(HttpStatus.BAD_REQUEST, "400", AUAResponse.getBytes(StandardCharsets.UTF_8), StandardCharsets.UTF_8));
        AUAResponse auaResponse = aadhaarServiceImpl.validateAUA(getStubAUARequest(), "test");
        assertEquals("VerifyCustomerAadhaarDetails-0001-S", auaResponse.getStatusCode());
    }

    @Test(expected = GenericException.class)
    public void validateAUAWithSuccessWithHttpServerErrorExceptionWithEmptyResponseBody() {
        when(environment.getProperty("config.aua.url.new")).thenReturn("http://10.56.110.191:15153/aadhaarABAUA");
        when(httpUtil.postXmlRequest(Mockito.anyString(), Mockito.anyString())).thenThrow(new HttpServerErrorException(HttpStatus.BAD_REQUEST));
        aadhaarServiceImpl.validateAUA(getStubAUARequest(), "test");
    }

    @Test(expected = GenericException.class)
    public void validateAUAWithSuccessWithRestClientException() {
        when(environment.getProperty("config.aua.url.new")).thenReturn("http://10.56.110.191:15153/aadhaarABAUA");
        when(httpUtil.postXmlRequest(Mockito.anyString(), Mockito.anyString())).thenThrow(new RestClientException(""));
        aadhaarServiceImpl.validateAUA(getStubAUARequest(), "test");
    }

    @Test
    public void getAadhaarDetailsKUASuccess() throws IOException {
        when(environment.getProperty("config.kua.url")).thenReturn("http://10.56.110.191:15153/aadhaarABKUA");
        when(environment.getProperty("aadhaarVault.apikey")).thenReturn("key");
        when(httpUtil.postXmlRequest(Mockito.anyString(), Mockito.anyString())).thenReturn(KUAResponse);
        when(httpUtil.handleRequest(Mockito.anyString(),
                Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(getStubAadhaarVaultResponse());
        when(aadhaarService.getAadhaarReference(Mockito.any())).thenReturn(getStubAadhaarVaultResponse());
        when(messageSource.getMessage("aadhaar.kua.failure.code", null, null)).thenReturn("2445");
        when(messageSource.getMessage("aadhaar.kua.failure.msg", null, null)).thenReturn("We are experiencing some technical issues. Please try again later.");
        when(messageSource.getMessage("config.kua.success.code", null, null)).thenReturn("2400");
        when(messageSource.getMessage("config.kua.success.msg", null, null)).thenReturn("Aadhaar Profile details found");
        ResponseDTO<AadhaarVerify> kuaResponse = aadhaarServiceImpl.getAadhaarDetailsKUA(getStubKUARequest(), "test");
        assertEquals("2400", kuaResponse.getMeta().getCode());
    }

    @Test
    public void getAadhaarDetailsKUAWithBiometricTypeSuccess() throws IOException {
        when(environment.getProperty("config.kua.url")).thenReturn("http://10.56.110.191:15153/aadhaarABKUA");
        when(environment.getProperty("aadhaarVault.apikey")).thenReturn("key");
        when(httpUtil.postXmlRequest(Mockito.anyString(), Mockito.anyString())).thenReturn(KUAResponse);
        when(httpUtil.handleRequest(Mockito.anyString(),
                Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(getStubAadhaarVaultResponse());
        when(aadhaarService.getAadhaarReference(Mockito.any())).thenReturn(getStubAadhaarVaultResponse());
        when(messageSource.getMessage("aadhaar.kua.failure.code", null, null)).thenReturn("2445");
        when(messageSource.getMessage("aadhaar.kua.failure.msg", null, null)).thenReturn("We are experiencing some technical issues. Please try again later.");
        when(messageSource.getMessage("config.kua.success.code", null, null)).thenReturn("2400");
        when(messageSource.getMessage("config.kua.success.msg", null, null)).thenReturn("Aadhaar Profile details found");
        KUARequest request = getStubKUARequest();
        request.setBiometricType("FIR");

        ResponseDTO<AadhaarVerify> kuaResponse = aadhaarServiceImpl.getAadhaarDetailsKUA(request, "test");
        assertEquals("2400", kuaResponse.getMeta().getCode());
    }

    @Test(expected = GenericException.class)
    public void getAadhaarDetailsKUAWithInvalidBiometricType() throws IOException {
        when(environment.getProperty("config.kua.url")).thenReturn("http://10.56.110.191:15153/aadhaarABKUA");
        when(environment.getProperty("aadhaarVault.apikey")).thenReturn("key");
        when(httpUtil.postXmlRequest(Mockito.anyString(), Mockito.anyString())).thenReturn(KUAResponse);
        when(httpUtil.handleRequest(Mockito.anyString(),
                Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(getStubAadhaarVaultResponse());
        when(aadhaarService.getAadhaarReference(Mockito.any())).thenReturn(getStubAadhaarVaultResponse());
        when(messageSource.getMessage("aadhaar.kua.failure.code", null, null)).thenReturn("2445");
        when(messageSource.getMessage("aadhaar.kua.failure.msg", null, null)).thenReturn("We are experiencing some technical issues. Please try again later.");
        when(messageSource.getMessage("config.kua.success.code", null, null)).thenReturn("2400");
        when(messageSource.getMessage("config.kua.success.msg", null, null)).thenReturn("Aadhaar Profile details found");
        KUARequest request = getStubKUARequest();
        request.setBiometricType("TEST");

        ResponseDTO<AadhaarVerify> kuaResponse = aadhaarServiceImpl.getAadhaarDetailsKUA(request, "test");
        assertEquals("1792", kuaResponse.getMeta().getCode());
    }
    @Test(expected = AadhaarKUAVerifyException.class)
    public void getAadhaarDetailsKUAWithAadhaarKUAVerifyAadhaarKUAVerifyException() throws IOException {
        when(environment.getProperty("config.kua.url")).thenReturn("http://10.56.110.191:15153/aadhaarABKUA");
        when(environment.getProperty("aadhaarVault.apikey")).thenReturn("key");
        when(httpUtil.postXmlRequest(Mockito.anyString(), Mockito.anyString())).thenThrow(new AadhaarKUAVerifyException());
        when(httpUtil.handleRequest(Mockito.anyString(),
                Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(getStubAadhaarVaultResponse());
        when(aadhaarService.getAadhaarReference(Mockito.any())).thenReturn(getStubAadhaarVaultResponse());
        when(messageSource.getMessage("aadhaar.kua.failure.code", null, null)).thenReturn("2445");
        when(messageSource.getMessage("aadhaar.kua.failure.msg", null, null)).thenReturn("We are experiencing some technical issues. Please try again later.");
        when(messageSource.getMessage("config.kua.success.code", null, null)).thenReturn("2400");
        when(messageSource.getMessage("config.kua.success.msg", null, null)).thenReturn("Aadhaar Profile details found");
        aadhaarServiceImpl.getAadhaarDetailsKUA(getStubKUARequest(), "test");
    }

    @Test(expected = ThirdPartyApiException.class)
    public void getAadhaarDetailsKUAWithAadhaarKUAVerifyResourceAccessException() throws IOException {
        when(environment.getProperty("config.kua.url")).thenReturn("http://10.56.110.191:15153/aadhaarABKUA");
        when(environment.getProperty("aadhaarVault.apikey")).thenReturn("key");
        when(httpUtil.postXmlRequest(Mockito.anyString(), Mockito.anyString())).thenThrow(new ResourceAccessException(""));
        when(httpUtil.handleRequest(Mockito.anyString(),
                Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(getStubAadhaarVaultResponse());
        when(aadhaarService.getAadhaarReference(Mockito.any())).thenReturn(getStubAadhaarVaultResponse());
        when(messageSource.getMessage("aadhaar.kua.failure.code", null, null)).thenReturn("2445");
        when(messageSource.getMessage("aadhaar.kua.failure.msg", null, null)).thenReturn("We are experiencing some technical issues. Please try again later.");
        when(messageSource.getMessage("config.kua.success.code", null, null)).thenReturn("2400");
        when(messageSource.getMessage("config.kua.success.msg", null, null)).thenReturn("Aadhaar Profile details found");
        when(documentAuditRepository.save(Mockito.any(DocumentAuditLog.class))).thenReturn(null);
        aadhaarServiceImpl.getAadhaarDetailsKUA(getStubKUARequest(), "test");
    }

    @Test(expected = GenericException.class)
    public void getAadhaarDetailsKUAWithAadhaarKUAVerifyRestClientException() throws IOException {
        when(environment.getProperty("config.kua.url")).thenReturn("http://10.56.110.191:15153/aadhaarABKUA");
        when(environment.getProperty("aadhaarVault.apikey")).thenReturn("key");
        when(httpUtil.postXmlRequest(Mockito.anyString(), Mockito.anyString())).thenThrow(new RestClientException(""));
        when(httpUtil.handleRequest(Mockito.anyString(),
                Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(getStubAadhaarVaultResponse());
        when(aadhaarService.getAadhaarReference(Mockito.any())).thenReturn(getStubAadhaarVaultResponse());
        when(messageSource.getMessage("aadhaar.kua.failure.code", null, null)).thenReturn("2445");
        when(messageSource.getMessage("aadhaar.kua.failure.msg", null, null)).thenReturn("We are experiencing some technical issues. Please try again later.");
        when(messageSource.getMessage("config.kua.success.code", null, null)).thenReturn("2400");
        when(messageSource.getMessage("config.kua.success.msg", null, null)).thenReturn("Aadhaar Profile details found");
        when(documentAuditRepository.save(Mockito.any(DocumentAuditLog.class))).thenReturn(null);
        aadhaarServiceImpl.getAadhaarDetailsKUA(getStubKUARequest(), "test");
    }

    @Test
    public void getAadhaarDetailsKUAWithAadhaarKUAVerifyHttpClientErrorExceptionWithResponseBody() throws IOException {
        when(environment.getProperty("config.kua.url")).thenReturn("http://10.56.110.191:15153/aadhaarABKUA");
        when(environment.getProperty("aadhaarVault.apikey")).thenReturn("key");
        when(httpUtil.postXmlRequest(Mockito.anyString(), Mockito.anyString())).thenThrow(new HttpClientErrorException(HttpStatus.BAD_REQUEST, "400", KUAResponse.getBytes(StandardCharsets.UTF_8), StandardCharsets.UTF_8));
        when(httpUtil.handleRequest(Mockito.anyString(),
                Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(getStubAadhaarVaultResponse());
        when(aadhaarService.getAadhaarReference(Mockito.any())).thenReturn(getStubAadhaarVaultResponse());
        when(messageSource.getMessage("aadhaar.kua.failure.code", null, null)).thenReturn("2445");
        when(messageSource.getMessage("aadhaar.kua.failure.msg", null, null)).thenReturn("We are experiencing some technical issues. Please try again later.");
        when(messageSource.getMessage("config.kua.success.code", null, null)).thenReturn("2400");
        when(messageSource.getMessage("config.kua.success.msg", null, null)).thenReturn("Aadhaar Profile details found");
        when(documentAuditRepository.save(Mockito.any(DocumentAuditLog.class))).thenReturn(null);
        ResponseDTO<AadhaarVerify> kuaResponse = aadhaarServiceImpl.getAadhaarDetailsKUA(getStubKUARequest(), "test");
        assertEquals("GetUserAadhaarProfile-0001-S", kuaResponse.getMeta().getCode());
    }

    @Test(expected = GenericException.class)
    public void getAadhaarDetailsKUAWithAadhaarKUAVerifyHttpClientErrorExceptionWithEmptyResponseBody() throws IOException {
        when(environment.getProperty("config.kua.url")).thenReturn("http://10.56.110.191:15153/aadhaarABKUA");
        when(environment.getProperty("aadhaarVault.apikey")).thenReturn("key");
        when(httpUtil.postXmlRequest(Mockito.anyString(), Mockito.anyString())).thenThrow(new HttpClientErrorException(HttpStatus.BAD_REQUEST));
        when(httpUtil.handleRequest(Mockito.anyString(),
                Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(getStubAadhaarVaultResponse());
        when(aadhaarService.getAadhaarReference(Mockito.any())).thenReturn(getStubAadhaarVaultResponse());
        when(messageSource.getMessage("aadhaar.kua.failure.code", null, null)).thenReturn("2445");
        when(messageSource.getMessage("aadhaar.kua.failure.msg", null, null)).thenReturn("We are experiencing some technical issues. Please try again later.");
        when(messageSource.getMessage("config.kua.success.code", null, null)).thenReturn("2400");
        when(messageSource.getMessage("config.kua.success.msg", null, null)).thenReturn("Aadhaar Profile details found");
        when(documentAuditRepository.save(Mockito.any(DocumentAuditLog.class))).thenReturn(null);
        aadhaarServiceImpl.getAadhaarDetailsKUA(getStubKUARequest(), "test");
    }

    @Test
    public void getAadhaarDetailsKUAWithAadhaarKUAVerifyHttpServerErrorExceptionWithResponseBody() throws IOException {
        when(environment.getProperty("config.kua.url")).thenReturn("http://10.56.110.191:15153/aadhaarABKUA");
        when(environment.getProperty("aadhaarVault.apikey")).thenReturn("key");
        when(httpUtil.postXmlRequest(Mockito.anyString(), Mockito.anyString())).thenThrow(new HttpServerErrorException(HttpStatus.BAD_REQUEST, "400", KUAResponse.getBytes(StandardCharsets.UTF_8), StandardCharsets.UTF_8));
        when(httpUtil.handleRequest(Mockito.anyString(),
                Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(getStubAadhaarVaultResponse());
        when(aadhaarService.getAadhaarReference(Mockito.any())).thenReturn(getStubAadhaarVaultResponse());
        when(messageSource.getMessage("aadhaar.kua.failure.code", null, null)).thenReturn("2445");
        when(messageSource.getMessage("aadhaar.kua.failure.msg", null, null)).thenReturn("We are experiencing some technical issues. Please try again later.");
        when(messageSource.getMessage("config.kua.success.code", null, null)).thenReturn("2400");
        when(messageSource.getMessage("config.kua.success.msg", null, null)).thenReturn("Aadhaar Profile details found");
        when(documentAuditRepository.save(Mockito.any(DocumentAuditLog.class))).thenReturn(null);
        ResponseDTO<AadhaarVerify> kuaResponse = aadhaarServiceImpl.getAadhaarDetailsKUA(getStubKUARequest(), "test");
        assertEquals("GetUserAadhaarProfile-0001-S", kuaResponse.getMeta().getCode());
    }

    @Test(expected = GenericException.class)
    public void getAadhaarDetailsKUAWithAadhaarKUAVerifyHttpServerErrorExceptionWithEmptyResponseBody() throws IOException {
        when(environment.getProperty("config.kua.url")).thenReturn("http://10.56.110.191:15153/aadhaarABKUA");
        when(environment.getProperty("aadhaarVault.apikey")).thenReturn("key");
        when(httpUtil.postXmlRequest(Mockito.anyString(), Mockito.anyString())).thenThrow(new HttpServerErrorException(HttpStatus.BAD_REQUEST));
        when(httpUtil.handleRequest(Mockito.anyString(),
                Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(getStubAadhaarVaultResponse());
        when(aadhaarService.getAadhaarReference(Mockito.any())).thenReturn(getStubAadhaarVaultResponse());
        when(messageSource.getMessage("aadhaar.kua.failure.code", null, null)).thenReturn("2445");
        when(messageSource.getMessage("aadhaar.kua.failure.msg", null, null)).thenReturn("We are experiencing some technical issues. Please try again later.");
        when(messageSource.getMessage("config.kua.success.code", null, null)).thenReturn("2400");
        when(messageSource.getMessage("config.kua.success.msg", null, null)).thenReturn("Aadhaar Profile details found");
        when(documentAuditRepository.save(Mockito.any(DocumentAuditLog.class))).thenReturn(null);
        aadhaarServiceImpl.getAadhaarDetailsKUA(getStubKUARequest(), "test");
    }

    @Test(expected = Exception.class)
    public void getAadhaarDetailsKUAWithAadhaarKUAVerifyWithException() throws IOException {
        when(environment.getProperty("config.kua.url")).thenReturn("http://10.56.110.191:15153/aadhaarABKUA");
        when(environment.getProperty("aadhaarVault.apikey")).thenReturn("key");
        when(httpUtil.postXmlRequest(Mockito.anyString(), Mockito.anyString())).thenThrow(new RuntimeException());
        when(httpUtil.handleRequest(Mockito.anyString(),
                Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(getStubAadhaarVaultResponse());
        when(aadhaarService.getAadhaarReference(Mockito.any())).thenReturn(getStubAadhaarVaultResponse());
        when(messageSource.getMessage("aadhaar.kua.failure.code", null, null)).thenReturn("2445");
        when(messageSource.getMessage("aadhaar.kua.failure.msg", null, null)).thenReturn("We are experiencing some technical issues. Please try again later.");
        when(messageSource.getMessage("config.kua.success.code", null, null)).thenReturn("2400");
        when(messageSource.getMessage("config.kua.success.msg", null, null)).thenReturn("Aadhaar Profile details found");
        when(documentAuditRepository.save(Mockito.any(DocumentAuditLog.class))).thenReturn(null);
        aadhaarServiceImpl.getAadhaarDetailsKUA(getStubKUARequest(), "test");
    }
    
    @Test()
    public void triggerAUAKibanaLoggingTest(){
    	
    	AUAUidaiResponse auaUidaiResponse = new AUAUidaiResponse();
    	DataAreaAUA dataArea = new DataAreaAUA();
    	VerifyCustomerAadhaarDetailsResponse verifyCustomerAadhaarDetailsResponse = new VerifyCustomerAadhaarDetailsResponse();
    	Status status = new Status();
    	status.setStatusCode("00");
    	status.setStatusDescription("Description");
    	verifyCustomerAadhaarDetailsResponse.setStatus(status);
    	dataArea.setVerifyCustomerAadhaarDetailsResponse(verifyCustomerAadhaarDetailsResponse);
    	auaUidaiResponse.setDataArea(dataArea);
        
    	when(environment.getProperty("config.aua.url.new")).thenReturn("http://10.56.110.191:15153/aadhaarABAUA");
        when(httpUtil.postXmlRequest(Mockito.anyString(), Mockito.anyString())).thenReturn(AUAResponse1);
        AUAResponse auaResponse = aadhaarServiceImpl.validateAUA(getStubAUARequest(), "test");
    }

    @Test
    public void removeAadhaarSuccess() throws IOException {
        when(httpUtil.processHttpRequest(Mockito.anyString(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any())).thenReturn("Test");
        ResponseDTO response = aadhaarServiceImpl.removeAadhaar(getStubAadhaarVaultRequest(), "test", "test");
        assertNotNull(response);
    }

    @Test(expected = ThirdPartyApiException.class)
    public void removeAadhaarWithThirdPartyApiException() throws IOException {
        when(httpUtil.processHttpRequest(Mockito.anyString(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any())).thenThrow(new ResourceAccessException("test"));
        aadhaarServiceImpl.removeAadhaar(getStubAadhaarVaultRequest(), "test", "test");
    }

    @Test(expected = GenericException.class)
    public void removeAadhaarWithHttpClientErrorException() throws IOException {
        when(httpUtil.processHttpRequest(Mockito.anyString(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any())).thenThrow(new HttpClientErrorException(HttpStatus.NOT_FOUND, null));
        aadhaarServiceImpl.removeAadhaar(getStubAadhaarVaultRequest(), "test", "test");
    }

    @Test(expected = VaultException.class)
    public void removeAadhaarWithHttpClientErrorExceptionWithValidError() throws IOException {
        String error = "{\"meta\":{\"code\":\"uid-25\",\"description\":\"Aadhaar already deleted\",\"status\":0}}";
        when(httpUtil.processHttpRequest(Mockito.anyString(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any())).thenThrow(new HttpClientErrorException(HttpStatus.NOT_FOUND, "test", error.getBytes(StandardCharsets.UTF_8), StandardCharsets.UTF_8));
        aadhaarServiceImpl.removeAadhaar(getStubAadhaarVaultRequest(), "test", "test");
    }

    @Test(expected = GenericException.class)
    public void removeAadhaarWithResourceAccessException() throws IOException {
        when(httpUtil.processHttpRequest(Mockito.anyString(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any())).thenThrow(new RestClientException("test"));
        aadhaarServiceImpl.removeAadhaar(getStubAadhaarVaultRequest(), "test", "test");
    }

    @Test(expected = Exception.class)
    public void removeAadhaarWithException() throws IOException {
        when(httpUtil.processHttpRequest(Mockito.anyString(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any())).thenThrow(new RuntimeException("test"));
        aadhaarServiceImpl.removeAadhaar(getStubAadhaarVaultRequest(), "test", "test");
    }

    @Test(expected = ClientSideValidationException.class)
    public void removeAadhaarWithClientSideValidationExceptionAppTypeBlank() throws IOException {
        when(httpUtil.processHttpRequest(Mockito.anyString(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any())).thenThrow(new RuntimeException("test"));
        aadhaarServiceImpl.removeAadhaar(getStubAadhaarVaultRequest(), "", "test");
    }

    @Test(expected = ClientSideValidationException.class)
    public void removeAadhaarWithClientSideValidationExceptionCustomerIdBlank() throws IOException {
        when(httpUtil.processHttpRequest(Mockito.anyString(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any())).thenThrow(new RuntimeException("test"));
        aadhaarServiceImpl.removeAadhaar(getStubAadhaarVaultRequest(), "test", "");
    }

    @Test(expected = ClientSideValidationException.class)
    public void removeAadhaarWithClientSideValidationExceptionRequestIdBlank() throws IOException {
        when(httpUtil.processHttpRequest(Mockito.anyString(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any())).thenThrow(new RuntimeException("test"));
        aadhaarServiceImpl.removeAadhaar(AadhaarVaultRequest.builder().requestId("").apiKey("test").referenceKey("test").build(), "test", "");
    }

    @Test(expected = ClientSideValidationException.class)
    public void removeAadhaarWithClientSideValidationExceptionApiKeyBlank() throws IOException {
        when(httpUtil.processHttpRequest(Mockito.anyString(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any())).thenThrow(new RuntimeException("test"));
        aadhaarServiceImpl.removeAadhaar(AadhaarVaultRequest.builder().requestId("test").apiKey("").referenceKey("test").build(), "test", "");
    }

    @Test(expected = ClientSideValidationException.class)
    public void removeAadhaarWithClientSideValidationExceptionReferenceKeyBlank() throws IOException {
        when(httpUtil.processHttpRequest(Mockito.anyString(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any())).thenThrow(new RuntimeException("test"));
        aadhaarServiceImpl.removeAadhaar(AadhaarVaultRequest.builder().requestId("test").apiKey("test").referenceKey("").build(), "test", "");
    }

    private KUARequest getStubKUARequest() {
        DeviceDetails deviceDetails = DeviceDetails.builder().registeredDeviceCode("test")
                .registeredDeviceModelID("test")
                .registeredDeviceProviderCode("test")
                .registeredDeviceServiceID("test")
                .registeredDeviceServiceVersion("test")
                .registeredDevicePublicKeyCertificate("test")
                .uniqueDeviceCode("test")
                .registeredDeviceCode("test").build();
        return KUARequest.builder().userIdentifier("test")
                .userIdentifierType("test")
                .aadhaarTimestamp("")
                .biometricData("test")
                .skey("test")
                .hmac("test")
                .serviceCode("2")
                .certificateIdentifier("test")
                .deviceDetails(deviceDetails).build();
    }

    private Document getStubDocument() {
        return Document.builder().mobile("1234567890").userIdentifierType(Constants.AADHAAR_IDENTIFIER).docNumber("123456789012").build();
    }

    private Document getStubDocumentWithoutMobileNumber() {
        return Document.builder().userIdentifierType(Constants.AADHAAR_IDENTIFIER).docNumber("123456789012").build();
    }

    private AadhaarVaultResponse getStubAadhaarVault() {
        return AadhaarVaultResponse.builder().uid("1234567890123").build();
    }

    private List<Identities> getStubIdentities() {
        List<Identities> identities = new ArrayList<>();
        identities.add(Identities.builder().id("123456").verifyCount(1).docType(Constants.AADHAAR_CASE).build());
        return identities;
    }

    private List<Identities> getStubIdentitiesWithGenCount() {
        List<Identities> identities = new ArrayList<>();
        identities.add(Identities.builder().id("123456").genCount(1).build());
        return identities;
    }

    private GenerateAadhaarOTPData getStubGenerateAadhaarOTPData() {
        return new GenerateAadhaarOTPData();
    }

    private GenerateAadharOTPDataResponse getStubGenerateAadharOTPDataResponse() {
        GenerateAadhaarOTPData generateAadhaarOTPData = new GenerateAadhaarOTPData();
        Status status = Status.builder().statusCode(Constants.GENERATE_AADHAAR_OTP_SUCCESS_STATUS_CODE).build();
        GenerateAadhaarOTPResponse generateAadhaarOTPResponse = GenerateAadhaarOTPResponse.builder()
                .status(status)
                .email("test@gmail.com")
                .mobileNumber("1234567890")
                .userIdentifierType(Constants.AADHAAR_IDENTIFIER)
                .build();
        DataArea dataArea = DataArea.builder().generateAadhaarOTPResponse(generateAadhaarOTPResponse).build();
        EbmHeader ebmHeader = new EbmHeader();
        ebmHeader.setConsumerTransactionId("test");
        return GenerateAadharOTPDataResponse.builder()
                .dataArea(dataArea)
                .ebmHeader(ebmHeader)
                .build();
    }

    private ValidateAadharOTPData getStubValidateAadharOTPData() {
        GenerateAadhaarOTPData generateAadhaarOTPData = new GenerateAadhaarOTPData();
        Status status = Status.builder().statusCode(Constants.GENERATE_AADHAAR_OTP_SUCCESS_STATUS_CODE).build();
        GenerateAadhaarOTPResponse generateAadhaarOTPResponse = GenerateAadhaarOTPResponse.builder()
                .status(status)
                .email("test@gmail.com")
                .mobileNumber("1234567890")
                .userIdentifierType(Constants.AADHAAR_IDENTIFIER)
                .build();
        DataArea dataArea = DataArea.builder().generateAadhaarOTPResponse(generateAadhaarOTPResponse).build();
        EbmHeader ebmHeader = new EbmHeader();
        ebmHeader.setConsumerTransactionId("test");
        ValidateAadharOTPData validateAadharOTPData = new ValidateAadharOTPData();
        validateAadharOTPData.setDataArea(dataArea);
        validateAadharOTPData.setEbmHeader(ebmHeader);
        return validateAadharOTPData;
    }

    private AadhaarVaultRequest getStubAadhaarVaultRequest() {
        return AadhaarVaultRequest.builder().requestId("1").apiKey("test").uid("123456789012").referenceKey("123456789012").build();
    }

    private AadhaarVaultResponse getStubAadhaarVaultResponse() {
        AadhaarVaultResponseResult aadhaarVaultResponseResult = new AadhaarVaultResponseResult();
        aadhaarVaultResponseResult.setStatusCode("uid-00");
        return AadhaarVaultResponse.builder().requestId("1").uid("123456789012").referenceKey("123456789012").result(aadhaarVaultResponseResult).build();
    }

    private AadhaarVaultResponse getStubAadhaarVaultResponseWithFailedStatus() {
        AadhaarVaultResponseResult aadhaarVaultResponseResult = new AadhaarVaultResponseResult();
        aadhaarVaultResponseResult.setStatusCode("failed");
        return AadhaarVaultResponse.builder().requestId("1").uid("123456789012").referenceKey("123456789012").result(aadhaarVaultResponseResult).build();
    }

    private AUARequest getStubAUARequest() {
        DeviceDetails deviceDetails = DeviceDetails.builder().registeredDeviceCode("test")
                .registeredDeviceModelID("test")
                .registeredDeviceProviderCode("test")
                .registeredDeviceServiceID("test")
                .registeredDeviceServiceVersion("test")
                .registeredDevicePublicKeyCertificate("test")
                .uniqueDeviceCode("test")
                .registeredDeviceCode("test").build();
        return AUARequest.builder().userIdentifier("test").userIdentifierType("A").aadhaarTimestamp("").biometricData("test")
                .skey("test").hmac("test").serviceCode("2").certificateIdentifier("test").deviceDetails(deviceDetails).build();
    }
}
