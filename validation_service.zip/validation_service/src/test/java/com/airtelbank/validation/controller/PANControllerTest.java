package com.airtelbank.validation.controller;

import com.airtelbank.validation.model.PANDetails;
import com.airtelbank.validation.model.PANRequest;
import com.airtelbank.validation.model.ResponseDTO;
import com.airtelbank.validation.service.PANService;
import org.apache.logging.log4j.core.config.Configurator;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.context.MessageSource;
import org.mockito.MockitoAnnotations;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;

@RunWith(MockitoJUnitRunner.class)
public class PANControllerTest {

    @Mock private MessageSource messageSource;
    @Mock private PANService panService;

    @InjectMocks private PANController panController;
    
    private MockMvc mvc;

    @Before
    public void init() {
        MockitoAnnotations.initMocks(this);
        mvc = MockMvcBuilders.standaloneSetup(panController).build();
        ReflectionTestUtils.setField(panController, "privateKey", "MIIBVAIBADANBgkqhkiG9w0BAQEFAASCAT4wggE6AgEAAkEAmUIa1G/XYHsFG9LjYIyDnzUQnz+P7R7NrJqEEbDxx6zSTbfh79Ri9vlH4+OPC+0RR7V4PCXyCZ16U6XpnHTP+QIDAQABAkA94QfuMD4Y0XLtmgd+ax2VwZo1gjd9eQt4HmcmsXfds5Q8DBRHX199+IypL4kO7Xj5wv7N7vrDdRv4P663ahGVAiEA1ogj2b2bFBPryaXadqXkqsCpqeAqAybGoO1Axyz1ptMCIQC24emDhhiyQuEehjTNiCtdkQpPi45o5erBZM/RHBqGgwIhAMvKp8PACgEYq3PyyYTMMlzCiGmHOGGmBCn7Nv3+B51hAiBEeJauKJGshD+25vZ0EUxzLq+WkqCSA6r+F1l7aDNCMwIgIw7Hu7V3NO6lFI4o8oXNYkJZisFhAlYe4kkG3HdW9Qs=");
        Configurator.setAllLevels("", org.apache.logging.log4j.Level.ALL);
    }

    @Test
    public void getPanDetailsTest(){
        String customerId ="123";
        String pan ="ABCD4949N";
        String contentId = "456";
        String channel = "Payment";
        PANRequest panRequest =new PANRequest();
        PANDetails panDetails = new PANDetails();
        when(panService.getPanDetails(Mockito.any(PANRequest.class))).thenReturn(panDetails);
        ResponseDTO<PANDetails> responseDTO = panController.getPanDetails(customerId,pan,contentId,channel);
        assertNotNull(responseDTO);
    }
    
    @Test
	public void getPanDetailsTestV2() throws Exception {
    	PANDetails response = new PANDetails();
		String pan = "SzTR2cBHLvJs08o5KLOrjIewSfeoXP9jw039vWjxZKjE/b0H5z4hgr+qW0nmJ/4a/deAi8CZgjWMAjgT1sobfg=="; String contentId = "content"; String channel = "channel";
		when(panService.getPanDetails(Mockito.any())).thenReturn(response);
		mvc.perform(MockMvcRequestBuilders
						.get("/api/v2/pan/")
						.contentType(MediaType.APPLICATION_JSON)
						.header("contentId", contentId)
						.header("channel", channel)
						.header("pan", pan)
						.accept(MediaType.APPLICATION_JSON))
				.andDo(print())
				.andExpect(status().isOk());
	}



    /*@Test
    public void validatePANDetailsTest() {
        ResponseEntity<ResponseDTO<PANDetails>> responseDTOResponseEntity=panController.validatePANDetails("test","test","test");
        assertNotNull(responseDTOResponseEntity);
    }*/
}