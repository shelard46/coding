package com.airtelbank.validation.service.impl.helper;

import static org.junit.Assert.assertNull;

import org.apache.logging.log4j.core.config.Configurator;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.MockitoJUnitRunner;

import com.airtelbank.validation.model.PanEsbRequest;
import com.airtelbank.validation.model.PanEsbResponse;
import com.airtelbank.validation.util.HttpUtil;
import com.airtelbank.validation.util.LogMasker;

@RunWith(MockitoJUnitRunner.class)
public class AbstractBaseServiceImplHelperTest {

    @Mock
    private HttpUtil mockHttpUtil;
    @Mock
    private LogMasker mockLogMasker;

    @InjectMocks
    private AbstractBaseServiceImplHelper abstractBaseServiceImplHelperUnderTest;
 

    @Before
    public void setUp() throws Exception {
        MockitoAnnotations.initMocks(this);
        Configurator.setAllLevels("", org.apache.logging.log4j.Level.ALL);
    }

    @After
    public void tearDown() throws Exception {
    }

    /*@Test
    public void testFetchResponseForXML() throws Exception {

        final PanEsbRequest requestObject = new PanEsbRequest();
        requestObject.setNamespace("test");
        final PanEsbResponse result = (PanEsbResponse) abstractBaseServiceImplHelperUnderTest.fetchResponseForXML(requestObject, "url", Object.class,
                Object.class);
        assertNull(result);

    }*/

    @Test
    public void testFetchResponseForXMLSuccess() throws Exception {
        final PanEsbRequest requestObject = null;

        final PanEsbResponse result = (PanEsbResponse) abstractBaseServiceImplHelperUnderTest.fetchResponseForXML(requestObject, "url", Object.class,
                Object.class);
        Assert.assertNull(result);
    }
    @Test(expected = Test.None.class)
    public void testFetchResponseForXML_HttpUtilThrowsIOException() throws Exception {
        final PanEsbRequest requestObject = null;
        abstractBaseServiceImplHelperUnderTest.fetchResponseForXML(requestObject, "url", Object.class, Object.class);
    }



}