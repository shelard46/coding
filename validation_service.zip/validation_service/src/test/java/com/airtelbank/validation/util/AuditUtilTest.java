package com.airtelbank.validation.util;

import com.airtelbank.validation.model.ResponseDTO;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.slf4j.Logger;
import org.springframework.http.HttpMethod;
import org.springframework.test.util.ReflectionTestUtils;

import java.io.IOException;

/**
 * @author Hitesh Khatri
 * @date 18/06/21
 */
public class AuditUtilTest {

    @Mock
    private HttpUtil httpUtil;

    @InjectMocks
    private AuditUtil auditUtil;

    @Mock
    private Logger logger;

    @Before
    public void init() {
        MockitoAnnotations.initMocks(this);
        ReflectionTestUtils.setField(auditUtil, "auditUrl", "http://localhost:8080/test");
    }

    @Test
    public void testDoAuditSuccess() throws IOException {
        Mockito.when(httpUtil.processHttpRequest(Mockito.anyString(),
                Mockito.anyString(), Mockito.any(), Mockito.anyMap(), Mockito.any(HttpMethod.class))).thenReturn(ResponseDTO.builder().build());
        auditUtil.doAudit("test", "test", "test", "test", "test", "test");
        Mockito.verify(httpUtil, Mockito.times(1)).processHttpRequest(Mockito.anyString(),
                Mockito.anyString(), Mockito.any(), Mockito.anyMap(), Mockito.any(HttpMethod.class));
        Mockito.when(httpUtil.processHttpRequest(Mockito.anyString(),
                Mockito.anyString(), Mockito.any(), Mockito.anyMap(), Mockito.any(HttpMethod.class))).thenThrow(new RuntimeException());
        auditUtil.doAudit("test", "test", "test", "test", "test", "test");
    }

}