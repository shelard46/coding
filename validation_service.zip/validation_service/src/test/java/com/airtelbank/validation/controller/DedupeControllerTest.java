package com.airtelbank.validation.controller;

import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.ArrayList;
import java.util.List;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.airtelbank.validation.dao.aerospike.PosidexCacheCustomerDao;
import com.airtelbank.validation.dao.aerospike.model.PosidexCacheCustomerDetails;
import com.airtelbank.validation.model.CBSDedupeRequest;
import com.airtelbank.validation.model.DedupeRequest;
import com.airtelbank.validation.model.DedupeResponse;
import com.airtelbank.validation.model.Meta;
import com.airtelbank.validation.model.ResponseDTO;
import com.airtelbank.validation.service.DedupeService;
import com.airtelbank.validation.util.ValidationUtils;

@RunWith(MockitoJUnitRunner.class)
public class DedupeControllerTest {

	@Mock private PosidexCacheCustomerDao posidexCacheCustomerDao;
	@Mock private ValidationUtils<DedupeRequest> validate;
	@Mock private DedupeService dedupeService;
	
	@InjectMocks private DedupeController dedupeController;

	private MockMvc mvc;

	@Before
	public void init() {
		MockitoAnnotations.initMocks(this);
		ReflectionTestUtils.setField(dedupeController, "privateKey", "MIIBVAIBADANBgkqhkiG9w0BAQEFAASCAT4wggE6AgEAAkEAmUIa1G/XYHsFG9LjYIyDnzUQnz+P7R7NrJqEEbDxx6zSTbfh79Ri9vlH4+OPC+0RR7V4PCXyCZ16U6XpnHTP+QIDAQABAkA94QfuMD4Y0XLtmgd+ax2VwZo1gjd9eQt4HmcmsXfds5Q8DBRHX199+IypL4kO7Xj5wv7N7vrDdRv4P663ahGVAiEA1ogj2b2bFBPryaXadqXkqsCpqeAqAybGoO1Axyz1ptMCIQC24emDhhiyQuEehjTNiCtdkQpPi45o5erBZM/RHBqGgwIhAMvKp8PACgEYq3PyyYTMMlzCiGmHOGGmBCn7Nv3+B51hAiBEeJauKJGshD+25vZ0EUxzLq+WkqCSA6r+F1l7aDNCMwIgIw7Hu7V3NO6lFI4o8oXNYkJZisFhAlYe4kkG3HdW9Qs=");
		mvc = MockMvcBuilders.standaloneSetup(dedupeController).build();
	}

	@Test
	public void getDetailsFromAerospikeForPoiNumberWhenFoundTest() throws Exception {
		List<PosidexCacheCustomerDetails> value = new ArrayList<>();
		value.add(PosidexCacheCustomerDetails.builder().build());
		String poiNumber = "9857648"; String contentId = "contentId"; String channel = "channel";
		when(posidexCacheCustomerDao.getPosidexDataFromAeroForPoiNumber(Mockito.anyString())).thenReturn(value);
		mvc.perform(MockMvcRequestBuilders
						.get("/api/v1/dedupeForPoi/" + poiNumber)
						.header("contentId", contentId)
						.header("channel", channel)
						.contentType(MediaType.APPLICATION_JSON)
						.accept(MediaType.APPLICATION_JSON))
				.andDo(print())
				.andExpect(status().isOk());
	}

	@Test
	public void getDetailsFromAerospikeForPoiNumberWhenNotFoundTest () throws Exception {
		String poiNumber = "9857648"; String contentId = "contentId"; String channel = "channel";
		when(posidexCacheCustomerDao.getPosidexDataFromAeroForPoiNumber(Mockito.anyString())).thenReturn(null);
		mvc.perform(MockMvcRequestBuilders
						.get("/api/v1/dedupeForPoi/" + poiNumber)
						.header("contentId", contentId)
						.header("channel", channel)
						.contentType(MediaType.APPLICATION_JSON)
						.accept(MediaType.APPLICATION_JSON))
				.andDo(print())
				.andExpect(status().isOk());
	}
	
	@Test
	public void getPoiDetailsFromAerospikeWhenFoundTest() throws Exception {
		List<PosidexCacheCustomerDetails> value = new ArrayList<>();
		value.add(PosidexCacheCustomerDetails.builder().build());
		String poiNumber = "SP9pwV9mnE+QLUM06lX3k82gZvS2PKXycwh/zDLvZ7iElS8PVoBVDPtNbmsiLedCKltpMpzJs+mq9GjUWrvxXQ=="; String contentId = "contentId"; String channel = "channel";
		when(posidexCacheCustomerDao.getPosidexDataFromAeroForPoiNumber(Mockito.anyString())).thenReturn(value);
		mvc.perform(MockMvcRequestBuilders
						.get("/api/v2/dedupeForPoi/")
						.header("contentId", contentId)
						.header("channel", channel)
						.header("poiNumber", poiNumber)
						.contentType(MediaType.APPLICATION_JSON)
						.accept(MediaType.APPLICATION_JSON))
				.andDo(print())
				.andExpect(status().isOk());
	}

	@Test
	public void getPoiDetailsFromAerospikeWhenNotFoundTest () throws Exception {
		String poiNumber = "SP9pwV9mnE+QLUM06lX3k82gZvS2PKXycwh/zDLvZ7iElS8PVoBVDPtNbmsiLedCKltpMpzJs+mq9GjUWrvxXQ=="; String contentId = "contentId"; String channel = "channel";
		when(posidexCacheCustomerDao.getPosidexDataFromAeroForPoiNumber(Mockito.anyString())).thenReturn(null);
		mvc.perform(MockMvcRequestBuilders
						.get("/api/v2/dedupeForPoi/")
						.header("contentId", contentId)
						.header("channel", channel)
						.header("poiNumber", poiNumber)
						.contentType(MediaType.APPLICATION_JSON)
						.accept(MediaType.APPLICATION_JSON))
				.andDo(print())
				.andExpect(status().isOk());
	}

	@Test
	public void dedupeCustomerTest() {

		Mockito.doNothing().when(validate).validate(Mockito.any());
		DedupeRequest dedupeRequest=new DedupeRequest();
		dedupeRequest.setCustomerId("test");
		ResponseDTO<DedupeResponse> response = new ResponseDTO<>();
		Meta meta=new Meta();
		meta.setDescription("test");
		meta.setCode("test");
		meta.setStatus(1);
		response.setMeta(meta);
		Mockito.when(dedupeService.fullKycDedupe(Mockito.any(),Mockito.any())).thenReturn(response);
		ResponseEntity<ResponseDTO<DedupeResponse>> responseDTOResponseEntity=dedupeController.dedupeCustomer(dedupeRequest,"test","test");
		Assert.assertNotNull(responseDTOResponseEntity);
	}

	@Test
	public void testDedupeCustomerTest() {
		CBSDedupeRequest dedupeRequest=new CBSDedupeRequest();
		dedupeRequest.setAadhaarNo("test");
		Mockito.when(dedupeService.checkCbsDedupe(Mockito.any(),Mockito.any())).thenReturn(new ResponseDTO<>());
		ResponseEntity<?> responseDTOResponseEntity=dedupeController.dedupeCustomer(dedupeRequest,"test","test");
		Assert.assertNotNull(responseDTOResponseEntity);
	}
}