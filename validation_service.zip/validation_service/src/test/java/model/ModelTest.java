package model;

import org.junit.Test;

import com.airtelbank.validation.dao.aerospike.model.AadhaarVerify;
import com.airtelbank.validation.dao.aerospike.model.Blackout;
import com.airtelbank.validation.dao.aerospike.model.ErrorCodeMapper;
import com.airtelbank.validation.dao.aerospike.model.Identities;
import com.airtelbank.validation.dao.aerospike.model.PinCode;
import com.airtelbank.validation.dao.aerospike.model.PincodeMasterCBS;
import com.airtelbank.validation.dao.aerospike.model.PosidexCacheCustomerDetails;
import com.airtelbank.validation.dao.aerospike.model.PosidexRules;
import com.airtelbank.validation.enums.CommunicationType;
import com.airtelbank.validation.model.AUARequest;
import com.airtelbank.validation.model.AUAResponse;
import com.airtelbank.validation.model.AadhaarInfo;
import com.airtelbank.validation.model.AadhaarProfileKUA;
import com.airtelbank.validation.model.AadhaarVaultRequest;
import com.airtelbank.validation.model.AadhaarVaultResponseResult;
import com.airtelbank.validation.model.BlacklistEntityResponse;
import com.airtelbank.validation.model.BlacklistResponse;
import com.airtelbank.validation.model.BlackoutRequest;
import com.airtelbank.validation.model.BlackoutResponse;
import com.airtelbank.validation.model.CBSDedupeRequest;
import com.airtelbank.validation.model.CBSDedupeResponse;
import com.airtelbank.validation.model.CustomError;
import com.airtelbank.validation.model.DataArea;
import com.airtelbank.validation.model.DataAreaAUA;
import com.airtelbank.validation.model.DedupeRequest;
import com.airtelbank.validation.model.DedupeResponse;
import com.airtelbank.validation.model.DeviceDetails;
import com.airtelbank.validation.model.Document;
import com.airtelbank.validation.model.EbmHeader;
import com.airtelbank.validation.model.GenerateAadhaarOTPResponse;
import com.airtelbank.validation.model.GetCustomerAadhaarOTPRequest;
import com.airtelbank.validation.model.GetCustomerAadhaarOTPResponse;
import com.airtelbank.validation.model.KUARequest;
import com.airtelbank.validation.model.KUAResponse;
import com.airtelbank.validation.model.KUAUidaiResponse;
import com.airtelbank.validation.model.LoggerModel;
import com.airtelbank.validation.model.Meta;
import com.airtelbank.validation.model.Metrics;
import com.airtelbank.validation.model.NameMatchRequest;
import com.airtelbank.validation.model.NameMatchResponse;
import com.airtelbank.validation.model.PANDetails;
import com.airtelbank.validation.model.PANRequest;
import com.airtelbank.validation.model.PANStatus;
import com.airtelbank.validation.model.PanEsbRequest;
import com.airtelbank.validation.model.PanEsbResponse;
import com.airtelbank.validation.model.PosidexPanRequest;
import com.airtelbank.validation.model.ResidentIdentity;
import com.airtelbank.validation.model.ResponseDTO;
import com.airtelbank.validation.model.Status;
import com.airtelbank.validation.model.UserAadharProfile;
import com.airtelbank.validation.model.UserAadharProfileResponse;
import com.airtelbank.validation.model.VerifyCustomerAadhaarDetailsResponse;
import com.airtelbank.validation.model.VerifyPANDetailsRequest;
import com.airtelbank.validation.model.VerifyPANDetailsResponse;
import com.airtelbank.validation.model.blacklist.Address;
import com.airtelbank.validation.model.blacklist.BlacklistData;
import com.airtelbank.validation.model.blacklist.BlacklistEntity;
import com.airtelbank.validation.model.blacklist.Contact;
import com.airtelbank.validation.model.blacklist.Customer;
import com.airtelbank.validation.model.blacklist.CustomerRequest;
import com.airtelbank.validation.model.blacklist.CustomerResponse;
import com.airtelbank.validation.model.blacklist.CustomerResult;
import com.airtelbank.validation.model.blacklist.Demographics;
import com.airtelbank.validation.model.blacklist.DemographicsResult;
import com.airtelbank.validation.model.blacklist.Email;
import com.airtelbank.validation.model.cbs.CustomerAddress;
import com.airtelbank.validation.model.cbs.CustomerDedupeDetailsDTO;
import com.airtelbank.validation.model.cbs.CustomerDedupeDetailsDTOArray;
import com.airtelbank.validation.model.cbs.DedupeRequestForCBS;
import com.airtelbank.validation.model.cbs.DedupeResponseFromCBS;
import com.airtelbank.validation.model.cbs.ExtendedReply;
import com.airtelbank.validation.model.cbs.Messages;
import com.airtelbank.validation.model.cbs.MessagesArray;
import com.airtelbank.validation.model.cbs.SessionContext;
import com.airtelbank.validation.model.cbs.TransactionStatus;
import com.airtelbank.validation.model.cbs.ValidationErrors;
import com.airtelbank.validation.model.communication.CommunicationData;
import com.airtelbank.validation.model.communication.SMSResponse;
import com.airtelbank.validation.model.communication.SMSTemplate;
import com.airtelbank.validation.model.communication.SmsData;
import com.airtelbank.validation.model.pan.VerifyCustomerPanDetailsRequestMessage;
import com.airtelbank.validation.model.pan.VerifyCustomerPanDetailsResponseMesssage;
import com.airtelbank.validation.model.posidex.namematch.NameRequest;
import com.airtelbank.validation.model.posidex.namematch.NameResult;
import com.openpojo.reflection.impl.PojoClassFactory;
import com.openpojo.validation.Validator;
import com.openpojo.validation.ValidatorBuilder;
import com.openpojo.validation.test.impl.GetterTester;
import com.openpojo.validation.test.impl.SetterTester;

public class ModelTest {
	
	private Validator VALIDATOR = ValidatorBuilder.create().with(new GetterTester()).with(new SetterTester()).build();

	@Test
	public void coverAadhaarInfoRequest() {
		VALIDATOR.validate(PojoClassFactory.getPojoClass(AadhaarInfo.class));
	}
	
	@Test
	public void coverAadhaarProfileKUA() {
		VALIDATOR.validate(PojoClassFactory.getPojoClass(AadhaarProfileKUA.class));
	}
	
	@Test
	public void coverAadhaarVaultRequest() {
		VALIDATOR.validate(PojoClassFactory.getPojoClass(AadhaarVaultRequest.class));
	}
	
	@Test
	public void coverAadhaarVaultResponseResult() {
		VALIDATOR.validate(PojoClassFactory.getPojoClass(AadhaarVaultResponseResult.class));
	}
	
	@Test
	public void coverAuaRequest() {
		VALIDATOR.validate(PojoClassFactory.getPojoClass(AUARequest.class));
	}
	
	@Test
	public void coverAuaResponse() {
		VALIDATOR.validate(PojoClassFactory.getPojoClass(AUAResponse.class));
	}
	
	@Test
	public void coverBlacklistEntity() {
		VALIDATOR.validate(PojoClassFactory.getPojoClass(BlacklistEntity.class));
	}
	
	@Test
	public void coverBlacklistResponse() {
		VALIDATOR.validate(PojoClassFactory.getPojoClass(BlacklistResponse.class));
	}
	
	@Test
	public void coverBlackoutRequest() {
		VALIDATOR.validate(PojoClassFactory.getPojoClass(BlackoutRequest.class));
	}
	
	@Test
	public void coverBlackoutResponse() {
		VALIDATOR.validate(PojoClassFactory.getPojoClass(BlackoutResponse.class));
	}
	
	@Test
	public void coverCBSDedupeRequest() {
		VALIDATOR.validate(PojoClassFactory.getPojoClass(CBSDedupeRequest.class));
	}
	
	@Test
	public void coverCBSDedupeResponse() {
		VALIDATOR.validate(PojoClassFactory.getPojoClass(CBSDedupeResponse.class));
	}
	
	@Test
	public void coverCustomError() {
		VALIDATOR.validate(PojoClassFactory.getPojoClass(CustomError.class));
	}
	
	@Test
	public void coverDataArea() {
		VALIDATOR.validate(PojoClassFactory.getPojoClass(DataArea.class));
	}
	
	@Test
	public void coverDataAreaAua() {
		VALIDATOR.validate(PojoClassFactory.getPojoClass(DataAreaAUA.class));
	}
	
	@Test
	public void coverDedupeRequest() {
		VALIDATOR.validate(PojoClassFactory.getPojoClass(DedupeRequest.class));
	}
	
	@Test
	public void coverDedupeResponse() {
		VALIDATOR.validate(PojoClassFactory.getPojoClass(DedupeResponse.class));
	}
	
	@Test
	public void coverDeviceDetails() {
		VALIDATOR.validate(PojoClassFactory.getPojoClass(DeviceDetails.class));
	}
	
	@Test
	public void coverDocument() {
		VALIDATOR.validate(PojoClassFactory.getPojoClass(Document.class));
	}
	
	@Test
	public void coverEbmHeader() {
		VALIDATOR.validate(PojoClassFactory.getPojoClass(EbmHeader.class));
	}
	
	@Test
	public void coverGenerateAadhaarOTPResponse() {
		VALIDATOR.validate(PojoClassFactory.getPojoClass(GenerateAadhaarOTPResponse.class));
	}
	
	@Test
	public void coverGetCustomerAadhaarOTPRequest() {
		VALIDATOR.validate(PojoClassFactory.getPojoClass(GetCustomerAadhaarOTPRequest.class));
	}
	
	@Test
	public void coverGetCustomerAadhaarOTPResponse() {
		VALIDATOR.validate(PojoClassFactory.getPojoClass(GetCustomerAadhaarOTPResponse.class));
	}
	
	@Test
	public void coverKuaRequest() {
		VALIDATOR.validate(PojoClassFactory.getPojoClass(KUARequest.class));
	}
	
	@Test
	public void coverKuaResponse() {
		VALIDATOR.validate(PojoClassFactory.getPojoClass(KUAResponse.class));
	}
	
	@Test
	public void coverKuaUidaiResponse() {
		VALIDATOR.validate(PojoClassFactory.getPojoClass(KUAUidaiResponse.class));
	}
	
	@Test
	public void coverLoggerModel() {
		VALIDATOR.validate(PojoClassFactory.getPojoClass(LoggerModel.class));
	}
	
	@Test
	public void coverMeta() {
		VALIDATOR.validate(PojoClassFactory.getPojoClass(Meta.class));
	}

	@Test
	public void coverMetrics() {
		VALIDATOR.validate(PojoClassFactory.getPojoClass(Metrics.class));
	}
	
	@Test
	public void coverNameMatchRequest() {
		VALIDATOR.validate(PojoClassFactory.getPojoClass(NameMatchRequest.class));
	}
	
	@Test
	public void coverNameMatchResponse() {
		VALIDATOR.validate(PojoClassFactory.getPojoClass(NameMatchResponse.class));
	}
	
	@Test
	public void coverPanDetails() {
		VALIDATOR.validate(PojoClassFactory.getPojoClass(PANDetails.class));
	}
	
	@Test
	public void coverPanEsbRequest() {
		VALIDATOR.validate(PojoClassFactory.getPojoClass(PanEsbRequest.class));
	}
	
	@Test
	public void coverPanEsbResponse() {
		VALIDATOR.validate(PojoClassFactory.getPojoClass(PanEsbResponse.class));
	}
	
	@Test
	public void coverPanRequest() {
		VALIDATOR.validate(PojoClassFactory.getPojoClass(PANRequest.class));
	}
	
	@Test
	public void coverPanStatus() {
		VALIDATOR.validate(PojoClassFactory.getPojoClass(PANStatus.class));
	}
	
	@Test
	public void coverPosidexPanDetails() {
		VALIDATOR.validate(PojoClassFactory.getPojoClass(PANDetails.class));
	}
	
	@Test
	public void coverPosidexPanRequest() {
		VALIDATOR.validate(PojoClassFactory.getPojoClass(PosidexPanRequest.class));
	}
	
	@Test
	public void coverResidentIdentity() {
		VALIDATOR.validate(PojoClassFactory.getPojoClass(ResidentIdentity.class));
	}
	
	@Test
	public void coverResponseDTO() {
		VALIDATOR.validate(PojoClassFactory.getPojoClass(ResponseDTO.class));
	}
	
	@Test
	public void coverStatus() {
		VALIDATOR.validate(PojoClassFactory.getPojoClass(Status.class));
	}
	
	@Test
	public void coverUserAadharProfile() {
		VALIDATOR.validate(PojoClassFactory.getPojoClass(UserAadharProfile.class));
	}
	
	@Test
	public void coverUserAadharProfileResponse() {
		VALIDATOR.validate(PojoClassFactory.getPojoClass(UserAadharProfileResponse.class));
	}
	
	@Test
	public void coverVerifyCustomerAadhaarDetailsResponse() {
		VALIDATOR.validate(PojoClassFactory.getPojoClass(VerifyCustomerAadhaarDetailsResponse.class));
	}
	
	@Test
	public void coverVerifyPanDetailsRequest() {
		VALIDATOR.validate(PojoClassFactory.getPojoClass(VerifyPANDetailsRequest.class));
	}
	
	@Test
	public void coverVerifyPanDetailsResponse() {
		VALIDATOR.validate(PojoClassFactory.getPojoClass(VerifyPANDetailsResponse.class));
	}
	
	@Test
	public void coverAddress() {
		VALIDATOR.validate(PojoClassFactory.getPojoClass(Address.class));
	}
	
	@Test
	public void coverBlacklistData() {
		VALIDATOR.validate(PojoClassFactory.getPojoClass(BlacklistData.class));
	}
	
	@Test
	public void coverContact() {
		VALIDATOR.validate(PojoClassFactory.getPojoClass(Contact.class));
	}
	
	@Test
	public void coverCustomer() {
		VALIDATOR.validate(PojoClassFactory.getPojoClass(Customer.class));
	}
	
	@Test
	public void coverCustomerRequest() {
		VALIDATOR.validate(PojoClassFactory.getPojoClass(CustomerRequest.class));
	}
	
	@Test
	public void coverCustomerResponse() {
		VALIDATOR.validate(PojoClassFactory.getPojoClass(CustomerResponse.class));
	}
	
	@Test
	public void coverCustomerResult() {
		VALIDATOR.validate(PojoClassFactory.getPojoClass(CustomerResult.class));
	}
	
	@Test
	public void coverDemographics() {
		VALIDATOR.validate(PojoClassFactory.getPojoClass(Demographics.class));
	}
	
	@Test
	public void coverDemographicsResult() {
		VALIDATOR.validate(PojoClassFactory.getPojoClass(DemographicsResult.class));
	}
	
	@Test
	public void coverEmail() {
		VALIDATOR.validate(PojoClassFactory.getPojoClass(Email.class));
	}
	
	@Test
	public void coverCustomerAddress() {
		VALIDATOR.validate(PojoClassFactory.getPojoClass(CustomerAddress.class));
	}
	
	@Test
	public void coverCustomerDedupeDetailsDTO() {
		VALIDATOR.validate(PojoClassFactory.getPojoClass(CustomerDedupeDetailsDTO.class));
	}
	
	@Test
	public void coverCustomerDedupeDetailsDTOArray() {
		VALIDATOR.validate(PojoClassFactory.getPojoClass(CustomerDedupeDetailsDTOArray.class));
	}
	
	@Test
	public void coverDedupeRequestForCBS() {
		VALIDATOR.validate(PojoClassFactory.getPojoClass(DedupeRequestForCBS.class));
	}
	
	@Test
	public void coverDedupeResponseFromCBS() {
		VALIDATOR.validate(PojoClassFactory.getPojoClass(DedupeResponseFromCBS.class));
	}
	
	@Test
	public void coverExtendedReply() {
		VALIDATOR.validate(PojoClassFactory.getPojoClass(ExtendedReply.class));
	}
	
	@Test
	public void coverMessages() {
		VALIDATOR.validate(PojoClassFactory.getPojoClass(Messages.class));
	}
	
	@Test
	public void coverMessagesArray() {
		VALIDATOR.validate(PojoClassFactory.getPojoClass(MessagesArray.class));
	}
	
	@Test
	public void coverSessionContext() {
		VALIDATOR.validate(PojoClassFactory.getPojoClass(SessionContext.class));
	}
	
	@Test
	public void coverTransactionStatus() {
		VALIDATOR.validate(PojoClassFactory.getPojoClass(TransactionStatus.class));
	}
	
	@Test
	public void coverValidationErrors() {
		VALIDATOR.validate(PojoClassFactory.getPojoClass(ValidationErrors.class));
	}
	
	@Test
	public void coverVerifyCustomerPanDetailsRequestMessage() {
		VALIDATOR.validate(PojoClassFactory.getPojoClass(VerifyCustomerPanDetailsRequestMessage.class));
	}
	
	@Test
	public void coverVerifyCustomerPanDetailsResponseMessage() {
		VALIDATOR.validate(PojoClassFactory.getPojoClass(VerifyCustomerPanDetailsResponseMesssage.class));
	}
	
	@Test
	public void coverNameRequest() {
		VALIDATOR.validate(PojoClassFactory.getPojoClass(NameRequest.class));
	}
	
	@Test
	public void coverNameResult() {
		VALIDATOR.validate(PojoClassFactory.getPojoClass(NameResult.class));
	}
	
	@Test
	public void coverPosidexAddress() {
		VALIDATOR.validate(PojoClassFactory.getPojoClass(com.airtelbank.validation.model.posidex.customer.Address.class));
	}
	
	@Test
	public void coverPosidexContact() {
		VALIDATOR.validate(PojoClassFactory.getPojoClass(com.airtelbank.validation.model.posidex.customer.Contact.class));
	}
	
	@Test
	public void coverPosidexCustomer() {
		VALIDATOR.validate(PojoClassFactory.getPojoClass(com.airtelbank.validation.model.posidex.customer.Customer.class));
	}
	
	@Test
	public void coverPosidexCustomerRequest() {
		VALIDATOR.validate(PojoClassFactory.getPojoClass(com.airtelbank.validation.model.posidex.customer.CustomerRequest.class));
	}
	
	@Test
	public void coverPosidexCustomerResponse() {
		VALIDATOR.validate(PojoClassFactory.getPojoClass(com.airtelbank.validation.model.posidex.customer.CustomerResponse.class));
	}
	
	@Test
	public void coverPosidexCustomerResult() {
		VALIDATOR.validate(PojoClassFactory.getPojoClass(com.airtelbank.validation.model.posidex.customer.CustomerResult.class));
	}
	
	@Test
	public void coverPosidexDemographics() {
		VALIDATOR.validate(PojoClassFactory.getPojoClass(com.airtelbank.validation.model.posidex.customer.Demographics.class));
	}
	
	@Test
	public void coverPosidexDemographicsResult() {
		VALIDATOR.validate(PojoClassFactory.getPojoClass(com.airtelbank.validation.model.posidex.customer.DemographicsResult.class));
	}
	
	@Test
	public void coverPosidexEmail() {
		VALIDATOR.validate(PojoClassFactory.getPojoClass(com.airtelbank.validation.model.posidex.customer.Email.class));
	}
	
	@Test
	public void coverPosidexReCustomer() {
		VALIDATOR.validate(PojoClassFactory.getPojoClass(com.airtelbank.validation.model.posidex.customer.RECustomer.class));
	}
	
	@Test
	public void coverPosidexReCustomerResults() {
		VALIDATOR.validate(PojoClassFactory.getPojoClass(com.airtelbank.validation.model.posidex.customer.RECustomerResults.class));
	}
	
	@Test
	public void coverPosidexReResults() {
		VALIDATOR.validate(PojoClassFactory.getPojoClass(com.airtelbank.validation.model.posidex.customer.REResult.class));
	}
	
	@Test
	public void coverPosidexResultAddress() {
		VALIDATOR.validate(PojoClassFactory.getPojoClass(com.airtelbank.validation.model.posidex.customer.ResultAddress.class));
	}
	
	@Test
	public void coverPosidexResultSearch() {
		VALIDATOR.validate(PojoClassFactory.getPojoClass(com.airtelbank.validation.model.posidex.customer.ResultSearch.class));
	}
	
	@Test
	public void coverAadhaarVerify() {
		VALIDATOR.validate(PojoClassFactory.getPojoClass(AadhaarVerify.class));
	}
	
	@Test
	public void coverBlackout() {
		VALIDATOR.validate(PojoClassFactory.getPojoClass(Blackout.class));
	}
	
	@Test
	public void coverErrorCodeMapper() {
		VALIDATOR.validate(PojoClassFactory.getPojoClass(ErrorCodeMapper.class));
	}
	
	@Test
	public void coverIdentities() {
		VALIDATOR.validate(PojoClassFactory.getPojoClass(Identities.class));
	}
	
	@Test
	public void coverPinCode() {
		VALIDATOR.validate(PojoClassFactory.getPojoClass(PinCode.class));
	}
	
	@Test
	public void coverPinCodeMasterCBS() {
		VALIDATOR.validate(PojoClassFactory.getPojoClass(PincodeMasterCBS.class));
	}
	
	@Test
	public void coverPosidexCacheCustomerDetails() {
		VALIDATOR.validate(PojoClassFactory.getPojoClass(PosidexCacheCustomerDetails.class));
	}
	
	@Test
	public void coverPosidexRules() {
		VALIDATOR.validate(PojoClassFactory.getPojoClass(PosidexRules.class));
	}
	
	@Test
	public void coverBlacklistEntityResponse() {
		VALIDATOR.validate(PojoClassFactory.getPojoClass(BlacklistEntityResponse.class));
    }
 
    @Test
	public void coverSmsType() {
		VALIDATOR.validate(PojoClassFactory.getPojoClass(CommunicationType.class));
	}
	
	@Test
	public void coverCommunicationData() {
		VALIDATOR.validate(PojoClassFactory.getPojoClass(CommunicationData.class));
	}
	
	@Test
	public void coverSmsData() {
		VALIDATOR.validate(PojoClassFactory.getPojoClass(SmsData.class));
	}
	
	@Test
	public void coverSMSResponse() {
		VALIDATOR.validate(PojoClassFactory.getPojoClass(SMSResponse.class));
	}
	
	@Test
	public void coverSMSTemplate() {
		VALIDATOR.validate(PojoClassFactory.getPojoClass(SMSTemplate.class));
	}
	
}
